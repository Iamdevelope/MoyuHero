package com.goldhuman.util;

import java.io.PrintStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public final class Idcard
{
  private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
  public static final int[] w;
  public static final Map<Integer, String> provinces;

  public static String to18(String paramString)
    throws ParseException
  {
    switch (paramString.length())
    {
    case 15:
      String str = paramString.substring(0, 6) + "19" + paramString.substring(6);
      paramString = str + makeISOMod(str);
      break;
    case 18:
      verifyISOMod(paramString);
      break;
    default:
      throw new RuntimeException("invalid length : " + paramString);
    }
    verifyAddress(paramString);
    verifyBirthday(paramString);
    return paramString;
  }

  public static boolean isFemale(String paramString)
  {
    return (getSerial(paramString) & 0x1) == 0;
  }

  public static int getSerial(String paramString)
  {
    return Integer.valueOf(paramString.substring(14, 17)).intValue();
  }

  public static int getYear(String paramString)
  {
    return Integer.valueOf(paramString.substring(6, 10)).intValue();
  }

  public static int getMonth(String paramString)
  {
    return Integer.valueOf(paramString.substring(10, 12)).intValue();
  }

  public static int getDay(String paramString)
  {
    return Integer.valueOf(paramString.substring(12, 14)).intValue();
  }

  public static String getBirthday(String paramString)
  {
    return paramString.substring(6, 14);
  }

  public static int getProvince(String paramString)
  {
    return Integer.valueOf(paramString.substring(0, 2)).intValue();
  }

  public static int getAge(String paramString)
  {
    return getAge(getYear(paramString), getMonth(paramString), getDay(paramString));
  }

  public static int getAge(int paramInt1, int paramInt2, int paramInt3)
  {
    Calendar localCalendar = Calendar.getInstance();
    int i = localCalendar.get(1) - paramInt1;
    int j = 1 + localCalendar.get(2) - paramInt2;
    if (j < 0)
      return i - 1;
    if (j > 0)
      return i;
    int k = localCalendar.get(5) - paramInt3;
    if (k < 0)
      return i - 1;
    return i;
  }

  public static boolean isLeapYear(int paramInt)
  {
    return (paramInt % 400 == 0) || ((paramInt % 4 == 0) && (paramInt % 100 != 0));
  }

  public static int dayOfMonth(int paramInt1, int paramInt2)
  {
    switch (paramInt2)
    {
    case 4:
    case 6:
    case 9:
    case 11:
      return 30;
    case 2:
      return isLeapYear(paramInt1) ? 29 : 28;
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    }
    return 31;
  }

  public static int sumISOMod(String paramString)
  {
    int i = 0;
    int j = paramString.length() - 1;
    int k = paramString.charAt(j);
    if ((k == 120) || (k == 88))
      i += 10;
    else
      j++;
    for (int m = 0; m < j; m++)
      i += w[m] * (paramString.charAt(m) - '0');
    return i;
  }

  public static char makeISOMod(String paramString)
  {
    int i = sumISOMod(paramString) % 11;
    switch (i)
    {
    case 0:
      return '1';
    case 1:
      return '0';
    case 2:
      return 'x';
    }
    return Character.forDigit(12 - i, 10);
  }

  public static void verifyISOMod(String paramString)
  {
    int i = sumISOMod(paramString);
    if (i % 11 != 1)
      throw new RuntimeException("invalid isomod11-2 : " + paramString);
  }

  public static void verifyBirthday(String paramString)
    throws ParseException
  {
    sdf.parse(getBirthday(paramString));
    int i = getAge(paramString);
    if ((i < 0) || (i > 150))
      throw new RuntimeException("age out of range [0, 100] : " + paramString);
  }

  public static void verifyAddress(String paramString)
  {
    int i = getProvince(paramString);
    if (provinces.get(Integer.valueOf(i)) == null)
      throw new RuntimeException("invalid province : " + paramString);
  }

  public static void test(int paramInt, String paramString1, String paramString2)
  {
    try
    {
      String str = to18(paramString1);
      if ((paramString2 != null) && (str.equals(paramString2)))
        return;
      System.out.println("test failed! i=" + paramInt + " idcard=" + paramString1 + " want=" + paramString2 + " result=" + str);
    }
    catch (Exception localException)
    {
      if (paramString2 == null)
        return;
      System.out.println("test failed! i=" + paramInt + " idcard=" + paramString1 + " want=" + paramString2 + " exp=" + localException);
    }
  }

  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    for (int i = 0; i < paramArrayOfString.length; i++)
    {
      Random localRandom = new Random(System.currentTimeMillis());
      String str = null;
      int k = localRandom.nextInt() % provinces.size();
      Object localObject = provinces.keySet().iterator();
      while (((Iterator)localObject).hasNext())
      {
        Integer localInteger = (Integer)((Iterator)localObject).next();
        str = localInteger.toString();
        k--;
        if (k < 0)
          break;
      }
      localObject = to18(str + "0101" + paramArrayOfString[i] + "010");
      System.out.println((String)localObject + " age=" + getAge((String)localObject));
    }
    String[] arrayOfString = { "352202760110425", "35220219760110425x", "440524800101001", "440524198001010013", "440524188001010014", "440524188001010014", "11010519491231002x", "11010519491231002x", "11010519491231002X", "11010519491231002X", "35220219760110425X", "35220219760110425X", "35220219760110425x", "35220219760110425x", "352202760229425", "352202197602294251", "352202761310425", null, "352202761100425", null, "352202770229425", null, "4405248001011", null, "993202760110425", null };
    for (int j = 0; j < arrayOfString.length; j += 2)
      test(j, arrayOfString[j], arrayOfString[(j + 1)]);
  }

  static
  {
    sdf.setLenient(false);
    w = new int[] { 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1 };
    provinces = new HashMap();
    provinces.put(Integer.valueOf(11), "北京市");
    provinces.put(Integer.valueOf(12), "天津市");
    provinces.put(Integer.valueOf(13), "河北省");
    provinces.put(Integer.valueOf(14), "山西省");
    provinces.put(Integer.valueOf(15), "内蒙古自治区");
    provinces.put(Integer.valueOf(21), "辽宁省");
    provinces.put(Integer.valueOf(22), "吉林省");
    provinces.put(Integer.valueOf(23), "黑龙江省");
    provinces.put(Integer.valueOf(31), "上海市");
    provinces.put(Integer.valueOf(32), "江苏省");
    provinces.put(Integer.valueOf(33), "浙江省");
    provinces.put(Integer.valueOf(34), "安徽省");
    provinces.put(Integer.valueOf(35), "福建省");
    provinces.put(Integer.valueOf(36), "江西省");
    provinces.put(Integer.valueOf(37), "山东省");
    provinces.put(Integer.valueOf(41), "河南省");
    provinces.put(Integer.valueOf(42), "湖北省");
    provinces.put(Integer.valueOf(43), "湖南省");
    provinces.put(Integer.valueOf(44), "广东省");
    provinces.put(Integer.valueOf(45), "广西壮族自治区");
    provinces.put(Integer.valueOf(46), "海南省");
    provinces.put(Integer.valueOf(50), "重庆市");
    provinces.put(Integer.valueOf(51), "四川省");
    provinces.put(Integer.valueOf(52), "贵州省");
    provinces.put(Integer.valueOf(53), "云南省");
    provinces.put(Integer.valueOf(54), "西藏自治区");
    provinces.put(Integer.valueOf(61), "陕西省");
    provinces.put(Integer.valueOf(62), "甘肃省");
    provinces.put(Integer.valueOf(63), "青海省");
    provinces.put(Integer.valueOf(64), "宁夏回族自治区");
    provinces.put(Integer.valueOf(65), "新疆维吾尔自治区");
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.util.Idcard
 * JD-Core Version:    0.6.2
 */