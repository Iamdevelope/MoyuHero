package com.goldhuman.Common.Marshal;

public abstract interface Marshal
{
  public abstract OctetsStream marshal(OctetsStream paramOctetsStream);

  public abstract OctetsStream unmarshal(OctetsStream paramOctetsStream)
    throws MarshalException;
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Marshal.Marshal
 * JD-Core Version:    0.6.2
 */