package com.goldhuman.Common;

public abstract class Runnable
  implements java.lang.Runnable
{
  private int priority;

  public Runnable()
  {
    this.priority = 0;
  }

  public Runnable(int paramInt)
  {
    this.priority = paramInt;
  }

  public int GetPriority()
  {
    return this.priority;
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Runnable
 * JD-Core Version:    0.6.2
 */