package com.goldhuman.Common.Security;

import com.goldhuman.Common.Octets;

public final class ARCFourSecurity extends Security
{
  private byte[] perm = new byte[256];
  private byte index1;
  private byte index2;

  public Object clone()
  {
    try
    {
      ARCFourSecurity localARCFourSecurity = (ARCFourSecurity)super.clone();
      localARCFourSecurity.perm = new byte[256];
      System.arraycopy(this.perm, 0, localARCFourSecurity.perm, 0, 256);
      return localARCFourSecurity;
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public void SetParameter(Octets paramOctets)
  {
    int i = paramOctets.size();
    int j = 0;
    for (int k = 0; k < 256; k++)
      this.perm[k] = ((byte)k);
    for (k = 0; k < 256; k++)
    {
      j = (byte)(j + (this.perm[k] + paramOctets.getByte(k % i)));
      int m = this.perm[k];
      this.perm[k] = this.perm[(j & 0xFF)];
      this.perm[(j & 0xFF)] = m;
    }
    this.index1 = (this.index2 = 0);
  }

  public Octets Update(Octets paramOctets)
  {
    int i = paramOctets.size();
    for (int j = 0; j < i; j++)
    {
      ARCFourSecurity tmp22_21 = this;
      this.index2 = ((byte)(this.index2 + this.perm[((tmp22_21.index1 = (byte)(tmp22_21.index1 + 1)) & 0xFF)]));
      int k = this.perm[(this.index1 & 0xFF)];
      this.perm[(this.index1 & 0xFF)] = this.perm[(this.index2 & 0xFF)];
      this.perm[(this.index2 & 0xFF)] = k;
      int m = (byte)(this.perm[(this.index1 & 0xFF)] + this.perm[(this.index2 & 0xFF)]);
      paramOctets.setByte(j, (byte)(paramOctets.getByte(j) ^ this.perm[(m & 0xFF)]));
    }
    return paramOctets;
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Security.ARCFourSecurity
 * JD-Core Version:    0.6.2
 */