package com.goldhuman.Common.Security;

import com.goldhuman.Common.Octets;

public final class HMAC_MD5Hash extends Security
{
  private Octets k_opad = new Octets(64);
  private MD5Hash md5hash = new MD5Hash();

  public Object clone()
  {
    try
    {
      HMAC_MD5Hash localHMAC_MD5Hash = (HMAC_MD5Hash)super.clone();
      (localHMAC_MD5Hash.k_opad = (Octets)this.k_opad.clone()).reserve(64);
      localHMAC_MD5Hash.md5hash = ((MD5Hash)this.md5hash.clone());
      return localHMAC_MD5Hash;
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public void SetParameter(Octets paramOctets)
  {
    Octets localOctets1 = new Octets(64);
    int i = paramOctets.size();
    if (i > 64)
    {
      Octets localOctets2 = MD5Hash.Digest(paramOctets);
      localOctets1.replace(localOctets2);
      this.k_opad.replace(localOctets2);
      i = localOctets2.size();
    }
    else
    {
      localOctets1.replace(paramOctets);
      this.k_opad.replace(paramOctets);
    }
    for (int j = 0; j < i; j++)
    {
      localOctets1.setByte(j, (byte)(localOctets1.getByte(j) ^ 0x36));
      this.k_opad.setByte(j, (byte)(this.k_opad.getByte(j) ^ 0x5C));
    }
    while (j < 64)
    {
      localOctets1.setByte(j, (byte)54);
      this.k_opad.setByte(j, (byte)92);
      j++;
    }
    localOctets1.resize(64);
    this.k_opad.resize(64);
    this.md5hash.Update(localOctets1);
  }

  public Octets Update(Octets paramOctets)
  {
    this.md5hash.Update(paramOctets);
    return paramOctets;
  }

  public Octets Final(Octets paramOctets)
  {
    this.md5hash.Final(paramOctets);
    MD5Hash localMD5Hash = new MD5Hash();
    localMD5Hash.Update(this.k_opad);
    localMD5Hash.Update(paramOctets);
    return localMD5Hash.Final(paramOctets);
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Security.HMAC_MD5Hash
 * JD-Core Version:    0.6.2
 */