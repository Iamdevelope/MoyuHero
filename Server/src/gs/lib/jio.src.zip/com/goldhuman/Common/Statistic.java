package com.goldhuman.Common;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public final class Statistic
{
  public int m_max;
  public int m_min;
  public int m_cur;
  public int m_cnt;
  public int m_sum;
  private static HashMap m_map = new HashMap();

  private Statistic()
  {
    reset();
  }

  public void reset()
  {
    this.m_cur = 0;
    this.m_cnt = 0;
    this.m_sum = 0;
    this.m_max = 0;
    this.m_min = 0;
  }

  public void update(int paramInt)
  {
    this.m_cur = paramInt;
    this.m_cnt += 1;
    this.m_sum += paramInt;
    this.m_max = (paramInt > this.m_max ? paramInt : this.m_max);
    this.m_min = (paramInt < this.m_min ? paramInt : 0 == this.m_min ? paramInt : this.m_min);
  }

  public static Statistic GetInstance(String paramString)
  {
    synchronized (m_map)
    {
      Statistic localStatistic = (Statistic)m_map.get(paramString);
      if (localStatistic != null)
        return localStatistic;
      localStatistic = new Statistic();
      m_map.put(paramString, localStatistic);
      return localStatistic;
    }
  }

  public static boolean enumdefault(String paramString, Statistic paramStatistic)
  {
    System.out.println(paramString);
    System.out.print(" MAX: " + paramStatistic.m_max);
    System.out.print(" MIN: " + paramStatistic.m_min);
    System.out.print(" CUR: " + paramStatistic.m_cur);
    System.out.print(" CNT: " + paramStatistic.m_cnt);
    System.out.println(" SUM: " + paramStatistic.m_sum);
    return true;
  }

  public static void enumerate(StatCallBack paramStatCallBack)
  {
    synchronized (m_map)
    {
      Iterator localIterator = m_map.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        String str = (String)localEntry.getKey();
        Statistic localStatistic = (Statistic)localEntry.getValue();
        paramStatCallBack.enumerate(str, localStatistic);
      }
    }
  }

  public static synchronized void resetall()
  {
    synchronized (m_map)
    {
      Iterator localIterator = m_map.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Statistic localStatistic = (Statistic)((Map.Entry)localIterator.next()).getValue();
        localStatistic.reset();
      }
    }
  }

  public static abstract interface StatCallBack
  {
    public abstract boolean enumerate(String paramString, Statistic paramStatistic);
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Statistic
 * JD-Core Version:    0.6.2
 */