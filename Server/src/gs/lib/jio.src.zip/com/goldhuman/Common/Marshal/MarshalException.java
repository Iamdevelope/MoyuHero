package com.goldhuman.Common.Marshal;

public final class MarshalException extends Exception
{
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Marshal.MarshalException
 * JD-Core Version:    0.6.2
 */