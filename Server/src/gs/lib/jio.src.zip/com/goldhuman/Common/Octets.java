package com.goldhuman.Common;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

public class Octets
  implements Cloneable, Comparable
{
  private static final int DEFAULT_SIZE = 128;
  private static String DEFAULT_CHARSET = "ISO-8859-1";
  private byte[] buffer = null;
  private int count = 0;

  private byte[] roundup(int paramInt)
  {
    int i = 16;
    while (paramInt > i)
      i <<= 1;
    return new byte[i];
  }

  public void reserve(int paramInt)
  {
    if (this.buffer == null)
    {
      this.buffer = roundup(paramInt);
    }
    else if (paramInt > this.buffer.length)
    {
      byte[] arrayOfByte = roundup(paramInt);
      System.arraycopy(this.buffer, 0, arrayOfByte, 0, this.count);
      this.buffer = arrayOfByte;
    }
  }

  public Octets replace(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    reserve(paramInt2);
    System.arraycopy(paramArrayOfByte, paramInt1, this.buffer, 0, paramInt2);
    this.count = paramInt2;
    return this;
  }

  public Octets replace(Octets paramOctets, int paramInt1, int paramInt2)
  {
    return replace(paramOctets.buffer, paramInt1, paramInt2);
  }

  public Octets replace(byte[] paramArrayOfByte)
  {
    return replace(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public Octets replace(Octets paramOctets)
  {
    return replace(paramOctets.buffer, 0, paramOctets.count);
  }

  public Octets()
  {
    reserve(128);
  }

  public Octets(int paramInt)
  {
    reserve(paramInt);
  }

  public Octets(Octets paramOctets)
  {
    replace(paramOctets);
  }

  public Octets(byte[] paramArrayOfByte)
  {
    replace(paramArrayOfByte);
  }

  private Octets(byte[] paramArrayOfByte, int paramInt)
  {
    this.buffer = paramArrayOfByte;
    this.count = paramInt;
  }

  public static Octets wrap(byte[] paramArrayOfByte, int paramInt)
  {
    return new Octets(paramArrayOfByte, paramInt);
  }

  public static Octets wrap(byte[] paramArrayOfByte)
  {
    return wrap(paramArrayOfByte, paramArrayOfByte.length);
  }

  public static Octets wrap(String paramString1, String paramString2)
  {
    try
    {
      return wrap(paramString1.getBytes(paramString2));
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      throw new RuntimeException(localUnsupportedEncodingException);
    }
  }

  public Octets(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    replace(paramArrayOfByte, paramInt1, paramInt2);
  }

  public Octets(Octets paramOctets, int paramInt1, int paramInt2)
  {
    replace(paramOctets, paramInt1, paramInt2);
  }

  public Octets resize(int paramInt)
  {
    reserve(paramInt);
    this.count = paramInt;
    return this;
  }

  public int size()
  {
    return this.count;
  }

  public int capacity()
  {
    return this.buffer.length;
  }

  public Octets clear()
  {
    this.count = 0;
    return this;
  }

  public Octets swap(Octets paramOctets)
  {
    int i = this.count;
    this.count = paramOctets.count;
    paramOctets.count = i;
    byte[] arrayOfByte = paramOctets.buffer;
    paramOctets.buffer = this.buffer;
    this.buffer = arrayOfByte;
    return this;
  }

  public Octets push_back(byte paramByte)
  {
    reserve(this.count + 1);
    this.buffer[(this.count++)] = paramByte;
    return this;
  }

  public Octets erase(int paramInt1, int paramInt2)
  {
    System.arraycopy(this.buffer, paramInt2, this.buffer, paramInt1, this.count - paramInt2);
    this.count -= paramInt2 - paramInt1;
    return this;
  }

  public Octets insert(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    reserve(this.count + paramInt3);
    System.arraycopy(this.buffer, paramInt1, this.buffer, paramInt1 + paramInt3, this.count - paramInt1);
    System.arraycopy(paramArrayOfByte, paramInt2, this.buffer, paramInt1, paramInt3);
    this.count += paramInt3;
    return this;
  }

  public Octets insert(int paramInt1, Octets paramOctets, int paramInt2, int paramInt3)
  {
    return insert(paramInt1, paramOctets.buffer, paramInt2, paramInt3);
  }

  public Octets insert(int paramInt, byte[] paramArrayOfByte)
  {
    return insert(paramInt, paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public Octets insert(int paramInt, Octets paramOctets)
  {
    return insert(paramInt, paramOctets.buffer, 0, paramOctets.size());
  }

  public Object clone()
  {
    return new Octets(this);
  }

  public int compareTo(Octets paramOctets)
  {
    int i = this.count - paramOctets.count;
    if (i != 0)
      return i;
    byte[] arrayOfByte1 = this.buffer;
    byte[] arrayOfByte2 = paramOctets.buffer;
    for (int j = 0; j < this.count; j++)
    {
      int k = arrayOfByte1[j] - arrayOfByte2[j];
      if (k != 0)
        return k;
    }
    return 0;
  }

  public int compareTo(Object paramObject)
  {
    return compareTo((Octets)paramObject);
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    return compareTo(paramObject) == 0;
  }

  public int hashCode()
  {
    if (this.buffer == null)
      return 0;
    int i = 1;
    for (int j = 0; j < this.count; j++)
      i = 31 * i + this.buffer[j];
    return i;
  }

  public String toString()
  {
    return "octets.size=" + this.count;
  }

  public byte[] getBytes()
  {
    byte[] arrayOfByte = new byte[this.count];
    System.arraycopy(this.buffer, 0, arrayOfByte, 0, this.count);
    return arrayOfByte;
  }

  public byte[] array()
  {
    return this.buffer;
  }

  public byte getByte(int paramInt)
  {
    return this.buffer[paramInt];
  }

  public void setByte(int paramInt, byte paramByte)
  {
    this.buffer[paramInt] = paramByte;
  }

  public ByteBuffer getByteBuffer(int paramInt1, int paramInt2)
  {
    return ByteBuffer.wrap(this.buffer, paramInt1, paramInt2);
  }

  public ByteBuffer getByteBuffer(int paramInt)
  {
    return ByteBuffer.wrap(this.buffer, paramInt, this.count - paramInt);
  }

  public ByteBuffer getByteBuffer()
  {
    return ByteBuffer.wrap(this.buffer, 0, this.count);
  }

  public String getString()
    throws Exception
  {
    return new String(this.buffer, 0, this.count, DEFAULT_CHARSET);
  }

  public String getString(String paramString)
  {
    try
    {
      return new String(this.buffer, 0, this.count, paramString);
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      throw new RuntimeException(localUnsupportedEncodingException);
    }
  }

  public void setString(String paramString)
    throws Exception
  {
    this.buffer = paramString.getBytes(DEFAULT_CHARSET);
    this.count = this.buffer.length;
  }

  public void dump()
  {
    for (int i = 0; i < size(); i++)
      System.out.printf("%02x ", new Object[] { Byte.valueOf(this.buffer[i]) });
    System.out.printf("\n", new Object[0]);
  }

  public static void setDefaultCharset(String paramString)
  {
    DEFAULT_CHARSET = paramString;
  }

  public static void main(String[] paramArrayOfString)
  {
    Octets localOctets1 = new Octets("ddd".getBytes());
    localOctets1.replace("abc".getBytes());
    localOctets1.replace("defghijklmn".getBytes());
    try
    {
      localOctets1.replace("0123456789".getBytes("UTF-8"));
    }
    catch (Exception localException)
    {
    }
    localOctets1.insert(localOctets1.size(), "abc".getBytes());
    localOctets1.insert(localOctets1.size(), "def".getBytes());
    System.out.println(new String(localOctets1.getBytes()));
    System.out.println("size = " + localOctets1.size());
    Octets localOctets2 = new Octets("ABC".getBytes());
    localOctets1.insert(localOctets1.size(), localOctets2);
    System.out.println(new String(localOctets1.getBytes()));
    Octets localOctets3 = (Octets)localOctets1.clone();
    System.out.println(new String(localOctets3.getBytes()));
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Octets
 * JD-Core Version:    0.6.2
 */