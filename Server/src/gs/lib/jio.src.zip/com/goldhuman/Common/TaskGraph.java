package com.goldhuman.Common;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;

public class TaskGraph extends Runnable
  implements TaskState
{
  private HashSet<StatefulRunnable> runners = new HashSet();
  private HashSet<TaskNode> nodes = new HashSet();
  private boolean restart = false;
  private boolean stopping = false;
  private TaskNode root = null;
  TaskContext context = null;
  Object locker = new Object();

  public void run()
  {
    if (!IsFinish())
    {
      ThreadPool.AddTask(this);
      this.stopping = false;
    }
    else
    {
      Iterator localIterator;
      if (this.restart)
      {
        localIterator = this.nodes.iterator();
        while (localIterator.hasNext())
          ((TaskNode)localIterator.next()).SetInit();
        this.root.TurnRunning();
        this.restart = false;
        this.stopping = false;
      }
      else
      {
        localIterator = this.runners.iterator();
        while (localIterator.hasNext())
          ((StatefulRunnable)localIterator.next()).Destroy();
        localIterator = this.nodes.iterator();
        while (localIterator.hasNext())
          ((TaskNode)localIterator.next()).Destroy();
      }
    }
  }

  protected TaskGraph(TaskContext paramTaskContext)
  {
    this.context = paramTaskContext;
  }

  public boolean IsFinish()
  {
    synchronized (this.locker)
    {
      Iterator localIterator = this.nodes.iterator();
      while (localIterator.hasNext())
        if (!((TaskNode)localIterator.next()).IsFinish())
          return false;
    }
    return true;
  }

  public boolean IsStopping()
  {
    return this.stopping;
  }

  public void Start(TaskNode paramTaskNode)
  {
    this.root = paramTaskNode;
    this.root.TurnRunning();
  }

  public void Restart(TaskNode paramTaskNode)
  {
    this.root = paramTaskNode;
    this.restart = true;
    Stop();
  }

  public void Stop()
  {
    synchronized (this.locker)
    {
      Iterator localIterator = this.nodes.iterator();
      while (localIterator.hasNext())
        ((TaskNode)localIterator.next()).TurnStopping();
      this.stopping = true;
      ThreadPool.AddTask(this);
    }
  }

  public TaskNode CreateNode(StatefulRunnable paramStatefulRunnable)
  {
    TaskNode localTaskNode = new TaskNode(paramStatefulRunnable, this);
    paramStatefulRunnable.graph = this;
    this.runners.add(paramStatefulRunnable);
    this.nodes.add(localTaskNode);
    return localTaskNode;
  }

  public TaskNode CreateStopNode()
  {
    TaskNode localTaskNode = new TaskNode(null, this);
    this.nodes.add(localTaskNode);
    return localTaskNode;
  }

  public TaskContext GetContext()
  {
    return this.context;
  }

  public void RunnableChangeState(TaskNode paramTaskNode)
  {
    if (paramTaskNode.GetState() == 4)
      Stop();
  }

  protected class TaskNode extends Runnable
    implements Observer
  {
    private HashSet<TaskNode> prev = new HashSet();
    private HashSet<TaskNode> next = new HashSet();
    private StatefulRunnable task = null;
    private TaskGraph graph = null;
    private int state;

    void TurnStopping()
    {
      if (this.state == 1)
        this.state = 2;
      else if (this.state == 0)
        this.state = 3;
    }

    void SetInit()
    {
      this.state = 0;
      if (this.task != null)
        this.task.Init();
    }

    void TurnRunning()
    {
      if ((this.state == 0) || (this.state >= 4))
      {
        ThreadPool.AddTask(this);
        this.state = 1;
      }
    }

    void Destroy()
    {
    }

    TaskNode(StatefulRunnable paramTaskGraph, TaskGraph arg3)
    {
      this.task = paramTaskGraph;
      Object localObject;
      this.graph = localObject;
      this.state = 0;
      if (this.task != null)
      {
        this.task.Init();
        this.task.addObserver(this);
      }
    }

    public void update(Observable paramObservable, Object paramObject)
    {
      synchronized (this.graph.locker)
      {
        if (this.graph.IsStopping())
          return;
        this.state = this.task.GetState();
      }
      this.graph.RunnableChangeState(this);
      if (this.state >= 4)
        synchronized (this.graph.locker)
        {
          Iterator localIterator = this.next.iterator();
          while (localIterator.hasNext())
            ((TaskNode)localIterator.next()).TurnRunning();
        }
      else if (this.state == 1)
        ThreadPool.AddTask(this);
    }

    boolean IsFinish()
    {
      return (this.state >= 4) || (this.state == 3);
    }

    public int GetState()
    {
      return this.state;
    }

    public void run()
    {
      if (this.state == 2)
      {
        this.state = 3;
        return;
      }
      if (this.state != 1)
        return;
      synchronized (this.graph.locker)
      {
        int i = 1;
        Iterator localIterator = this.prev.iterator();
        while (localIterator.hasNext())
          if (!((TaskNode)localIterator.next()).IsFinish())
            i = 0;
        if (i == 0)
        {
          this.state = 0;
          return;
        }
      }
      if (this.task != null)
      {
        this.task.Run();
        if ((this.state == 1) || (this.state == 2))
          ThreadPool.AddTask(this);
      }
      else
      {
        this.state = 3;
        this.graph.Stop();
      }
    }

    public void AddChild(TaskNode paramTaskNode)
    {
      synchronized (this.graph.locker)
      {
        this.next.add(paramTaskNode);
        paramTaskNode.prev.add(this);
      }
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.TaskGraph
 * JD-Core Version:    0.6.2
 */