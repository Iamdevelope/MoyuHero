package com.goldhuman.Common;

import java.io.PrintStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;

public class Cache
{
  public static int default_size = 100;
  public static int default_timeout = 10;
  private Map cache = new HashMap();
  private LRU lru = new LRU(null);
  private int nitem;
  private int maxsize = default_size;
  private int time_stamp = 0;
  private int life_time = default_timeout;
  private int[] key_pos;
  private static Map all_caches = Collections.synchronizedMap(new HashMap());

  private void add(Item paramItem)
  {
    paramItem.life_time = this.life_time;
    if (this.cache.size() == this.maxsize)
      remove(this.lru.last());
    this.cache.put(paramItem, paramItem);
    this.lru.add(paramItem);
  }

  private void remove(Item paramItem)
  {
    paramItem.revoke();
    this.cache.remove(paramItem);
    this.lru.remove(paramItem);
  }

  private boolean contains(Item paramItem)
  {
    return this.cache.containsKey(paramItem);
  }

  private Cache(int paramInt, int[] paramArrayOfInt)
  {
    this.nitem = paramInt;
    this.key_pos = paramArrayOfInt;
  }

  private Cache(int paramInt1, int[] paramArrayOfInt, int paramInt2, int paramInt3)
  {
    this.nitem = paramInt1;
    this.key_pos = paramArrayOfInt;
    this.maxsize = paramInt2;
    this.life_time = paramInt3;
  }

  public static Cache Create(String paramString, int paramInt, int[] paramArrayOfInt)
  {
    Cache localCache = new Cache(paramInt, paramArrayOfInt);
    all_caches.put(paramString, localCache);
    return localCache;
  }

  public static Cache Create(String paramString, int paramInt1, int[] paramArrayOfInt, int paramInt2, int paramInt3)
  {
    Cache localCache = new Cache(paramInt1, paramArrayOfInt, paramInt2, paramInt3);
    all_caches.put(paramString, localCache);
    return localCache;
  }

  public static Cache getInstance(String paramString)
  {
    return (Cache)all_caches.get(paramString);
  }

  public synchronized int size()
  {
    return this.cache.size();
  }

  public synchronized Item find(Item paramItem)
  {
    Item localItem = (Item)this.cache.get(paramItem);
    if (localItem == null)
      return null;
    this.lru.access(localItem);
    return (Item)localItem.clone();
  }

  public Item newItem()
  {
    return new Item(this, null);
  }

  public static void main(String[] paramArrayOfString)
  {
    Cache localCache = Create("c1", 2, new int[] { 0 });
    try
    {
      localCache.newItem().set(0, new Integer(1)).set(1, new String("a")).commit();
      localCache.newItem().set(0, new Integer(2)).set(1, new String("b")).commit();
      localCache.newItem().set(0, new Integer(3)).set(1, new String("c")).commit();
      Item localItem1 = localCache.find(localCache.newItem().set(0, new Integer(1)));
      localCache.newItem().set(0, new Integer(4)).set(1, new String("d")).commit();
      Item localItem2 = localCache.find(localCache.newItem().set(0, new Integer(3)));
      localCache.newItem().set(0, new Integer(5)).set(1, new String("e")).commit();
      System.out.println("Size = " + localCache.size());
      Thread.sleep(1000L);
      System.out.println("Size = " + localCache.size());
      Thread.sleep(1000L);
      System.out.println("Size = " + localCache.size());
      Thread.sleep(1000L);
      System.out.println("Size = " + localCache.size());
      Thread.sleep(1000L);
      System.out.println("Size = " + localCache.size());
      Thread.sleep(1000L);
      System.out.println("Size = " + localCache.size());
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  static
  {
    new Timer(true).schedule(new TimerTask()
    {
      public void run()
      {
        synchronized (Cache.all_caches)
        {
          Iterator localIterator1 = Cache.all_caches.entrySet().iterator();
          while (localIterator1.hasNext())
          {
            Cache localCache = (Cache)((Map.Entry)localIterator1.next()).getValue();
            synchronized (localCache)
            {
              Iterator localIterator2 = localCache.cache.entrySet().iterator();
              while (localIterator2.hasNext())
              {
                Cache.Item localItem = (Cache.Item)((Map.Entry)localIterator2.next()).getValue();
                if (Cache.Item.access$306(localItem) <= 0)
                {
                  localItem.revoke();
                  localIterator2.remove();
                  localCache.lru.remove(localItem);
                }
              }
            }
          }
        }
      }
    }
    , 0L, 1000L);
  }

  public class Item
    implements Cloneable
  {
    private static final int CLEAN = 0;
    private static final int DIRTY = 1;
    private Item origin;
    private int time_stamp;
    private int life_time;
    private int access_count = 0;
    private int status;
    private Object[] items;
    private Cache owner;

    protected Object clone()
    {
      try
      {
        Item localItem = (Item)super.clone();
        localItem.items = new Object[this.items.length];
        System.arraycopy(this.items, 0, localItem.items, 0, this.items.length);
        localItem.origin = this;
        return localItem;
      }
      catch (Exception localException)
      {
      }
      return null;
    }

    private Item(Cache arg2)
    {
      Cache localCache;
      this.owner = localCache;
      this.items = new Object[localCache.nitem];
      this.status = 1;
      this.time_stamp = Cache.access$808(localCache);
    }

    private void revoke()
    {
    }

    public boolean equals(Object paramObject)
    {
      for (int i = 0; i < this.owner.key_pos.length; i++)
        if (!this.items[Cache.this.key_pos[i]].equals(((Item)paramObject).items[Cache.this.key_pos[i]]))
          return false;
      return true;
    }

    public int hashCode()
    {
      int i = 0;
      for (int j = 0; j < this.owner.key_pos.length; j++)
        i = i + this.items[Cache.this.key_pos[j]].hashCode() * 17 >> 4;
      return i;
    }

    public void commit()
      throws RuntimeException
    {
      if (this.status == 0)
        return;
      synchronized (this.owner)
      {
        if (this.origin == null)
        {
          if (this.owner.contains(this))
            throw new RuntimeException("Duplicate Key");
        }
        else
        {
          if (this.origin.time_stamp != this.time_stamp)
            throw new RuntimeException("TimeStamp Collision");
          if ((hashCode() != this.origin.hashCode()) || (!equals(this.origin)))
            this.owner.remove(this.origin);
          this.time_stamp = (this.origin.time_stamp = Cache.access$808(this.owner));
          this.origin = null;
        }
        this.status = 0;
        this.owner.add(this);
      }
    }

    public Item set(int paramInt, Object paramObject)
    {
      this.items[paramInt] = paramObject;
      this.status = 1;
      return this;
    }

    public Object get(int paramInt)
    {
      return this.items[paramInt];
    }
  }

  private class LRU
  {
    private TreeMap lru = new TreeMap();

    private LRU()
    {
    }

    public void add(Cache.Item paramItem)
    {
      Integer localInteger = new Integer(paramItem.access_count);
      LinkedList localLinkedList = (LinkedList)this.lru.get(localInteger);
      if (localLinkedList == null)
        this.lru.put(localInteger, localLinkedList = new LinkedList());
      localLinkedList.addLast(paramItem);
    }

    public void remove(Cache.Item paramItem)
    {
      Integer localInteger = new Integer(paramItem.access_count);
      LinkedList localLinkedList = (LinkedList)this.lru.get(localInteger);
      localLinkedList.remove(paramItem);
      if (localLinkedList.size() == 0)
        this.lru.remove(localInteger);
    }

    public Cache.Item last()
    {
      return (Cache.Item)((LinkedList)this.lru.get(this.lru.firstKey())).getFirst();
    }

    public void access(Cache.Item paramItem)
    {
      remove(paramItem);
      Cache.Item.access$608(paramItem);
      add(paramItem);
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Cache
 * JD-Core Version:    0.6.2
 */