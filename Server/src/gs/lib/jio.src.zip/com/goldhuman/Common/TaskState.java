package com.goldhuman.Common;

public abstract interface TaskState
{
  public static final int INIT = 0;
  public static final int RUNNING = 1;
  public static final int STOPPING = 2;
  public static final int STOPPED = 3;
  public static final int FAIL = 4;
  public static final int SUCCEED = 5;
  public static final int USERDEFINE = 6;
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.TaskState
 * JD-Core Version:    0.6.2
 */