package com.goldhuman.Common.Security;

import com.goldhuman.Common.Octets;
import java.net.URL;
import java.util.HashMap;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public abstract class Security
  implements Cloneable
{
  private static final HashMap map = new HashMap();
  private int type;

  public void SetParameter(Octets paramOctets)
  {
  }

  public void GetParameter(Octets paramOctets)
  {
  }

  public Octets Update(Octets paramOctets)
  {
    return paramOctets;
  }

  public Octets Final(Octets paramOctets)
  {
    return paramOctets;
  }

  public Object clone()
  {
    try
    {
      return super.clone();
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public static Security Create(String paramString)
  {
    Security localSecurity = (Security)map.get(paramString.toUpperCase());
    return localSecurity == null ? new NullSecurity() : (Security)localSecurity.clone();
  }

  public static Security Create(int paramInt)
  {
    return Create(Integer.toString(paramInt));
  }

  static
  {
    try
    {
      SAXParser localSAXParser = SAXParserFactory.newInstance().newSAXParser();
      localSAXParser.parse(Security.class.getResource("/config.xml").openStream(), new DefaultHandler()
      {
        private boolean parsing = false;

        public void startElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3, Attributes paramAnonymousAttributes)
        {
          if (paramAnonymousString3.compareTo("security") == 0)
            this.parsing = true;
          if ((this.parsing) && (paramAnonymousString3.compareTo("entity") == 0))
            try
            {
              String str1 = paramAnonymousAttributes.getValue("class").trim();
              String str2 = paramAnonymousAttributes.getValue("name").trim().toUpperCase();
              String str3 = paramAnonymousAttributes.getValue("type").trim();
              Security localSecurity = (Security)Class.forName(str1).newInstance();
              localSecurity.type = Integer.parseInt(str3);
              Security.map.put(str2, localSecurity);
              Security.map.put(str3, localSecurity);
            }
            catch (Exception localException)
            {
              localException.printStackTrace();
            }
        }

        public void endElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3)
        {
          if (paramAnonymousString3.compareTo("security") == 0)
            this.parsing = false;
        }
      });
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Security.Security
 * JD-Core Version:    0.6.2
 */