package com.goldhuman.Common;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Observable;
import java.util.Observer;

public class TimerTask
  implements Observer
{
  private static TimerTask instance = new TimerTask();
  private LinkedList tasks = new LinkedList();
  private long elapse = 0L;

  private TimerTask()
  {
    TimerObserver.GetInstance().addObserver(this);
  }

  public synchronized void update(Observable paramObservable, Object paramObject)
  {
    this.elapse += 1L;
    Iterator localIterator = this.tasks.iterator();
    while (localIterator.hasNext())
    {
      TaskPair localTaskPair = (TaskPair)localIterator.next();
      if (localTaskPair.waitsecds > this.elapse)
        break;
      ThreadPool.AddTask(localTaskPair.task);
      localIterator.remove();
    }
  }

  public synchronized void AddTask(Runnable paramRunnable, long paramLong)
  {
    this.tasks.add(new TaskPair(paramLong + this.elapse, paramRunnable));
  }

  public static void AddTimerTask(Runnable paramRunnable, long paramLong)
  {
    instance.AddTask(paramRunnable, paramLong);
  }

  private class TaskPair
  {
    long waitsecds;
    Runnable task;

    TaskPair(long arg2, Runnable arg4)
    {
      this.waitsecds = ???;
      Object localObject;
      this.task = localObject;
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.TimerTask
 * JD-Core Version:    0.6.2
 */