package com.goldhuman.Common.Security;

public final class NullSecurity extends Security
{
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Security.NullSecurity
 * JD-Core Version:    0.6.2
 */