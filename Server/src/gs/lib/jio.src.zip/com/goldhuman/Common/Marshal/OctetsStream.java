package com.goldhuman.Common.Marshal;

import com.goldhuman.Common.Octets;

public class OctetsStream extends Octets
{
  private static final int MAXSPARE = 16384;
  private int pos = 0;
  private int tranpos = 0;

  public OctetsStream()
  {
  }

  public OctetsStream(int paramInt)
  {
    super(paramInt);
  }

  public OctetsStream(Octets paramOctets)
  {
    super(paramOctets);
  }

  public static OctetsStream wrap(Octets paramOctets)
  {
    OctetsStream localOctetsStream = new OctetsStream();
    localOctetsStream.swap(paramOctets);
    return localOctetsStream;
  }

  public Object clone()
  {
    OctetsStream localOctetsStream = (OctetsStream)super.clone();
    localOctetsStream.pos = this.pos;
    localOctetsStream.tranpos = this.pos;
    return localOctetsStream;
  }

  public final boolean eos()
  {
    return this.pos == size();
  }

  public final int position(int paramInt)
  {
    this.pos = paramInt;
    return this.pos;
  }

  public final int position()
  {
    return this.pos;
  }

  public final int remain()
  {
    return size() - this.pos;
  }

  public OctetsStream marshal(byte paramByte)
  {
    push_back(paramByte);
    return this;
  }

  public OctetsStream marshal(boolean paramBoolean)
  {
    push_back((byte)(paramBoolean ? 1 : 0));
    return this;
  }

  public OctetsStream marshal(short paramShort)
  {
    return marshal((byte)(paramShort >> 8)).marshal((byte)paramShort);
  }

  public OctetsStream marshal(char paramChar)
  {
    return marshal((byte)(paramChar >> '\b')).marshal((byte)paramChar);
  }

  public OctetsStream marshal(int paramInt)
  {
    return marshal((byte)(paramInt >> 24)).marshal((byte)(paramInt >> 16)).marshal((byte)(paramInt >> 8)).marshal((byte)paramInt);
  }

  public OctetsStream marshal(long paramLong)
  {
    return marshal((byte)(int)(paramLong >> 56)).marshal((byte)(int)(paramLong >> 48)).marshal((byte)(int)(paramLong >> 40)).marshal((byte)(int)(paramLong >> 32)).marshal((byte)(int)(paramLong >> 24)).marshal((byte)(int)(paramLong >> 16)).marshal((byte)(int)(paramLong >> 8)).marshal((byte)(int)paramLong);
  }

  public OctetsStream marshal(float paramFloat)
  {
    return marshal(Float.floatToRawIntBits(paramFloat));
  }

  public OctetsStream marshal(double paramDouble)
  {
    return marshal(Double.doubleToRawLongBits(paramDouble));
  }

  public OctetsStream compact_uint32(int paramInt)
  {
    if (paramInt < 64)
      return marshal((byte)paramInt);
    if (paramInt < 16384)
      return marshal((short)(paramInt | 0x8000));
    if (paramInt < 536870912)
      return marshal(paramInt | 0xC0000000);
    marshal((byte)-32);
    return marshal(paramInt);
  }

  public OctetsStream compact_sint32(int paramInt)
  {
    if (paramInt >= 0)
    {
      if (paramInt < 64)
        return marshal((byte)paramInt);
      if (paramInt < 8192)
        return marshal((short)(paramInt | 0x8000));
      if (paramInt < 268435456)
        return marshal(paramInt | 0xC0000000);
      marshal((byte)-32);
      return marshal(paramInt);
    }
    if (-paramInt > 0)
    {
      paramInt = -paramInt;
      if (paramInt < 64)
        return marshal((byte)(paramInt | 0x40));
      if (paramInt < 8192)
        return marshal((short)(paramInt | 0xA000));
      if (paramInt < 268435456)
        return marshal(paramInt | 0xD0000000);
      marshal((byte)-16);
      return marshal(paramInt);
    }
    marshal((byte)-16);
    return marshal(paramInt);
  }

  public OctetsStream marshal(Marshal paramMarshal)
  {
    return paramMarshal.marshal(this);
  }

  public OctetsStream marshal(Octets paramOctets)
  {
    compact_uint32(paramOctets.size());
    insert(size(), paramOctets);
    return this;
  }

  public OctetsStream marshal(String paramString)
  {
    return marshal(paramString, null);
  }

  public OctetsStream marshal(String paramString1, String paramString2)
  {
    try
    {
      marshal(paramString2 == null ? paramString1.getBytes() : paramString1.getBytes(paramString2));
    }
    catch (Exception localException)
    {
      throw new RuntimeException(localException);
    }
    return this;
  }

  public OctetsStream Begin()
  {
    this.tranpos = this.pos;
    return this;
  }

  public OctetsStream Rollback()
  {
    this.pos = this.tranpos;
    return this;
  }

  public OctetsStream Commit()
  {
    if (this.pos >= 16384)
    {
      erase(0, this.pos);
      this.pos = 0;
    }
    return this;
  }

  public byte unmarshal_byte()
    throws MarshalException
  {
    if (this.pos + 1 > size())
      throw new MarshalException();
    return getByte(this.pos++);
  }

  public boolean unmarshal_boolean()
    throws MarshalException
  {
    return unmarshal_byte() == 1;
  }

  public short unmarshal_short()
    throws MarshalException
  {
    if (this.pos + 2 > size())
      throw new MarshalException();
    int i = getByte(this.pos++);
    int j = getByte(this.pos++);
    return (short)(i << 8 | j & 0xFF);
  }

  public char unmarshal_char()
    throws MarshalException
  {
    if (this.pos + 2 > size())
      throw new MarshalException();
    int i = getByte(this.pos++);
    int j = getByte(this.pos++);
    return (char)(i << 8 | j & 0xFF);
  }

  public int unmarshal_int()
    throws MarshalException
  {
    if (this.pos + 4 > size())
      throw new MarshalException();
    int i = getByte(this.pos++);
    int j = getByte(this.pos++);
    int k = getByte(this.pos++);
    int m = getByte(this.pos++);
    return (i & 0xFF) << 24 | (j & 0xFF) << 16 | (k & 0xFF) << 8 | (m & 0xFF) << 0;
  }

  public long unmarshal_long()
    throws MarshalException
  {
    if (this.pos + 8 > size())
      throw new MarshalException();
    int i = getByte(this.pos++);
    int j = getByte(this.pos++);
    int k = getByte(this.pos++);
    int m = getByte(this.pos++);
    int n = getByte(this.pos++);
    int i1 = getByte(this.pos++);
    int i2 = getByte(this.pos++);
    int i3 = getByte(this.pos++);
    return (i & 0xFF) << 56 | (j & 0xFF) << 48 | (k & 0xFF) << 40 | (m & 0xFF) << 32 | (n & 0xFF) << 24 | (i1 & 0xFF) << 16 | (i2 & 0xFF) << 8 | (i3 & 0xFF) << 0;
  }

  public float unmarshal_float()
    throws MarshalException
  {
    return Float.intBitsToFloat(unmarshal_int());
  }

  public double unmarshal_double()
    throws MarshalException
  {
    return Double.longBitsToDouble(unmarshal_long());
  }

  public int uncompact_uint32()
    throws MarshalException
  {
    if (this.pos == size())
      throw new MarshalException();
    switch (getByte(this.pos) & 0xE0)
    {
    case 224:
      unmarshal_byte();
      return unmarshal_int();
    case 192:
      return unmarshal_int() & 0x3FFFFFFF;
    case 128:
    case 160:
      return unmarshal_short() & 0x7FFF;
    }
    return unmarshal_byte();
  }

  public int uncompact_sint32()
    throws MarshalException
  {
    if (this.pos == size())
      throw new MarshalException();
    switch (getByte(this.pos) & 0xF0)
    {
    case 240:
      unmarshal_byte();
      return -unmarshal_int();
    case 224:
      unmarshal_byte();
      return unmarshal_int();
    case 208:
      return -(unmarshal_int() & 0x2FFFFFFF);
    case 192:
      return unmarshal_int() & 0x3FFFFFFF;
    case 160:
    case 176:
      return -(unmarshal_short() & 0x5FFF);
    case 128:
    case 144:
      return unmarshal_short() & 0x7FFF;
    case 64:
    case 80:
    case 96:
    case 112:
      return -(unmarshal_byte() & 0xFFFFFFBF);
    }
    return unmarshal_byte();
  }

  public Octets unmarshal_Octets()
    throws MarshalException
  {
    int i = uncompact_uint32();
    if (this.pos + i > size())
      throw new MarshalException();
    Octets localOctets = new Octets(this, this.pos, i);
    this.pos += i;
    return localOctets;
  }

  public byte[] unmarshal_bytes()
    throws MarshalException
  {
    int i = uncompact_uint32();
    if (this.pos + i > size())
      throw new MarshalException();
    byte[] arrayOfByte = new byte[i];
    System.arraycopy(array(), this.pos, arrayOfByte, 0, i);
    this.pos += i;
    return arrayOfByte;
  }

  public OctetsStream marshal(byte[] paramArrayOfByte)
  {
    compact_uint32(paramArrayOfByte.length);
    insert(size(), paramArrayOfByte);
    return this;
  }

  public OctetsStream unmarshal(Octets paramOctets)
    throws MarshalException
  {
    int i = uncompact_uint32();
    if (this.pos + i > size())
      throw new MarshalException();
    paramOctets.replace(this, this.pos, i);
    this.pos += i;
    return this;
  }

  public String unmarshal_String()
    throws MarshalException
  {
    return unmarshal_String(null);
  }

  public String unmarshal_String(String paramString)
    throws MarshalException
  {
    try
    {
      int i = uncompact_uint32();
      if (this.pos + i > size())
        throw new MarshalException();
      int j = this.pos;
      this.pos += i;
      return paramString == null ? new String(array(), j, i) : new String(array(), j, i, paramString);
    }
    catch (Exception localException)
    {
    }
    throw new MarshalException();
  }

  public OctetsStream unmarshal(Marshal paramMarshal)
    throws MarshalException
  {
    return paramMarshal.unmarshal(this);
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Marshal.OctetsStream
 * JD-Core Version:    0.6.2
 */