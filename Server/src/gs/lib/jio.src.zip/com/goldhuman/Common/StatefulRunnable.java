package com.goldhuman.Common;

import java.util.Observable;
import java.util.Observer;

public abstract class StatefulRunnable extends Observable
  implements Observer, TaskState
{
  TaskGraph graph = null;

  TaskContext GetContext()
  {
    return this.graph.context;
  }

  public void Destroy()
  {
  }

  public void Init()
  {
  }

  public void update(Observable paramObservable, Object paramObject)
  {
  }

  public abstract int GetState();

  public abstract void Run();
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.StatefulRunnable
 * JD-Core Version:    0.6.2
 */