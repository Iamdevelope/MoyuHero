package com.goldhuman.Common;

import java.io.PrintStream;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ThreadPool
  implements java.lang.Runnable
{
  private static SortedMap tasks = Collections.synchronizedSortedMap(new TreeMap());
  private static SortedMap count = new TreeMap();
  private static int task_count = 0;
  private static Object task_count_locker = new Object();
  private static long time_lastadd = 0L;
  private static long task_total = 0L;
  private static LinkedList remove = new LinkedList();
  public Integer priority;

  private ThreadPool(Integer paramInteger)
  {
    this.priority = paramInteger;
    synchronized (count)
    {
      Integer localInteger = (Integer)count.get(paramInteger);
      count.put(paramInteger, new Integer(localInteger == null ? 1 : localInteger.intValue() + 1));
    }
  }

  public void run()
  {
    while (true)
      try
      {
        Runnable localRunnable = null;
        LinkedList localLinkedList = (LinkedList)tasks.get(this.priority);
        synchronized (localLinkedList)
        {
          if (localLinkedList.isEmpty())
          {
            localLinkedList.wait();
            continue;
          }
          localRunnable = (Runnable)localLinkedList.removeLast();
          synchronized (task_count_locker)
          {
            task_count -= 1;
          }
        }
        localRunnable.run();
        synchronized (remove)
        {
          if ((!remove.isEmpty()) && (this.priority.equals(remove.getLast())))
          {
            remove.removeLast();
            return;
          }
        }
      }
      catch (Exception localException)
      {
      }
  }

  public static void AddTask(Runnable paramRunnable)
  {
    LinkedList localLinkedList = (LinkedList)tasks.get(new Integer(paramRunnable.GetPriority()));
    if (localLinkedList == null)
    {
      System.out.println("ThreadPool thread LinkedList == null: no Match priority(" + paramRunnable.GetPriority() + ")");
      return;
    }
    synchronized (localLinkedList)
    {
      localLinkedList.addFirst(paramRunnable);
      synchronized (task_count_locker)
      {
        task_count += 1;
        task_total += 1L;
      }
      time_lastadd = System.currentTimeMillis();
      localLinkedList.notify();
    }
  }

  public static int TaskCount()
  {
    synchronized (task_count_locker)
    {
      return task_count;
    }
  }

  public static long TaskTotal()
  {
    synchronized (task_count_locker)
    {
      return task_total;
    }
  }

  public static long TimeLastAdd()
  {
    return time_lastadd;
  }

  public static void AddThread(int paramInt)
  {
    new Thread(new ThreadPool(new Integer(paramInt))).start();
    if (tasks.get(Integer.valueOf(paramInt)) == null)
      tasks.put(Integer.valueOf(paramInt), new LinkedList());
  }

  public static int ThreadCount()
  {
    int i = 0;
    synchronized (count)
    {
      Iterator localIterator = count.entrySet().iterator();
      while (localIterator.hasNext())
        i += ((Integer)((Map.Entry)localIterator.next()).getValue()).intValue();
    }
    return i;
  }

  public static int ThreadCount(int paramInt)
  {
    int i = 0;
    synchronized (count)
    {
      Integer localInteger = (Integer)count.get(new Integer(paramInt));
      if (localInteger != null)
        i = localInteger.intValue();
    }
    return i;
  }

  public static void RemoveThread(int paramInt)
  {
    Integer localInteger1 = new Integer(paramInt);
    synchronized (count)
    {
      Integer localInteger2 = (Integer)count.get(localInteger1);
      if (localInteger2 != null)
      {
        int i = localInteger2.intValue() - 1;
        if (i > 0)
        {
          count.put(localInteger1, new Integer(i));
          synchronized (remove)
          {
            remove.addFirst(localInteger1);
          }
        }
        else
        {
          count.remove(localInteger1);
        }
      }
    }
  }

  static
  {
    try
    {
      String str = Conf.GetInstance().find("ThreadPool", "config");
      if (str != null)
      {
        Matcher localMatcher = Pattern.compile("\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*\\)").matcher(str);
        while (localMatcher.find())
        {
          int i = Integer.parseInt(localMatcher.group(1));
          for (int j = Integer.parseInt(localMatcher.group(2)); j > 0; j--)
            AddThread(i);
        }
      }
    }
    catch (Exception localException)
    {
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.ThreadPool
 * JD-Core Version:    0.6.2
 */