package com.goldhuman.Common;

public class TaskContext
{
  public Object locker = new Object();
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.TaskContext
 * JD-Core Version:    0.6.2
 */