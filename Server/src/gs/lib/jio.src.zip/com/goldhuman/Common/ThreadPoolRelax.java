package com.goldhuman.Common;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ThreadPoolRelax
  implements java.lang.Runnable
{
  private static SortedMap tasks = new TreeMap();
  private static SortedMap count = new TreeMap();
  private static int task_count = 0;
  private static long time_lastadd = 0L;
  private static LinkedList remove = new LinkedList();
  public Integer priority;

  private ThreadPoolRelax(Integer paramInteger)
  {
    this.priority = paramInteger;
    synchronized (count)
    {
      Integer localInteger = (Integer)count.get(paramInteger);
      count.put(paramInteger, new Integer(localInteger == null ? 1 : localInteger.intValue() + 1));
    }
  }

  private Runnable GetTask(SortedMap paramSortedMap)
  {
    Iterator localIterator = paramSortedMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      LinkedList localLinkedList = (LinkedList)((Map.Entry)localIterator.next()).getValue();
      if (!localLinkedList.isEmpty())
        return (Runnable)localLinkedList.removeLast();
    }
    return null;
  }

  public void run()
  {
    while (true)
      try
      {
        Runnable localRunnable = null;
        synchronized (tasks)
        {
          if (task_count == 0)
          {
            tasks.wait();
            continue;
          }
          if ((localRunnable = GetTask(tasks.tailMap(this.priority))) == null)
            localRunnable = GetTask(tasks);
          task_count -= 1;
        }
        localRunnable.run();
        synchronized (remove)
        {
          if ((!remove.isEmpty()) && (this.priority.equals(remove.getLast())))
          {
            remove.removeLast();
            return;
          }
        }
      }
      catch (Exception localException)
      {
      }
  }

  public static void AddTask(Runnable paramRunnable)
  {
    synchronized (tasks)
    {
      Integer localInteger = new Integer(paramRunnable.GetPriority());
      LinkedList localLinkedList = (LinkedList)tasks.get(localInteger);
      if (localLinkedList == null)
        tasks.put(localInteger, localLinkedList = new LinkedList());
      localLinkedList.addFirst(paramRunnable);
      task_count += 1;
      time_lastadd = System.currentTimeMillis();
      tasks.notify();
    }
  }

  public static int TaskCount()
  {
    return task_count;
  }

  public static long TimeLastAdd()
  {
    return time_lastadd;
  }

  public static void AddThread(int paramInt)
  {
    new Thread(new ThreadPoolRelax(new Integer(paramInt))).start();
  }

  public static int ThreadCount()
  {
    int i = 0;
    synchronized (count)
    {
      Iterator localIterator = count.entrySet().iterator();
      while (localIterator.hasNext())
        i += ((Integer)((Map.Entry)localIterator.next()).getValue()).intValue();
    }
    return i;
  }

  public static int ThreadCount(int paramInt)
  {
    int i = 0;
    synchronized (count)
    {
      Integer localInteger = (Integer)count.get(new Integer(paramInt));
      if (localInteger != null)
        i = localInteger.intValue();
    }
    return i;
  }

  public static void RemoveThread(int paramInt)
  {
    Integer localInteger1 = new Integer(paramInt);
    synchronized (count)
    {
      Integer localInteger2 = (Integer)count.get(localInteger1);
      if (localInteger2 != null)
      {
        int i = localInteger2.intValue() - 1;
        if (i > 0)
        {
          count.put(localInteger1, new Integer(i));
          synchronized (remove)
          {
            remove.addFirst(localInteger1);
          }
        }
        else
        {
          count.remove(localInteger1);
        }
      }
    }
  }

  static
  {
    try
    {
      String str = Conf.GetInstance().find("ThreadPool", "config");
      if (str != null)
      {
        Matcher localMatcher = Pattern.compile("\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*\\)").matcher(str);
        while (localMatcher.find())
        {
          int i = Integer.parseInt(localMatcher.group(1));
          for (int j = Integer.parseInt(localMatcher.group(2)); j > 0; j--)
            AddThread(i);
        }
      }
    }
    catch (Exception localException)
    {
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.ThreadPoolRelax
 * JD-Core Version:    0.6.2
 */