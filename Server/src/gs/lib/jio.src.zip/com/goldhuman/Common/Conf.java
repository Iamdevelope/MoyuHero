package com.goldhuman.Common;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;

public final class Conf
{
  private static Conf instance = new Conf();
  private File conffile;
  private long mtime;
  private HashMap confhash = new HashMap();
  private String charset = new String("GBK");

  private void parse(BufferedReader paramBufferedReader)
    throws IOException
  {
    Object localObject = null;
    HashMap localHashMap = new HashMap();
    this.confhash.clear();
    while (paramBufferedReader.ready())
    {
      String str = paramBufferedReader.readLine().trim();
      if (str.length() != 0)
      {
        int i = str.charAt(0);
        if ((i != 35) && (i != 59))
          if (i == 91)
          {
            str = str.substring(1, str.indexOf(93)).trim();
            if (localObject != null)
            {
              this.confhash.put(localObject, localHashMap);
              localHashMap = new HashMap();
            }
            localObject = str;
          }
          else
          {
            String[] arrayOfString = str.split("=", 2);
            localHashMap.put(arrayOfString[0].trim(), arrayOfString[1].trim());
          }
      }
    }
    if (localObject != null)
      this.confhash.put(localObject, localHashMap);
  }

  private void reload()
  {
    try
    {
      for (long l = this.conffile.lastModified(); l != this.mtime; l = this.conffile.lastModified())
      {
        this.mtime = l;
        URL localURL = this.conffile.toURI().toURL();
        BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localURL.openStream(), this.charset));
        parse(localBufferedReader);
        localBufferedReader.close();
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public synchronized String find(String paramString1, String paramString2)
  {
    HashMap localHashMap = (HashMap)this.confhash.get(paramString1);
    if (localHashMap != null)
    {
      String str = (String)localHashMap.get(paramString2);
      if (str != null)
        return new String(str);
    }
    return new String();
  }

  public synchronized void put(String paramString1, String paramString2, String paramString3)
  {
    HashMap localHashMap = (HashMap)this.confhash.get(paramString1);
    if (null == localHashMap)
    {
      localHashMap = new HashMap();
      this.confhash.put(paramString1, localHashMap);
    }
    localHashMap.put(paramString2, paramString3);
  }

  public static synchronized Conf GetInstance(String paramString1, String paramString2)
  {
    if (paramString2 != null)
      instance.charset = paramString2;
    File localFile = new File(paramString1);
    if (localFile.isFile())
    {
      instance.conffile = localFile;
      instance.reload();
    }
    return instance;
  }

  public static synchronized Conf GetInstance(URL paramURL, String paramString)
  {
    try
    {
      if (paramString != null)
        instance.charset = paramString;
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(paramURL.openStream(), instance.charset));
      instance.parse(localBufferedReader);
      localBufferedReader.close();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return instance;
  }

  public static synchronized Conf GetInstance()
  {
    return instance;
  }

  public static void main(String[] paramArrayOfString)
  {
    GetInstance(paramArrayOfString[0], null);
    System.out.println(GetInstance().find(paramArrayOfString[1], paramArrayOfString[2]));
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Conf
 * JD-Core Version:    0.6.2
 */