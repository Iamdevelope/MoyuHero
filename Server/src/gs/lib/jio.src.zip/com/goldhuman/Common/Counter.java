package com.goldhuman.Common;

import java.lang.management.ManagementFactory;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;
import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.DynamicMBean;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.ReflectionException;

public class Counter
  implements DynamicMBean
{
  private ConcurrentMap<String, AtomicLong> mapcount = new ConcurrentHashMap();

  public void increment(String paramString)
  {
    AtomicLong localAtomicLong1 = new AtomicLong(1L);
    AtomicLong localAtomicLong2 = (AtomicLong)this.mapcount.putIfAbsent(paramString, localAtomicLong1);
    if (null != localAtomicLong2)
      localAtomicLong2.incrementAndGet();
  }

  public void increment(String paramString, int paramInt)
  {
    AtomicLong localAtomicLong1 = new AtomicLong(paramInt);
    AtomicLong localAtomicLong2 = (AtomicLong)this.mapcount.putIfAbsent(paramString, localAtomicLong1);
    if (null != localAtomicLong2)
      localAtomicLong2.addAndGet(paramInt);
  }

  public AtomicLong get(String paramString)
  {
    return (AtomicLong)this.mapcount.get(paramString);
  }

  public void set(String paramString, long paramLong)
  {
    AtomicLong localAtomicLong1 = new AtomicLong(paramLong);
    AtomicLong localAtomicLong2 = (AtomicLong)this.mapcount.putIfAbsent(paramString, localAtomicLong1);
    if (null != localAtomicLong2)
      localAtomicLong2.set(paramLong);
  }

  public Object getAttribute(String paramString)
  {
    return this.mapcount.get(paramString);
  }

  public AttributeList getAttributes(String[] paramArrayOfString)
  {
    AttributeList localAttributeList = new AttributeList();
    for (int i = 0; i < paramArrayOfString.length; i++)
    {
      Object localObject = getAttribute(paramArrayOfString[i]);
      localAttributeList.add(new Attribute(paramArrayOfString[i], localObject));
    }
    return localAttributeList;
  }

  public void setAttribute(Attribute paramAttribute)
  {
  }

  public AttributeList setAttributes(AttributeList paramAttributeList)
  {
    return null;
  }

  public Object invoke(String paramString, Object[] paramArrayOfObject, String[] paramArrayOfString)
    throws MBeanException, ReflectionException
  {
    return null;
  }

  public MBeanInfo getMBeanInfo()
  {
    MBeanAttributeInfo[] arrayOfMBeanAttributeInfo = new MBeanAttributeInfo[this.mapcount.size()];
    int i = 0;
    Iterator localIterator = this.mapcount.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      arrayOfMBeanAttributeInfo[(i++)] = new MBeanAttributeInfo(str, str.getClass().getName(), str, true, false, false);
    }
    return new MBeanInfo(getClass().getName(), "Counter", arrayOfMBeanAttributeInfo, null, null, null);
  }

  public Counter(String paramString)
  {
    try
    {
      MBeanServer localMBeanServer = ManagementFactory.getPlatformMBeanServer();
      localMBeanServer.registerMBean(this, new ObjectName("Counter:type=" + paramString));
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.Common.Counter
 * JD-Core Version:    0.6.2
 */