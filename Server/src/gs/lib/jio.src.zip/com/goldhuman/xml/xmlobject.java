package com.goldhuman.xml;

import org.xml.sax.Attributes;

public abstract class xmlobject
{
  public String name;
  public String content = "";
  public xmlobject parent;
  public xmlobject[] children = new xmlobject[0];

  protected void setchild(xmlobject paramxmlobject)
  {
    xmlobject[] arrayOfxmlobject = new xmlobject[this.children.length + 1];
    System.arraycopy(this.children, 0, arrayOfxmlobject, 0, this.children.length);
    arrayOfxmlobject[this.children.length] = paramxmlobject;
    this.children = arrayOfxmlobject;
  }

  protected void setparent(xmlobject paramxmlobject)
  {
    this.parent = paramxmlobject;
  }

  protected void setattr(Attributes paramAttributes)
  {
    this.name = paramAttributes.getValue("name");
  }

  public abstract void action();
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.xml.xmlobject
 * JD-Core Version:    0.6.2
 */