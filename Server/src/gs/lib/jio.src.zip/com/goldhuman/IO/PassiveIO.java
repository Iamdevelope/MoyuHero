package com.goldhuman.IO;

import com.goldhuman.Common.Conf;
import com.goldhuman.IO.NetIO.NetSession;
import com.goldhuman.IO.NetIO.StreamIO;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

public class PassiveIO extends PollIO
{
  boolean closing;
  NetSession assoc_session;

  protected int UpdateEvent()
  {
    return this.closing ? -1 : 16;
  }

  protected void PollAccept()
  {
    try
    {
      SocketChannel localSocketChannel = ((ServerSocketChannel)this.channel).accept();
      if (localSocketChannel != null)
      {
        NetSession localNetSession = (NetSession)this.assoc_session.clone();
        localNetSession.setPeerAddress(localSocketChannel.socket().getRemoteSocketAddress());
        register(new StreamIO(localSocketChannel, localNetSession));
      }
    }
    catch (Exception localException)
    {
    }
  }

  private PassiveIO(ServerSocketChannel paramServerSocketChannel, NetSession paramNetSession)
  {
    super(paramServerSocketChannel);
    (this.assoc_session = paramNetSession).LoadConfig();
    this.closing = false;
  }

  public boolean Close()
  {
    return this.closing = 1;
  }

  public static PassiveIO Open(NetSession paramNetSession)
  {
    Conf localConf = Conf.GetInstance();
    String str1 = paramNetSession.Identification();
    String str2 = localConf.find(str1, "type");
    if (str2.compareToIgnoreCase("tcp") == 0)
      try
      {
        ServerSocketChannel localServerSocketChannel = ServerSocketChannel.open();
        InetSocketAddress localInetSocketAddress = null;
        try
        {
          localInetSocketAddress = new InetSocketAddress(InetAddress.getByName(localConf.find(str1, "address")), Integer.parseInt(localConf.find(str1, "port")));
        }
        catch (Exception localException2)
        {
        }
        ServerSocket localServerSocket = localServerSocketChannel.socket();
        try
        {
          localServerSocket.setReuseAddress(true);
          localServerSocket.setReceiveBufferSize(Integer.parseInt(localConf.find(str1, "so_rcvbuf")));
        }
        catch (Exception localException3)
        {
        }
        localServerSocket.bind(paramNetSession.OnCheckAddress(localInetSocketAddress), Integer.parseInt(localConf.find(str1, "listen_backlog")));
        return (PassiveIO)register(new PassiveIO(localServerSocketChannel, paramNetSession));
      }
      catch (Exception localException1)
      {
        localException1.printStackTrace();
      }
    return null;
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.PassiveIO
 * JD-Core Version:    0.6.2
 */