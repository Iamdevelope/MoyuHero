package com.goldhuman.IO.NetIO;

import com.goldhuman.IO.PollIO;
import java.nio.channels.SelectableChannel;

public abstract class NetIO extends PollIO
{
  protected NetSession session;

  protected NetIO(SelectableChannel paramSelectableChannel, NetSession paramNetSession)
  {
    super(paramSelectableChannel);
    this.session = paramNetSession;
  }

  protected boolean Close()
  {
    this.session.OnClose();
    return true;
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.NetIO.NetIO
 * JD-Core Version:    0.6.2
 */