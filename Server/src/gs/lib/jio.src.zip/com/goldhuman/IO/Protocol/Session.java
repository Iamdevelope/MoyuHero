package com.goldhuman.IO.Protocol;

import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.Octets;
import com.goldhuman.Common.Runnable;
import com.goldhuman.Common.TimerObserver.WatchDog;
import com.goldhuman.IO.NetIO.NetSession;
import java.net.SocketAddress;
import java.util.LinkedList;

public final class Session extends NetSession
{
  protected Manager manager;
  protected static boolean need_wakeup = false;
  private State state;
  private Stream is;
  private LinkedList os;
  private TimerObserver.WatchDog timer;
  private long timestamp;
  private LinkedList private_tasks;

  public void AddTask(Runnable paramRunnable)
  {
    synchronized (this.private_tasks)
    {
      if (this.private_tasks.isEmpty())
      {
        this.private_tasks.addFirst(paramRunnable);
        new Thread(new Runnable()
        {
          public void run()
          {
            while (true)
            {
              Runnable localRunnable = null;
              synchronized (Session.this.private_tasks)
              {
                localRunnable = (Runnable)Session.this.private_tasks.getLast();
              }
              localRunnable.run();
              synchronized (Session.this.private_tasks)
              {
                Session.this.private_tasks.removeLast();
                if (Session.this.private_tasks.isEmpty())
                  return;
              }
            }
          }
        }).start();
      }
      else
      {
        this.private_tasks.addFirst(paramRunnable);
      }
      this.private_tasks.notify();
    }
  }

  public Object clone()
  {
    try
    {
      Session localSession = (Session)super.clone();
      localSession.state = new State(this.state);
      localSession.is = new Stream(this);
      localSession.os = new LinkedList();
      localSession.private_tasks = new LinkedList();
      localSession.timer = new TimerObserver.WatchDog();
      return localSession;
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public String Identification()
  {
    return this.manager.Identification();
  }

  public SocketAddress OnCheckAddress(SocketAddress paramSocketAddress)
  {
    return this.manager.OnCheckAddress(paramSocketAddress);
  }

  protected void OnOpen()
  {
    this.timer.Reset();
    this.manager.AddSession(this);
  }

  protected void OnClose()
  {
    this.manager.DelSession(this);
  }

  public void OnAbort()
  {
    this.manager.AbortSession(this);
  }

  public long getTimestamp()
  {
    return this.timestamp;
  }

  protected void OnRecv()
  {
    this.timestamp = System.currentTimeMillis();
    this.timer.Reset();
    Octets localOctets = Input();
    this.is.insert(this.is.size(), localOctets);
    localOctets.clear();
    try
    {
      Protocol localProtocol;
      while ((localProtocol = Protocol.Decode(this.is)) != null)
        Task.Dispatch(this.manager, this, localProtocol);
    }
    catch (ProtocolException localProtocolException)
    {
      Close();
    }
  }

  protected void OnSend()
  {
    if (this.state.TimePolicy(this.timer.Elapse()))
    {
      if (this.os.size() != 0)
      {
        do
        {
          OctetsStream localOctetsStream = (OctetsStream)this.os.getFirst();
          if (!Output(localOctetsStream))
            break;
          this.os.removeFirst();
        }
        while (this.os.size() != 0);
        this.timer.Reset();
      }
    }
    else
      Close();
  }

  protected boolean Send(Protocol paramProtocol)
  {
    synchronized (this)
    {
      OctetsStream localOctetsStream = new OctetsStream();
      paramProtocol.Encode(localOctetsStream);
      if (paramProtocol.SizePolicy(localOctetsStream.size()))
      {
        this.os.addLast(localOctetsStream);
        need_wakeup = true;
        return true;
      }
    }
    return false;
  }

  protected boolean StatePolicy(int paramInt)
  {
    return this.state.TypePolicy(paramInt);
  }

  protected void Close()
  {
    this.closing = true;
  }

  protected void ChangeState(String paramString)
  {
    synchronized (this)
    {
      this.state = State.Get(paramString);
    }
  }

  public Session(Manager paramManager)
  {
    this.manager = paramManager;
    this.state = this.manager.GetInitState();
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Protocol.Session
 * JD-Core Version:    0.6.2
 */