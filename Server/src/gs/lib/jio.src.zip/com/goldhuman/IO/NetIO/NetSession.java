package com.goldhuman.IO.NetIO;

import com.goldhuman.Common.Conf;
import com.goldhuman.Common.Octets;
import com.goldhuman.Common.Security.Security;
import java.net.SocketAddress;

public abstract class NetSession
  implements Cloneable
{
  private static final int DEFAULTIOBUF = 8192;
  protected Octets ibuffer = new Octets(8192);
  protected Octets obuffer = new Octets(8192);
  protected Octets isecbuf = new Octets(8192);
  Security isec = Security.Create("NULLSECURITY");
  Security osec = Security.Create("NULLSECURITY");
  protected boolean closing = false;
  protected SocketAddress peeraddress = null;

  public synchronized void setPeerAddress(SocketAddress paramSocketAddress)
  {
    this.peeraddress = paramSocketAddress;
  }

  public synchronized SocketAddress getPeerAddress()
  {
    return this.peeraddress;
  }

  protected boolean Output(Octets paramOctets)
  {
    if (paramOctets.size() + this.obuffer.size() > this.obuffer.capacity())
      return false;
    this.osec.Update(paramOctets);
    this.obuffer.insert(this.obuffer.size(), paramOctets);
    return true;
  }

  protected Octets Input()
  {
    this.isec.Update(this.ibuffer);
    this.isecbuf.insert(this.isecbuf.size(), this.ibuffer);
    this.ibuffer.clear();
    return this.isecbuf;
  }

  public void SetISecurity(String paramString, Octets paramOctets)
  {
    synchronized (this)
    {
      this.isec = Security.Create(paramString);
      this.isec.SetParameter(paramOctets);
    }
  }

  public void SetOSecurity(String paramString, Octets paramOctets)
  {
    synchronized (this)
    {
      this.osec = Security.Create(paramString);
      this.osec.SetParameter(paramOctets);
    }
  }

  public void LoadConfig()
  {
    Conf localConf = Conf.GetInstance();
    String str = Identification();
    try
    {
      this.ibuffer.reserve(Integer.parseInt(localConf.find(str, "ibuffermax")));
    }
    catch (Exception localException1)
    {
    }
    try
    {
      this.obuffer.reserve(Integer.parseInt(localConf.find(str, "obuffermax")));
    }
    catch (Exception localException2)
    {
    }
    try
    {
      SetISecurity(localConf.find(str, "isec").trim(), new Octets(localConf.find(str, "iseckey").getBytes()));
    }
    catch (Exception localException3)
    {
    }
    try
    {
      SetOSecurity(localConf.find(str, "osec").trim(), new Octets(localConf.find(str, "oseckey").getBytes()));
    }
    catch (Exception localException4)
    {
    }
  }

  protected void Close()
  {
    this.closing = true;
  }

  protected abstract void OnRecv();

  protected abstract void OnSend();

  protected abstract void OnOpen();

  protected abstract void OnClose();

  public void OnAbort()
  {
  }

  public abstract String Identification();

  public SocketAddress OnCheckAddress(SocketAddress paramSocketAddress)
  {
    return paramSocketAddress;
  }

  public Object clone()
  {
    try
    {
      NetSession localNetSession = (NetSession)super.clone();
      localNetSession.ibuffer = new Octets(this.ibuffer.capacity());
      localNetSession.obuffer = new Octets(this.obuffer.capacity());
      localNetSession.isecbuf = new Octets(this.isecbuf.capacity());
      localNetSession.isec = ((Security)this.isec.clone());
      localNetSession.osec = ((Security)this.osec.clone());
      return localNetSession;
    }
    catch (Exception localException)
    {
    }
    return null;
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.NetIO.NetSession
 * JD-Core Version:    0.6.2
 */