package com.goldhuman.IO.Protocol;

public final class ProtocolException extends Exception
{
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Protocol.ProtocolException
 * JD-Core Version:    0.6.2
 */