package com.goldhuman.IO.Protocol;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class Parser
{
  private static SAXParser sap;
  private static URL config = Parser.class.getResource("/config.xml");
  public static final String default_package = "protocol";

  public void setConfig(URL paramURL)
  {
    config = paramURL;
  }

  private static PrintStream find_file(String paramString)
  {
    String str = "protocol/" + paramString;
    File localFile = new File(str + ".java");
    if (localFile.exists())
    {
      if (!new File(str + ".class").exists())
        System.err.println("Compile " + str + ".java first...");
      return null;
    }
    System.out.println("Generate " + localFile.getName());
    try
    {
      return new PrintStream(new FileOutputStream(localFile));
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }

  private static void generate_import(PrintStream paramPrintStream)
  {
    paramPrintStream.println("package protocol;\n");
    paramPrintStream.println("import com.goldhuman.Common.*;");
    paramPrintStream.println("import com.goldhuman.Common.Marshal.*;");
    paramPrintStream.println("import com.goldhuman.Common.Security.*;");
    paramPrintStream.println("import com.goldhuman.IO.Protocol.*;");
    paramPrintStream.println("");
  }

  private static void generate_datamember(PrintStream paramPrintStream, Vector paramVector)
  {
    int i = paramVector.size();
    for (int j = 0; j < i; j++)
    {
      Variable localVariable = (Variable)paramVector.get(j);
      if (localVariable.type.endsWith("Vector"))
        paramPrintStream.println("\tpublic Rpc.Data.DataVector\t" + localVariable.name + ";");
      else
        paramPrintStream.println("\tpublic " + localVariable.type + "\t" + localVariable.name + ";");
    }
    paramPrintStream.println("");
  }

  private static void generate_marshalable(PrintStream paramPrintStream, Vector paramVector)
  {
    paramPrintStream.println("\tpublic OctetsStream marshal(OctetsStream os)");
    paramPrintStream.println("\t{");
    int i = paramVector.size();
    Variable localVariable;
    for (int j = 0; j < i; j++)
    {
      localVariable = (Variable)paramVector.get(j);
      paramPrintStream.println("\t\tos.marshal(" + localVariable.name + ");");
    }
    paramPrintStream.println("\t\treturn os;\n\t}");
    paramPrintStream.println("");
    paramPrintStream.println("\tpublic OctetsStream unmarshal(OctetsStream os) throws MarshalException");
    paramPrintStream.println("\t{");
    for (j = 0; j < i; j++)
    {
      localVariable = (Variable)paramVector.get(j);
      String str = localVariable.type;
      if ((str.compareTo("int") == 0) || (str.compareTo("short") == 0) || (str.compareTo("long") == 0) || (str.compareTo("byte") == 0) || (str.compareTo("float") == 0) || (str.compareTo("double") == 0))
        paramPrintStream.println("\t\t" + localVariable.name + " = os.unmarshal_" + str + "();");
      else
        paramPrintStream.println("\t\tos.unmarshal(" + localVariable.name + ");");
    }
    paramPrintStream.println("\t\treturn os;\n\t}");
    paramPrintStream.println("");
  }

  private static void generate_defaultconstructor(PrintStream paramPrintStream, String paramString, Vector paramVector)
  {
    paramPrintStream.println("\tpublic " + paramString + "()");
    paramPrintStream.println("\t{");
    int i = paramVector.size();
    for (int j = 0; j < i; j++)
    {
      Variable localVariable = (Variable)paramVector.get(j);
      String str1 = localVariable.type;
      String str2 = localVariable.name;
      if ((str1.compareTo("int") != 0) && (str1.compareTo("short") != 0) && (str1.compareTo("long") != 0) && (str1.compareTo("byte") != 0) && (str1.compareTo("float") != 0) && (str1.compareTo("double") != 0))
        if (localVariable.type.endsWith("Vector"))
          paramPrintStream.println("\t\t" + str2 + " = new Rpc.Data.DataVector(" + "new " + str1.replaceAll("Vector", "") + "());");
        else
          paramPrintStream.println("\t\t" + str2 + " = new " + str1 + "();");
    }
    paramPrintStream.println("\t}");
    paramPrintStream.println("");
  }

  private static void generate_cloneable(PrintStream paramPrintStream, String paramString, Vector paramVector)
  {
    paramPrintStream.println("\tpublic Object clone()");
    paramPrintStream.println("\t{");
    paramPrintStream.println("\t\ttry");
    paramPrintStream.println("\t\t{");
    paramPrintStream.println("\t\t\t" + paramString + " o = (" + paramString + ")super.clone();");
    int i = paramVector.size();
    for (int j = 0; j < i; j++)
    {
      Variable localVariable = (Variable)paramVector.get(j);
      String str1 = localVariable.type;
      String str2 = localVariable.name;
      if ((str1.compareTo("int") != 0) && (str1.compareTo("short") != 0) && (str1.compareTo("long") != 0) && (str1.compareTo("byte") != 0) && (str1.compareTo("float") != 0) && (str1.compareTo("double") != 0))
        if (localVariable.type.endsWith("Vector"))
          paramPrintStream.println("\t\t\to." + str2 + " = (Rpc.Data.DataVector)" + str2 + ".clone();");
        else
          paramPrintStream.println("\t\t\to." + str2 + " = (" + str1 + ")" + str2 + ".clone();");
    }
    paramPrintStream.println("\t\t\treturn o;");
    paramPrintStream.println("\t\t}");
    paramPrintStream.println("\t\tcatch (Exception e) { }");
    paramPrintStream.println("\t\treturn null;\n\t}");
    paramPrintStream.println("");
  }

  private static void generate_dataaccess(PrintStream paramPrintStream, Vector paramVector)
  {
    int i = paramVector.size();
    for (int j = 0; j < i; j++)
    {
      Variable localVariable = (Variable)paramVector.get(j);
      String str1 = localVariable.type;
      String str2 = localVariable.name;
      paramPrintStream.println("");
      paramPrintStream.println("\tpublic void Set" + str2 + "(" + str1 + " " + str2 + ") { this." + str2 + " = " + str2 + "; }");
      paramPrintStream.println("");
    }
  }

  private static void protocol_generate(String paramString, Vector paramVector)
  {
    PrintStream localPrintStream = find_file(paramString);
    if (localPrintStream == null)
      return;
    generate_import(localPrintStream);
    localPrintStream.println("public final class " + paramString + " extends Protocol");
    localPrintStream.println("{");
    generate_datamember(localPrintStream, paramVector);
    generate_defaultconstructor(localPrintStream, paramString, paramVector);
    generate_marshalable(localPrintStream, paramVector);
    generate_cloneable(localPrintStream, paramString, paramVector);
    localPrintStream.println("\tpublic void Process(Manager manager, Session session) throws ProtocolException");
    localPrintStream.println("\t{");
    localPrintStream.println("\t}");
    localPrintStream.println("");
    localPrintStream.println("}");
    localPrintStream.close();
  }

  private static void rpcdata_generate(String paramString, Vector paramVector)
  {
    PrintStream localPrintStream = find_file(paramString);
    if (localPrintStream == null)
      return;
    generate_import(localPrintStream);
    localPrintStream.println("public final class " + paramString + " extends Rpc.Data");
    localPrintStream.println("{");
    generate_datamember(localPrintStream, paramVector);
    generate_defaultconstructor(localPrintStream, paramString, paramVector);
    generate_marshalable(localPrintStream, paramVector);
    generate_cloneable(localPrintStream, paramString, paramVector);
    localPrintStream.println("}");
    localPrintStream.close();
  }

  private static void rpc_generate(String paramString1, String paramString2, String paramString3)
  {
    PrintStream localPrintStream = find_file(paramString1);
    if (localPrintStream == null)
      return;
    generate_import(localPrintStream);
    localPrintStream.println("public final class " + paramString1 + " extends Rpc");
    localPrintStream.println("{");
    localPrintStream.println("\tpublic void Server(Data argument, Data result) throws ProtocolException");
    localPrintStream.println("\t{");
    localPrintStream.println("\t\t" + paramString2 + " arg = (" + paramString2 + ")argument;");
    localPrintStream.println("\t\t" + paramString3 + " res = (" + paramString3 + ")result;");
    localPrintStream.println("\t}");
    localPrintStream.println("");
    localPrintStream.println("\tpublic void Client(Data argument, Data result) throws ProtocolException");
    localPrintStream.println("\t{");
    localPrintStream.println("\t\t" + paramString2 + " arg = (" + paramString2 + ")argument;");
    localPrintStream.println("\t\t" + paramString3 + " res = (" + paramString3 + ")result;");
    localPrintStream.println("\t}");
    localPrintStream.println("");
    localPrintStream.println("\tpublic void OnTimeout()");
    localPrintStream.println("\t{");
    localPrintStream.println("\t}");
    localPrintStream.println("");
    localPrintStream.println("}");
    localPrintStream.close();
  }

  protected static void ParseProtocol(Map paramMap)
    throws Exception
  {
    sap.parse(config.openStream(), new DefaultHandler()
    {
      private boolean parsing = false;
      private String name;
      private String type;
      private String class_name;
      private String maxsize;
      private String priority;
      private Vector variables;

      public void startElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3, Attributes paramAnonymousAttributes)
      {
        try
        {
          if (paramAnonymousString3.compareTo("protocol") == 0)
          {
            this.parsing = true;
            this.variables = new Vector();
            this.name = paramAnonymousAttributes.getValue("name");
            this.type = paramAnonymousAttributes.getValue("type");
            this.class_name = paramAnonymousAttributes.getValue("class");
            this.maxsize = paramAnonymousAttributes.getValue("maxsize");
            this.priority = paramAnonymousAttributes.getValue("priority");
            if (this.priority == null)
              this.priority = paramAnonymousAttributes.getValue("prior");
          }
          else if ((this.parsing) && (paramAnonymousString3.compareTo("variable") == 0))
          {
            String str = paramAnonymousAttributes.getValue("type");
            str = str.replaceAll("unsigned", "").trim();
            str = str.replaceAll("char", "byte").trim();
            this.variables.add(new Parser.Variable(paramAnonymousAttributes.getValue("name"), str));
          }
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }

      public void endElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3)
      {
        if ((this.parsing) && (paramAnonymousString3.compareTo("protocol") == 0))
        {
          this.parsing = false;
          try
          {
            Protocol localProtocol = (Protocol)Class.forName(new StringBuilder().append("protocol.").append(this.class_name == null ? this.name : this.class_name).toString()).newInstance();
            localProtocol.type = Integer.parseInt(this.type);
            localProtocol.size_policy = (this.maxsize == null ? 0 : Integer.parseInt(this.maxsize));
            localProtocol.prior_policy = (this.priority == null ? 0 : Integer.parseInt(this.priority));
            if (this.val$map.put(this.name.toUpperCase(), localProtocol) != null)
              System.err.println(new StringBuilder().append("Duplicate protocol name ").append(this.name).toString());
            if (this.val$map.put(this.type, localProtocol) != null)
              System.err.println(new StringBuilder().append("Duplicate protocol type ").append(this.type).toString());
          }
          catch (Exception localException)
          {
            Parser.protocol_generate(this.name, this.variables);
          }
          this.name = null;
          this.type = null;
          this.class_name = null;
          this.maxsize = null;
          this.priority = null;
          this.variables = null;
        }
      }
    });
  }

  protected static void ParseState(final Map paramMap)
    throws Exception
  {
    HashMap localHashMap = new HashMap();
    sap.parse(config.openStream(), new DefaultHandler()
    {
      public void startElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3, Attributes paramAnonymousAttributes)
      {
        if ((paramAnonymousString3.compareTo("protocol") != 0) && (paramAnonymousString3.compareTo("rpc") != 0))
          return;
        try
        {
          this.val$typemap.put(paramAnonymousAttributes.getValue("name").trim(), paramAnonymousAttributes.getValue("type").trim());
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }
    });
    sap.parse(config.openStream(), new DefaultHandler()
    {
      private String state_name = null;
      private State state = null;

      public void startElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3, Attributes paramAnonymousAttributes)
      {
        if (paramAnonymousString3.compareTo("state") == 0)
          try
          {
            this.state_name = paramAnonymousAttributes.getValue("name").trim().toUpperCase();
            try
            {
              this.state = new State(1000L * Long.parseLong(paramAnonymousAttributes.getValue("timeout").trim()));
            }
            catch (Exception localException1)
            {
              this.state = new State(0L);
            }
          }
          catch (Exception localException2)
          {
          }
        if ((this.state_name != null) && (paramAnonymousString3.compareTo("proto") == 0))
          this.state.AddProtocolType((String)this.val$typemap.get(paramAnonymousAttributes.getValue("name")));
      }

      public void endElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3)
      {
        if (paramAnonymousString3.compareTo("state") == 0)
        {
          if (this.state_name != null)
            paramMap.put(this.state_name, this.state);
          this.state_name = null;
        }
      }
    });
  }

  private static final Map ParseRpcData()
    throws Exception
  {
    HashMap localHashMap = new HashMap();
    sap.parse(config.openStream(), new DefaultHandler()
    {
      private boolean parsing = false;
      private String rpcdataName = null;
      private Vector variables;

      public void startElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3, Attributes paramAnonymousAttributes)
      {
        try
        {
          if (paramAnonymousString3.compareTo("rpcdata") == 0)
          {
            this.parsing = true;
            this.variables = new Vector();
            this.rpcdataName = paramAnonymousAttributes.getValue("name");
          }
          else if ((this.parsing) && (paramAnonymousString3.compareTo("variable") == 0))
          {
            String str = paramAnonymousAttributes.getValue("type");
            str = str.replaceAll("unsigned", "").trim();
            str = str.replaceAll("char", "byte").trim();
            this.variables.add(new Parser.Variable(paramAnonymousAttributes.getValue("name"), str));
          }
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }

      public void endElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3)
      {
        if ((this.parsing) && (paramAnonymousString3.compareTo("rpcdata") == 0))
        {
          this.parsing = false;
          try
          {
            this.val$typemap.put(this.rpcdataName, Class.forName("protocol." + this.rpcdataName).newInstance());
          }
          catch (Exception localException)
          {
            Parser.rpcdata_generate(this.rpcdataName, this.variables);
          }
          this.rpcdataName = null;
          this.variables = null;
        }
      }
    });
    return localHashMap;
  }

  protected static void ParseRpc(final Map paramMap)
    throws Exception
  {
    Map localMap = ParseRpcData();
    sap.parse(config.openStream(), new DefaultHandler()
    {
      public void startElement(String paramAnonymousString1, String paramAnonymousString2, String paramAnonymousString3, Attributes paramAnonymousAttributes)
      {
        if (paramAnonymousString3.compareTo("rpc") == 0)
          try
          {
            String str1 = paramAnonymousAttributes.getValue("name");
            String str2 = paramAnonymousAttributes.getValue("type");
            String str3 = paramAnonymousAttributes.getValue("argument");
            String str4 = paramAnonymousAttributes.getValue("result");
            String str5 = paramAnonymousAttributes.getValue("maxsize");
            String str6 = paramAnonymousAttributes.getValue("timeout");
            String str7 = paramAnonymousAttributes.getValue("priority");
            if (str7 == null)
              str7 = paramAnonymousAttributes.getValue("prior");
            Rpc localRpc = null;
            try
            {
              localRpc = (Rpc)Class.forName("protocol." + str1).newInstance();
            }
            catch (Exception localException2)
            {
              Parser.rpc_generate(str1, str3, str4);
              return;
            }
            localRpc.argument = ((Rpc.Data)this.val$typemap.get(str3));
            localRpc.result = ((Rpc.Data)this.val$typemap.get(str4));
            localRpc.type = Integer.parseInt(str2);
            localRpc.prior_policy = (str7 == null ? 0 : Integer.parseInt(str7));
            localRpc.time_policy = (str6 == null ? 25000L : 1000L * Long.parseLong(str6));
            localRpc.size_policy = (str5 == null ? 0 : Integer.parseInt(str5));
            if (paramMap.put(str1.toUpperCase(), localRpc) != null)
              System.err.println("Duplicate protocol name " + str1);
            if (paramMap.put(str2, localRpc) != null)
              System.err.println("Duplicate protocol type " + str2);
          }
          catch (Exception localException1)
          {
            localException1.printStackTrace();
          }
      }
    });
  }

  static
  {
    try
    {
      sap = SAXParserFactory.newInstance().newSAXParser();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  private static class Variable
  {
    public String name;
    public String type;

    public Variable(String paramString1, String paramString2)
    {
      this.name = paramString1;
      this.type = paramString2;
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Protocol.Parser
 * JD-Core Version:    0.6.2
 */