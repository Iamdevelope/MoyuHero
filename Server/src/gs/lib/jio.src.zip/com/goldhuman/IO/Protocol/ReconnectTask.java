package com.goldhuman.IO.Protocol;

import com.goldhuman.Common.Runnable;

public class ReconnectTask extends Runnable
{
  public Manager manager;

  public ReconnectTask(Manager paramManager, int paramInt)
  {
    super(paramInt);
    this.manager = paramManager;
  }

  public void run()
  {
    Protocol.Client(this.manager);
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Protocol.ReconnectTask
 * JD-Core Version:    0.6.2
 */