package com.goldhuman.IO;

import com.goldhuman.Common.Runnable;
import com.goldhuman.Common.ThreadPool;

class Task extends Runnable
{
  protected Task()
  {
    super(1);
  }

  public void run()
  {
    PollIO.Poll(1000L);
    ThreadPool.AddTask(this);
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Task
 * JD-Core Version:    0.6.2
 */