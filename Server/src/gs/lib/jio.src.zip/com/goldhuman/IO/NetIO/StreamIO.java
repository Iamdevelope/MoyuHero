package com.goldhuman.IO.NetIO;

import com.goldhuman.Common.Octets;
import java.nio.ByteBuffer;
import java.nio.channels.SelectableChannel;
import java.nio.channels.SocketChannel;

public class StreamIO extends NetIO
{
  protected void PollIn()
  {
    try
    {
      ByteBuffer localByteBuffer = this.session.ibuffer.getByteBuffer(this.session.ibuffer.size(), this.session.ibuffer.capacity() - this.session.ibuffer.size());
      if (((SocketChannel)this.channel).read(localByteBuffer) > 0)
      {
        this.session.ibuffer.resize(localByteBuffer.position());
        return;
      }
    }
    catch (Exception localException)
    {
    }
    this.session.obuffer.clear();
    this.session.closing = true;
  }

  protected void PollOut()
  {
    try
    {
      ByteBuffer localByteBuffer = this.session.obuffer.getByteBuffer(0, this.session.obuffer.size());
      if (((SocketChannel)this.channel).write(localByteBuffer) > 0)
      {
        this.session.obuffer.erase(0, localByteBuffer.position());
        return;
      }
    }
    catch (Exception localException)
    {
    }
    this.session.obuffer.clear();
    this.session.closing = true;
  }

  protected int UpdateEvent()
  {
    int i = 0;
    synchronized (this.session)
    {
      if (this.session.ibuffer.size() > 0)
        this.session.OnRecv();
      if (!this.session.closing)
        this.session.OnSend();
      if (this.session.obuffer.size() > 0)
        i = 4;
      if (this.session.closing)
      {
        try
        {
          this.channel.close();
        }
        catch (Exception localException)
        {
        }
        return -1;
      }
      if (this.session.ibuffer.size() < this.session.ibuffer.capacity())
        i |= 1;
    }
    return i;
  }

  public StreamIO(SelectableChannel paramSelectableChannel, NetSession paramNetSession)
  {
    super(paramSelectableChannel, paramNetSession);
    paramNetSession.OnOpen();
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.NetIO.StreamIO
 * JD-Core Version:    0.6.2
 */