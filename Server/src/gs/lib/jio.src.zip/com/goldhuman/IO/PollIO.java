package com.goldhuman.IO;

import com.goldhuman.Common.Runnable;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectableChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

public abstract class PollIO
{
  private static Selector iomap = null;
  private static final Runnable task = new Task();
  private static Object regist_locker = new Object();
  protected SelectableChannel channel;

  protected abstract int UpdateEvent();

  protected abstract boolean Close();

  protected void PollIn()
  {
  }

  protected void PollOut()
  {
  }

  protected void PollAccept()
  {
  }

  protected void PollConnect()
  {
  }

  public static PollIO register(PollIO paramPollIO)
  {
    synchronized (regist_locker)
    {
      WakeUp();
      try
      {
        paramPollIO.channel.register(iomap, 0, paramPollIO);
      }
      catch (ClosedChannelException localClosedChannelException)
      {
        localClosedChannelException.printStackTrace();
      }
      return paramPollIO;
    }
  }

  protected static synchronized void Poll(long paramLong)
  {
    try
    {
      ArrayList localArrayList = new ArrayList();
      Object localObject1;
      synchronized (regist_locker)
      {
        localObject1 = iomap.keys().iterator();
        while (((Iterator)localObject1).hasNext())
          localArrayList.add(((Iterator)localObject1).next());
      }
      ??? = localArrayList.iterator();
      PollIO localPollIO;
      while (((Iterator)???).hasNext())
      {
        localObject1 = (SelectionKey)((Iterator)???).next();
        localPollIO = (PollIO)((SelectionKey)localObject1).attachment();
        int i = localPollIO.UpdateEvent();
        if (i == -1)
        {
          if (localPollIO.Close())
          {
            try
            {
              localPollIO.channel.close();
            }
            catch (Exception localException2)
            {
            }
            ((SelectionKey)localObject1).cancel();
          }
        }
        else
          try
          {
            ((SelectionKey)localObject1).interestOps(i);
          }
          catch (Exception localException3)
          {
          }
      }
      iomap.selectedKeys().clear();
      if (paramLong < 0L)
        iomap.select();
      else if (paramLong == 0L)
        iomap.selectNow();
      else
        iomap.select(paramLong);
      ??? = iomap.selectedKeys().iterator();
      while (((Iterator)???).hasNext())
      {
        localObject1 = (SelectionKey)((Iterator)???).next();
        localPollIO = (PollIO)((SelectionKey)localObject1).attachment();
        if (((SelectionKey)localObject1).isAcceptable())
          localPollIO.PollAccept();
        if (((SelectionKey)localObject1).isConnectable())
          localPollIO.PollConnect();
        if (((SelectionKey)localObject1).isReadable())
          localPollIO.PollIn();
        if (((SelectionKey)localObject1).isWritable())
          localPollIO.PollOut();
      }
    }
    catch (Exception localException1)
    {
      localException1.printStackTrace();
    }
  }

  protected PollIO(SelectableChannel paramSelectableChannel)
  {
    try
    {
      this.channel = paramSelectableChannel;
      paramSelectableChannel.configureBlocking(false);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public static Runnable GetTask()
  {
    return task;
  }

  public static void WakeUp()
  {
    iomap.wakeup();
  }

  static
  {
    try
    {
      iomap = Selector.open();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.PollIO
 * JD-Core Version:    0.6.2
 */