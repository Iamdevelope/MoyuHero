package com.goldhuman.IO.Protocol;

import java.io.File;
import java.net.URI;
import java.net.URL;

public class Rpcgen extends Parser
{
  public Rpcgen(URL paramURL)
  {
    if (paramURL != null)
      setConfig(paramURL);
  }

  public void generate_code()
    throws Exception
  {
    Parser.ParseProtocol(null);
    Parser.ParseRpc(null);
  }

  public static void main(String[] paramArrayOfString)
  {
    String str = null;
    if (paramArrayOfString.length != 0)
      str = paramArrayOfString[0];
    try
    {
      Rpcgen localRpcgen = new Rpcgen(str == null ? null : new File(str).toURI().toURL());
      localRpcgen.generate_code();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Protocol.Rpcgen
 * JD-Core Version:    0.6.2
 */