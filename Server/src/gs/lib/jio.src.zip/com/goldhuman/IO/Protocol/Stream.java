package com.goldhuman.IO.Protocol;

import com.goldhuman.Common.Marshal.OctetsStream;

public final class Stream extends OctetsStream
{
  protected Session session;
  protected boolean check_policy = true;
  protected int checked_size = 0;

  protected Stream(Session paramSession)
  {
    this.session = paramSession;
  }

  protected Stream(Session paramSession, int paramInt)
  {
    super(paramInt);
    this.session = paramSession;
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Protocol.Stream
 * JD-Core Version:    0.6.2
 */