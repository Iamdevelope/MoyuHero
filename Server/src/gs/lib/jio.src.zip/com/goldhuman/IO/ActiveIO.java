package com.goldhuman.IO;

import com.goldhuman.Common.Conf;
import com.goldhuman.IO.NetIO.NetSession;
import com.goldhuman.IO.NetIO.StreamIO;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.channels.SocketChannel;

public class ActiveIO extends PollIO
{
  boolean closing;
  NetSession assoc_session;

  protected int UpdateEvent()
  {
    return this.closing ? -1 : 8;
  }

  protected void PollConnect()
  {
    this.closing = true;
  }

  private ActiveIO(SocketChannel paramSocketChannel, NetSession paramNetSession)
  {
    super(paramSocketChannel);
    (this.assoc_session = paramNetSession).LoadConfig();
    this.closing = false;
    PollIO.WakeUp();
  }

  public boolean Close()
  {
    boolean bool = true;
    try
    {
      SocketChannel localSocketChannel = (SocketChannel)this.channel;
      if (localSocketChannel.finishConnect())
      {
        bool = false;
        register(new StreamIO(localSocketChannel, (NetSession)this.assoc_session.clone()));
        PollIO.WakeUp();
        return false;
      }
    }
    catch (Exception localException1)
    {
      localException1.printStackTrace();
      System.err.println("assoc_session = " + this.assoc_session + " activeio = " + this);
    }
    try
    {
      this.assoc_session.OnAbort();
    }
    catch (Exception localException2)
    {
      localException2.printStackTrace();
      System.err.println("assoc_session = " + this.assoc_session + " activeio = " + this);
      return bool;
    }
    return true;
  }

  public static ActiveIO Open(NetSession paramNetSession)
  {
    Conf localConf = Conf.GetInstance();
    String str1 = paramNetSession.Identification();
    String str2 = localConf.find(str1, "type");
    if (str2.compareToIgnoreCase("tcp") == 0)
      try
      {
        SocketChannel localSocketChannel = SocketChannel.open();
        localSocketChannel.configureBlocking(false);
        InetSocketAddress localInetSocketAddress = null;
        try
        {
          localInetSocketAddress = new InetSocketAddress(InetAddress.getByName(localConf.find(str1, "address")), Integer.parseInt(localConf.find(str1, "port")));
        }
        catch (Exception localException2)
        {
        }
        Socket localSocket = localSocketChannel.socket();
        try
        {
          localSocket.setReceiveBufferSize(Integer.parseInt(localConf.find(str1, "so_rcvbuf")));
        }
        catch (Exception localException3)
        {
        }
        try
        {
          localSocket.setSendBufferSize(Integer.parseInt(localConf.find(str1, "so_sndbuf")));
        }
        catch (Exception localException4)
        {
        }
        try
        {
          if (Integer.parseInt(localConf.find(str1, "tcp_nodelay")) != 0)
            localSocket.setTcpNoDelay(true);
        }
        catch (Exception localException5)
        {
        }
        SocketAddress localSocketAddress = paramNetSession.OnCheckAddress(localInetSocketAddress);
        localSocketChannel.connect(localSocketAddress);
        NetSession localNetSession = (NetSession)paramNetSession.clone();
        localNetSession.setPeerAddress(localSocketAddress);
        return (ActiveIO)register(new ActiveIO(localSocketChannel, localNetSession));
      }
      catch (Exception localException1)
      {
        localException1.printStackTrace();
      }
    return null;
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.ActiveIO
 * JD-Core Version:    0.6.2
 */