package com.goldhuman.IO.Protocol;

import com.goldhuman.Common.Octets;
import java.net.SocketAddress;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public abstract class Manager
{
  private Set set = Collections.synchronizedSet(new HashSet());

  protected void AddSession(Session paramSession)
  {
    this.set.add(paramSession);
    try
    {
      OnAddSession(paramSession);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  protected void DelSession(Session paramSession)
  {
    try
    {
      OnDelSession(paramSession);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    this.set.remove(paramSession);
  }

  protected void AbortSession(Session paramSession)
  {
    try
    {
      OnAbortSession(paramSession);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public boolean SetISecurity(Session paramSession, String paramString, Octets paramOctets)
  {
    if (!this.set.contains(paramSession))
      return false;
    paramSession.SetISecurity(paramString, paramOctets);
    return true;
  }

  public boolean SetOSecurity(Session paramSession, String paramString, Octets paramOctets)
  {
    if (!this.set.contains(paramSession))
      return false;
    paramSession.SetOSecurity(paramString, paramOctets);
    return true;
  }

  public boolean Send(Session paramSession, Protocol paramProtocol)
  {
    if (!this.set.contains(paramSession))
      return false;
    return paramSession.Send(paramProtocol);
  }

  public boolean Close(Session paramSession)
  {
    if (!this.set.contains(paramSession))
      return false;
    paramSession.Close();
    return true;
  }

  public boolean ChangeState(Session paramSession, String paramString)
  {
    if (!this.set.contains(paramSession))
      return false;
    paramSession.ChangeState(paramString);
    return true;
  }

  protected abstract void OnAddSession(Session paramSession);

  protected abstract void OnDelSession(Session paramSession);

  protected void OnAbortSession(Session paramSession)
  {
  }

  protected abstract State GetInitState();

  protected int PriorPolicy(int paramInt)
  {
    return Protocol.GetStub(paramInt).PriorPolicy();
  }

  protected boolean InputPolicy(int paramInt1, int paramInt2)
  {
    return Protocol.GetStub(paramInt1).SizePolicy(paramInt2);
  }

  protected abstract String Identification();

  protected SocketAddress OnCheckAddress(SocketAddress paramSocketAddress)
  {
    return paramSocketAddress;
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Protocol.Manager
 * JD-Core Version:    0.6.2
 */