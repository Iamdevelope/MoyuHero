package com.goldhuman.IO.Protocol;

import com.goldhuman.Common.Marshal.Marshal;
import com.goldhuman.Common.Marshal.MarshalException;
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.TimerObserver;
import com.goldhuman.Common.TimerObserver.WatchDog;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;
import java.util.Vector;

public class Rpc extends Protocol
{
  private static Map map = Collections.synchronizedMap(new HashMap());
  private static HouseKeeper housekeeper = new HouseKeeper();
  private XID xid = new XID(null);
  private TimerObserver.WatchDog timer = new TimerObserver.WatchDog();
  protected Data argument;
  protected Data result;
  protected long time_policy;

  public OctetsStream marshal(OctetsStream paramOctetsStream)
  {
    paramOctetsStream.marshal(this.xid);
    paramOctetsStream.marshal(this.xid.IsRequest() ? this.argument : this.result);
    return paramOctetsStream;
  }

  public OctetsStream unmarshal(OctetsStream paramOctetsStream)
    throws MarshalException
  {
    paramOctetsStream.unmarshal(this.xid);
    if (this.xid.IsRequest())
      return paramOctetsStream.unmarshal(this.argument);
    Rpc localRpc = (Rpc)map.get(this.xid);
    if (localRpc != null)
      paramOctetsStream.unmarshal(localRpc.result);
    return paramOctetsStream;
  }

  public Object clone()
  {
    try
    {
      Rpc localRpc = (Rpc)super.clone();
      localRpc.xid = ((XID)this.xid.clone());
      localRpc.timer = new TimerObserver.WatchDog();
      localRpc.argument = ((Data)this.argument.clone());
      localRpc.result = ((Data)this.result.clone());
      return localRpc;
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public void Process(Manager paramManager, Session paramSession)
    throws ProtocolException
  {
    if (this.xid.IsRequest())
    {
      int i = this.prior_policy;
      Server(this.argument, this.result, paramManager, paramSession);
      if (this.prior_policy == i)
      {
        this.xid.ClrRequest();
        paramManager.Send(paramSession, this);
      }
      else
      {
        Task.Dispatch(paramManager, paramSession, this);
      }
      return;
    }
    Rpc localRpc = (Rpc)map.remove(this.xid);
    if (localRpc != null)
      localRpc.Client(localRpc.argument, localRpc.result);
  }

  protected void Server(Data paramData1, Data paramData2)
    throws ProtocolException
  {
  }

  protected void Server(Data paramData1, Data paramData2, Manager paramManager, Session paramSession)
    throws ProtocolException
  {
    Server(paramData1, paramData2);
  }

  protected void Client(Data paramData1, Data paramData2)
    throws ProtocolException
  {
  }

  protected void OnTimeout()
  {
  }

  private static Rpc Call(Rpc paramRpc, Data paramData)
  {
    paramRpc.xid.SetRequest();
    paramRpc.argument = paramData;
    map.put(paramRpc.xid, paramRpc);
    return paramRpc;
  }

  public static Rpc Call(int paramInt, Data paramData)
  {
    return Call((Rpc)Protocol.Create(paramInt), paramData);
  }

  public static Rpc Call(String paramString, Data paramData)
  {
    return Call((Rpc)Protocol.Create(paramString), paramData);
  }

  public static abstract class Data
    implements Marshal, Cloneable
  {
    protected Object clone()
    {
      try
      {
        Data localData = (Data)super.clone();
        return localData;
      }
      catch (Exception localException)
      {
      }
      return null;
    }

    public static class DataVector extends Vector
      implements Marshal, Cloneable
    {
      protected Rpc.Data stub;

      private DataVector()
      {
      }

      public Object clone()
      {
        try
        {
          DataVector localDataVector = (DataVector)super.clone();
          localDataVector.stub = ((Rpc.Data)this.stub.clone());
          return localDataVector;
        }
        catch (Exception localException)
        {
        }
        return null;
      }

      public DataVector(Rpc.Data paramData)
      {
        this.stub = paramData;
      }

      public OctetsStream marshal(OctetsStream paramOctetsStream)
      {
        paramOctetsStream.compact_uint32(size());
        for (int i = 0; i < size(); i++)
          ((Cloneable)get(i)).marshal(paramOctetsStream);
        return paramOctetsStream;
      }

      public OctetsStream unmarshal(OctetsStream paramOctetsStream)
        throws MarshalException
      {
        int i = paramOctetsStream.uncompact_uint32();
        for (int j = 0; j < i; j++)
        {
          Rpc.Data localData = (Rpc.Data)this.stub.clone();
          localData.unmarshal(paramOctetsStream);
          add(localData);
        }
        return paramOctetsStream;
      }
    }
  }

  private static class XID
    implements Marshal, Cloneable
  {
    public int count = 0;
    private boolean is_request = true;
    private static int xid_count = 0;
    private static Object xid_locker = new Object();

    public OctetsStream marshal(OctetsStream paramOctetsStream)
    {
      return paramOctetsStream.marshal(this.is_request ? this.count | 0x80000000 : this.count & 0x7FFFFFFF);
    }

    public OctetsStream unmarshal(OctetsStream paramOctetsStream)
      throws MarshalException
    {
      this.count = paramOctetsStream.unmarshal_int();
      this.is_request = ((this.count & 0x80000000) != 0);
      return paramOctetsStream;
    }

    public boolean IsRequest()
    {
      return this.is_request;
    }

    public void ClrRequest()
    {
      this.is_request = false;
    }

    public void SetRequest()
    {
      this.is_request = true;
      synchronized (xid_locker)
      {
        this.count = (xid_count++);
      }
    }

    public Object clone()
    {
      try
      {
        return super.clone();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
      return null;
    }

    public boolean equals(Object paramObject)
    {
      return (((XID)paramObject).count & 0x7FFFFFFF) == (this.count & 0x7FFFFFFF);
    }

    public int hashCode()
    {
      return this.count & 0x7FFFFFFF;
    }
  }

  private static class HouseKeeper
    implements Observer
  {
    public HouseKeeper()
    {
      TimerObserver.GetInstance().addObserver(this);
    }

    public void update(Observable paramObservable, Object paramObject)
    {
      ArrayList localArrayList = new ArrayList();
      synchronized (Rpc.map)
      {
        Iterator localIterator = Rpc.map.entrySet().iterator();
        while (localIterator.hasNext())
        {
          Rpc localRpc = (Rpc)((Map.Entry)localIterator.next()).getValue();
          if (localRpc.time_policy < localRpc.timer.Elapse())
          {
            localArrayList.add(localRpc);
            localIterator.remove();
          }
        }
      }
      ??? = localArrayList.iterator();
      while (((Iterator)???).hasNext())
        ((Rpc)((Iterator)???).next()).OnTimeout();
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Protocol.Rpc
 * JD-Core Version:    0.6.2
 */