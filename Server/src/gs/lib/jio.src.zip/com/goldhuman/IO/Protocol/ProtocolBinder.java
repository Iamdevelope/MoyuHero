package com.goldhuman.IO.Protocol;

import com.goldhuman.Common.Marshal.OctetsStream;
import java.util.Iterator;
import java.util.Vector;

public final class ProtocolBinder extends Protocol
{
  private Vector binder = new Vector();

  public OctetsStream marshal(OctetsStream paramOctetsStream)
  {
    synchronized (this.binder)
    {
      Iterator localIterator = this.binder.iterator();
      while (localIterator.hasNext())
        ((Protocol)localIterator.next()).Encode(paramOctetsStream);
    }
    return paramOctetsStream;
  }

  public OctetsStream unmarshal(OctetsStream paramOctetsStream)
  {
    Stream localStream = (Stream)paramOctetsStream;
    synchronized (this.binder)
    {
      try
      {
        while ((localObject1 = Protocol.Decode(localStream)) != null)
          this.binder.add(localObject1);
        Object localObject1 = this.binder.iterator();
        while (((Iterator)localObject1).hasNext())
          Task.Dispatch(localStream.session.manager, localStream.session, (Protocol)((Iterator)localObject1).next());
      }
      catch (Exception localException)
      {
        localStream.session.Close();
      }
    }
    return paramOctetsStream;
  }

  public Object clone()
  {
    try
    {
      ProtocolBinder localProtocolBinder = (ProtocolBinder)super.clone();
      synchronized (this.binder)
      {
        Iterator localIterator = this.binder.iterator();
        while (localIterator.hasNext())
          localProtocolBinder.binder.add(((Protocol)localIterator.next()).clone());
        return localProtocolBinder;
      }
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public void Process(Manager paramManager, Session paramSession)
    throws ProtocolException
  {
  }

  ProtocolBinder bind(Protocol paramProtocol)
  {
    synchronized (this.binder)
    {
      this.binder.add(paramProtocol);
    }
    return this;
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Protocol.ProtocolBinder
 * JD-Core Version:    0.6.2
 */