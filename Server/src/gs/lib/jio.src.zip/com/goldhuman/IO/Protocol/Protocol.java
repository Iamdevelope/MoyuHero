package com.goldhuman.IO.Protocol;

import com.goldhuman.Common.Counter;
import com.goldhuman.Common.Marshal.Marshal;
import com.goldhuman.Common.Marshal.MarshalException;
import com.goldhuman.Common.Marshal.OctetsStream;
import com.goldhuman.Common.TimerObserver;
import com.goldhuman.IO.ActiveIO;
import com.goldhuman.IO.PassiveIO;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

public abstract class Protocol
  implements Marshal, Cloneable
{
  private static final Map map = new HashMap();
  private static final Counter counter = new Counter("Protocol");
  protected int type;
  protected int size_policy;
  protected int prior_policy;
  protected long time_wait = 0L;

  public Object clone()
  {
    try
    {
      return super.clone();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }

  public static Protocol GetStub(String paramString)
  {
    return (Protocol)map.get(paramString.toUpperCase());
  }

  public static Protocol GetStub(int paramInt)
  {
    return GetStub(Integer.toString(paramInt));
  }

  public static Protocol Create(String paramString)
  {
    Protocol localProtocol = GetStub(paramString);
    return localProtocol == null ? null : (Protocol)localProtocol.clone();
  }

  public static Protocol Create(int paramInt)
  {
    return Create(Integer.toString(paramInt));
  }

  public int getType()
  {
    return this.type;
  }

  protected void Encode(OctetsStream paramOctetsStream)
  {
    paramOctetsStream.compact_uint32(this.type).marshal(new OctetsStream().marshal(this));
  }

  protected static Protocol Decode(Stream paramStream)
    throws ProtocolException
  {
    if (paramStream.eos())
      return null;
    Protocol localProtocol = null;
    int i = 0;
    int j = 0;
    try
    {
      if (paramStream.check_policy)
      {
        paramStream.Begin();
        i = paramStream.uncompact_uint32();
        j = paramStream.uncompact_uint32();
        paramStream.Rollback();
        if ((!paramStream.session.StatePolicy(i)) || (!paramStream.session.manager.InputPolicy(i, j)))
        {
          System.out.println("Protocol Decode CheckPolicy Error:type=" + i + ",size=" + j);
          throw new ProtocolException();
        }
        paramStream.check_policy = false;
        paramStream.checked_size = j;
      }
      Stream localStream = new Stream(paramStream.session, paramStream.checked_size);
      paramStream.Begin();
      i = paramStream.uncompact_uint32();
      paramStream.unmarshal(localStream);
      paramStream.Commit();
      if ((localProtocol = Create(i)) != null)
      {
        localProtocol.unmarshal(localStream);
        counter.increment(localProtocol.getClass().getName());
      }
      paramStream.check_policy = true;
    }
    catch (MarshalException localMarshalException)
    {
      paramStream.Rollback();
      if (localProtocol != null)
      {
        System.out.println("Protocol Decode Unmarshal Error:type=" + i + ",size=" + j);
        throw new ProtocolException();
      }
      System.out.println("Protocol Decode Warning:uncomplete data,protocol type=" + i + ",size=" + j);
    }
    return localProtocol;
  }

  public static PassiveIO Server(Manager paramManager)
  {
    return PassiveIO.Open(new Session(paramManager));
  }

  public static ActiveIO Client(Manager paramManager)
  {
    return ActiveIO.Open(new Session(paramManager));
  }

  protected int PriorPolicy()
  {
    return this.prior_policy;
  }

  protected boolean SizePolicy(int paramInt)
  {
    return (paramInt <= 0) || (paramInt < this.size_policy);
  }

  public abstract void Process(Manager paramManager, Session paramSession)
    throws ProtocolException;

  public static void main(String[] paramArrayOfString)
  {
    TimerObserver.GetInstance().StopTimer();
  }

  static
  {
    try
    {
      Parser.ParseProtocol(map);
    }
    catch (Exception localException1)
    {
      localException1.printStackTrace();
    }
    try
    {
      Parser.ParseRpc(map);
    }
    catch (Exception localException2)
    {
      localException2.printStackTrace();
    }
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Protocol.Protocol
 * JD-Core Version:    0.6.2
 */