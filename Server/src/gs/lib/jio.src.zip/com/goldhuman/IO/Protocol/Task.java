package com.goldhuman.IO.Protocol;

import com.goldhuman.Common.Runnable;
import com.goldhuman.Common.ThreadPool;
import com.goldhuman.IO.PollIO;

public final class Task extends Runnable
{
  private Manager manager;
  private Session session;
  private Protocol protocol;
  private long time_start = 0L;

  private Task(int paramInt, Manager paramManager, Session paramSession, Protocol paramProtocol)
  {
    super(paramInt);
    this.manager = paramManager;
    this.session = paramSession;
    this.protocol = paramProtocol;
    this.time_start = System.currentTimeMillis();
  }

  public void run()
  {
    try
    {
      this.protocol.time_wait = (System.currentTimeMillis() - this.time_start);
      this.protocol.Process(this.manager, this.session);
      if (Session.need_wakeup)
      {
        PollIO.WakeUp();
        Session.need_wakeup = false;
      }
    }
    catch (ProtocolException localProtocolException)
    {
      this.manager.Close(this.session);
    }
  }

  protected static void Dispatch(Manager paramManager, Session paramSession, Protocol paramProtocol)
  {
    int i = paramManager.PriorPolicy(paramProtocol.type);
    Task localTask = new Task(i, paramManager, paramSession, paramProtocol);
    if (i > 0)
      ThreadPool.AddTask(localTask);
    else
      paramSession.AddTask(localTask);
  }
}

/* Location:           E:\gameserver\Server\src\gs\lib\jio.jar
 * Qualified Name:     com.goldhuman.IO.Protocol.Task
 * JD-Core Version:    0.6.2
 */