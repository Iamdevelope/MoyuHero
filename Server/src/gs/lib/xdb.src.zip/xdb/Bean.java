package xdb;

import com.goldhuman.Common.Marshal.Marshal;

public abstract interface Bean extends Marshal
{
  public abstract boolean xdbManaged();

  public abstract Bean xdbParent();

  public abstract String xdbVarname();

  public abstract Long xdbObjId();

  public abstract Bean toConst();

  public abstract boolean isConst();

  public abstract boolean isData();
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Bean
 * JD-Core Version:    0.6.2
 */