/*     */ package xdb;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import xdb.util.Counter;
/*     */ import xio.Protocol;
/*     */ import xio.Xio;
/*     */ 
/*     */ public final class Transaction
/*     */ {
/*  20 */   private int trancount = 0;
/*  21 */   private List<Savepoint> logs = new ArrayList();
/*     */ 
/*  24 */   Map<LogKey, Object> wrappers = new HashMap();
/*     */ 
/*  31 */   private HashMap<Lockey, Lockey> locks = new HashMap();
/*     */ 
/*  34 */   private HashMap<String, TTable<?, ?>> logNotifyTTables = new HashMap();
/*     */ 
/*  39 */   private HashMap<String, HashMap<Object, Object>> cachedTRecord = new HashMap();
/*     */ 
/* 175 */   private static ThreadLocal<Transaction> threadlocal = new ThreadLocal();
/*     */ 
/* 261 */   private static Counter counter = new Counter(Xdb.mbeans(), "xdb", "Procedures");
/*     */ 
/* 263 */   private static AtomicLong totalCount = new AtomicLong();
/* 264 */   private static AtomicLong totalFalse = new AtomicLong();
/* 265 */   private static AtomicLong totalException = new AtomicLong();
/*     */ 
/* 461 */   private ArrayList<Procedure.Task> _ttasks = new ArrayList();
/*     */ 
/*     */   public void add(Lockey paramLockey)
/*     */   {
/*  45 */     if (null == this.locks.get(paramLockey))
/*     */     {
/*  47 */       paramLockey.lock();
/*  48 */       this.locks.put(paramLockey, paramLockey);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addLogNotifyTTable(TTable<?, ?> paramTTable)
/*     */   {
/*  56 */     this.logNotifyTTables.put(paramTTable.getName(), paramTTable);
/*     */   }
/*     */ 
/*     */   <K, V> void addCachedTRecord(TTable<K, V> paramTTable, TRecord<K, V> paramTRecord)
/*     */   {
/*  63 */     HashMap localHashMap = (HashMap)this.cachedTRecord.get(paramTTable.getName());
/*  64 */     if (localHashMap == null) {
/*  65 */       localHashMap = new HashMap();
/*  66 */       this.cachedTRecord.put(paramTTable.getName(), localHashMap);
/*     */     }
/*  68 */     localHashMap.put(paramTRecord.getKey(), paramTRecord);
/*     */   }
/*     */ 
/*     */   <K, V> void rmvCachedTRecord(TTable<K, V> paramTTable, K paramK)
/*     */   {
/*  75 */     HashMap localHashMap = (HashMap)this.cachedTRecord.get(paramTTable.getName());
/*  76 */     if (localHashMap != null)
/*  77 */       localHashMap.remove(paramK);
/*     */   }
/*     */ 
/*     */   <K, V> TRecord<K, V> getCachedTRecord(TTable<K, V> paramTTable, K paramK)
/*     */   {
/*  86 */     HashMap localHashMap = (HashMap)this.cachedTRecord.get(paramTTable.getName());
/*  87 */     if (localHashMap == null) {
/*  88 */       localHashMap = new HashMap();
/*  89 */       this.cachedTRecord.put(paramTTable.getName(), localHashMap);
/*     */     }
/*  91 */     return (TRecord)localHashMap.get(paramK);
/*     */   }
/*     */ 
/*     */   Lockey get(Lockey paramLockey)
/*     */   {
/*  98 */     return (Lockey)this.locks.get(paramLockey);
/*     */   }
/*     */ 
/*     */   private void finish()
/*     */   {
/* 105 */     this.wrappers.clear();
/*     */ 
/* 108 */     for (Lockey localLockey : this.locks.values()) {
/*     */       try
/*     */       {
/* 111 */         localLockey.unlock();
/*     */       } catch (Throwable localThrowable) {
/* 113 */         Trace.fatal("unlock " + localLockey, localThrowable);
/*     */       }
/*     */     }
/* 116 */     this.locks.clear();
/* 117 */     this.cachedTRecord.clear();
/*     */   }
/*     */ 
/*     */   public void begin()
/*     */   {
/* 122 */     this.trancount += 1;
/*     */   }
/*     */ 
/*     */   public int trancount() {
/* 126 */     return this.trancount;
/*     */   }
/*     */ 
/*     */   public void commit() {
/* 130 */     if (--this.trancount < 0)
/* 131 */       throw new XError("xdb: commit mismatch");
/*     */   }
/*     */ 
/*     */   int savepoint() {
/* 135 */     this.logs.add(new Savepoint());
/* 136 */     return this.logs.size();
/*     */   }
/*     */ 
/*     */   public int currentSavepointId()
/*     */   {
/* 143 */     return this.logs.size();
/*     */   }
/*     */ 
/*     */   public Savepoint getSavepoint(int paramInt)
/*     */   {
/* 159 */     if ((paramInt < 1) || (paramInt > this.logs.size()))
/* 160 */       return null;
/* 161 */     return (Savepoint)this.logs.get(paramInt - 1);
/*     */   }
/*     */ 
/*     */   public void rollback(int paramInt) {
/* 165 */     if ((paramInt < 1) || (paramInt > this.logs.size())) {
/* 166 */       throw new XError("xdb: invalid savepoint " + paramInt + "@" + this.logs.size());
/*     */     }
/* 168 */     while (this.logs.size() >= paramInt) {
/* 169 */       ((Savepoint)this.logs.remove(this.logs.size() - 1)).rollback();
/*     */     }
/* 171 */     this.trancount -= 1;
/*     */   }
/*     */ 
/*     */   public static final Transaction create()
/*     */   {
/* 178 */     Transaction localTransaction = (Transaction)threadlocal.get();
/* 179 */     if (null == localTransaction)
/* 180 */       threadlocal.set(localTransaction = new Transaction());
/* 181 */     return localTransaction;
/*     */   }
/*     */ 
/*     */   public static final void destroy() {
/* 185 */     threadlocal.set(null);
/*     */   }
/*     */ 
/*     */   public static final Transaction current() {
/* 189 */     return (Transaction)threadlocal.get();
/*     */   }
/*     */ 
/*     */   public static final Savepoint currentSavepoint() {
/* 193 */     Transaction localTransaction = current();
/* 194 */     return (Savepoint)localTransaction.logs.get(localTransaction.logs.size() - 1);
/*     */   }
/*     */ 
/*     */   public static final void verify() {
/* 198 */     if (threadlocal.get() == null)
/* 199 */       throw new XError("Transaction.verify");
/*     */   }
/*     */ 
/*     */   private void _last_rollback_()
/*     */   {
/*     */     try
/*     */     {
/* 210 */       for (int i = this.logs.size() - 1; i >= 0; i--)
/* 211 */         ((Savepoint)this.logs.get(i)).rollback();
/* 212 */       this.logs.clear();
/* 213 */       this.trancount = 0;
/*     */     }
/*     */     catch (Throwable localThrowable) {
/* 216 */       Trace.fatal("last rollback ", localThrowable);
/* 217 */       Runtime.getRuntime().halt(54321);
/*     */     }
/*     */   }
/*     */ 
/*     */   private int _real_commit_()
/*     */   {
/* 226 */     if (0 != this.trancount)
/* 227 */       throw new XError("xdb: mismatch (begin,commit/rollback) trancount=" + this.trancount);
/* 228 */     int i = 0;
/* 229 */     for (Savepoint localSavepoint : this.logs)
/* 230 */       i += localSavepoint.commit();
/* 231 */     this.logs.clear();
/* 232 */     return i;
/*     */   }
/*     */ 
/*     */   private void logNotify(Procedure paramProcedure)
/*     */   {
/*     */     try {
/* 238 */       int i = 255;
/* 239 */       for (int j = 0; j < i; j++) {
/* 240 */         HashMap localHashMap = this.logNotifyTTables;
/* 241 */         this.logNotifyTTables = new HashMap();
/* 242 */         for (TTable localTTable : localHashMap.values()) {
/* 243 */           localTTable.logNotify();
/*     */         }
/*     */ 
/* 246 */         if (_real_commit_() == 0) {
/* 247 */           return;
/*     */         }
/*     */       }
/* 250 */       Trace.fatal("reach maxNestNotify. proc=" + paramProcedure.getClass().getName());
/*     */     } catch (Throwable localThrowable) {
/* 252 */       Trace.fatal("logNotify", localThrowable);
/*     */     }
/*     */ 
/* 255 */     _last_rollback_();
/*     */ 
/* 257 */     this.logNotifyTTables.clear();
/*     */   }
/*     */ 
/*     */   public static long getTotalCount()
/*     */   {
/* 267 */     return totalCount.get(); } 
/* 268 */   public static long getTotalFalse() { return totalFalse.get(); } 
/* 269 */   public static long getTotalException() { return totalException.get(); }
/*     */ 
/*     */   public void perform(Procedure paramProcedure) throws Throwable
/*     */   {
/*     */     try {
/* 274 */       counter.increment(paramProcedure.getClass().getName());
/* 275 */       totalCount.incrementAndGet();
/*     */ 
/* 278 */       Lock localLock = Xdb.getInstance().getTables().flushReadLock();
/* 279 */       localLock.lockInterruptibly();
/*     */       try {
/* 281 */         if (paramProcedure.call()) {
/* 282 */           if (_real_commit_() > 0) {
/* 283 */             logNotify(paramProcedure);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 288 */           counter.increment(paramProcedure.getClass().getName() + ".False");
/* 289 */           totalFalse.incrementAndGet();
/* 290 */           _last_rollback_();
/*     */         }
/*     */       }
/*     */       catch (Throwable localThrowable2) {
/* 294 */         _last_rollback_();
/* 295 */         throw localThrowable2;
/*     */       }
/*     */       finally {
/* 298 */         doneRunAllTask();
/* 299 */         finish();
/* 300 */         localLock.unlock();
/*     */       }
/*     */     }
/*     */     catch (Throwable localThrowable1) {
/* 304 */       paramProcedure.setException(localThrowable1);
/*     */ 
/* 306 */       counter.increment(paramProcedure.getClass().getName() + ".Exception");
/* 307 */       totalException.incrementAndGet();
/*     */ 
/* 309 */       Trace.log(paramProcedure.getConf().getTrace(), "Transaction Perform Exception", localThrowable1);
/* 310 */       throw localThrowable1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void tsend(long paramLong, Protocol paramProtocol)
/*     */   {
/* 337 */     tpost(new Procedure.SendToRole(paramLong, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void tsend(long paramLong1, long paramLong2, Protocol paramProtocol)
/*     */   {
/* 342 */     tpost(new Procedure.SendToRoles(paramLong1, paramLong2, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void tsend(Collection<Long> paramCollection, Protocol paramProtocol)
/*     */   {
/* 347 */     tpost(new Procedure.SendToRoles(paramCollection, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void tsendResponse(Protocol paramProtocol1, Protocol paramProtocol2)
/*     */   {
/* 352 */     tpost(new Procedure.SendResponse(paramProtocol1, paramProtocol2));
/*     */   }
/*     */ 
/*     */   public static void tbroadcast(Protocol paramProtocol, int paramInt)
/*     */   {
/* 357 */     tpost(new Procedure.Broadcast(paramProtocol, paramInt));
/*     */   }
/*     */ 
/*     */   public static void tsend(Xio paramXio, Protocol paramProtocol)
/*     */   {
/* 362 */     tpost(new Procedure.SendToXio(paramXio, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void texecute(Procedure paramProcedure)
/*     */   {
/* 367 */     tpost(new Procedure.ExecuteProcedure(paramProcedure));
/*     */   }
/*     */ 
/*     */   public static void texecute(Runnable paramRunnable)
/*     */   {
/* 372 */     tpost(new Procedure.ExecuteRunnable(paramRunnable));
/*     */   }
/*     */ 
/*     */   public static void tsendWhileCommit(long paramLong, Protocol paramProtocol)
/*     */   {
/* 378 */     tpostWhileCommit(new Procedure.SendToRole(paramLong, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void tsendWhileCommit(long paramLong1, long paramLong2, Protocol paramProtocol) {
/* 382 */     tpostWhileCommit(new Procedure.SendToRoles(paramLong1, paramLong2, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void tsendWhileCommit(Collection<Long> paramCollection, Protocol paramProtocol) {
/* 386 */     tpostWhileCommit(new Procedure.SendToRoles(paramCollection, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void tsendResponseWhileCommit(Protocol paramProtocol1, Protocol paramProtocol2) {
/* 390 */     tpostWhileCommit(new Procedure.SendResponse(paramProtocol1, paramProtocol2));
/*     */   }
/*     */ 
/*     */   public static void tbroadcastWhileCommit(Protocol paramProtocol, int paramInt) {
/* 394 */     tpostWhileCommit(new Procedure.Broadcast(paramProtocol, paramInt));
/*     */   }
/*     */ 
/*     */   public static void tsendWhileCommit(Xio paramXio, Protocol paramProtocol) {
/* 398 */     tpostWhileCommit(new Procedure.SendToXio(paramXio, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void texecuteWhileCommit(Procedure paramProcedure) {
/* 402 */     tpostWhileCommit(new Procedure.ExecuteProcedure(paramProcedure));
/*     */   }
/*     */ 
/*     */   public static void texecuteWhileCommit(Runnable paramRunnable) {
/* 406 */     tpostWhileCommit(new Procedure.ExecuteRunnable(paramRunnable));
/*     */   }
/*     */ 
/*     */   public static void tsendWhileRollback(long paramLong, Protocol paramProtocol)
/*     */   {
/* 411 */     tpostWhileRollback(new Procedure.SendToRole(paramLong, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void tsendWhileRollback(long paramLong1, long paramLong2, Protocol paramProtocol) {
/* 415 */     tpostWhileRollback(new Procedure.SendToRoles(paramLong1, paramLong2, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void tsendWhileRollback(Collection<Long> paramCollection, Protocol paramProtocol) {
/* 419 */     tpostWhileRollback(new Procedure.SendToRoles(paramCollection, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void tsendResponseWhileRollback(Protocol paramProtocol1, Protocol paramProtocol2) {
/* 423 */     tpostWhileRollback(new Procedure.SendResponse(paramProtocol1, paramProtocol2));
/*     */   }
/*     */ 
/*     */   public static void tbroadcastWhileRollback(Protocol paramProtocol, int paramInt) {
/* 427 */     tpostWhileRollback(new Procedure.Broadcast(paramProtocol, paramInt));
/*     */   }
/*     */ 
/*     */   public static void tsendWhileRollback(Xio paramXio, Protocol paramProtocol) {
/* 431 */     tpostWhileRollback(new Procedure.SendToXio(paramXio, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void texecuteWhileRollback(Procedure paramProcedure) {
/* 435 */     tpostWhileRollback(new Procedure.ExecuteProcedure(paramProcedure));
/*     */   }
/*     */ 
/*     */   public static void texecuteWhileRollback(Runnable paramRunnable) {
/* 439 */     tpostWhileRollback(new Procedure.ExecuteRunnable(paramRunnable));
/*     */   }
/*     */ 
/*     */   private static void tpostWhileCommit(Procedure.Task paramTask)
/*     */   {
/* 444 */     paramTask.setExpected(true);
/* 445 */     currentSavepoint().add(new LogKey(new XBean(null, null), ""), paramTask);
/* 446 */     tpost(paramTask);
/*     */   }
/*     */ 
/*     */   private static void tpostWhileRollback(Procedure.Task paramTask)
/*     */   {
/* 451 */     paramTask.setExpected(false);
/* 452 */     currentSavepoint().add(new LogKey(new XBean(null, null), ""), paramTask);
/* 453 */     tpost(paramTask);
/*     */   }
/*     */ 
/*     */   private static void tpost(Procedure.Task paramTask)
/*     */   {
/* 458 */     current()._ttasks.add(paramTask);
/*     */   }
/*     */ 
/*     */   private void doneRunAllTask()
/*     */   {
/* 466 */     for (Procedure.Task localTask : this._ttasks)
/*     */     {
/*     */       try
/*     */       {
/* 470 */         localTask.process();
/*     */       }
/*     */       catch (Throwable localThrowable) {
/* 473 */         Trace.error("Transaction.runTasks", localThrowable);
/*     */       }
/*     */     }
/* 476 */     this._ttasks.clear();
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Transaction
 * JD-Core Version:    0.6.2
 */