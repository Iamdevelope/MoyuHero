package xdb;

import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;

public abstract interface XdbMBean
{
  public abstract void shutdown(String paramString);

  public abstract int getAngleInterruptCount();

  public abstract long getTransactionCount();

  public abstract long getTransactionFalse();

  public abstract long getTransactionException();

  public abstract void testAlive(long paramLong)
    throws InterruptedException, ExecutionException, TimeoutException;

  public abstract Map<String, AtomicInteger> top(String paramString1, String paramString2);
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.XdbMBean
 * JD-Core Version:    0.6.2
 */