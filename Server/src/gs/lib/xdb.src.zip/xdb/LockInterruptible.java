/*    */ package xdb;
/*    */ 
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ 
/*    */ public final class LockInterruptible extends ReentrantLock
/*    */ {
/*    */   private static final long serialVersionUID = -3127211387464574647L;
/*    */ 
/*    */   public LockInterruptible()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LockInterruptible(boolean paramBoolean)
/*    */   {
/* 41 */     super(paramBoolean);
/*    */   }
/*    */ 
/*    */   public void lock()
/*    */   {
/*    */     try {
/* 47 */       super.lockInterruptibly();
/*    */     } catch (InterruptedException localInterruptedException) {
/* 49 */       if (Worker.angelInterrupted())
/* 50 */         throw new XLockDead();
/* 51 */       throw new XLockInterrupted("lock");
/*    */     }
/*    */   }
/*    */ 
/*    */   public void lockInterruptibly()
/*    */   {
/*    */     try {
/* 58 */       super.lockInterruptibly();
/*    */     } catch (InterruptedException localInterruptedException) {
/* 60 */       if (Worker.angelInterrupted())
/* 61 */         throw new XLockDead();
/* 62 */       throw new XLockInterrupted("lockInterruptibly");
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean tryLock(long paramLong, TimeUnit paramTimeUnit)
/*    */   {
/*    */     try {
/* 69 */       return super.tryLock(paramLong, paramTimeUnit);
/*    */     }
/*    */     catch (InterruptedException localInterruptedException) {
/*    */     }
/* 73 */     throw new XLockInterrupted("tryLock");
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.LockInterruptible
 * JD-Core Version:    0.6.2
 */