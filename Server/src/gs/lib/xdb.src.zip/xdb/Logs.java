/*     */ package xdb;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NavigableMap;
/*     */ import java.util.Set;
/*     */ import xdb.logs.LogList;
/*     */ import xdb.logs.LogMap;
/*     */ import xdb.logs.LogNavigableMap;
/*     */ import xdb.logs.LogNotify;
/*     */ import xdb.logs.LogSet;
/*     */ import xdb.util.SetX;
/*     */ 
/*     */ public final class Logs
/*     */ {
/*     */   public static void logIf(LogKey paramLogKey)
/*     */   {
/*  15 */     Savepoint localSavepoint = Transaction.currentSavepoint();
/*  16 */     if (null == localSavepoint.get(paramLogKey)) {
/*  17 */       Log localLog = paramLogKey.create();
/*  18 */       localSavepoint.add(paramLogKey, localLog);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static <E> List<E> logList(LogKey paramLogKey, List<E> paramList)
/*     */   {
/*  25 */     Map localMap = Transaction.current().wrappers;
/*  26 */     Object localObject = localMap.get(paramLogKey);
/*  27 */     if (null == localObject) {
/*  28 */       localLogList = new LogList(paramLogKey, paramList);
/*  29 */       localMap.put(paramLogKey, localLogList);
/*  30 */       return localLogList;
/*     */     }
/*     */ 
/*  33 */     LogList localLogList = (LogList)localObject;
/*  34 */     return localLogList;
/*     */   }
/*     */ 
/*     */   public static <K, V> Map<K, V> logMap(LogKey paramLogKey, Map<K, V> paramMap) {
/*  38 */     Map localMap = Transaction.current().wrappers;
/*  39 */     Object localObject = localMap.get(paramLogKey);
/*  40 */     if (null == localObject) {
/*  41 */       localLogMap = new LogMap(paramLogKey, paramMap);
/*  42 */       localMap.put(paramLogKey, localLogMap);
/*  43 */       return localLogMap;
/*     */     }
/*     */ 
/*  46 */     LogMap localLogMap = (LogMap)localObject;
/*  47 */     return localLogMap;
/*     */   }
/*     */ 
/*     */   public static <K, V> NavigableMap<K, V> logNavigableMap(LogKey paramLogKey, NavigableMap<K, V> paramNavigableMap) {
/*  51 */     Map localMap = Transaction.current().wrappers;
/*  52 */     Object localObject = localMap.get(paramLogKey);
/*  53 */     if (null == localObject) {
/*  54 */       localLogNavigableMap = new LogNavigableMap(paramLogKey, paramNavigableMap);
/*  55 */       localMap.put(paramLogKey, localLogNavigableMap);
/*  56 */       return localLogNavigableMap;
/*     */     }
/*     */ 
/*  59 */     LogNavigableMap localLogNavigableMap = (LogNavigableMap)localObject;
/*  60 */     return localLogNavigableMap;
/*     */   }
/*     */ 
/*     */   public static <E> Set<E> logSet(LogKey paramLogKey, SetX<E> paramSetX) {
/*  64 */     Map localMap = Transaction.current().wrappers;
/*  65 */     Object localObject = localMap.get(paramLogKey);
/*  66 */     if (null == localObject) {
/*  67 */       localLogSet = new LogSet(paramLogKey, paramSetX);
/*  68 */       localMap.put(paramLogKey, localLogSet);
/*  69 */       return localLogSet;
/*     */     }
/*     */ 
/*  72 */     LogSet localLogSet = (LogSet)localObject;
/*  73 */     return localLogSet;
/*     */   }
/*     */ 
/*     */   public static boolean isImmutable(Class paramClass)
/*     */   {
/*  83 */     return (paramClass == String.class) || (paramClass == Integer.class) || (paramClass == Long.class) || (paramClass == Boolean.class) || (paramClass == Short.class) || (paramClass == Byte.class) || (paramClass == Character.class) || (paramClass == Float.class) || (paramClass == Double.class) || (paramClass.isPrimitive());
/*     */   }
/*     */ 
/*     */   public static boolean isImmutable(Object paramObject)
/*     */   {
/*  98 */     return isImmutable(paramObject.getClass());
/*     */   }
/*     */ 
/*     */   public static void xdbParent(Object paramObject, XBean paramXBean, String paramString, boolean paramBoolean)
/*     */   {
/* 113 */     if (null == paramObject) {
/* 114 */       throw new NullPointerException();
/*     */     }
/* 116 */     if ((paramObject instanceof Bean))
/*     */     {
/* 118 */       if (!(paramObject instanceof XBean)) {
/* 119 */         throw new XManagedError();
/*     */       }
/* 121 */       ((XBean)paramObject).xdbParent(paramXBean, paramString, paramBoolean);
/* 122 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void xdbParent(Object paramObject, XBean paramXBean, String paramString)
/*     */   {
/* 134 */     xdbParent(paramObject, paramXBean, paramString, true);
/*     */   }
/*     */ 
/*     */   public static void xdbManagedCheck(Object paramObject)
/*     */   {
/* 145 */     if (null == paramObject) {
/* 146 */       throw new NullPointerException();
/*     */     }
/* 148 */     if ((paramObject instanceof Bean))
/*     */     {
/* 150 */       if (!(paramObject instanceof XBean)) {
/* 151 */         throw new XManagedError();
/*     */       }
/* 153 */       if (((XBean)paramObject).xdbManaged()) {
/* 154 */         throw new XManagedError();
/*     */       }
/* 156 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void logNotify(XBean paramXBean, LogNotify paramLogNotify)
/*     */   {
/* 168 */     paramXBean.xdbLogNotify(paramLogNotify);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Logs
 * JD-Core Version:    0.6.2
 */