/*     */ package xdb;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ public final class Lockeys
/*     */ {
/*  18 */   private final Locks locks = new Locks();
/*     */ 
/*  47 */   private static Lockeys instance = new Lockeys();
/*     */ 
/* 136 */   private final Map<String, Integer> lockIdMap = new HashMap();
/* 137 */   private int autoId = 0;
/* 138 */   private final Lock syncIdMap = new ReentrantLock();
/*     */ 
/*     */   public final boolean exist(String paramString, Object paramObject)
/*     */   {
/*  27 */     return this.locks.exist(new Lockey(paramString, getLockId(paramString), paramObject));
/*     */   }
/*     */ 
/*     */   private final Lockey get(Lockey paramLockey)
/*     */   {
/*  32 */     Transaction localTransaction = Transaction.current();
/*  33 */     if (localTransaction != null) {
/*  34 */       Lockey localLockey = localTransaction.get(paramLockey);
/*  35 */       if (localLockey != null)
/*  36 */         return localLockey;
/*     */     }
/*  38 */     return this.locks.get(paramLockey);
/*     */   }
/*     */ 
/*     */   public final int size() {
/*  42 */     return this.locks.size();
/*     */   }
/*     */ 
/*     */   public static Lockeys getInstance()
/*     */   {
/*  50 */     return instance;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static Lockey get(String paramString, Object paramObject)
/*     */   {
/*  62 */     return instance.get(new Lockey(paramString, instance.getLockId(paramString), paramObject));
/*     */   }
/*     */ 
/*     */   static Lockey get(String paramString, int paramInt, Object paramObject)
/*     */   {
/*  67 */     return instance.get(new Lockey(paramString, paramInt, paramObject));
/*     */   }
/*     */ 
/*     */   public static Lockey get(TTable<?, ?> paramTTable, Object paramObject)
/*     */   {
/*  77 */     return get(paramTTable.getLockName(), paramTTable.getLockId(), paramObject);
/*     */   }
/*     */ 
/*     */   public static Lockey[] get(TTable<?, ?> paramTTable, Object[] paramArrayOfObject)
/*     */   {
/*  88 */     String str = paramTTable.getLockName();
/*  89 */     int i = paramTTable.getLockId();
/*  90 */     Lockey[] arrayOfLockey = new Lockey[paramArrayOfObject.length];
/*     */ 
/*  92 */     int j = 0;
/*  93 */     for (Object localObject : paramArrayOfObject) {
/*  94 */       arrayOfLockey[(j++)] = get(str, i, localObject);
/*     */     }
/*  96 */     return arrayOfLockey;
/*     */   }
/*     */ 
/*     */   public static Lockey[] get(TTable<?, ?> paramTTable, Collection<?> paramCollection)
/*     */   {
/* 106 */     String str = paramTTable.getLockName();
/* 107 */     int i = paramTTable.getLockId();
/* 108 */     Lockey[] arrayOfLockey = new Lockey[paramCollection.size()];
/*     */ 
/* 110 */     int j = 0;
/* 111 */     for (Iterator localIterator = paramCollection.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 112 */       arrayOfLockey[(j++)] = get(str, i, localObject);
/*     */     }
/* 114 */     return arrayOfLockey;
/*     */   }
/*     */ 
/*     */   public static void lock(TTable<?, ?> paramTTable, Collection<?> paramCollection) {
/* 118 */     lock(get(paramTTable, paramCollection));
/*     */   }
/*     */ 
/*     */   public static void lock(Lockey[] paramArrayOfLockey)
/*     */   {
/* 127 */     Arrays.sort(paramArrayOfLockey);
/* 128 */     for (Lockey localLockey : paramArrayOfLockey)
/*     */     {
/* 130 */       Transaction.current().add(localLockey);
/*     */     }
/*     */   }
/*     */ 
/*     */   final int getLockId(String paramString)
/*     */   {
/* 147 */     this.syncIdMap.lock();
/*     */     try {
/* 149 */       Integer localInteger = (Integer)this.lockIdMap.get(paramString);
/*     */       int i;
/* 150 */       if (null != localInteger)
/* 151 */         return localInteger.intValue();
/* 152 */       this.autoId += 1;
/* 153 */       this.lockIdMap.put(paramString, Integer.valueOf(this.autoId));
/* 154 */       return this.autoId;
/*     */     } finally {
/* 156 */       this.syncIdMap.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   final void initializeLockIdMap(Collection<Table> paramCollection)
/*     */   {
/* 166 */     HashSet localHashSet = new HashSet();
/* 167 */     for (Table localTable : paramCollection) {
/* 168 */       if ((localTable instanceof TTable)) {
/* 169 */         TTable localTTable = (TTable)localTable;
/* 170 */         localHashSet.add(localTTable.getLockName());
/*     */       }
/*     */     }
/* 173 */     initializeLockIdMap((String[])localHashSet.toArray(new String[localHashSet.size()]));
/*     */   }
/*     */ 
/*     */   final void initializeLockIdMap(String[] paramArrayOfString)
/*     */   {
/* 178 */     Arrays.sort(paramArrayOfString);
/* 179 */     for (String str : paramArrayOfString)
/* 180 */       getLockId(str);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Lockeys
 * JD-Core Version:    0.6.2
 */