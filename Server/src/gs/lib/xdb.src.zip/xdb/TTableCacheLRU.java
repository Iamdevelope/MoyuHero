/*     */ package xdb;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ public final class TTableCacheLRU<K, V> extends TTableCache<K, V>
/*     */ {
/*     */   private LinkedHashMap<K, TRecord<K, V>> lru;
/*     */   private final TTableCacheLRU<K, V>.Cleaner cleaner;
/*     */ 
/*     */   public TTableCacheLRU()
/*     */   {
/*  44 */     this.cleaner = new Cleaner(null);
/*     */   }
/*     */ 
/*     */   void initialize(TTable<K, V> paramTTable, TableConf paramTableConf)
/*     */   {
/*  24 */     super.initialize(paramTTable, paramTableConf);
/*     */ 
/*  26 */     this.lru = new LinkedHashMap(16, 0.75F, true)
/*     */     {
/*     */       static final long serialVersionUID = 3287086177585999328L;
/*     */ 
/*     */       protected boolean removeEldestEntry(Map.Entry<K, TRecord<K, V>> paramAnonymousEntry) {
/*  31 */         int i = TTableCacheLRU.this.getCapacity();
/*  32 */         if (i <= 0) {
/*  33 */           return false;
/*     */         }
/*  35 */         if (size() <= i) {
/*  36 */           return false;
/*     */         }
/*  38 */         TTableCacheLRU.this.cleaner.start();
/*  39 */         return false;
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  97 */     if (super.getTable().getPersistence() != Table.Persistence.MEMORY)
/*  98 */       throw new UnsupportedOperationException();
/*  99 */     synchronized (this.lru) {
/* 100 */       this.lru.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   int getSize()
/*     */   {
/* 107 */     synchronized (this.lru) {
/* 108 */       return this.lru.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void walk(CacheQuery<K, V> paramCacheQuery)
/*     */   {
/*     */     Object[] arrayOfObject;
/* 115 */     synchronized (this.lru) {
/* 116 */       arrayOfObject = this.lru.values().toArray();
/*     */     }
/* 118 */     super._walk_notify_query(arrayOfObject, paramCacheQuery);
/*     */   }
/*     */ 
/*     */   TRecord<K, V> get(K paramK)
/*     */   {
/* 131 */     synchronized (this.lru) {
/* 132 */       return (TRecord)this.lru.get(paramK);
/*     */     }
/*     */   }
/*     */ 
/*     */   void addNoLog(K paramK, TRecord<K, V> paramTRecord)
/*     */   {
/* 138 */     synchronized (this.lru) {
/* 139 */       if (this.lru.containsKey(paramK))
/* 140 */         throw new XError("cache.addNoLog duplicate record");
/* 141 */       this.lru.put(paramK, paramTRecord);
/*     */     }
/*     */   }
/*     */ 
/*     */   void add(K paramK, TRecord<K, V> paramTRecord)
/*     */   {
/* 148 */     synchronized (this.lru) {
/* 149 */       if (this.lru.containsKey(paramK))
/* 150 */         throw new XError("cache.add duplicate record");
/* 151 */       super.logAddRemove(paramK, paramTRecord);
/* 152 */       this.lru.put(paramK, paramTRecord);
/*     */     }
/*     */   }
/*     */ 
/*     */   TRecord<K, V> remove(Object paramObject)
/*     */   {
/* 159 */     Transaction localTransaction = Transaction.current();
/* 160 */     if (null != localTransaction)
/* 161 */       localTransaction.rmvCachedTRecord(super.getTable(), paramObject);
/* 162 */     synchronized (this.lru) {
/* 163 */       return (TRecord)this.lru.remove(paramObject);
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class Cleaner
/*     */     implements Runnable
/*     */   {
/*  47 */     private boolean working = false;
/*     */ 
/*     */     private Cleaner() {  } 
/*  50 */     public void start() { synchronized (TTableCacheLRU.this.lru) {
/*  51 */         if (false == this.working) {
/*  52 */           Xdb.executor().execute(this);
/*  53 */           this.working = true;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*  60 */       Lock localLock = Xdb.getInstance().getTables().flushReadLock();
/*  61 */       localLock.lock();
/*     */       try {
/*  63 */         Object[] arrayOfObject = null;
/*     */         int i;
/*     */         int j;
/*     */         Object localObject2;
/*  64 */         synchronized (TTableCacheLRU.this.lru)
/*     */         {
/*     */           try {
/*  67 */             i = TTableCacheLRU.this.getCapacity();
/*  68 */             j = TTableCacheLRU.this.lru.size();
/*  69 */             if (j > i) {
/*  70 */               int k = Math.min(j - i + 255, j);
/*  71 */               arrayOfObject = new Object[k];
/*  72 */               localObject2 = TTableCacheLRU.this.lru.entrySet().iterator();
/*  73 */               for (int m = 0; m < k; m++)
/*  74 */                 arrayOfObject[m] = ((Map.Entry)((Iterator)localObject2).next()).getValue();
/*     */             }
/*     */           }
/*     */           finally {
/*  78 */             this.working = false;
/*     */           }
/*     */         }
/*  81 */         if (null != arrayOfObject)
/*  82 */           for (Object localObject1 : arrayOfObject)
/*     */           {
/*  84 */             localObject2 = (TRecord)localObject1;
/*  85 */             if (false == TTableCacheLRU.this.tryRemoveRecord((TRecord)localObject2))
/*     */               break;
/*     */           }
/*     */       }
/*     */       finally {
/*  90 */         localLock.unlock();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.TTableCacheLRU
 * JD-Core Version:    0.6.2
 */