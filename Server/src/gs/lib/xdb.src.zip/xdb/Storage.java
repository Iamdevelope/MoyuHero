/*     */ package xdb;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import com.goldhuman.Common.Octets;
/*     */ import java.io.File;
/*     */ import java.util.Iterator;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ public abstract class Storage
/*     */ {
/*  32 */   private final Lock lock = new ReentrantLock();
/*     */   private final File file;
/*     */   private final Logger logger;
/*     */   private long handle;
/*     */ 
/*     */   public final void lock()
/*     */   {
/*  37 */     this.lock.lock();
/*     */   }
/*     */ 
/*     */   public final void lockInterruptibly() {
/*     */     try {
/*  42 */       this.lock.lockInterruptibly();
/*     */     } catch (InterruptedException localInterruptedException) {
/*  44 */       throw new XLockInterrupted("Storage:" + this.file.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void unlock() {
/*  49 */     this.lock.unlock();
/*     */   }
/*     */ 
/*     */   int marshalN()
/*     */   {
/*  54 */     return 0; } 
/*  55 */   int marshal0() { return 0; } 
/*  56 */   int snapshot() { return 0; } 
/*  57 */   int flush() { return 0; }
/*     */ 
/*     */ 
/*     */   public Storage(Logger paramLogger, XdbConf paramXdbConf, TableConf paramTableConf)
/*     */   {
/*  69 */     this(paramLogger, paramXdbConf.getTableHome(), paramTableConf.getName(), paramTableConf.getCacheHigh(), paramTableConf.getCacheLow());
/*     */   }
/*     */ 
/*     */   public Storage(Logger paramLogger, File paramFile, String paramString, int paramInt1, int paramInt2)
/*     */   {
/*  74 */     this.file = new File(paramFile, paramString);
/*     */ 
/*  76 */     this.handle = open(paramLogger.getHandle(), this.file.toString(), paramInt1, paramInt2);
/*  77 */     if (0L == this.handle)
/*  78 */       throw new XError("Storage open faild : " + this.file);
/*  79 */     this.logger = paramLogger;
/*     */   }
/*     */ 
/*     */   public final Logger getLogger() {
/*  83 */     return this.logger;
/*     */   }
/*     */ 
/*     */   public final boolean exist(OctetsStream paramOctetsStream)
/*     */   {
/*  92 */     this.lock.lock();
/*     */     try {
/*  94 */       if (0L == this.handle) {
/*  95 */         throw new XError("storage has closed");
/*     */       }
/*  97 */       return exist(this.handle, paramOctetsStream.array(), paramOctetsStream.size());
/*     */     } finally {
/*  99 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final OctetsStream find(OctetsStream paramOctetsStream)
/*     */   {
/* 107 */     this.lock.lock();
/*     */     try {
/* 109 */       if (0L == this.handle) {
/* 110 */         throw new XError("storage has closed");
/*     */       }
/* 112 */       byte[] arrayOfByte = find(this.handle, paramOctetsStream.array(), paramOctetsStream.size());
/*     */       OctetsStream localOctetsStream;
/* 113 */       if (null == arrayOfByte) {
/* 114 */         return null;
/*     */       }
/* 116 */       return OctetsStream.wrap(Octets.wrap(arrayOfByte, arrayOfByte.length));
/*     */     }
/*     */     finally {
/* 119 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void replaceUnsafe(OctetsStream paramOctetsStream1, OctetsStream paramOctetsStream2)
/*     */   {
/* 128 */     this.lock.lock();
/*     */     try {
/* 130 */       if (0L == this.handle) {
/* 131 */         throw new XError("storage has closed");
/*     */       }
/* 133 */       if (false == replace(this.handle, paramOctetsStream1.array(), paramOctetsStream1.size(), paramOctetsStream2.array(), paramOctetsStream2.size()))
/* 134 */         throw new XError("replace faild");
/*     */     } finally {
/* 136 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void insertUnsafe(OctetsStream paramOctetsStream1, OctetsStream paramOctetsStream2)
/*     */   {
/* 145 */     this.lock.lock();
/*     */     try {
/* 147 */       if (0L == this.handle) {
/* 148 */         throw new XError("storage has closed");
/*     */       }
/* 150 */       if (false == insert(this.handle, paramOctetsStream1.array(), paramOctetsStream1.size(), paramOctetsStream2.array(), paramOctetsStream2.size()))
/* 151 */         throw new XError("insert faild");
/*     */     } finally {
/* 153 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void removeUnsafe(OctetsStream paramOctetsStream)
/*     */   {
/* 162 */     this.lock.lock();
/*     */     try {
/* 164 */       if (0L == this.handle) {
/* 165 */         throw new XError("storage has closed");
/*     */       }
/* 167 */       if (false == remove(this.handle, paramOctetsStream.array(), paramOctetsStream.size()))
/* 168 */         throw new XError("remove faild");
/*     */     } finally {
/* 170 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean replace(OctetsStream paramOctetsStream1, OctetsStream paramOctetsStream2)
/*     */   {
/* 179 */     if (0L == this.handle) {
/* 180 */       throw new XError("storage has closed");
/*     */     }
/* 182 */     return replace(this.handle, paramOctetsStream1.array(), paramOctetsStream1.size(), paramOctetsStream2.array(), paramOctetsStream2.size());
/*     */   }
/*     */ 
/*     */   public boolean insert(OctetsStream paramOctetsStream1, OctetsStream paramOctetsStream2)
/*     */   {
/* 190 */     if (0L == this.handle) {
/* 191 */       throw new XError("storage has closed");
/*     */     }
/* 193 */     return insert(this.handle, paramOctetsStream1.array(), paramOctetsStream1.size(), paramOctetsStream2.array(), paramOctetsStream2.size());
/*     */   }
/*     */ 
/*     */   public boolean remove(OctetsStream paramOctetsStream)
/*     */   {
/* 201 */     if (0L == this.handle) {
/* 202 */       throw new XError("storage has closed");
/*     */     }
/* 204 */     return remove(this.handle, paramOctetsStream.array(), paramOctetsStream.size());
/*     */   }
/*     */ 
/*     */   public void walk(IWalk paramIWalk)
/*     */   {
/* 211 */     this.lock.lock();
/*     */     try {
/* 213 */       if (0L == this.handle)
/* 214 */         throw new XError("storage has closed");
/* 215 */       walk(this.handle, paramIWalk);
/*     */     } finally {
/* 217 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void browse(IWalk paramIWalk, int paramInt)
/*     */   {
/* 225 */     if (0L == this.handle)
/* 226 */       throw new XError("storage has closed");
/* 227 */     browse(this.handle, paramIWalk, paramInt);
/*     */   }
/*     */ 
/*     */   public void _walk(IWalk paramIWalk)
/*     */   {
/* 244 */     this.lock.lock();
/*     */     try {
/* 246 */       if (0L == this.handle)
/* 247 */         throw new XError("storage has closed");
/* 248 */       _walk(this.handle, paramIWalk);
/*     */     } finally {
/* 250 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void _browse(IWalk paramIWalk, int paramInt)
/*     */   {
/* 258 */     if (0L == this.handle)
/* 259 */       throw new XError("storage has closed");
/* 260 */     _browse(this.handle, paramIWalk, paramInt);
/*     */   }
/*     */ 
/*     */   public final OctetsStream _find(OctetsStream paramOctetsStream)
/*     */   {
/* 267 */     this.lock.lock();
/*     */     try {
/* 269 */       if (0L == this.handle) {
/* 270 */         throw new XError("storage has closed");
/*     */       }
/* 272 */       byte[] arrayOfByte = _find(this.handle, paramOctetsStream.array(), paramOctetsStream.size());
/*     */       OctetsStream localOctetsStream;
/* 273 */       if (null == arrayOfByte) {
/* 274 */         return null;
/*     */       }
/* 276 */       return OctetsStream.wrap(Octets.wrap(arrayOfByte, arrayOfByte.length));
/*     */     }
/*     */     finally {
/* 279 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean _replace(OctetsStream paramOctetsStream1, OctetsStream paramOctetsStream2)
/*     */   {
/* 289 */     if (0L == this.handle) {
/* 290 */       throw new XError("storage has closed");
/*     */     }
/* 292 */     return _replace(this.handle, paramOctetsStream1.array(), paramOctetsStream1.size(), paramOctetsStream2.array(), paramOctetsStream2.size());
/*     */   }
/*     */ 
/*     */   public boolean _insert(OctetsStream paramOctetsStream1, OctetsStream paramOctetsStream2)
/*     */   {
/* 301 */     if (0L == this.handle) {
/* 302 */       throw new XError("storage has closed");
/*     */     }
/* 304 */     return _insert(this.handle, paramOctetsStream1.array(), paramOctetsStream1.size(), paramOctetsStream2.array(), paramOctetsStream2.size());
/*     */   }
/*     */ 
/*     */   public static final OctetsStream _compress(OctetsStream paramOctetsStream)
/*     */   {
/* 311 */     byte[] arrayOfByte = _compress(paramOctetsStream.array(), paramOctetsStream.size());
/* 312 */     return OctetsStream.wrap(Octets.wrap(arrayOfByte, arrayOfByte.length));
/*     */   }
/*     */ 
/*     */   public static final OctetsStream _uncompress(OctetsStream paramOctetsStream)
/*     */   {
/* 319 */     byte[] arrayOfByte = _uncompress(paramOctetsStream.array(), paramOctetsStream.size());
/* 320 */     return OctetsStream.wrap(Octets.wrap(arrayOfByte, arrayOfByte.length));
/*     */   }
/*     */ 
/*     */   public final OctetsStream firstKey()
/*     */   {
/* 328 */     this.lock.lock();
/*     */     try {
/* 330 */       if (0L == this.handle) {
/* 331 */         throw new XError("storage has closed");
/*     */       }
/* 333 */       byte[] arrayOfByte = firstKey(this.handle);
/*     */       OctetsStream localOctetsStream;
/* 334 */       if (null == arrayOfByte)
/* 335 */         return null;
/* 336 */       return OctetsStream.wrap(Octets.wrap(arrayOfByte, arrayOfByte.length));
/*     */     } finally {
/* 338 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final OctetsStream nextKey(OctetsStream paramOctetsStream)
/*     */   {
/* 348 */     this.lock.lock();
/*     */     try {
/* 350 */       if (0L == this.handle) {
/* 351 */         throw new XError("storage has closed");
/*     */       }
/* 353 */       byte[] arrayOfByte = nextKey(this.handle, paramOctetsStream.array(), paramOctetsStream.size());
/*     */       OctetsStream localOctetsStream;
/* 354 */       if (null == arrayOfByte)
/* 355 */         return null;
/* 356 */       return OctetsStream.wrap(Octets.wrap(arrayOfByte, arrayOfByte.length));
/*     */     } finally {
/* 358 */       this.lock.unlock(); }  } 
/*     */   private native void walk(long paramLong, IWalk paramIWalk);
/*     */ 
/*     */   private native void browse(long paramLong, IWalk paramIWalk, int paramInt);
/*     */ 
/*     */   private native boolean exist(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*     */ 
/*     */   private native byte[] find(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*     */ 
/*     */   private native boolean replace(long paramLong, byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2);
/*     */ 
/*     */   private native boolean insert(long paramLong, byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2);
/*     */ 
/*     */   private native boolean remove(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*     */ 
/*     */   private native long open(long paramLong, String paramString, int paramInt1, int paramInt2);
/*     */ 
/*     */   private native void close(long paramLong);
/*     */ 
/*     */   private native void snapshot_create(long paramLong);
/*     */ 
/*     */   private native void snapshot_release(long paramLong);
/*     */ 
/*     */   private native void _walk(long paramLong, IWalk paramIWalk);
/*     */ 
/*     */   private native void _browse(long paramLong, IWalk paramIWalk, int paramInt);
/*     */ 
/*     */   private native byte[] _find(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*     */ 
/*     */   private native boolean _replace(long paramLong, byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2);
/*     */ 
/*     */   private native boolean _insert(long paramLong, byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2);
/*     */ 
/*     */   private native byte[] firstKey(long paramLong);
/*     */ 
/*     */   private native byte[] nextKey(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*     */ 
/*     */   public static native byte[] _compress(byte[] paramArrayOfByte, int paramInt);
/*     */ 
/*     */   public static native byte[] _uncompress(byte[] paramArrayOfByte, int paramInt);
/*     */ 
/* 399 */   public final File getFile() { return this.file; }
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 406 */     if (0L == this.handle)
/* 407 */       throw new XError("storage has closed");
/* 408 */     close(this.handle);
/* 409 */     this.handle = 0L;
/*     */   }
/*     */ 
/*     */   protected void finalize() throws Throwable
/*     */   {
/* 414 */     if (0L != this.handle)
/* 415 */       close(this.handle);
/* 416 */     super.finalize();
/*     */   }
/*     */ 
/*     */   public final void snapshot_create()
/*     */   {
/* 423 */     if (0L == this.handle)
/* 424 */       throw new XError("storage has closed");
/* 425 */     snapshot_create(this.handle);
/*     */   }
/*     */ 
/*     */   public final void snapshot_release()
/*     */   {
/* 432 */     if (0L == this.handle)
/* 433 */       throw new XError("storage has closed");
/* 434 */     snapshot_release(this.handle);
/*     */   }
/*     */ 
/*     */   public final Iterator<OctetsStream> iterator()
/*     */   {
/* 473 */     return new KeyIterator();
/*     */   }
/*     */ 
/*     */   private class KeyIterator
/*     */     implements Iterator<OctetsStream>
/*     */   {
/* 438 */     private OctetsStream cur = null;
/*     */     private OctetsStream next;
/*     */ 
/*     */     KeyIterator()
/*     */     {
/* 442 */       this.next = Storage.this.firstKey();
/*     */     }
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/* 447 */       return null != this.next;
/*     */     }
/*     */ 
/*     */     public OctetsStream next()
/*     */     {
/* 452 */       if (null == this.cur)
/* 453 */         throw new IllegalStateException();
/* 454 */       this.cur = this.next;
/* 455 */       this.next = Storage.this.nextKey(this.cur);
/* 456 */       return this.cur;
/*     */     }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 461 */       if (null == this.cur)
/* 462 */         throw new IllegalStateException();
/* 463 */       Storage.this.remove(this.cur);
/* 464 */       this.cur = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface IWalk
/*     */   {
/*     */     public abstract boolean onRecord(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Storage
 * JD-Core Version:    0.6.2
 */