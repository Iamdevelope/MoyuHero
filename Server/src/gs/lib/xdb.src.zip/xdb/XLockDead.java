package xdb;

public class XLockDead extends XError
{
  static final long serialVersionUID = -2462357962362386409L;
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.XLockDead
 * JD-Core Version:    0.6.2
 */