/*     */ package xdb;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.MarshalException;
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*     */ import xdb.util.Misc;
/*     */ import xio.MarshalError;
/*     */ 
/*     */ final class TStorage<K, V> extends Storage
/*     */ {
/*  46 */   private ConcurrentMap<K, TRecord<K, V>> changed = Misc.newConcurrentMap();
/*  47 */   private ConcurrentMap<K, TRecord<K, V>> marshal = Misc.newConcurrentMap();
/*  48 */   private ConcurrentMap<K, TRecord<K, V>> snapshot = Misc.newConcurrentMap();
/*  49 */   private final ReentrantReadWriteLock snapshotClearLock = new ReentrantReadWriteLock();
/*     */ 
/*  71 */   private volatile long countMarshalN = 0L;
/*  72 */   private volatile long countMarshal0 = 0L;
/*  73 */   private volatile long countFlush = 0L;
/*  74 */   private volatile long countSnapshot = 0L;
/*  75 */   private volatile long countMarshalNTryFail = 0L;
/*     */ 
/*  77 */   volatile long flushKeySize = 0L;
/*  78 */   volatile long flushValueSize = 0L;
/*     */ 
/*     */   TStorage(Logger paramLogger, XdbConf paramXdbConf, TableConf paramTableConf)
/*     */   {
/*  23 */     super(paramLogger, paramXdbConf, paramTableConf);
/*     */   }
/*     */ 
/*     */   void onRecordChange(TRecord<K, V> paramTRecord)
/*     */   {
/*  55 */     if (paramTRecord.getState() == TRecord.State.REMOVE) {
/*  56 */       this.changed.remove(paramTRecord.getKey());
/*  57 */       this.marshal.remove(paramTRecord.getKey());
/*     */     } else {
/*  59 */       this.changed.put(paramTRecord.getKey(), paramTRecord);
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean isChangedOrUnknown(K paramK)
/*     */   {
/*  67 */     return (this.changed.containsKey(paramK)) || (this.marshal.containsKey(paramK));
/*     */   }
/*     */ 
/*     */   int marshalN()
/*     */   {
/* 108 */     int i = 0;
/* 109 */     int j = 0;
/*     */ 
/* 112 */     for (Iterator localIterator = this.changed.values().iterator(); localIterator.hasNext(); )
/*     */     {
/* 131 */       TRecord localTRecord = (TRecord)localIterator.next();
/* 132 */       if (localTRecord.tryMarshalN())
/*     */       {
/* 137 */         this.marshal.put(localTRecord.getKey(), localTRecord);
/*     */ 
/* 142 */         localIterator.remove();
/* 143 */         i++;
/*     */       } else {
/* 145 */         j++;
/*     */       }
/*     */     }
/* 147 */     this.countMarshalN += i;
/* 148 */     this.countMarshalNTryFail += j;
/* 149 */     return i;
/*     */   }
/*     */ 
/*     */   int marshal0()
/*     */   {
/* 158 */     this.marshal.putAll(this.changed);
/* 159 */     for (TRecord localTRecord : this.changed.values())
/* 160 */       localTRecord.marshal0();
/* 161 */     int i = this.changed.size();
/* 162 */     this.changed.clear();
/* 163 */     this.countMarshal0 += i;
/* 164 */     return i;
/*     */   }
/*     */ 
/*     */   int snapshot()
/*     */   {
/* 173 */     ConcurrentMap localConcurrentMap = this.snapshot;
/* 174 */     this.snapshot = this.marshal;
/* 175 */     this.marshal = localConcurrentMap;
/* 176 */     for (TRecord localTRecord : this.snapshot.values())
/* 177 */       localTRecord.snapshot();
/* 178 */     this.countSnapshot += this.snapshot.size();
/* 179 */     return this.snapshot.size();
/*     */   }
/*     */ 
/*     */   int flush()
/*     */   {
/* 189 */     int i = 0;
/* 190 */     for (Object localObject1 = this.snapshot.values().iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (TRecord)((Iterator)localObject1).next();
/*     */ 
/* 192 */       if (((TRecord)localObject2).flush(this)) {
/* 193 */         i++;
/*     */       }
/*     */     }
/*     */ 
/* 197 */     localObject1 = null;
/*     */ 
/* 200 */     Object localObject2 = this.snapshotClearLock.writeLock();
/* 201 */     ((Lock)localObject2).lock();
/*     */     try {
/* 203 */       localObject1 = this.snapshot;
/* 204 */       this.snapshot = Misc.newConcurrentMap();
/*     */     } finally {
/* 206 */       ((Lock)localObject2).unlock();
/*     */     }
/*     */ 
/* 209 */     for (TRecord localTRecord : ((Map)localObject1).values())
/* 210 */       localTRecord.clear();
/* 211 */     this.countFlush += i;
/* 212 */     return i;
/*     */   }
/*     */ 
/*     */   final boolean exist(K paramK, TTable<K, V> paramTTable)
/*     */   {
/* 221 */     ReentrantReadWriteLock.ReadLock localReadLock = this.snapshotClearLock.readLock();
/* 222 */     localReadLock.lock();
/*     */     try {
/* 224 */       TRecord localTRecord = (TRecord)this.snapshot.get(paramK);
/* 225 */       if (null != localTRecord)
/* 226 */         return localTRecord.exist();
/*     */     } finally {
/* 228 */       localReadLock.unlock();
/*     */     }
/* 230 */     return super.exist(paramTTable.marshalKey(paramK));
/*     */   }
/*     */ 
/*     */   V find(K paramK, TTable<K, V> paramTTable)
/*     */   {
/* 238 */     OctetsStream localOctetsStream = null;
/* 239 */     int i = 0;
/*     */ 
/* 241 */     ReentrantReadWriteLock.ReadLock localReadLock = this.snapshotClearLock.readLock();
/* 242 */     localReadLock.lock();
/*     */     try {
/* 244 */       TRecord localTRecord = (TRecord)this.snapshot.get(paramK);
/* 245 */       if (null != localTRecord) {
/* 246 */         i = 1;
/*     */ 
/* 249 */         localOctetsStream = localTRecord.find();
/*     */       }
/*     */     } finally {
/* 252 */       localReadLock.unlock();
/*     */     }
/*     */     try
/*     */     {
/* 256 */       if (i != 0) {
/* 257 */         if (null != localOctetsStream)
/* 258 */           return paramTTable.unmarshalValue(localOctetsStream);
/* 259 */         return null;
/*     */       }
/*     */ 
/* 262 */       localOctetsStream = super.find(paramTTable.marshalKey(paramK));
/* 263 */       if (null != localOctetsStream)
/* 264 */         return paramTTable.unmarshalValue(localOctetsStream);
/* 265 */       return null; } catch (MarshalException localMarshalException) {
/*     */     }
/* 267 */     throw new MarshalError();
/*     */   }
/*     */ 
/*     */   public long getCountFlush()
/*     */   {
/* 272 */     return this.countFlush;
/*     */   }
/*     */ 
/*     */   public long getCountMarshal0() {
/* 276 */     return this.countMarshal0;
/*     */   }
/*     */ 
/*     */   public long getCountMarshalN() {
/* 280 */     return this.countMarshalN;
/*     */   }
/*     */ 
/*     */   public long getCountMarshalNTryFail() {
/* 284 */     return this.countMarshalNTryFail;
/*     */   }
/*     */ 
/*     */   public long getCountSnapshot() {
/* 288 */     return this.countSnapshot;
/*     */   }
/*     */ 
/*     */   public long getFlushKeySize() {
/* 292 */     return this.flushKeySize;
/*     */   }
/*     */ 
/*     */   public long getFlushValueSize() {
/* 296 */     return this.flushValueSize;
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.TStorage
 * JD-Core Version:    0.6.2
 */