/*     */ package xdb;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import xgen.Define;
/*     */ 
/*     */ public final class TableConf
/*     */ {
/*     */   public static final int DEFAULT_CACHE_HIGH = 512;
/*     */   public static final int DEFAULT_CACHE_LOW = 256;
/*     */   public static final int DEFAULT_CACHE_CAPACITY = 10240;
/*     */   public static final int DEFAULT_CACHE_CLEAN_TRY = 256;
/*     */   private String name;
/*     */   private int cachehigh;
/*     */   private int cachelow;
/*     */   private int cacheCapacity;
/*     */   private Table.Persistence persistence;
/*     */   private String lockname;
/*  23 */   private Map<String, String> otherAttrs = new HashMap();
/*     */ 
/*     */   TableConf(String paramString, int paramInt1, int paramInt2)
/*     */   {
/*  27 */     this.name = paramString;
/*  28 */     this.cachehigh = paramInt1;
/*  29 */     this.cachelow = paramInt2;
/*     */   }
/*     */ 
/*     */   TableConf(Element paramElement)
/*     */   {
/*  34 */     this.name = paramElement.getAttribute("name");
/*     */ 
/*  36 */     Define localDefine = Define.getInstance();
/*     */     Object localObject1;
/*  37 */     if (localDefine.isParsed())
/*     */     {
/*  39 */       localObject1 = localDefine.getCacheCap(paramElement.getAttribute("cacheCapacity"));
/*  40 */       this.cacheCapacity = (localObject1 != null ? ((Integer)localObject1).intValue() : 10240);
/*  41 */       localObject2 = localDefine.getCachePage(paramElement.getAttribute("cachePage"));
/*  42 */       this.cachelow = (localObject2 != null ? localObject2[0].intValue() : 256);
/*  43 */       this.cachehigh = (localObject2 != null ? localObject2[1].intValue() : 512);
/*     */     }
/*     */     else
/*     */     {
/*  47 */       this.cachehigh = XdbConf.getInt(paramElement, "cachehigh", 512);
/*  48 */       this.cachelow = XdbConf.getInt(paramElement, "cachelow", 256);
/*  49 */       this.cacheCapacity = XdbConf.getInt(paramElement, "cacheCapacity", 10240);
/*     */     }
/*     */ 
/*  53 */     this.lockname = ((localObject1 = paramElement.getAttribute("lock")).isEmpty() ? this.name : (String)localObject1);
/*  54 */     this.persistence = ((localObject1 = paramElement.getAttribute("persistence").toUpperCase()).isEmpty() ? Table.Persistence.DB : Table.Persistence.valueOf((String)localObject1));
/*     */ 
/*  58 */     Object localObject2 = paramElement.getAttributes();
/*  59 */     for (int i = 0; i < ((NamedNodeMap)localObject2).getLength(); i++) {
/*  60 */       Attr localAttr = (Attr)((NamedNodeMap)localObject2).item(i);
/*  61 */       this.otherAttrs.put(localAttr.getName(), localAttr.getValue());
/*     */     }
/*     */ 
/*  64 */     this.otherAttrs.remove("name");
/*  65 */     this.otherAttrs.remove("cacheHigh");
/*  66 */     this.otherAttrs.remove("cacheLow");
/*  67 */     this.otherAttrs.remove("cacheCapacity");
/*  68 */     this.otherAttrs.remove("lock");
/*  69 */     this.otherAttrs.remove("persistence");
/*     */   }
/*     */ 
/*     */   public Map<String, String> getOtherAttrs()
/*     */   {
/*  74 */     return this.otherAttrs;
/*     */   }
/*     */ 
/*     */   public String getOtherAttr(String paramString) {
/*  78 */     String str = (String)this.otherAttrs.get(paramString);
/*  79 */     return str == null ? "" : str;
/*     */   }
/*     */ 
/*     */   public int getOtherAttrInt(String paramString, int paramInt) {
/*  83 */     String str = getOtherAttr(paramString);
/*  84 */     return str.isEmpty() ? paramInt : Integer.valueOf(str).intValue();
/*     */   }
/*     */ 
/*     */   public long getOtherAttrLong(String paramString, long paramLong) {
/*  88 */     String str = getOtherAttr(paramString);
/*  89 */     return str.isEmpty() ? paramLong : Long.valueOf(str).longValue();
/*     */   }
/*     */ 
/*     */   public int getCacheCapacity() {
/*  93 */     return this.cacheCapacity;
/*     */   }
/*     */ 
/*     */   public String getLockName() {
/*  97 */     return this.lockname;
/*     */   }
/*     */ 
/*     */   public int getCacheHigh() {
/* 101 */     return this.cachehigh;
/*     */   }
/*     */ 
/*     */   public int getCacheLow() {
/* 105 */     return this.cachelow;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 109 */     return this.name;
/*     */   }
/*     */ 
/*     */   public Table.Persistence getPersistence() {
/* 113 */     return this.persistence;
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.TableConf
 * JD-Core Version:    0.6.2
 */