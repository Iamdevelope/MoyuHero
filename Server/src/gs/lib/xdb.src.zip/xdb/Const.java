package xdb;

public final class Const
{
  public static final String IO_CHARSET = "UTF-16LE";
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Const
 * JD-Core Version:    0.6.2
 */