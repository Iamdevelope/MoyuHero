package xdb;

public abstract interface Log
{
  public abstract void rollback();

  public abstract void commit();
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Log
 * JD-Core Version:    0.6.2
 */