/*    */ package xdb;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public final class Savepoint
/*    */ {
/*    */   Map<LogKey, Log> logs;
/*    */   List<Log> addOrder;
/*    */   int access;
/*    */ 
/*    */   public Savepoint()
/*    */   {
/*  7 */     this.logs = new HashMap();
/*  8 */     this.addOrder = new ArrayList();
/*  9 */     this.access = 0;
/*    */   }
/*    */ 
/*    */   int commit()
/*    */   {
/* 12 */     Log localLog;
/* 12 */     for (Iterator localIterator = this.addOrder.iterator(); localIterator.hasNext(); localLog.commit()) localLog = (Log)localIterator.next();
/*    */ 
/* 15 */     return this.addOrder.size();
/*    */   }
/*    */ 
/*    */   int rollback()
/*    */   {
/* 22 */     for (int i = this.addOrder.size() - 1; i >= 0; i--)
/* 23 */       ((Log)this.addOrder.get(i)).rollback();
/* 24 */     return this.addOrder.size();
/*    */   }
/*    */ 
/*    */   public int size() {
/* 28 */     return this.addOrder.size();
/*    */   }
/*    */ 
/*    */   public boolean isAccessSince(int paramInt) {
/* 32 */     return paramInt != this.access;
/*    */   }
/*    */ 
/*    */   public int getAccess() {
/* 36 */     return this.access;
/*    */   }
/*    */ 
/*    */   public Log get(LogKey paramLogKey) {
/* 40 */     this.access += 1;
/* 41 */     return (Log)this.logs.get(paramLogKey);
/*    */   }
/*    */ 
/*    */   public void add(LogKey paramLogKey, Log paramLog) {
/* 45 */     this.access += 1;
/* 46 */     Log localLog = (Log)this.logs.put(paramLogKey, paramLog);
/* 47 */     if (null != localLog) {
/* 48 */       this.logs.put(paramLogKey, localLog);
/* 49 */       throw new XError("xdb.Savepoint.add duplicate log");
/*    */     }
/* 51 */     this.addOrder.add(paramLog);
/*    */   }
/*    */ 
/*    */   public boolean addIfAbsent(LogKey paramLogKey, Log paramLog) {
/* 55 */     this.access += 1;
/* 56 */     if (!this.logs.containsKey(paramLogKey)) {
/* 57 */       this.logs.put(paramLogKey, paramLog);
/* 58 */       this.addOrder.add(paramLog);
/* 59 */       return true;
/*    */     }
/* 61 */     return false;
/*    */   }
/*    */ 
/*    */   public static void main(String[] paramArrayOfString)
/*    */   {
/* 83 */     Savepoint localSavepoint = new Savepoint();
/* 84 */     XBean localXBean1 = new XBean(null, null);
/* 85 */     XBean localXBean2 = new XBean(null, null);
/* 86 */     XBean localXBean3 = new XBean(null, null);
/* 87 */     localSavepoint.add(new LogKey(localXBean3, "c"), new L("c"));
/* 88 */     localSavepoint.add(new LogKey(localXBean2, "b"), new L("b"));
/* 89 */     localSavepoint.add(new LogKey(localXBean1, "a"), new L("a"));
/* 90 */     System.out.println(localSavepoint.addOrder);
/*    */   }
/*    */ 
/*    */   private static class L
/*    */     implements Log
/*    */   {
/*    */     private String name;
/*    */ 
/*    */     L(String paramString)
/*    */     {
/* 69 */       this.name = paramString;
/*    */     }
/*    */ 
/*    */     public void commit() {
/*    */     }
/*    */ 
/*    */     public void rollback() {
/*    */     }
/*    */ 
/*    */     public String toString() {
/* 79 */       return this.name;
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Savepoint
 * JD-Core Version:    0.6.2
 */