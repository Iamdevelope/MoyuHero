/*    */ package xdb.logs;
/*    */ 
/*    */ import xdb.Log;
/*    */ import xdb.LogKey;
/*    */ import xdb.Logs;
/*    */ 
/*    */ public abstract class LogLong extends Note
/*    */   implements Log
/*    */ {
/*    */   protected LogKey logkey;
/*    */   protected long _xdb_saved;
/*    */ 
/*    */   protected LogLong(LogKey paramLogKey, long paramLong)
/*    */   {
/* 11 */     this.logkey = paramLogKey;
/* 12 */     this._xdb_saved = paramLong;
/*    */   }
/*    */ 
/*    */   public void commit()
/*    */   {
/* 17 */     Logs.logNotify(this.logkey.getXBean(), new LogNotify(this.logkey, this));
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogLong
 * JD-Core Version:    0.6.2
 */