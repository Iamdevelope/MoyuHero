/*     */ package xdb.logs;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import xdb.TRecord;
/*     */ import xdb.TRecord.State;
/*     */ import xdb.TTable;
/*     */ import xdb.Transaction;
/*     */ 
/*     */ public final class LogRecord<K, V>
/*     */ {
/*  22 */   private Map<K, LogR<K, V>> changed = new HashMap();
/*     */   private Listenable seed;
/*     */   private int hasListener;
/*     */ 
/*     */   public LogRecord(TTable<K, V> paramTTable)
/*     */   {
/*  27 */     this.seed = paramTTable.getRecordListenableSeed();
/*  28 */     this.seed.setVarName("value").makeFullVarName("");
/*     */   }
/*     */ 
/*     */   public String toFullVarName(VarNames paramVarNames) {
/*  32 */     if (!"value".equals(paramVarNames.next()))
/*  33 */       throw new IllegalStateException();
/*  34 */     return this.seed.toFullVarName(paramVarNames);
/*     */   }
/*     */ 
/*     */   public void onChanged(TTable<K, V> paramTTable, TRecord<K, V> paramTRecord, LogNotify paramLogNotify)
/*     */   {
/*  46 */     if (this.hasListener == 0) {
/*  47 */       this.hasListener = (paramTTable.hasListener() ? 1 : -1);
/*     */     }
/*  49 */     if (this.hasListener == -1) {
/*  50 */       return;
/*     */     }
/*  52 */     Transaction.current().addLogNotifyTTable(paramTTable);
/*     */ 
/*  54 */     LogR localLogR = (LogR)this.changed.get(paramTRecord.getKey());
/*  55 */     if (null == localLogR)
/*  56 */       this.changed.put(paramTRecord.getKey(), localLogR = new LogR(paramTRecord, this.seed.copy()));
/*  57 */     if (paramLogNotify.isAddRemove())
/*     */     {
/*  62 */       if (null == localLogR.addRemoveInfo)
/*  63 */         localLogR.addRemoveInfo = paramLogNotify.getAddRemoveInfo();
/*     */     }
/*     */     else {
/*  66 */       paramLogNotify.pop();
/*  67 */       localLogR.value.setChanged(paramLogNotify);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void logNotify(ListenerMap paramListenerMap) {
/*  72 */     this.hasListener = 0;
/*  73 */     for (LogR localLogR : this.changed.values())
/*  74 */       localLogR.value.logNotify(localLogR.r.getKey(), localLogR.getRecordState(), paramListenerMap);
/*  75 */     this.changed.clear();
/*     */   }
/*     */   private static class LogR<K, V> {
/*     */     private TRecord<K, V> r;
/*     */     private AddRemoveInfo addRemoveInfo;
/*     */     private Listenable value;
/*     */ 
/*  84 */     LogR(TRecord<K, V> paramTRecord, Listenable paramListenable) { this.r = paramTRecord;
/*  85 */       this.value = paramListenable; }
/*     */ 
/*     */     private RecordState getRecordState()
/*     */     {
/*  89 */       if (null != this.addRemoveInfo)
/*     */       {
/*  91 */         if ((this.addRemoveInfo.isCreateCache()) && (TRecord.State.ADD == this.addRemoveInfo.getSavedState()) && (TRecord.State.REMOVE == this.r.getState()))
/*  92 */           return RecordState.NONE;
/*  93 */         if ((!this.addRemoveInfo.isCreateCache()) && (TRecord.State.ADD == this.addRemoveInfo.getSavedState()) && (TRecord.State.REMOVE == this.r.getState()))
/*  94 */           return RecordState.REMOVED;
/*  95 */         if ((TRecord.State.ADD == this.addRemoveInfo.getSavedState()) && (TRecord.State.ADD == this.r.getState()))
/*  96 */           return RecordState.ADDED;
/*  97 */         if ((TRecord.State.INDB_GET == this.addRemoveInfo.getSavedState()) && (TRecord.State.INDB_REMOVE == this.r.getState()))
/*  98 */           return RecordState.REMOVED;
/*  99 */         if ((TRecord.State.INDB_GET == this.addRemoveInfo.getSavedState()) && (TRecord.State.INDB_ADD == this.r.getState()))
/* 100 */           return RecordState.ADDED;
/* 101 */         if ((TRecord.State.INDB_REMOVE == this.addRemoveInfo.getSavedState()) && (TRecord.State.INDB_ADD == this.r.getState()))
/* 102 */           return RecordState.ADDED;
/* 103 */         if ((this.addRemoveInfo.isCreateCache()) && (TRecord.State.INDB_REMOVE == this.addRemoveInfo.getSavedState()) && (TRecord.State.INDB_REMOVE == this.r.getState()))
/* 104 */           return RecordState.REMOVED;
/* 105 */         if ((!this.addRemoveInfo.isCreateCache()) && (TRecord.State.INDB_REMOVE == this.addRemoveInfo.getSavedState()) && (TRecord.State.INDB_REMOVE == this.r.getState()))
/* 106 */           return RecordState.NONE;
/* 107 */         if ((this.addRemoveInfo.isCreateCache()) && (TRecord.State.REMOVE == this.addRemoveInfo.getSavedState()) && (TRecord.State.REMOVE == this.r.getState()))
/* 108 */           return RecordState.NONE;
/* 109 */         if ((this.addRemoveInfo.isCreateCache()) && (TRecord.State.REMOVE == this.addRemoveInfo.getSavedState()) && (TRecord.State.ADD == this.r.getState()))
/* 110 */           return RecordState.ADDED;
/* 111 */         if ((!this.addRemoveInfo.isCreateCache()) && (TRecord.State.INDB_ADD == this.addRemoveInfo.getSavedState()) && (TRecord.State.INDB_ADD == this.r.getState()))
/* 112 */           return RecordState.ADDED;
/* 113 */         if ((!this.addRemoveInfo.isCreateCache()) && (TRecord.State.INDB_ADD == this.addRemoveInfo.getSavedState()) && (TRecord.State.INDB_REMOVE == this.r.getState())) {
/* 114 */           return RecordState.REMOVED;
/*     */         }
/*     */ 
/* 117 */         throw new IllegalStateException("AddRemoveState Error!");
/*     */       }
/*     */ 
/* 120 */       return RecordState.CHANGED;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogRecord
 * JD-Core Version:    0.6.2
 */