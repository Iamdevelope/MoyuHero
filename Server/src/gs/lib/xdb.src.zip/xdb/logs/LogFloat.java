/*    */ package xdb.logs;
/*    */ 
/*    */ import xdb.Log;
/*    */ import xdb.LogKey;
/*    */ import xdb.Logs;
/*    */ 
/*    */ public abstract class LogFloat extends Note
/*    */   implements Log
/*    */ {
/*    */   protected LogKey logkey;
/*    */   protected float _xdb_saved;
/*    */ 
/*    */   protected LogFloat(LogKey paramLogKey, float paramFloat)
/*    */   {
/* 11 */     this.logkey = paramLogKey;
/* 12 */     this._xdb_saved = paramFloat;
/*    */   }
/*    */ 
/*    */   public void commit()
/*    */   {
/* 17 */     Logs.logNotify(this.logkey.getXBean(), new LogNotify(this.logkey, this));
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 22 */     return String.valueOf(this._xdb_saved);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogFloat
 * JD-Core Version:    0.6.2
 */