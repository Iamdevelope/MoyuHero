/*     */ package xdb.logs;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import xdb.Savepoint;
/*     */ import xdb.Trace;
/*     */ import xdb.Transaction;
/*     */ 
/*     */ public final class ListenerMap
/*     */ {
/*     */   private Map<String, Set<Listener>> listenerMap;
/*     */   private final Lock sync;
/*     */   private volatile Map<String, Set<Listener>> listenerMapCopy;
/*     */ 
/*     */   public ListenerMap()
/*     */   {
/*  15 */     this.listenerMap = new HashMap();
/*  16 */     this.sync = new ReentrantLock();
/*     */ 
/*  22 */     this.listenerMapCopy = new HashMap();
/*     */   }
/*     */ 
/*     */   private void setListenerMapCopy() {
/*  26 */     HashMap localHashMap = new HashMap();
/*  27 */     for (Map.Entry localEntry : this.listenerMap.entrySet()) {
/*  28 */       HashSet localHashSet = new HashSet();
/*  29 */       localHashSet.addAll((Collection)localEntry.getValue());
/*  30 */       localHashMap.put(localEntry.getKey(), localHashSet);
/*     */     }
/*  32 */     this.listenerMapCopy = localHashMap;
/*     */   }
/*     */ 
/*     */   public final String add(String paramString, Listener paramListener) {
/*  36 */     this.sync.lock();
/*     */     try {
/*  38 */       Object localObject1 = (Set)this.listenerMap.get(paramString);
/*  39 */       if (null == localObject1)
/*  40 */         this.listenerMap.put(paramString, localObject1 = new HashSet());
/*  41 */       if (!((Set)localObject1).add(paramListener)) {
/*  42 */         throw new IllegalStateException("Listener has added");
/*     */       }
/*  44 */       setListenerMapCopy();
/*     */     } finally {
/*  46 */       this.sync.unlock();
/*     */     }
/*  48 */     return paramString;
/*     */   }
/*     */ 
/*     */   public final void remove(String paramString, Listener paramListener) {
/*  52 */     this.sync.lock();
/*     */     try {
/*  54 */       Set localSet = (Set)this.listenerMap.get(paramString);
/*  55 */       if (null != localSet) {
/*  56 */         boolean bool = localSet.remove(paramListener);
/*  57 */         if (localSet.isEmpty()) {
/*  58 */           this.listenerMap.remove(paramString);
/*     */         }
/*  60 */         if (bool)
/*  61 */           setListenerMapCopy();
/*     */       }
/*     */     } finally {
/*  64 */       this.sync.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final boolean hasListener() {
/*  69 */     Map localMap = this.listenerMapCopy;
/*  70 */     return false == localMap.isEmpty();
/*     */   }
/*     */ 
/*     */   public final boolean hasListener(String paramString) {
/*  74 */     Map localMap = this.listenerMapCopy;
/*     */ 
/*  76 */     return null != localMap.get(paramString);
/*     */   }
/*     */ 
/*     */   final void notifyChanged(String paramString, Object paramObject)
/*     */   {
/*  81 */     notify(ZZZ.CHANGED_ALL, paramString, paramObject, null);
/*     */   }
/*     */ 
/*     */   final void notifyRemoved(String paramString, Object paramObject) {
/*  85 */     notify(ZZZ.REMOVED, paramString, paramObject, null);
/*     */   }
/*     */ 
/*     */   final void notifyChanged(String paramString, Object paramObject, Note paramNote) {
/*  89 */     notify(ZZZ.CHANGED_NOTE, paramString, paramObject, paramNote);
/*     */   }
/*     */ 
/*     */   private final void notify(ZZZ paramZZZ, String paramString, Object paramObject, Note paramNote)
/*     */   {
/*  98 */     Map localMap = this.listenerMapCopy;
/*  99 */     Set localSet = (Set)localMap.get(paramString);
/*     */ 
/* 101 */     if (null == localSet) {
/* 102 */       return;
/*     */     }
/* 104 */     for (Listener localListener : localSet) {
/* 105 */       Transaction localTransaction = Transaction.current();
/* 106 */       int i = localTransaction.currentSavepointId();
/* 107 */       int j = i > 0 ? localTransaction.getSavepoint(i).getAccess() : 0;
/*     */       try
/*     */       {
/* 110 */         switch (1.$SwitchMap$xdb$logs$ListenerMap$ZZZ[paramZZZ.ordinal()]) { case 1:
/* 111 */           localListener.onChanged(paramObject); break;
/*     */         case 2:
/* 112 */           localListener.onChanged(paramObject, paramString, paramNote); break;
/*     */         case 3:
/* 113 */           localListener.onRemoved(paramObject); }
/*     */       }
/*     */       catch (Throwable localThrowable)
/*     */       {
/* 117 */         Trace.error("doChanged key=" + paramObject + " name=" + paramString, localThrowable);
/*     */ 
/* 131 */         int k = localTransaction.currentSavepointId();
/* 132 */         if (0 == i) {
/* 133 */           if (k > 0)
/* 134 */             localTransaction.rollback(i + 1);
/*     */         }
/*     */         else {
/* 137 */           if (k < i) {
/* 138 */             throw new IllegalStateException("spAfter < spBefore");
/*     */           }
/* 140 */           if (localTransaction.getSavepoint(i).isAccessSince(j))
/* 141 */             localTransaction.rollback(i);
/* 142 */           else if (k > i)
/* 143 */             localTransaction.rollback(i + 1);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static enum ZZZ
/*     */   {
/*  94 */     CHANGED_ALL, CHANGED_NOTE, REMOVED;
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.ListenerMap
 * JD-Core Version:    0.6.2
 */