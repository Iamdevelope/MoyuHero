/*    */ package xdb.logs;
/*    */ 
/*    */ import xdb.Log;
/*    */ import xdb.LogKey;
/*    */ import xdb.Logs;
/*    */ 
/*    */ public abstract class LogObject<T> extends Note
/*    */   implements Log
/*    */ {
/*    */   protected LogKey logkey;
/*    */   protected T _xdb_saved;
/*    */ 
/*    */   protected LogObject(LogKey paramLogKey, T paramT)
/*    */   {
/* 11 */     this.logkey = paramLogKey;
/* 12 */     this._xdb_saved = paramT;
/*    */   }
/*    */ 
/*    */   public void commit()
/*    */   {
/* 17 */     Logs.logNotify(this.logkey.getXBean(), new LogNotify(this.logkey, this));
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogObject
 * JD-Core Version:    0.6.2
 */