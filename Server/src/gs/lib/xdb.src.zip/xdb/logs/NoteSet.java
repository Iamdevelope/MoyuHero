/*    */ package xdb.logs;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class NoteSet<E> extends Note
/*    */ {
/*  7 */   private final Set<E> added = new HashSet();
/*  8 */   private final Set<E> removed = new HashSet();
/*  9 */   private final Set<E> old = new HashSet();
/*    */ 
/*    */   final void merge(Note paramNote)
/*    */   {
/* 17 */     NoteSet localNoteSet = (NoteSet)paramNote;
/*    */     Object localObject;
/* 19 */     for (Iterator localIterator = localNoteSet.added.iterator(); localIterator.hasNext(); logAdd(localObject)) localObject = localIterator.next();
/* 20 */     for (localIterator = localNoteSet.removed.iterator(); localIterator.hasNext(); logRemove(localObject)) localObject = localIterator.next(); 
/*    */   }
/*    */ 
/*    */   final void logAdd(E paramE)
/*    */   {
/* 24 */     if (false == this.removed.remove(paramE))
/* 25 */       this.added.add(paramE);
/*    */   }
/*    */ 
/*    */   final void logRemove(E paramE)
/*    */   {
/* 30 */     if (false == this.added.remove(paramE)) {
/* 31 */       this.removed.add(paramE);
/*    */ 
/* 33 */       if (false == this.old.contains(paramE))
/* 34 */         this.old.add(paramE);
/*    */     }
/*    */   }
/*    */ 
/*    */   public final Set<E> getAdded() {
/* 39 */     return this.added;
/*    */   }
/*    */ 
/*    */   public final Set<E> getRemoved() {
/* 43 */     return this.removed;
/*    */   }
/*    */ 
/*    */   public final Set<E> getOld() {
/* 47 */     return this.old;
/*    */   }
/*    */ 
/*    */   public final boolean isSetChanged() {
/* 51 */     return (false == this.added.isEmpty()) || (false == this.removed.isEmpty());
/*    */   }
/*    */ 
/*    */   public final void clear() {
/* 55 */     this.added.clear();
/* 56 */     this.removed.clear();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 61 */     return "added=" + this.added + " removed=" + this.removed;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.NoteSet
 * JD-Core Version:    0.6.2
 */