/*    */ package xdb.logs;
/*    */ 
/*    */ public enum RecordState
/*    */ {
/* 11 */   ADDED, 
/* 12 */   REMOVED, 
/* 13 */   CHANGED, 
/* 14 */   NONE;
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.RecordState
 * JD-Core Version:    0.6.2
 */