/*     */ package xdb.logs;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ class WrapList<E>
/*     */   implements List<E>
/*     */ {
/*     */   private LogList<E> root;
/*     */   private List<E> wrapped;
/*     */ 
/*     */   public WrapList(LogList<E> paramLogList, List<E> paramList)
/*     */   {
/*  88 */     this.root = paramLogList;
/*  89 */     this.wrapped = paramList;
/*     */   }
/*     */ 
/*     */   protected void beforeChange()
/*     */   {
/*  95 */     this.root.beforeChange();
/*     */   }
/*     */ 
/*     */   protected void afterAdd(E paramE) {
/*  99 */     this.root.afterAdd(paramE);
/*     */   }
/*     */ 
/*     */   protected void beforeRemove(E paramE) {
/* 103 */     this.root.beforeRemove(paramE);
/*     */   }
/*     */ 
/*     */   protected List<E> getWrapped() {
/* 107 */     return this.wrapped;
/*     */   }
/*     */ 
/*     */   public boolean add(E paramE)
/*     */   {
/* 113 */     beforeChange();
/* 114 */     if (this.wrapped.add(paramE)) {
/* 115 */       afterAdd(paramE);
/* 116 */       return true;
/*     */     }
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */   public void add(int paramInt, E paramE)
/*     */   {
/* 123 */     beforeChange();
/* 124 */     this.wrapped.add(paramInt, paramE);
/* 125 */     afterAdd(paramE);
/*     */   }
/*     */ 
/*     */   public boolean addAll(Collection<? extends E> paramCollection)
/*     */   {
/* 130 */     beforeChange();
/* 131 */     if (this.wrapped.addAll(paramCollection)) {
/* 132 */       for (Iterator localIterator = paramCollection.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 133 */         afterAdd(localObject); }
/* 134 */       return true;
/*     */     }
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean addAll(int paramInt, Collection<? extends E> paramCollection)
/*     */   {
/* 141 */     beforeChange();
/* 142 */     if (this.wrapped.addAll(paramInt, paramCollection)) {
/* 143 */       for (Iterator localIterator = paramCollection.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 144 */         afterAdd(localObject); }
/* 145 */       return true;
/*     */     }
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 152 */     beforeChange();
/* 153 */     for (Iterator localIterator = this.wrapped.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 154 */       beforeRemove(localObject); }
/* 155 */     this.wrapped.clear();
/*     */   }
/*     */ 
/*     */   public boolean contains(Object paramObject)
/*     */   {
/* 160 */     return this.wrapped.contains(paramObject);
/*     */   }
/*     */ 
/*     */   public boolean containsAll(Collection<?> paramCollection)
/*     */   {
/* 165 */     return this.wrapped.containsAll(paramCollection);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object paramObject)
/*     */   {
/* 170 */     return this.wrapped.equals(paramObject);
/*     */   }
/*     */ 
/*     */   public E get(int paramInt)
/*     */   {
/* 175 */     return this.wrapped.get(paramInt);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 180 */     return this.wrapped.hashCode();
/*     */   }
/*     */ 
/*     */   public int indexOf(Object paramObject)
/*     */   {
/* 185 */     return this.wrapped.indexOf(paramObject);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 190 */     return this.wrapped.isEmpty();
/*     */   }
/*     */ 
/*     */   public Iterator<E> iterator()
/*     */   {
/* 217 */     return new WrapIt(null);
/*     */   }
/*     */ 
/*     */   public int lastIndexOf(Object paramObject)
/*     */   {
/* 222 */     return this.wrapped.lastIndexOf(paramObject);
/*     */   }
/*     */ 
/*     */   public ListIterator<E> listIterator()
/*     */   {
/* 292 */     return new WrapListIt();
/*     */   }
/*     */ 
/*     */   public ListIterator<E> listIterator(int paramInt)
/*     */   {
/* 297 */     return new WrapListIt(paramInt);
/*     */   }
/*     */ 
/*     */   public E remove(int paramInt)
/*     */   {
/* 302 */     beforeChange();
/* 303 */     Object localObject = this.wrapped.remove(paramInt);
/* 304 */     beforeRemove(localObject);
/* 305 */     return localObject;
/*     */   }
/*     */ 
/*     */   public boolean remove(Object paramObject)
/*     */   {
/* 310 */     int i = indexOf(paramObject);
/* 311 */     if (i < 0)
/* 312 */       return false;
/* 313 */     remove(i);
/* 314 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean removeAll(Collection<?> paramCollection)
/*     */   {
/* 320 */     boolean bool = false;
/* 321 */     Iterator localIterator = iterator();
/* 322 */     while (localIterator.hasNext()) {
/* 323 */       if (paramCollection.contains(localIterator.next())) {
/* 324 */         localIterator.remove();
/* 325 */         bool = true;
/*     */       }
/*     */     }
/* 328 */     return bool;
/*     */   }
/*     */ 
/*     */   public boolean retainAll(Collection<?> paramCollection)
/*     */   {
/* 334 */     boolean bool = false;
/* 335 */     Iterator localIterator = iterator();
/* 336 */     while (localIterator.hasNext()) {
/* 337 */       if (!paramCollection.contains(localIterator.next())) {
/* 338 */         localIterator.remove();
/* 339 */         bool = true;
/*     */       }
/*     */     }
/* 342 */     return bool;
/*     */   }
/*     */ 
/*     */   public E set(int paramInt, E paramE)
/*     */   {
/* 347 */     beforeChange();
/* 348 */     Object localObject = this.wrapped.set(paramInt, paramE);
/* 349 */     beforeRemove(localObject);
/* 350 */     afterAdd(paramE);
/* 351 */     return localObject;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 356 */     return this.wrapped.size();
/*     */   }
/*     */ 
/*     */   public List<E> subList(int paramInt1, int paramInt2)
/*     */   {
/* 361 */     return new WrapList(this.root, this.wrapped.subList(paramInt1, paramInt2));
/*     */   }
/*     */ 
/*     */   public Object[] toArray()
/*     */   {
/* 366 */     return this.wrapped.toArray();
/*     */   }
/*     */ 
/*     */   public <X> X[] toArray(X[] paramArrayOfX)
/*     */   {
/* 371 */     return this.wrapped.toArray(paramArrayOfX);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 376 */     return this.wrapped.toString();
/*     */   }
/*     */ 
/*     */   private class WrapListIt
/*     */     implements ListIterator<E>
/*     */   {
/*     */     private ListIterator<E> it;
/*     */     private E current;
/*     */ 
/*     */     WrapListIt()
/*     */     {
/* 230 */       this.it = WrapList.this.wrapped.listIterator();
/*     */     }
/*     */ 
/*     */     WrapListIt(int arg2)
/*     */     {
/*     */       int i;
/* 234 */       this.it = WrapList.this.wrapped.listIterator(i);
/*     */     }
/*     */ 
/*     */     public void add(E paramE)
/*     */     {
/* 239 */       WrapList.this.beforeChange();
/* 240 */       this.it.add(paramE);
/* 241 */       WrapList.this.afterAdd(paramE);
/*     */     }
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/* 246 */       return this.it.hasNext();
/*     */     }
/*     */ 
/*     */     public boolean hasPrevious()
/*     */     {
/* 251 */       return this.it.hasPrevious();
/*     */     }
/*     */ 
/*     */     public E next()
/*     */     {
/* 256 */       return this.current = this.it.next();
/*     */     }
/*     */ 
/*     */     public int nextIndex()
/*     */     {
/* 261 */       return this.it.nextIndex();
/*     */     }
/*     */ 
/*     */     public E previous()
/*     */     {
/* 266 */       return this.current = this.it.previous();
/*     */     }
/*     */ 
/*     */     public int previousIndex()
/*     */     {
/* 271 */       return this.it.previousIndex();
/*     */     }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 276 */       WrapList.this.beforeChange();
/* 277 */       WrapList.this.beforeRemove(this.current);
/* 278 */       this.it.remove();
/*     */     }
/*     */ 
/*     */     public void set(E paramE)
/*     */     {
/* 283 */       WrapList.this.beforeChange();
/* 284 */       WrapList.this.beforeRemove(this.current);
/* 285 */       this.it.set(paramE);
/* 286 */       WrapList.this.afterAdd(paramE);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class WrapIt
/*     */     implements Iterator<E>
/*     */   {
/* 194 */     private Iterator<E> it = WrapList.this.wrapped.iterator();
/*     */     private E current;
/*     */ 
/*     */     private WrapIt()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/* 199 */       return this.it.hasNext();
/*     */     }
/*     */ 
/*     */     public E next()
/*     */     {
/* 204 */       return this.current = this.it.next();
/*     */     }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 209 */       WrapList.this.beforeChange();
/* 210 */       WrapList.this.beforeRemove(this.current);
/* 211 */       this.it.remove();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.WrapList
 * JD-Core Version:    0.6.2
 */