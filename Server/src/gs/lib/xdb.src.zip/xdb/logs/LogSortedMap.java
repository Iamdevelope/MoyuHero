/*    */ package xdb.logs;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import java.util.SortedMap;
/*    */ import xdb.LogKey;
/*    */ 
/*    */ public class LogSortedMap<K, V, W extends SortedMap<K, V>> extends LogMap<K, V, W>
/*    */   implements SortedMap<K, V>
/*    */ {
/*    */   public LogSortedMap(LogKey paramLogKey, W paramW)
/*    */   {
/* 20 */     super(paramLogKey, paramW);
/*    */   }
/*    */ 
/*    */   public Comparator<? super K> comparator()
/*    */   {
/* 25 */     return ((SortedMap)this.wrapped).comparator();
/*    */   }
/*    */ 
/*    */   public K firstKey()
/*    */   {
/* 30 */     return ((SortedMap)this.wrapped).firstKey();
/*    */   }
/*    */ 
/*    */   public K lastKey()
/*    */   {
/* 35 */     return ((SortedMap)this.wrapped).lastKey();
/*    */   }
/*    */ 
/*    */   public SortedMap<K, V> headMap(K paramK)
/*    */   {
/* 40 */     return new LogSortedMap(this.logkey, ((SortedMap)this.wrapped).headMap(paramK));
/*    */   }
/*    */ 
/*    */   public SortedMap<K, V> subMap(K paramK1, K paramK2)
/*    */   {
/* 45 */     return new LogSortedMap(this.logkey, ((SortedMap)this.wrapped).subMap(paramK1, paramK2));
/*    */   }
/*    */ 
/*    */   public SortedMap<K, V> tailMap(K paramK)
/*    */   {
/* 50 */     return new LogSortedMap(this.logkey, ((SortedMap)this.wrapped).tailMap(paramK));
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogSortedMap
 * JD-Core Version:    0.6.2
 */