/*    */ package xdb.logs;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import xdb.LogKey;
/*    */ 
/*    */ public final class ListenableBean extends Listenable
/*    */ {
/*  8 */   private boolean changed = false;
/*  9 */   private Map<String, Listenable> vars = new HashMap();
/*    */ 
/*    */   public void add(Listenable paramListenable) {
/* 12 */     if (null != this.vars.put(paramListenable.getVarName(), paramListenable))
/* 13 */       throw new IllegalStateException();
/*    */   }
/*    */ 
/*    */   public String toFullVarName(VarNames paramVarNames)
/*    */   {
/* 18 */     if (paramVarNames.hasNext())
/* 19 */       return ((Listenable)this.vars.get(paramVarNames.next())).toFullVarName(paramVarNames);
/* 20 */     return this.fullVarName;
/*    */   }
/*    */ 
/*    */   public void makeFullVarName(String paramString)
/*    */   {
/* 25 */     super.makeFullVarName(paramString);
/* 26 */     for (Listenable localListenable : this.vars.values())
/* 27 */       localListenable.makeFullVarName(this.fullVarName);
/*    */   }
/*    */ 
/*    */   public ListenableBean copy()
/*    */   {
/* 32 */     ListenableBean localListenableBean = new ListenableBean();
/* 33 */     localListenableBean.fullVarName = this.fullVarName;
/* 34 */     for (Map.Entry localEntry : this.vars.entrySet()) {
/* 35 */       localListenableBean.vars.put(localEntry.getKey(), ((Listenable)localEntry.getValue()).copy());
/*    */     }
/* 37 */     return localListenableBean;
/*    */   }
/*    */ 
/*    */   public void setChanged(LogNotify paramLogNotify)
/*    */   {
/* 42 */     this.changed = true;
/*    */ 
/* 44 */     ((Listenable)this.vars.get(paramLogNotify.pop().getVarname())).setChanged(paramLogNotify);
/*    */   }
/*    */ 
/*    */   public void logNotify(Object paramObject, RecordState paramRecordState, ListenerMap paramListenerMap)
/*    */   {
/* 49 */     switch (1.$SwitchMap$xdb$logs$RecordState[paramRecordState.ordinal()])
/*    */     {
/*    */     case 1:
/* 52 */       return;
/*    */     case 2:
/* 54 */       paramListenerMap.notifyChanged(this.fullVarName, paramObject);
/* 55 */       break;
/*    */     case 3:
/* 58 */       paramListenerMap.notifyRemoved(this.fullVarName, paramObject);
/* 59 */       break;
/*    */     case 4:
/* 62 */       if (this.changed)
/* 63 */         paramListenerMap.notifyChanged(this.fullVarName, paramObject, null);
/*    */       else
/*    */         return;
/*    */       break;
/*    */     }
/* 68 */     this.changed = false;
/* 69 */     for (Listenable localListenable : this.vars.values())
/* 70 */       localListenable.logNotify(paramObject, paramRecordState, paramListenerMap);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.ListenableBean
 * JD-Core Version:    0.6.2
 */