package xdb.logs;

public class Note
{
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.Note
 * JD-Core Version:    0.6.2
 */