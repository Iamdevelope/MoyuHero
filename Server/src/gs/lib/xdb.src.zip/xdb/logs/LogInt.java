/*    */ package xdb.logs;
/*    */ 
/*    */ import xdb.Log;
/*    */ import xdb.LogKey;
/*    */ import xdb.Logs;
/*    */ 
/*    */ public abstract class LogInt extends Note
/*    */   implements Log
/*    */ {
/*    */   protected LogKey logkey;
/*    */   protected int _xdb_saved;
/*    */ 
/*    */   protected LogInt(LogKey paramLogKey, int paramInt)
/*    */   {
/* 11 */     this.logkey = paramLogKey;
/* 12 */     this._xdb_saved = paramInt;
/*    */   }
/*    */ 
/*    */   public void commit()
/*    */   {
/* 17 */     Logs.logNotify(this.logkey.getXBean(), new LogNotify(this.logkey, this));
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 22 */     return String.valueOf(this._xdb_saved);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogInt
 * JD-Core Version:    0.6.2
 */