/*    */ package xdb.logs;
/*    */ 
/*    */ import java.util.List;
/*    */ import xdb.Log;
/*    */ import xdb.LogKey;
/*    */ import xdb.Logs;
/*    */ import xdb.Savepoint;
/*    */ import xdb.Transaction;
/*    */ 
/*    */ public final class LogList<E> extends WrapList<E>
/*    */ {
/*    */   private LogKey logkey;
/*    */ 
/*    */   private final LogList<E>.MyLog myLog()
/*    */   {
/* 45 */     Savepoint localSavepoint = Transaction.currentSavepoint();
/* 46 */     Object localObject = localSavepoint.get(this.logkey);
/* 47 */     if (null == localObject)
/* 48 */       localSavepoint.add(this.logkey, localObject = new MyLog(null));
/* 49 */     return (MyLog)localObject;
/*    */   }
/*    */ 
/*    */   protected final void beforeChange()
/*    */   {
/* 57 */     myLog().beforeChange();
/*    */   }
/*    */ 
/*    */   protected void afterAdd(E paramE)
/*    */   {
/* 62 */     Logs.xdbParent(paramE, this.logkey.getXBean(), this.logkey.getVarname());
/*    */   }
/*    */ 
/*    */   protected void beforeRemove(E paramE)
/*    */   {
/* 67 */     Logs.xdbParent(paramE, null, null);
/*    */   }
/*    */ 
/*    */   public List<E> subList(int paramInt1, int paramInt2)
/*    */   {
/* 73 */     return new WrapList(this, getWrapped().subList(paramInt1, paramInt2));
/*    */   }
/*    */ 
/*    */   public LogList(LogKey paramLogKey, List<E> paramList) {
/* 77 */     super(null, paramList);
/* 78 */     this.logkey = paramLogKey;
/*    */   }
/*    */ 
/*    */   private final class MyLog extends Note
/*    */     implements Log
/*    */   {
/*    */     private Object[] savedonwrite;
/*    */ 
/*    */     private MyLog()
/*    */     {
/*    */     }
/*    */ 
/*    */     public void commit()
/*    */     {
/* 22 */       if (this.savedonwrite != null)
/* 23 */         Logs.logNotify(LogList.this.logkey.getXBean(), new LogNotify(LogList.this.logkey, this));
/*    */     }
/*    */ 
/*    */     public void rollback()
/*    */     {
/* 28 */       LogList.this.getWrapped().clear();
/* 29 */       for (int i = 0; i < this.savedonwrite.length; i++)
/*    */       {
/* 31 */         Object localObject = this.savedonwrite[i];
/* 32 */         LogList.this.getWrapped().add(localObject);
/*    */       }
/*    */     }
/*    */ 
/*    */     void beforeChange() {
/* 37 */       if (this.savedonwrite == null)
/* 38 */         this.savedonwrite = LogList.this.getWrapped().toArray();
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogList
 * JD-Core Version:    0.6.2
 */