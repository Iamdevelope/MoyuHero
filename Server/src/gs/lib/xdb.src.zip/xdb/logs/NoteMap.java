/*     */ package xdb.logs;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class NoteMap<K, V> extends Note
/*     */ {
/*  10 */   private final Set<K> added = new HashSet();
/*  11 */   private final Map<K, V> removed = new HashMap();
/*  12 */   private final Map<K, V> replaced = new HashMap();
/*     */   private List<V> changed;
/*     */ 
/*     */   final void setChanged(List<V> paramList)
/*     */   {
/*  16 */     this.changed = paramList;
/*     */   }
/*     */ 
/*     */   final void merge(Note paramNote)
/*     */   {
/*  25 */     NoteMap localNoteMap = (NoteMap)paramNote;
/*     */ 
/*  27 */     for (Iterator localIterator = localNoteMap.added.iterator(); localIterator.hasNext(); ) { localObject = localIterator.next();
/*  28 */       logPut(localObject, null, null);
/*     */     }
/*  29 */     Object localObject;
/*  29 */     for (localIterator = localNoteMap.removed.entrySet().iterator(); localIterator.hasNext(); ) { localObject = (Map.Entry)localIterator.next();
/*  30 */       logRemove(((Map.Entry)localObject).getKey(), ((Map.Entry)localObject).getValue()); }
/*  31 */     for (localIterator = localNoteMap.replaced.entrySet().iterator(); localIterator.hasNext(); ) { localObject = (Map.Entry)localIterator.next();
/*  32 */       logPut(((Map.Entry)localObject).getKey(), ((Map.Entry)localObject).getValue(), ((Map.Entry)localObject).getValue()); }
/*     */   }
/*     */ 
/*     */   public final Set<K> getAdded() {
/*  36 */     return this.added;
/*     */   }
/*     */ 
/*     */   public final Map<K, V> getReplaced()
/*     */   {
/*  44 */     return this.replaced;
/*     */   }
/*     */ 
/*     */   public final Map<K, V> getRemoved()
/*     */   {
/*  52 */     return this.removed;
/*     */   }
/*     */ 
/*     */   public final List<V> getChanged()
/*     */   {
/*  61 */     return this.changed;
/*     */   }
/*     */ 
/*     */   final boolean isMapChanged()
/*     */   {
/*  66 */     return (!this.added.isEmpty()) || (!this.removed.isEmpty()) || (!this.replaced.isEmpty());
/*     */   }
/*     */ 
/*     */   final void clear() {
/*  70 */     this.added.clear();
/*  71 */     this.removed.clear();
/*  72 */     this.replaced.clear();
/*  73 */     this.changed = null;
/*     */   }
/*     */ 
/*     */   final void logRemove(K paramK, V paramV) {
/*  77 */     if (!this.added.remove(paramK))
/*     */     {
/*  79 */       Object localObject = this.replaced.remove(paramK);
/*  80 */       this.removed.put(paramK, localObject == null ? paramV : localObject);
/*     */     }
/*     */   }
/*     */ 
/*     */   final void logPut(K paramK, V paramV1, V paramV2) {
/*  85 */     if (this.added.contains(paramK)) {
/*  86 */       return;
/*     */     }
/*     */ 
/*  89 */     Object localObject = this.removed.remove(paramK);
/*  90 */     if (null != localObject)
/*     */     {
/*  93 */       this.replaced.put(paramK, localObject);
/*  94 */       return;
/*     */     }
/*  96 */     if (this.replaced.containsKey(paramK)) {
/*  97 */       return;
/*     */     }
/*     */ 
/* 100 */     if (null == paramV1)
/* 101 */       this.added.add(paramK);
/*     */     else
/* 103 */       this.replaced.put(paramK, paramV1);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 108 */     return "added=" + this.added + " replaced=" + this.replaced + " removed=" + this.removed + " changed=" + this.changed;
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.NoteMap
 * JD-Core Version:    0.6.2
 */