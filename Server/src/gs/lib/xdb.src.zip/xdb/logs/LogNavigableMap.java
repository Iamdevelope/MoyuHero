/*     */ package xdb.logs;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NavigableMap;
/*     */ import java.util.NavigableSet;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import xdb.LogKey;
/*     */ 
/*     */ public class LogNavigableMap<K, V> extends LogSortedMap<K, V, NavigableMap<K, V>>
/*     */   implements NavigableMap<K, V>
/*     */ {
/*  97 */   private NavigableMap<K, V> descendingMap = null;
/*     */ 
/* 244 */   private KeySet<K, V> keyset = null;
/*     */ 
/*     */   public LogNavigableMap(LogKey paramLogKey, NavigableMap<K, V> paramNavigableMap)
/*     */   {
/*  14 */     super(paramLogKey, paramNavigableMap);
/*     */   }
/*     */ 
/*     */   public K ceilingKey(K paramK)
/*     */   {
/*  19 */     return ((NavigableMap)this.wrapped).ceilingKey(paramK);
/*     */   }
/*     */ 
/*     */   public Map.Entry<K, V> ceilingEntry(K paramK)
/*     */   {
/*  26 */     return ((NavigableMap)this.wrapped).ceilingEntry(paramK);
/*     */   }
/*     */ 
/*     */   public K higherKey(K paramK)
/*     */   {
/*  32 */     return ((NavigableMap)this.wrapped).higherKey(paramK);
/*     */   }
/*     */ 
/*     */   public Map.Entry<K, V> higherEntry(K paramK)
/*     */   {
/*  37 */     return ((NavigableMap)this.wrapped).higherEntry(paramK);
/*     */   }
/*     */ 
/*     */   public K floorKey(K paramK)
/*     */   {
/*  43 */     return ((NavigableMap)this.wrapped).floorKey(paramK);
/*     */   }
/*     */ 
/*     */   public Map.Entry<K, V> floorEntry(K paramK)
/*     */   {
/*  48 */     return ((NavigableMap)this.wrapped).floorEntry(paramK);
/*     */   }
/*     */ 
/*     */   public K lowerKey(K paramK)
/*     */   {
/*  54 */     return ((NavigableMap)this.wrapped).lowerKey(paramK);
/*     */   }
/*     */ 
/*     */   public Map.Entry<K, V> lowerEntry(K paramK)
/*     */   {
/*  59 */     return ((NavigableMap)this.wrapped).lowerEntry(paramK);
/*     */   }
/*     */ 
/*     */   public Map.Entry<K, V> firstEntry()
/*     */   {
/*  65 */     return ((NavigableMap)this.wrapped).firstEntry();
/*     */   }
/*     */ 
/*     */   public Map.Entry<K, V> lastEntry()
/*     */   {
/*  71 */     return ((NavigableMap)this.wrapped).lastEntry();
/*     */   }
/*     */ 
/*     */   public Map.Entry<K, V> pollFirstEntry()
/*     */   {
/*  77 */     Map.Entry localEntry = ((NavigableMap)this.wrapped).pollFirstEntry();
/*  78 */     if (null != localEntry) {
/*  79 */       myLog().afterRemove(localEntry.getKey(), localEntry.getValue());
/*  80 */       return localEntry;
/*     */     }
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   public Map.Entry<K, V> pollLastEntry()
/*     */   {
/*  87 */     Map.Entry localEntry = ((NavigableMap)this.wrapped).pollLastEntry();
/*  88 */     if (null != localEntry) {
/*  89 */       myLog().afterRemove(localEntry.getKey(), localEntry.getValue());
/*  90 */       return localEntry;
/*     */     }
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */   public NavigableMap<K, V> descendingMap()
/*     */   {
/* 100 */     if (null == this.descendingMap)
/* 101 */       this.descendingMap = new LogNavigableMap(this.logkey, ((NavigableMap)this.wrapped).descendingMap());
/* 102 */     return this.descendingMap;
/*     */   }
/*     */ 
/*     */   public NavigableMap<K, V> headMap(K paramK, boolean paramBoolean)
/*     */   {
/* 107 */     return new LogNavigableMap(this.logkey, ((NavigableMap)this.wrapped).headMap(paramK, paramBoolean));
/*     */   }
/*     */ 
/*     */   public NavigableMap<K, V> subMap(K paramK1, boolean paramBoolean1, K paramK2, boolean paramBoolean2)
/*     */   {
/* 112 */     return new LogNavigableMap(this.logkey, ((NavigableMap)this.wrapped).subMap(paramK1, paramBoolean1, paramK2, paramBoolean2));
/*     */   }
/*     */ 
/*     */   public NavigableMap<K, V> tailMap(K paramK, boolean paramBoolean)
/*     */   {
/* 117 */     return new LogNavigableMap(this.logkey, ((NavigableMap)this.wrapped).tailMap(paramK, paramBoolean));
/*     */   }
/*     */ 
/*     */   public NavigableSet<K> navigableKeySet()
/*     */   {
/* 248 */     return this.keyset = new KeySet(this);
/*     */   }
/*     */ 
/*     */   public NavigableSet<K> descendingKeySet()
/*     */   {
/* 253 */     return descendingMap().navigableKeySet();
/*     */   }
/*     */ 
/*     */   private static final class KeySet<K, V> extends AbstractSet<K>
/*     */     implements NavigableSet<K>
/*     */   {
/*     */     private final NavigableMap<K, V> m;
/*     */ 
/*     */     KeySet(NavigableMap<K, V> paramNavigableMap)
/*     */     {
/* 128 */       this.m = paramNavigableMap;
/*     */     }
/*     */ 
/*     */     public Iterator<K> iterator()
/*     */     {
/* 133 */       return this.m.keySet().iterator();
/*     */     }
/*     */ 
/*     */     public Iterator<K> descendingIterator()
/*     */     {
/* 138 */       return descendingSet().iterator();
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 143 */       return this.m.size();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object paramObject)
/*     */     {
/* 148 */       return this.m.containsKey(paramObject);
/*     */     }
/*     */ 
/*     */     public boolean remove(Object paramObject)
/*     */     {
/* 153 */       return this.m.remove(paramObject) != null;
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 158 */       this.m.clear();
/*     */     }
/*     */ 
/*     */     public K ceiling(K paramK)
/*     */     {
/* 163 */       return this.m.ceilingKey(paramK);
/*     */     }
/*     */ 
/*     */     public Comparator<? super K> comparator()
/*     */     {
/* 168 */       return this.m.comparator();
/*     */     }
/*     */ 
/*     */     public K first()
/*     */     {
/* 173 */       return this.m.firstKey();
/*     */     }
/*     */ 
/*     */     public K floor(K paramK)
/*     */     {
/* 178 */       return this.m.floorKey(paramK);
/*     */     }
/*     */ 
/*     */     public K lower(K paramK)
/*     */     {
/* 183 */       return this.m.lowerKey(paramK);
/*     */     }
/*     */ 
/*     */     public K last()
/*     */     {
/* 188 */       return this.m.lastKey();
/*     */     }
/*     */ 
/*     */     public K higher(K paramK)
/*     */     {
/* 193 */       return this.m.higherKey(paramK);
/*     */     }
/*     */ 
/*     */     public K pollFirst()
/*     */     {
/* 198 */       Map.Entry localEntry = this.m.pollFirstEntry();
/* 199 */       return localEntry == null ? null : localEntry.getKey();
/*     */     }
/*     */ 
/*     */     public K pollLast()
/*     */     {
/* 204 */       Map.Entry localEntry = this.m.pollLastEntry();
/* 205 */       return localEntry == null ? null : localEntry.getKey();
/*     */     }
/*     */ 
/*     */     public NavigableSet<K> headSet(K paramK, boolean paramBoolean)
/*     */     {
/* 210 */       return new KeySet(this.m.headMap(paramK, paramBoolean));
/*     */     }
/*     */ 
/*     */     public SortedSet<K> headSet(K paramK)
/*     */     {
/* 215 */       return headSet(paramK, true);
/*     */     }
/*     */ 
/*     */     public NavigableSet<K> subSet(K paramK1, boolean paramBoolean1, K paramK2, boolean paramBoolean2)
/*     */     {
/* 220 */       return new KeySet(this.m.subMap(paramK1, paramBoolean1, paramK2, paramBoolean2));
/*     */     }
/*     */ 
/*     */     public SortedSet<K> subSet(K paramK1, K paramK2)
/*     */     {
/* 225 */       return subSet(paramK1, true, paramK2, false);
/*     */     }
/*     */ 
/*     */     public NavigableSet<K> tailSet(K paramK, boolean paramBoolean)
/*     */     {
/* 230 */       return new KeySet(this.m.tailMap(paramK, paramBoolean));
/*     */     }
/*     */ 
/*     */     public SortedSet<K> tailSet(K paramK)
/*     */     {
/* 235 */       return tailSet(paramK, true);
/*     */     }
/*     */ 
/*     */     public NavigableSet<K> descendingSet()
/*     */     {
/* 240 */       return this.m.descendingKeySet();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogNavigableMap
 * JD-Core Version:    0.6.2
 */