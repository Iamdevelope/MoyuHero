/*    */ package xdb.logs;
/*    */ 
/*    */ public abstract class Listenable
/*    */ {
/*    */   private String varName;
/*    */   protected String fullVarName;
/*    */ 
/*    */   public final Listenable setVarName(String paramString)
/*    */   {
/*  8 */     this.varName = paramString;
/*  9 */     return this;
/*    */   }
/*    */ 
/*    */   public final String getVarName() {
/* 13 */     return this.varName;
/*    */   }
/*    */ 
/*    */   public final String getFullVarName() {
/* 17 */     return this.fullVarName;
/*    */   }
/*    */ 
/*    */   public String toFullVarName(VarNames paramVarNames)
/*    */   {
/* 23 */     paramVarNames.assertLast();
/* 24 */     return this.fullVarName;
/*    */   }
/*    */ 
/*    */   public void makeFullVarName(String paramString) {
/* 28 */     this.fullVarName = (paramString + "." + this.varName);
/*    */   }
/*    */ 
/*    */   public abstract Listenable copy();
/*    */ 
/*    */   public abstract void setChanged(LogNotify paramLogNotify);
/*    */ 
/*    */   public abstract void logNotify(Object paramObject, RecordState paramRecordState, ListenerMap paramListenerMap);
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.Listenable
 * JD-Core Version:    0.6.2
 */