/*    */ package xdb.logs;
/*    */ 
/*    */ public final class ListenableSet extends Listenable
/*    */ {
/*    */   private Note note;
/*    */ 
/*    */   public void setChanged(LogNotify paramLogNotify)
/*    */   {
/* 11 */     if (!paramLogNotify.isLast())
/*    */     {
/* 13 */       return;
/*    */     }
/*    */ 
/* 16 */     if (null == this.note)
/* 17 */       this.note = paramLogNotify.getNote();
/*    */     else
/* 19 */       ((NoteSet)this.note).merge(paramLogNotify.getNote());
/*    */   }
/*    */ 
/*    */   public ListenableSet copy()
/*    */   {
/* 25 */     ListenableSet localListenableSet = new ListenableSet();
/* 26 */     localListenableSet.fullVarName = this.fullVarName;
/* 27 */     return localListenableSet;
/*    */   }
/*    */ 
/*    */   public void logNotify(Object paramObject, RecordState paramRecordState, ListenerMap paramListenerMap)
/*    */   {
/* 32 */     switch (1.$SwitchMap$xdb$logs$RecordState[paramRecordState.ordinal()]) {
/*    */     case 1:
/* 34 */       paramListenerMap.notifyChanged(this.fullVarName, paramObject);
/* 35 */       break;
/*    */     case 2:
/* 38 */       paramListenerMap.notifyRemoved(this.fullVarName, paramObject);
/* 39 */       break;
/*    */     case 3:
/* 42 */       if (null != this.note)
/* 43 */         paramListenerMap.notifyChanged(this.fullVarName, paramObject, this.note);
/*    */       break;
/*    */     }
/* 46 */     this.note = null;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.ListenableSet
 * JD-Core Version:    0.6.2
 */