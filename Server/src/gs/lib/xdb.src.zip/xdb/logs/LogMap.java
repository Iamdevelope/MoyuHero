/*     */ package xdb.logs;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import xdb.Log;
/*     */ import xdb.LogKey;
/*     */ import xdb.Logs;
/*     */ import xdb.Savepoint;
/*     */ import xdb.Transaction;
/*     */ 
/*     */ public class LogMap<K, V, W extends Map<K, V>>
/*     */   implements Map<K, V>
/*     */ {
/*     */   final LogKey logkey;
/*     */   final W wrapped;
/*     */   private LogMap<K, V, W>.EntrySet esview;
/*     */   private LogMap<K, V, W>.KeySet ksview;
/*     */   private LogMap<K, V, W>.Values vsview;
/*     */ 
/*     */   public LogMap(LogKey paramLogKey, W paramW)
/*     */   {
/*  33 */     this.logkey = paramLogKey;
/*  34 */     this.wrapped = paramW;
/*     */   }
/*     */ 
/*     */   final LogMap<K, V, W>.MyLog myLog()
/*     */   {
/* 140 */     Savepoint localSavepoint = Transaction.currentSavepoint();
/* 141 */     Object localObject = localSavepoint.get(this.logkey);
/* 142 */     if (null == localObject)
/* 143 */       localSavepoint.add(this.logkey, localObject = new MyLog());
/* 144 */     return (MyLog)localObject;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 150 */     for (Map.Entry localEntry : this.wrapped.entrySet())
/* 151 */       myLog().beforeRemove(localEntry.getKey(), localEntry.getValue());
/* 152 */     this.wrapped.clear();
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object paramObject)
/*     */   {
/* 157 */     return this.wrapped.containsKey(paramObject);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object paramObject)
/*     */   {
/* 162 */     return this.wrapped.containsValue(paramObject);
/*     */   }
/*     */ 
/*     */   private Iterator<Map.Entry<K, V>> newEntryIterator()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 24	xdb/logs/LogMap$1
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: invokespecial 25	xdb/logs/LogMap$1:<init>	(Lxdb/logs/LogMap;)V
/*     */     //   8: areturn
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<K, V>> entrySet()
/*     */   {
/* 278 */     return this.esview = new EntrySet(null);
/*     */   }
/*     */ 
/*     */   public V get(Object paramObject)
/*     */   {
/* 283 */     return this.wrapped.get(paramObject);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 288 */     return this.wrapped.hashCode();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object paramObject)
/*     */   {
/* 293 */     return this.wrapped.equals(paramObject);
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 298 */     return this.wrapped.isEmpty();
/*     */   }
/*     */ 
/*     */   private Iterator<K> newKeyIterator()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 33	xdb/logs/LogMap$2
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: invokespecial 34	xdb/logs/LogMap$2:<init>	(Lxdb/logs/LogMap;)V
/*     */     //   8: areturn
/*     */   }
/*     */ 
/*     */   public Set<K> keySet()
/*     */   {
/* 340 */     return this.ksview = new KeySet(null);
/*     */   }
/*     */ 
/*     */   public V put(K paramK, V paramV)
/*     */   {
/* 345 */     if ((null == paramV) || (null == paramK)) {
/* 346 */       throw new NullPointerException();
/*     */     }
/* 348 */     Logs.xdbParent(paramV, this.logkey.getXBean(), this.logkey.getVarname());
/* 349 */     Object localObject = this.wrapped.put(paramK, paramV);
/* 350 */     myLog().afterPut(paramK, localObject, paramV);
/* 351 */     return localObject;
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends K, ? extends V> paramMap)
/*     */   {
/* 356 */     for (Map.Entry localEntry : paramMap.entrySet())
/* 357 */       put(localEntry.getKey(), localEntry.getValue());
/*     */   }
/*     */ 
/*     */   public V remove(Object paramObject)
/*     */   {
/* 363 */     Object localObject1 = this.wrapped.remove(paramObject);
/* 364 */     if (null != localObject1)
/*     */     {
/* 366 */       Object localObject2 = paramObject;
/* 367 */       myLog().afterRemove(localObject2, localObject1);
/*     */     }
/* 369 */     return localObject1;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 374 */     return this.wrapped.size();
/*     */   }
/*     */ 
/*     */   private Iterator<V> newValueIterator()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 49	xdb/logs/LogMap$3
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: invokespecial 50	xdb/logs/LogMap$3:<init>	(Lxdb/logs/LogMap;)V
/*     */     //   8: areturn
/*     */   }
/*     */ 
/*     */   public Collection<V> values()
/*     */   {
/* 411 */     return this.vsview = new Values(null);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 416 */     return this.wrapped.toString();
/*     */   }
/*     */ 
/*     */   private final class Values extends AbstractCollection<V>
/*     */   {
/*     */     private Values()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<V> iterator()
/*     */     {
/* 388 */       return LogMap.this.newValueIterator();
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 393 */       return LogMap.this.size();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object paramObject)
/*     */     {
/* 398 */       return LogMap.this.containsValue(paramObject);
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 403 */       LogMap.this.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class KeySet extends AbstractSet<K>
/*     */   {
/*     */     private KeySet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<K> iterator()
/*     */     {
/* 312 */       return LogMap.this.newKeyIterator();
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 317 */       return LogMap.this.size();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object paramObject)
/*     */     {
/* 322 */       return LogMap.this.containsKey(paramObject);
/*     */     }
/*     */ 
/*     */     public boolean remove(Object paramObject)
/*     */     {
/* 327 */       return LogMap.this.remove(paramObject) != null;
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 332 */       LogMap.this.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class EntrySet extends AbstractSet<Map.Entry<K, V>>
/*     */   {
/*     */     private EntrySet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<K, V>> iterator()
/*     */     {
/* 242 */       return LogMap.this.newEntryIterator();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object paramObject)
/*     */     {
/* 247 */       return LogMap.this.wrapped.entrySet().contains(paramObject);
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 252 */       return LogMap.this.wrapped.entrySet().size();
/*     */     }
/*     */ 
/*     */     public boolean remove(Object paramObject)
/*     */     {
/* 257 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 270 */       LogMap.this.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   final class WrapEntry
/*     */     implements Map.Entry<K, V>
/*     */   {
/*     */     private Map.Entry<K, V> e;
/*     */ 
/*     */     WrapEntry()
/*     */     {
/*     */       Object localObject;
/* 205 */       this.e = localObject;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object paramObject)
/*     */     {
/* 210 */       return this.e.equals(paramObject);
/*     */     }
/*     */ 
/*     */     public K getKey()
/*     */     {
/* 215 */       return this.e.getKey();
/*     */     }
/*     */ 
/*     */     public V getValue()
/*     */     {
/* 220 */       return this.e.getValue();
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 225 */       return this.e.hashCode();
/*     */     }
/*     */ 
/*     */     public V setValue(V paramV)
/*     */     {
/* 230 */       if (null == paramV)
/* 231 */         throw new NullPointerException();
/* 232 */       Logs.xdbParent(paramV, LogMap.this.logkey.getXBean(), LogMap.this.logkey.getVarname());
/* 233 */       Object localObject = this.e.setValue(paramV);
/* 234 */       LogMap.MyLog.access$100(LogMap.this.myLog(), this.e.getKey(), localObject, paramV);
/* 235 */       return localObject;
/*     */     }
/*     */   }
/*     */ 
/*     */   abstract class WrapEntryIt<E>
/*     */     implements Iterator<E>
/*     */   {
/*     */     private final Iterator<Map.Entry<K, V>> it;
/*     */     private LogMap<K, V, W>.WrapEntry current;
/*     */ 
/*     */     WrapEntryIt()
/*     */     {
/* 171 */       this.it = LogMap.this.wrapped.entrySet().iterator();
/*     */     }
/*     */ 
/*     */     WrapEntryIt()
/*     */     {
/*     */       Object localObject;
/* 175 */       this.it = localObject;
/*     */     }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 180 */       LogMap.MyLog.access$000(LogMap.this.myLog(), this.current.getKey(), this.current.getValue());
/* 181 */       this.it.remove();
/*     */     }
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/* 186 */       return this.it.hasNext();
/*     */     }
/*     */ 
/*     */     Map.Entry<K, V> nextEntry() {
/* 190 */       return this.current = new LogMap.WrapEntry(LogMap.this, (Map.Entry)this.it.next());
/*     */     }
/*     */   }
/*     */ 
/*     */   final class MyLog extends NoteMap<K, V>
/*     */     implements Log
/*     */   {
/*     */     MyLog()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void commit()
/*     */     {
/*  40 */       if (super.isMapChanged())
/*  41 */         Logs.logNotify(LogMap.this.logkey.getXBean(), new LogNotify(LogMap.this.logkey, this));
/*     */     }
/*     */ 
/*     */     public void rollback()
/*     */     {
/*  46 */       Object localObject;
/*  46 */       for (Iterator localIterator = super.getAdded().iterator(); localIterator.hasNext(); LogMap.this.wrapped.remove(localObject)) localObject = localIterator.next();
/*  47 */       LogMap.this.wrapped.putAll(super.getRemoved());
/*  48 */       LogMap.this.wrapped.putAll(super.getReplaced());
/*  49 */       super.clear();
/*     */     }
/*     */ 
/*     */     private void beforeRemove(K paramK, V paramV)
/*     */     {
/*  60 */       Logs.xdbParent(paramV, null, null);
/*  61 */       super.logRemove(paramK, paramV);
/*     */     }
/*     */ 
/*     */     void afterRemove(K paramK, V paramV)
/*     */     {
/*  66 */       super.logRemove(paramK, paramV);
/*  67 */       Logs.xdbParent(paramV, null, null);
/*     */     }
/*     */ 
/*     */     private void afterPut(K paramK, V paramV1, V paramV2) {
/*  71 */       super.logPut(paramK, paramV1, paramV2);
/*     */ 
/*  73 */       if (null != paramV1)
/*  74 */         Logs.xdbParent(paramV1, null, null);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogMap
 * JD-Core Version:    0.6.2
 */