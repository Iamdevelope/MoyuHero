/*    */ package xdb.logs;
/*    */ 
/*    */ import xdb.TRecord.State;
/*    */ 
/*    */ public final class AddRemoveInfo
/*    */ {
/*    */   private boolean _isCreateCache;
/*    */   private TRecord.State _savedState;
/*    */ 
/*    */   public AddRemoveInfo(boolean paramBoolean, TRecord.State paramState)
/*    */   {
/* 10 */     this._isCreateCache = paramBoolean;
/* 11 */     this._savedState = paramState;
/*    */   }
/*    */ 
/*    */   public boolean isCreateCache() {
/* 15 */     return this._isCreateCache;
/*    */   }
/*    */ 
/*    */   public TRecord.State getSavedState() {
/* 19 */     return this._savedState;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.AddRemoveInfo
 * JD-Core Version:    0.6.2
 */