/*    */ package xdb.logs;
/*    */ 
/*    */ import xdb.Log;
/*    */ import xdb.LogKey;
/*    */ import xdb.Logs;
/*    */ 
/*    */ public abstract class LogString extends Note
/*    */   implements Log
/*    */ {
/*    */   protected LogKey logkey;
/*    */   protected String _xdb_saved;
/*    */ 
/*    */   protected LogString(LogKey paramLogKey, String paramString)
/*    */   {
/* 11 */     this.logkey = paramLogKey;
/* 12 */     this._xdb_saved = paramString;
/*    */   }
/*    */ 
/*    */   public void commit()
/*    */   {
/* 17 */     Logs.logNotify(this.logkey.getXBean(), new LogNotify(this.logkey, this));
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogString
 * JD-Core Version:    0.6.2
 */