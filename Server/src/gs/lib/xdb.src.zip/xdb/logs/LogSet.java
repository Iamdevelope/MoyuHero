/*     */ package xdb.logs;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import xdb.Log;
/*     */ import xdb.LogKey;
/*     */ import xdb.Logs;
/*     */ import xdb.Savepoint;
/*     */ import xdb.Transaction;
/*     */ import xdb.util.SetX;
/*     */ 
/*     */ public final class LogSet<E> extends AbstractSet<E>
/*     */ {
/*     */   private LogKey logkey;
/*     */   private final SetX<E> wrapped;
/*     */ 
/*     */   private final LogSet<E>.MyLog myLog()
/*     */   {
/*  54 */     Savepoint localSavepoint = Transaction.currentSavepoint();
/*  55 */     Object localObject = localSavepoint.get(this.logkey);
/*  56 */     if (null == localObject)
/*  57 */       localSavepoint.add(this.logkey, localObject = new MyLog(null));
/*  58 */     return (MyLog)localObject;
/*     */   }
/*     */ 
/*     */   public LogSet(LogKey paramLogKey, SetX<E> paramSetX)
/*     */   {
/*  63 */     this.logkey = paramLogKey;
/*  64 */     this.wrapped = paramSetX;
/*     */   }
/*     */ 
/*     */   public boolean add(E paramE)
/*     */   {
/*  70 */     Logs.xdbManagedCheck(paramE);
/*  71 */     if (this.wrapped.add(paramE)) {
/*  72 */       myLog().afterAdd(paramE);
/*  73 */       Logs.xdbParent(paramE, this.logkey.getXBean(), this.logkey.getVarname());
/*  74 */       return true;
/*     */     }
/*  76 */     return false;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  81 */     for (Iterator localIterator = iterator(); localIterator.hasNext(); ) {
/*  82 */       myLog().beforeRemove(localIterator.next());
/*     */     }
/*  84 */     this.wrapped.clear();
/*     */   }
/*     */ 
/*     */   public boolean contains(Object paramObject)
/*     */   {
/*  89 */     return this.wrapped.contains(paramObject);
/*     */   }
/*     */ 
/*     */   public Iterator<E> iterator()
/*     */   {
/* 115 */     return new WrapIt(null);
/*     */   }
/*     */ 
/*     */   public boolean remove(Object paramObject)
/*     */   {
/* 120 */     Object localObject = this.wrapped.removex(paramObject);
/* 121 */     if (localObject != null) {
/* 122 */       myLog().afterRemove(localObject);
/* 123 */       return true;
/*     */     }
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 130 */     return this.wrapped.size();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 135 */     return this.wrapped.hashCode();
/*     */   }
/*     */ 
/*     */   private class WrapIt
/*     */     implements Iterator<E>
/*     */   {
/*  93 */     Iterator<E> it = LogSet.this.wrapped.iterator();
/*     */     E current;
/*     */ 
/*     */     private WrapIt()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean hasNext()
/*     */     {
/*  98 */       return this.it.hasNext();
/*     */     }
/*     */ 
/*     */     public E next()
/*     */     {
/* 103 */       return this.current = this.it.next();
/*     */     }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 108 */       LogSet.MyLog.access$400(LogSet.this.myLog(), this.current);
/* 109 */       this.it.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class MyLog extends NoteSet<E>
/*     */     implements Log
/*     */   {
/*     */     private MyLog()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void commit()
/*     */     {
/*  21 */       if (super.isSetChanged())
/*  22 */         Logs.logNotify(LogSet.this.logkey.getXBean(), new LogNotify(LogSet.this.logkey, this));
/*     */     }
/*     */ 
/*     */     public void rollback()
/*     */     {
/*  28 */       LogSet.this.wrapped.removeAll(super.getAdded());
/*  29 */       LogSet.this.wrapped.addAll(super.getRemoved());
/*  30 */       for (Iterator localIterator = super.getOld().iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/*  31 */         LogSet.this.wrapped.remove(localObject);
/*  32 */         LogSet.this.wrapped.add(localObject);
/*     */       }
/*  34 */       super.clear();
/*     */     }
/*     */ 
/*     */     private void beforeRemove(E paramE) {
/*  38 */       Logs.xdbParent(paramE, null, null);
/*  39 */       super.logRemove(paramE);
/*     */     }
/*     */ 
/*     */     private void afterRemove(E paramE) {
/*  43 */       super.logRemove(paramE);
/*  44 */       Logs.xdbParent(paramE, null, null);
/*     */     }
/*     */ 
/*     */     private void afterAdd(E paramE) {
/*  48 */       super.logAdd(paramE);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogSet
 * JD-Core Version:    0.6.2
 */