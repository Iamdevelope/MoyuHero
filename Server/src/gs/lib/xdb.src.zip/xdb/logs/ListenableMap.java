/*    */ package xdb.logs;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import xdb.LogKey;
/*    */ 
/*    */ public final class ListenableMap extends Listenable
/*    */ {
/*    */   private Note note;
/*    */   private List<Object> changed;
/*    */ 
/*    */   public void setChanged(LogNotify paramLogNotify)
/*    */   {
/* 13 */     if (paramLogNotify.isLast())
/*    */     {
/* 15 */       if (null == this.note)
/* 16 */         this.note = paramLogNotify.getNote();
/*    */       else
/* 18 */         ((NoteMap)this.note).merge(paramLogNotify.getNote());
/*    */     }
/*    */     else
/*    */     {
/* 22 */       if (null == this.changed) {
/* 23 */         this.changed = new ArrayList();
/*    */       }
/* 25 */       LogKey localLogKey = paramLogNotify.pop();
/* 26 */       this.changed.add(localLogKey.getXBean());
/*    */     }
/*    */   }
/*    */ 
/*    */   public ListenableMap copy()
/*    */   {
/* 32 */     ListenableMap localListenableMap = new ListenableMap();
/* 33 */     localListenableMap.fullVarName = this.fullVarName;
/* 34 */     return localListenableMap;
/*    */   }
/*    */ 
/*    */   public void logNotify(Object paramObject, RecordState paramRecordState, ListenerMap paramListenerMap)
/*    */   {
/* 40 */     switch (1.$SwitchMap$xdb$logs$RecordState[paramRecordState.ordinal()]) {
/*    */     case 1:
/* 42 */       paramListenerMap.notifyChanged(this.fullVarName, paramObject);
/* 43 */       break;
/*    */     case 2:
/* 46 */       paramListenerMap.notifyRemoved(this.fullVarName, paramObject);
/* 47 */       break;
/*    */     case 3:
/* 50 */       if (((null != this.note) || (null != this.changed)) && (paramListenerMap.hasListener(this.fullVarName))) {
/* 51 */         NoteMap localNoteMap = null != this.note ? (NoteMap)this.note : new NoteMap();
/* 52 */         localNoteMap.setChanged(null != this.changed ? this.changed : new ArrayList());
/* 53 */         paramListenerMap.notifyChanged(this.fullVarName, paramObject, localNoteMap);
/*    */       }
/*    */       break;
/*    */     }
/* 57 */     this.note = null;
/* 58 */     this.changed = null;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.ListenableMap
 * JD-Core Version:    0.6.2
 */