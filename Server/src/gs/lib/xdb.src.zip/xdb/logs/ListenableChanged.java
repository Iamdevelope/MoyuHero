/*    */ package xdb.logs;
/*    */ 
/*    */ public final class ListenableChanged extends Listenable
/*    */ {
/*  7 */   private boolean changed = false;
/*    */ 
/*    */   public void setChanged(LogNotify paramLogNotify)
/*    */   {
/* 11 */     this.changed = true;
/*    */   }
/*    */ 
/*    */   public ListenableChanged copy()
/*    */   {
/* 17 */     ListenableChanged localListenableChanged = new ListenableChanged();
/* 18 */     localListenableChanged.fullVarName = this.fullVarName;
/* 19 */     return localListenableChanged;
/*    */   }
/*    */ 
/*    */   public void logNotify(Object paramObject, RecordState paramRecordState, ListenerMap paramListenerMap)
/*    */   {
/* 24 */     switch (1.$SwitchMap$xdb$logs$RecordState[paramRecordState.ordinal()]) {
/*    */     case 1:
/* 26 */       paramListenerMap.notifyChanged(this.fullVarName, paramObject);
/* 27 */       break;
/*    */     case 2:
/* 30 */       paramListenerMap.notifyRemoved(this.fullVarName, paramObject);
/* 31 */       break;
/*    */     case 3:
/* 34 */       if (this.changed)
/* 35 */         paramListenerMap.notifyChanged(this.fullVarName, paramObject, null);
/*    */       break;
/*    */     }
/* 38 */     this.changed = false;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.ListenableChanged
 * JD-Core Version:    0.6.2
 */