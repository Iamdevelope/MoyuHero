/*    */ package xdb.logs;
/*    */ 
/*    */ public class VarNames
/*    */ {
/*    */   private String[] path;
/*    */   private int pos;
/*    */ 
/*    */   public VarNames(String[] paramArrayOfString)
/*    */   {
/* 16 */     this.path = paramArrayOfString;
/* 17 */     this.pos = 0;
/*    */   }
/*    */ 
/*    */   public String currentFullVarName() {
/* 21 */     if (this.path.length == 0) {
/* 22 */       return ".";
/*    */     }
/* 24 */     StringBuilder localStringBuilder = new StringBuilder();
/* 25 */     for (int i = 0; i < this.pos; i++) {
/* 26 */       localStringBuilder.append('.').append(this.path[i]);
/*    */     }
/* 28 */     return localStringBuilder.toString();
/*    */   }
/*    */ 
/*    */   public String next() {
/* 32 */     return this.path[(this.pos++)];
/*    */   }
/*    */ 
/*    */   public boolean hasNext() {
/* 36 */     return this.pos < this.path.length;
/*    */   }
/*    */ 
/*    */   public void assertLast() {
/* 40 */     if (hasNext())
/* 41 */       throw new IllegalStateException();
/*    */   }
/*    */ 
/*    */   public void reset() {
/* 45 */     this.pos = 0;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.VarNames
 * JD-Core Version:    0.6.2
 */