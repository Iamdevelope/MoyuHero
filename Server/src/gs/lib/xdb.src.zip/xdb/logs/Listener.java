package xdb.logs;

public abstract interface Listener
{
  public abstract void onChanged(Object paramObject);

  public abstract void onRemoved(Object paramObject);

  public abstract void onChanged(Object paramObject, String paramString, Note paramNote);
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.Listener
 * JD-Core Version:    0.6.2
 */