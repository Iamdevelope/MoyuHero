/*    */ package xdb.logs;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import xdb.LogKey;
/*    */ 
/*    */ public final class LogNotify
/*    */ {
/* 13 */   private List<LogKey> path = new ArrayList();
/*    */   private Note note;
/*    */   private AddRemoveInfo addRemoveInfo;
/*    */ 
/*    */   public LogNotify(LogKey paramLogKey, Note paramNote)
/*    */   {
/* 18 */     this.path.add(paramLogKey);
/* 19 */     this.note = paramNote;
/*    */   }
/*    */ 
/*    */   public LogNotify(AddRemoveInfo paramAddRemoveInfo) {
/* 23 */     this.addRemoveInfo = paramAddRemoveInfo;
/*    */   }
/*    */ 
/*    */   public boolean isLast() {
/* 27 */     return this.path.isEmpty();
/*    */   }
/*    */ 
/*    */   public LogKey pop() {
/* 31 */     return (LogKey)this.path.remove(this.path.size() - 1);
/*    */   }
/*    */ 
/*    */   public LogNotify push(LogKey paramLogKey) {
/* 35 */     this.path.add(paramLogKey);
/* 36 */     return this;
/*    */   }
/*    */ 
/*    */   public boolean isAddRemove() {
/* 40 */     return null != this.addRemoveInfo;
/*    */   }
/*    */ 
/*    */   public AddRemoveInfo getAddRemoveInfo() {
/* 44 */     return this.addRemoveInfo;
/*    */   }
/*    */ 
/*    */   public Note getNote() {
/* 48 */     return this.note;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 53 */     StringBuilder localStringBuilder = new StringBuilder();
/* 54 */     for (int i = this.path.size() - 1; i >= 0; i--)
/* 55 */       localStringBuilder.append('.').append(((LogKey)this.path.get(i)).getVarname());
/* 56 */     localStringBuilder.append('=').append(this.note);
/* 57 */     return localStringBuilder.toString();
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.logs.LogNotify
 * JD-Core Version:    0.6.2
 */