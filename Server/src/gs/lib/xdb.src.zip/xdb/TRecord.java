/*     */ package xdb;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import xdb.logs.AddRemoveInfo;
/*     */ import xdb.logs.LogNotify;
/*     */ 
/*     */ public final class TRecord<K, V> extends XBean
/*     */ {
/*     */   private V value;
/*     */   private final Lockey lockey;
/*     */   private State state;
/*  22 */   private long lastAccessTime = System.nanoTime();
/*     */   public static final String RECORD_VARNAME = "value";
/* 226 */   private OctetsStream snapshotKey = null;
/* 227 */   private OctetsStream snapshotValue = null;
/* 228 */   private State snapshotState = null;
/*     */ 
/*     */   void access()
/*     */   {
/*  25 */     this.lastAccessTime = System.nanoTime();
/*     */   }
/*     */ 
/*     */   public final long getLastAccessTime() {
/*  29 */     return this.lastAccessTime;
/*     */   }
/*     */ 
/*     */   public final String toString()
/*     */   {
/*  43 */     return getTable().getName() + "," + this.lockey + "," + this.state;
/*     */   }
/*     */ 
/*     */   final TTable<K, V> getTable()
/*     */   {
/*  48 */     TTable localTTable = (TTable)xdbParent();
/*  49 */     return localTTable;
/*     */   }
/*     */ 
/*     */   public final K getKey()
/*     */   {
/*  54 */     Object localObject = this.lockey.getKey();
/*  55 */     return localObject;
/*     */   }
/*     */ 
/*     */   private final OctetsStream marshalKey() {
/*  59 */     return getTable().marshalKey(getKey());
/*     */   }
/*     */ 
/*     */   private final OctetsStream marshalValue()
/*     */   {
/*  64 */     return getTable().marshalValue(this.value);
/*     */   }
/*     */ 
/*     */   public final State getState() {
/*  68 */     return this.state;
/*     */   }
/*     */ 
/*     */   final void setState(State paramState)
/*     */   {
/*  77 */     this.state = paramState;
/*     */   }
/*     */ 
/*     */   final void xdbLogNotify(LogNotify paramLogNotify)
/*     */   {
/*  82 */     getTable().onRecordChanged(this, paramLogNotify);
/*     */   }
/*     */ 
/*     */   final boolean commit()
/*     */   {
/*  91 */     switch (1.$SwitchMap$xdb$TRecord$State[this.state.ordinal()])
/*     */     {
/*     */     case 1:
/*  95 */       return false;
/*     */     case 2:
/*  96 */       throw new XError("xdb:invalid record state");
/*     */     }
/*     */ 
/*  99 */     return true;
/*     */   }
/*     */ 
/*     */   final boolean rollback()
/*     */   {
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */   final Lockey getLockey() {
/* 119 */     return this.lockey;
/*     */   }
/*     */ 
/*     */   final LogKey getLogKey()
/*     */   {
/* 125 */     return new LogKey(this, "value");
/*     */   }
/*     */ 
/*     */   TRecord(TTable<K, V> paramTTable, V paramV, Lockey paramLockey, boolean paramBoolean) {
/* 129 */     this(paramTTable, paramV, paramLockey, paramBoolean ? State.INDB_REMOVE : State.REMOVE);
/*     */   }
/*     */ 
/*     */   TRecord(TTable<K, V> paramTTable, V paramV, Lockey paramLockey, State paramState) {
/* 133 */     super(paramTTable, "value");
/*     */ 
/* 137 */     if (null != paramV) {
/* 138 */       Logs.xdbParent(paramV, this, "value", State.INDB_GET != paramState);
/*     */     }
/*     */ 
/* 141 */     this.value = paramV;
/* 142 */     this.lockey = paramLockey;
/* 143 */     this.state = paramState;
/*     */   }
/*     */ 
/*     */   private final void _remove() {
/* 147 */     Logs.xdbParent(this.value, null, null);
/* 148 */     Transaction.currentSavepoint().addIfAbsent(getLogKey(), new LogAddRemove());
/* 149 */     this.value = null;
/*     */   }
/*     */ 
/*     */   final boolean remove() {
/* 153 */     switch (1.$SwitchMap$xdb$TRecord$State[this.state.ordinal()]) { case 2:
/* 154 */       _remove(); this.state = State.INDB_REMOVE; return true;
/*     */     case 3:
/* 155 */       _remove(); this.state = State.INDB_REMOVE; return true;
/*     */     case 4:
/* 156 */       _remove(); this.state = State.REMOVE; return true;
/*     */     }
/*     */ 
/* 160 */     return false;
/*     */   }
/*     */ 
/*     */   private final void _add(V paramV) {
/* 164 */     Logs.xdbParent(paramV, this, "value");
/* 165 */     Transaction.currentSavepoint().addIfAbsent(getLogKey(), new LogAddRemove());
/* 166 */     this.value = paramV;
/*     */   }
/*     */ 
/*     */   final boolean add(V paramV) {
/* 170 */     switch (1.$SwitchMap$xdb$TRecord$State[this.state.ordinal()])
/*     */     {
/*     */     case 5:
/* 174 */       _add(paramV); this.state = State.INDB_ADD; return true;
/*     */     case 1:
/* 175 */       _add(paramV); this.state = State.ADD; return true;
/*     */     }
/* 177 */     return false;
/*     */   }
/*     */ 
/*     */   final V getValue() {
/* 181 */     return this.value;
/*     */   }
/*     */ 
/*     */   final boolean tryMarshalN()
/*     */   {
/* 234 */     if (!this.lockey.tryLock())
/* 235 */       return false;
/*     */     try {
/* 237 */       marshal0();
/*     */     } finally {
/* 239 */       this.lockey.unlock();
/*     */     }
/* 241 */     return true;
/*     */   }
/*     */ 
/*     */   final void marshal0()
/*     */   {
/* 249 */     switch (1.$SwitchMap$xdb$TRecord$State[this.state.ordinal()]) { case 2:
/*     */     case 3:
/*     */     case 4:
/* 251 */       this.snapshotKey = marshalKey();
/* 252 */       this.snapshotValue = marshalValue();
/* 253 */       break;
/*     */     case 5:
/* 255 */       this.snapshotKey = marshalKey();
/* 256 */       break;
/*     */     case 1:
/*     */     }
/*     */   }
/*     */ 
/*     */   final void snapshot()
/*     */   {
/* 268 */     this.snapshotState = this.state;
/* 269 */     switch (1.$SwitchMap$xdb$TRecord$State[this.state.ordinal()])
/*     */     {
/*     */     case 2:
/* 272 */       break;
/*     */     case 5:
/* 274 */       getTable().getCache().remove(getKey());
/* 275 */       break;
/*     */     case 3:
/* 277 */       setState(State.INDB_GET);
/* 278 */       break;
/*     */     case 4:
/* 280 */       setState(State.INDB_GET);
/* 281 */       break;
/*     */     case 1:
/* 284 */       Trace.info("snapshot REMOVE record=" + this);
/* 285 */       getTable().getCache().remove(getKey());
/*     */     }
/*     */   }
/*     */ 
/*     */   final boolean flush(TStorage<K, V> paramTStorage)
/*     */   {
/* 297 */     switch (1.$SwitchMap$xdb$TRecord$State[this.snapshotState.ordinal()]) {
/*     */     case 2:
/* 299 */       paramTStorage.flushKeySize += this.snapshotKey.size();
/* 300 */       paramTStorage.flushValueSize += this.snapshotValue.size();
/* 301 */       paramTStorage.replaceUnsafe(this.snapshotKey, this.snapshotValue);
/* 302 */       break;
/*     */     case 3:
/* 304 */       paramTStorage.flushKeySize += this.snapshotKey.size();
/* 305 */       paramTStorage.flushValueSize += this.snapshotValue.size();
/* 306 */       paramTStorage.replaceUnsafe(this.snapshotKey, this.snapshotValue);
/* 307 */       break;
/*     */     case 4:
/* 309 */       paramTStorage.flushKeySize += this.snapshotKey.size();
/* 310 */       paramTStorage.flushValueSize += this.snapshotValue.size();
/* 311 */       paramTStorage.insertUnsafe(this.snapshotKey, this.snapshotValue);
/* 312 */       break;
/*     */     case 5:
/* 314 */       paramTStorage.flushKeySize += this.snapshotKey.size();
/* 315 */       paramTStorage.removeUnsafe(this.snapshotKey);
/* 316 */       break;
/*     */     case 1:
/* 319 */       return false;
/*     */     }
/* 321 */     return true;
/*     */   }
/*     */ 
/*     */   final void clear()
/*     */   {
/* 328 */     this.snapshotKey = null;
/* 329 */     this.snapshotValue = null;
/* 330 */     this.snapshotState = null;
/*     */   }
/*     */ 
/*     */   final boolean exist()
/*     */   {
/* 338 */     Trace.info("TRecord.exist " + this);
/* 339 */     switch (1.$SwitchMap$xdb$TRecord$State[this.snapshotState.ordinal()]) { case 2:
/*     */     case 3:
/*     */     case 4:
/* 341 */       return true;
/*     */     case 1:
/*     */     case 5:
/* 343 */       return false;
/*     */     }
/* 345 */     throw new XError("invalid record state");
/*     */   }
/*     */ 
/*     */   final OctetsStream find()
/*     */   {
/* 352 */     Trace.info("TRecord.find " + this);
/* 353 */     switch (1.$SwitchMap$xdb$TRecord$State[this.snapshotState.ordinal()]) { case 2:
/*     */     case 3:
/*     */     case 4:
/* 355 */       return this.snapshotValue;
/*     */     case 1:
/*     */     case 5:
/* 357 */       return null;
/*     */     }
/* 359 */     throw new XError("invalid record state");
/*     */   }
/*     */ 
/*     */   private class LogAddRemove
/*     */     implements Log
/*     */   {
/*     */     private V saved_value;
/*     */     private TRecord.State saved_state;
/*     */ 
/*     */     LogAddRemove()
/*     */     {
/* 201 */       this.saved_value = TRecord.this.value;
/* 202 */       this.saved_state = TRecord.this.state;
/*     */     }
/*     */ 
/*     */     public void commit()
/*     */     {
/* 207 */       TRecord.this.xdbLogNotify(new LogNotify(new AddRemoveInfo(false, this.saved_state)));
/*     */     }
/*     */ 
/*     */     public void rollback()
/*     */     {
/* 212 */       TRecord.this.value = this.saved_value;
/* 213 */       TRecord.this.state = this.saved_state;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 218 */       return "state=" + this.saved_state + " value=" + this.saved_value;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum State
/*     */   {
/*  34 */     INDB_GET, 
/*  35 */     INDB_REMOVE, 
/*  36 */     INDB_ADD, 
/*  37 */     ADD, 
/*  38 */     REMOVE;
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.TRecord
 * JD-Core Version:    0.6.2
 */