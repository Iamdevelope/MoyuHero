/*    */ package xdb.consts;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import xdb.Consts;
/*    */ 
/*    */ public class ConstIterator<E>
/*    */   implements Iterator<E>
/*    */ {
/*    */   private final Iterator<E> it;
/*    */ 
/*    */   public ConstIterator(Iterator<E> paramIterator)
/*    */   {
/*  9 */     this.it = paramIterator;
/*    */   }
/*    */ 
/*    */   public final boolean hasNext()
/*    */   {
/* 14 */     return this.it.hasNext();
/*    */   }
/*    */ 
/*    */   public final E next()
/*    */   {
/* 19 */     return Consts.toConst(this.it.next());
/*    */   }
/*    */ 
/*    */   public final void remove()
/*    */   {
/* 24 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.consts.ConstIterator
 * JD-Core Version:    0.6.2
 */