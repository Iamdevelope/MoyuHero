/*    */ package xdb.consts;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NavigableSet;
/*    */ import xdb.Consts;
/*    */ 
/*    */ public class ConstNavigableSet<E> extends ConstSortedSet<E, NavigableSet<E>>
/*    */   implements NavigableSet<E>
/*    */ {
/*    */   private NavigableSet<E> descendingSet;
/*    */ 
/*    */   public ConstNavigableSet(NavigableSet<E> paramNavigableSet)
/*    */   {
/*  9 */     super(paramNavigableSet);
/*    */   }
/*    */ 
/*    */   public final E ceiling(E paramE)
/*    */   {
/* 14 */     return Consts.toConst(((NavigableSet)this.w).ceiling(paramE));
/*    */   }
/*    */ 
/*    */   public final E lower(E paramE)
/*    */   {
/* 19 */     return Consts.toConst(((NavigableSet)this.w).lower(paramE));
/*    */   }
/*    */ 
/*    */   public E higher(E paramE)
/*    */   {
/* 24 */     return Consts.toConst(((NavigableSet)this.w).higher(paramE));
/*    */   }
/*    */ 
/*    */   public final E floor(E paramE)
/*    */   {
/* 29 */     return Consts.toConst(((NavigableSet)this.w).floor(paramE));
/*    */   }
/*    */ 
/*    */   public Iterator<E> descendingIterator()
/*    */   {
/* 34 */     return new ConstIterator(((NavigableSet)this.w).descendingIterator());
/*    */   }
/*    */ 
/*    */   public final E pollFirst()
/*    */   {
/* 39 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public final E pollLast()
/*    */   {
/* 44 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public final NavigableSet<E> descendingSet()
/*    */   {
/* 51 */     if (null == this.descendingSet)
/* 52 */       this.descendingSet = new ConstNavigableSet(((NavigableSet)this.w).descendingSet());
/* 53 */     return this.descendingSet;
/*    */   }
/*    */ 
/*    */   public final NavigableSet<E> headSet(E paramE, boolean paramBoolean)
/*    */   {
/* 58 */     return new ConstNavigableSet(((NavigableSet)this.w).headSet(paramE, paramBoolean));
/*    */   }
/*    */ 
/*    */   public final NavigableSet<E> subSet(E paramE1, boolean paramBoolean1, E paramE2, boolean paramBoolean2)
/*    */   {
/* 63 */     return new ConstNavigableSet(((NavigableSet)this.w).subSet(paramE1, paramBoolean1, paramE2, paramBoolean2));
/*    */   }
/*    */ 
/*    */   public final NavigableSet<E> tailSet(E paramE, boolean paramBoolean)
/*    */   {
/* 68 */     return new ConstNavigableSet(((NavigableSet)this.w).tailSet(paramE, paramBoolean));
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.consts.ConstNavigableSet
 * JD-Core Version:    0.6.2
 */