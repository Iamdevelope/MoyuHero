/*    */ package xdb.consts;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import java.util.SortedMap;
/*    */ import xdb.Consts;
/*    */ 
/*    */ public class ConstSortedMap<K, V, W extends SortedMap<K, V>> extends ConstMap<K, V, W>
/*    */   implements SortedMap<K, V>
/*    */ {
/*    */   public ConstSortedMap(W paramW)
/*    */   {
/*  9 */     super(paramW);
/*    */   }
/*    */ 
/*    */   public Comparator<? super K> comparator()
/*    */   {
/* 14 */     return ((SortedMap)this.w).comparator();
/*    */   }
/*    */ 
/*    */   public SortedMap<K, V> headMap(K paramK)
/*    */   {
/* 19 */     return new ConstSortedMap(((SortedMap)this.w).headMap(paramK));
/*    */   }
/*    */ 
/*    */   public SortedMap<K, V> subMap(K paramK1, K paramK2)
/*    */   {
/* 24 */     return new ConstSortedMap(((SortedMap)this.w).subMap(paramK1, paramK2));
/*    */   }
/*    */ 
/*    */   public SortedMap<K, V> tailMap(K paramK)
/*    */   {
/* 29 */     return new ConstSortedMap(((SortedMap)this.w).tailMap(paramK));
/*    */   }
/*    */ 
/*    */   public K firstKey()
/*    */   {
/* 34 */     return Consts.toConst(((SortedMap)this.w).firstKey());
/*    */   }
/*    */ 
/*    */   public K lastKey()
/*    */   {
/* 39 */     return Consts.toConst(((SortedMap)this.w).lastKey());
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.consts.ConstSortedMap
 * JD-Core Version:    0.6.2
 */