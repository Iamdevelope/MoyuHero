/*    */ package xdb.consts;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import xdb.Consts;
/*    */ 
/*    */ public class ConstCollection<E, W extends Collection<E>>
/*    */   implements Collection<E>
/*    */ {
/*    */   final W w;
/*    */ 
/*    */   public ConstCollection(W paramW)
/*    */   {
/* 13 */     this.w = paramW;
/*    */   }
/*    */ 
/*    */   public final int size()
/*    */   {
/* 18 */     return this.w.size();
/*    */   }
/*    */ 
/*    */   public final boolean isEmpty()
/*    */   {
/* 23 */     return this.w.isEmpty();
/*    */   }
/*    */ 
/*    */   public final boolean contains(Object paramObject)
/*    */   {
/* 28 */     return this.w.contains(paramObject);
/*    */   }
/*    */ 
/*    */   public final String toString()
/*    */   {
/* 33 */     return this.w.toString();
/*    */   }
/*    */ 
/*    */   public final boolean add(E paramE)
/*    */   {
/* 38 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public final boolean remove(Object paramObject)
/*    */   {
/* 43 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public final boolean containsAll(Collection<?> paramCollection)
/*    */   {
/* 48 */     return this.w.containsAll(paramCollection);
/*    */   }
/*    */ 
/*    */   public final boolean addAll(Collection<? extends E> paramCollection)
/*    */   {
/* 53 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public final boolean removeAll(Collection<?> paramCollection)
/*    */   {
/* 58 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public final boolean retainAll(Collection<?> paramCollection)
/*    */   {
/* 63 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public final void clear()
/*    */   {
/* 68 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public final boolean equals(Object paramObject)
/*    */   {
/* 73 */     return (paramObject == this) || (this.w.equals(paramObject));
/*    */   }
/*    */ 
/*    */   public final int hashCode()
/*    */   {
/* 78 */     return this.w.hashCode();
/*    */   }
/*    */ 
/*    */   public Object[] toArray()
/*    */   {
/* 83 */     return Consts.toConst(this.w.toArray());
/*    */   }
/*    */ 
/*    */   public <T> T[] toArray(T[] paramArrayOfT)
/*    */   {
/* 89 */     return Consts.toConst(this.w.toArray(paramArrayOfT));
/*    */   }
/*    */ 
/*    */   public Iterator<E> iterator()
/*    */   {
/* 94 */     return new ConstIterator(this.w.iterator());
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.consts.ConstCollection
 * JD-Core Version:    0.6.2
 */