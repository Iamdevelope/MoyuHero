/*    */ package xdb.consts;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import java.util.SortedSet;
/*    */ import xdb.Consts;
/*    */ 
/*    */ public class ConstSortedSet<E, W extends SortedSet<E>> extends ConstSet<E, W>
/*    */   implements SortedSet<E>
/*    */ {
/*    */   public ConstSortedSet(W paramW)
/*    */   {
/*  9 */     super(paramW);
/*    */   }
/*    */ 
/*    */   public final Comparator<? super E> comparator()
/*    */   {
/* 14 */     return ((SortedSet)this.w).comparator();
/*    */   }
/*    */ 
/*    */   public final E first()
/*    */   {
/* 19 */     return Consts.toConst(((SortedSet)this.w).first());
/*    */   }
/*    */ 
/*    */   public final E last()
/*    */   {
/* 24 */     return Consts.toConst(((SortedSet)this.w).last());
/*    */   }
/*    */ 
/*    */   public final SortedSet<E> headSet(E paramE)
/*    */   {
/* 29 */     return new ConstSortedSet(((SortedSet)this.w).headSet(paramE));
/*    */   }
/*    */ 
/*    */   public final SortedSet<E> subSet(E paramE1, E paramE2)
/*    */   {
/* 34 */     return new ConstSortedSet(((SortedSet)this.w).subSet(paramE1, paramE2));
/*    */   }
/*    */ 
/*    */   public final SortedSet<E> tailSet(E paramE)
/*    */   {
/* 39 */     return new ConstSortedSet(((SortedSet)this.w).tailSet(paramE));
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.consts.ConstSortedSet
 * JD-Core Version:    0.6.2
 */