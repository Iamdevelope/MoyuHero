/*    */ package xdb.consts;
/*    */ 
/*    */ import java.util.Map.Entry;
/*    */ import xdb.Consts;
/*    */ 
/*    */ public class ConstEntry<K, V>
/*    */   implements Map.Entry<K, V>
/*    */ {
/*    */   private Map.Entry<K, V> e;
/*    */ 
/*    */   public ConstEntry(Map.Entry<K, V> paramEntry)
/*    */   {
/* 11 */     this.e = paramEntry;
/*    */   }
/*    */ 
/*    */   public K getKey()
/*    */   {
/* 16 */     return Consts.toConst(this.e.getKey());
/*    */   }
/*    */ 
/*    */   public V getValue()
/*    */   {
/* 21 */     return Consts.toConst(this.e.getValue());
/*    */   }
/*    */ 
/*    */   public V setValue(V paramV)
/*    */   {
/* 26 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 31 */     return this.e.hashCode();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object paramObject)
/*    */   {
/* 36 */     return this.e.equals(paramObject);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 41 */     return this.e.toString();
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.consts.ConstEntry
 * JD-Core Version:    0.6.2
 */