/*     */ package xdb.consts;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import xdb.Consts;
/*     */ 
/*     */ public class ConstMap<K, V, W extends Map<K, V>>
/*     */   implements Map<K, V>
/*     */ {
/*     */   final W w;
/*  64 */   private Set<K> keySet = null;
/*  65 */   private Set<Map.Entry<K, V>> entrySet = null;
/*  66 */   private Collection<V> values = null;
/*     */ 
/*     */   public ConstMap(W paramW)
/*     */   {
/*  16 */     this.w = paramW;
/*     */   }
/*     */ 
/*     */   public final int size()
/*     */   {
/*  21 */     return this.w.size();
/*     */   }
/*     */ 
/*     */   public final boolean isEmpty()
/*     */   {
/*  26 */     return this.w.isEmpty();
/*     */   }
/*     */ 
/*     */   public final boolean containsKey(Object paramObject)
/*     */   {
/*  31 */     return this.w.containsKey(paramObject);
/*     */   }
/*     */ 
/*     */   public final boolean containsValue(Object paramObject)
/*     */   {
/*  36 */     return this.w.containsValue(paramObject);
/*     */   }
/*     */ 
/*     */   public final V get(Object paramObject)
/*     */   {
/*  41 */     return Consts.toConst(this.w.get(paramObject));
/*     */   }
/*     */ 
/*     */   public final V put(K paramK, V paramV)
/*     */   {
/*  46 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final V remove(Object paramObject)
/*     */   {
/*  51 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final void putAll(Map<? extends K, ? extends V> paramMap)
/*     */   {
/*  56 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final void clear()
/*     */   {
/*  61 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final Set<K> keySet()
/*     */   {
/*  70 */     if (this.keySet == null)
/*  71 */       this.keySet = new ConstSet(this.w.keySet());
/*  72 */     return this.keySet;
/*     */   }
/*     */ 
/*     */   public final Set<Map.Entry<K, V>> entrySet()
/*     */   {
/*  77 */     if (this.entrySet == null)
/*  78 */       this.entrySet = new ConstEntrySet(this.w.entrySet());
/*  79 */     return this.entrySet;
/*     */   }
/*     */ 
/*     */   public final Collection<V> values()
/*     */   {
/*  84 */     if (this.values == null)
/*  85 */       this.values = new ConstCollection(this.w.values());
/*  86 */     return this.values;
/*     */   }
/*     */ 
/*     */   public final boolean equals(Object paramObject)
/*     */   {
/*  91 */     return (paramObject == this) || (this.w.equals(paramObject));
/*     */   }
/*     */ 
/*     */   public final int hashCode()
/*     */   {
/*  96 */     return this.w.hashCode();
/*     */   }
/*     */ 
/*     */   public final String toString()
/*     */   {
/* 101 */     return this.w.toString();
/*     */   }
/*     */ 
/*     */   private static final class ConstEntrySet<K, V> extends ConstSet<Map.Entry<K, V>, Set<Map.Entry<K, V>>>
/*     */   {
/*     */     ConstEntrySet(Set<Map.Entry<K, V>> paramSet) {
/* 107 */       super();
/*     */     }
/*     */ 
/*     */     public final Iterator<Map.Entry<K, V>> iterator()
/*     */     {
/* 112 */       return new Iterator() {
/* 113 */         Iterator<Map.Entry<K, V>> i = ((Set)ConstMap.ConstEntrySet.this.w).iterator();
/*     */ 
/*     */         public boolean hasNext() {
/* 116 */           return this.i.hasNext();
/*     */         }
/*     */ 
/*     */         public Map.Entry<K, V> next() {
/* 120 */           return new ConstEntry((Map.Entry)this.i.next());
/*     */         }
/*     */ 
/*     */         public void remove() {
/* 124 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/*     */     public final Object[] toArray()
/*     */     {
/* 132 */       Object[] arrayOfObject = ((Set)this.w).toArray();
/* 133 */       for (int i = 0; i < arrayOfObject.length; i++)
/* 134 */         arrayOfObject[i] = new ConstEntry((Map.Entry)arrayOfObject[i]);
/* 135 */       return arrayOfObject;
/*     */     }
/*     */ 
/*     */     public final <T> T[] toArray(T[] paramArrayOfT)
/*     */     {
/* 144 */       Object[] arrayOfObject = ((Set)this.w).toArray(paramArrayOfT.length == 0 ? paramArrayOfT : Arrays.copyOf(paramArrayOfT, 0));
/*     */ 
/* 146 */       for (int i = 0; i < arrayOfObject.length; i++) {
/* 147 */         arrayOfObject[i] = new ConstEntry((Map.Entry)arrayOfObject[i]);
/*     */       }
/* 149 */       if (arrayOfObject.length > paramArrayOfT.length) {
/* 150 */         return (Object[])arrayOfObject;
/*     */       }
/* 152 */       System.arraycopy(arrayOfObject, 0, paramArrayOfT, 0, arrayOfObject.length);
/* 153 */       if (paramArrayOfT.length > arrayOfObject.length)
/* 154 */         paramArrayOfT[arrayOfObject.length] = null;
/* 155 */       return paramArrayOfT;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.consts.ConstMap
 * JD-Core Version:    0.6.2
 */