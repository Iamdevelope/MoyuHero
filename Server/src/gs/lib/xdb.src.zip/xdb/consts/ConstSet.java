/*   */ package xdb.consts;
/*   */ 
/*   */ import java.util.Set;
/*   */ 
/*   */ public class ConstSet<E, W extends Set<E>> extends ConstCollection<E, W>
/*   */   implements Set<E>
/*   */ {
/*   */   public ConstSet(W paramW)
/*   */   {
/* 8 */     super(paramW);
/*   */   }
/*   */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.consts.ConstSet
 * JD-Core Version:    0.6.2
 */