/*     */ package xdb.consts;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import xdb.Consts;
/*     */ 
/*     */ public class ConstList<E> extends ConstCollection<E, List<E>>
/*     */   implements List<E>
/*     */ {
/*     */   public ConstList(List<E> paramList)
/*     */   {
/*  11 */     super(paramList);
/*     */   }
/*     */ 
/*     */   public final E get(int paramInt)
/*     */   {
/*  16 */     return Consts.toConst(((List)this.w).get(paramInt));
/*     */   }
/*     */ 
/*     */   public final void add(int paramInt, E paramE)
/*     */   {
/*  21 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final int indexOf(Object paramObject)
/*     */   {
/*  26 */     return ((List)this.w).indexOf(paramObject);
/*     */   }
/*     */ 
/*     */   public final int lastIndexOf(Object paramObject)
/*     */   {
/*  31 */     return ((List)this.w).lastIndexOf(paramObject);
/*     */   }
/*     */ 
/*     */   public final boolean addAll(int paramInt, Collection<? extends E> paramCollection)
/*     */   {
/*  36 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final ListIterator<E> listIterator()
/*     */   {
/*  41 */     return listIterator(0);
/*     */   }
/*     */ 
/*     */   public final ListIterator<E> listIterator(final int paramInt)
/*     */   {
/*  46 */     return new ListIterator() {
/*  47 */       private final ListIterator<E> i = ((List)ConstList.this.w).listIterator(paramInt);
/*     */ 
/*     */       public boolean hasNext()
/*     */       {
/*  51 */         return this.i.hasNext();
/*     */       }
/*     */ 
/*     */       public E next()
/*     */       {
/*  56 */         return Consts.toConst(this.i.next());
/*     */       }
/*     */ 
/*     */       public boolean hasPrevious()
/*     */       {
/*  61 */         return this.i.hasPrevious();
/*     */       }
/*     */ 
/*     */       public E previous()
/*     */       {
/*  66 */         return Consts.toConst(this.i.previous());
/*     */       }
/*     */ 
/*     */       public int nextIndex()
/*     */       {
/*  71 */         return this.i.nextIndex();
/*     */       }
/*     */ 
/*     */       public int previousIndex()
/*     */       {
/*  76 */         return this.i.previousIndex();
/*     */       }
/*     */ 
/*     */       public void remove()
/*     */       {
/*  81 */         throw new UnsupportedOperationException();
/*     */       }
/*     */ 
/*     */       public void set(E paramAnonymousE)
/*     */       {
/*  86 */         throw new UnsupportedOperationException();
/*     */       }
/*     */ 
/*     */       public void add(E paramAnonymousE)
/*     */       {
/*  91 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public final List<E> subList(int paramInt1, int paramInt2)
/*     */   {
/*  98 */     return new ConstList(((List)this.w).subList(paramInt1, paramInt2));
/*     */   }
/*     */ 
/*     */   public final E remove(int paramInt)
/*     */   {
/* 103 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final E set(int paramInt, E paramE)
/*     */   {
/* 108 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.consts.ConstList
 * JD-Core Version:    0.6.2
 */