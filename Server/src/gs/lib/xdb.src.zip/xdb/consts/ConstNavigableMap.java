/*     */ package xdb.consts;
/*     */ 
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NavigableMap;
/*     */ import java.util.NavigableSet;
/*     */ import xdb.Consts;
/*     */ 
/*     */ public class ConstNavigableMap<K, V> extends ConstSortedMap<K, V, NavigableMap<K, V>>
/*     */   implements NavigableMap<K, V>
/*     */ {
/*     */   private NavigableMap<K, V> descendingMap;
/*     */   private NavigableSet<K> navigableKeySet;
/*     */ 
/*     */   public ConstNavigableMap(NavigableMap<K, V> paramNavigableMap)
/*     */   {
/*   9 */     super(paramNavigableMap);
/*     */   }
/*     */ 
/*     */   public final Map.Entry<K, V> higherEntry(K paramK)
/*     */   {
/*  14 */     return new ConstEntry(((NavigableMap)this.w).higherEntry(paramK));
/*     */   }
/*     */ 
/*     */   public final K higherKey(K paramK)
/*     */   {
/*  19 */     return Consts.toConst(((NavigableMap)this.w).higherKey(paramK));
/*     */   }
/*     */ 
/*     */   public final Map.Entry<K, V> lowerEntry(K paramK)
/*     */   {
/*  24 */     return new ConstEntry(((NavigableMap)this.w).lowerEntry(paramK));
/*     */   }
/*     */ 
/*     */   public final K lowerKey(K paramK)
/*     */   {
/*  29 */     return Consts.toConst(((NavigableMap)this.w).lowerKey(paramK));
/*     */   }
/*     */ 
/*     */   public final Map.Entry<K, V> ceilingEntry(K paramK)
/*     */   {
/*  34 */     return new ConstEntry(((NavigableMap)this.w).ceilingEntry(paramK));
/*     */   }
/*     */ 
/*     */   public final K ceilingKey(K paramK)
/*     */   {
/*  39 */     return Consts.toConst(((NavigableMap)this.w).ceilingKey(paramK));
/*     */   }
/*     */ 
/*     */   public final Map.Entry<K, V> firstEntry()
/*     */   {
/*  44 */     return new ConstEntry(((NavigableMap)this.w).firstEntry());
/*     */   }
/*     */ 
/*     */   public final Map.Entry<K, V> lastEntry()
/*     */   {
/*  49 */     return new ConstEntry(((NavigableMap)this.w).lastEntry());
/*     */   }
/*     */ 
/*     */   public final Map.Entry<K, V> floorEntry(K paramK)
/*     */   {
/*  54 */     return new ConstEntry(((NavigableMap)this.w).floorEntry(paramK));
/*     */   }
/*     */ 
/*     */   public final K floorKey(K paramK)
/*     */   {
/*  59 */     return Consts.toConst(((NavigableMap)this.w).floorKey(paramK));
/*     */   }
/*     */ 
/*     */   public final Map.Entry<K, V> pollFirstEntry()
/*     */   {
/*  64 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final Map.Entry<K, V> pollLastEntry()
/*     */   {
/*  69 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final NavigableMap<K, V> descendingMap()
/*     */   {
/*  76 */     if (null == this.descendingMap)
/*  77 */       this.descendingMap = new ConstNavigableMap(((NavigableMap)this.w).descendingMap());
/*  78 */     return this.descendingMap;
/*     */   }
/*     */ 
/*     */   public final NavigableMap<K, V> headMap(K paramK, boolean paramBoolean)
/*     */   {
/*  83 */     return new ConstNavigableMap(((NavigableMap)this.w).headMap(paramK, paramBoolean));
/*     */   }
/*     */ 
/*     */   public final NavigableMap<K, V> subMap(K paramK1, boolean paramBoolean1, K paramK2, boolean paramBoolean2)
/*     */   {
/*  88 */     return new ConstNavigableMap(((NavigableMap)this.w).subMap(paramK1, paramBoolean1, paramK2, paramBoolean2));
/*     */   }
/*     */ 
/*     */   public final NavigableMap<K, V> tailMap(K paramK, boolean paramBoolean)
/*     */   {
/*  93 */     return new ConstNavigableMap(((NavigableMap)this.w).tailMap(paramK, paramBoolean));
/*     */   }
/*     */ 
/*     */   public final NavigableSet<K> navigableKeySet()
/*     */   {
/* 100 */     if (null == this.navigableKeySet)
/* 101 */       this.navigableKeySet = new ConstNavigableSet(((NavigableMap)this.w).navigableKeySet());
/* 102 */     return this.navigableKeySet;
/*     */   }
/*     */ 
/*     */   public final NavigableSet<K> descendingKeySet()
/*     */   {
/* 107 */     return descendingMap().navigableKeySet();
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.consts.ConstNavigableMap
 * JD-Core Version:    0.6.2
 */