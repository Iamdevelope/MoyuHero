/*    */ package xdb;
/*    */ 
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public class ProcedureConf
/*    */ {
/*    */   private volatile int executionTime;
/*    */   private volatile int retryTimes;
/*    */   private volatile int retryDelay;
/*    */   private volatile int maxExecutionTime;
/*    */   private volatile Trace trace;
/*    */ 
/*    */   ProcedureConf(Element paramElement)
/*    */   {
/*  8 */     this.maxExecutionTime = XdbConf.getInt(paramElement, "maxExecutionTime", 0);
/*  9 */     this.executionTime = XdbConf.getInt(paramElement, "executionTime", 1000);
/* 10 */     this.retryTimes = XdbConf.getInt(paramElement, "retryTimes", 3);
/* 11 */     this.retryDelay = XdbConf.getInt(paramElement, "retryDelay", 100);
/* 12 */     this.trace = Trace.valueOf(XdbConf.getString(paramElement, "trace", "WARN").toUpperCase());
/*    */   }
/*    */ 
/*    */   public ProcedureConf()
/*    */   {
/* 19 */     this(0, 1000, 3, 100);
/*    */   }
/*    */ 
/*    */   public ProcedureConf(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 23 */     this.maxExecutionTime = paramInt1;
/* 24 */     this.executionTime = paramInt2;
/* 25 */     this.retryTimes = paramInt3;
/* 26 */     this.retryDelay = paramInt4;
/* 27 */     this.trace = Trace.WARN;
/*    */   }
/*    */ 
/*    */   public Trace getTrace()
/*    */   {
/* 37 */     return this.trace;
/*    */   }
/*    */ 
/*    */   public synchronized void setTrace(Trace paramTrace) {
/* 41 */     this.trace = paramTrace;
/*    */   }
/*    */ 
/*    */   public int getMaxExecutionTime() {
/* 45 */     return this.maxExecutionTime;
/*    */   }
/*    */ 
/*    */   public synchronized void setMaxExecutionTime(int paramInt) {
/* 49 */     this.maxExecutionTime = paramInt;
/*    */   }
/*    */ 
/*    */   public int getExecutionTime() {
/* 53 */     return this.executionTime;
/*    */   }
/*    */ 
/*    */   public synchronized void setExecutionTime(int paramInt) {
/* 57 */     this.executionTime = paramInt;
/*    */   }
/*    */ 
/*    */   public int getRetryDelay() {
/* 61 */     return this.retryDelay;
/*    */   }
/*    */ 
/*    */   public synchronized void setRetryDelay(int paramInt) {
/* 65 */     this.retryDelay = paramInt;
/*    */   }
/*    */ 
/*    */   public int getRetryTimes() {
/* 69 */     return this.retryTimes;
/*    */   }
/*    */ 
/*    */   public synchronized void setRetryTimes(int paramInt) {
/* 73 */     this.retryTimes = paramInt;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.ProcedureConf
 * JD-Core Version:    0.6.2
 */