/*     */ package xdb;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.MarshalException;
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import xdb.logs.Listenable;
/*     */ import xdb.logs.LogNotify;
/*     */ 
/*     */ public class XBean
/*     */   implements Bean
/*     */ {
/*  16 */   private static final AtomicLong objid = new AtomicLong();
/*     */ 
/*  18 */   private final Long _objid_ = Long.valueOf(objid.incrementAndGet());
/*     */   private XBean _parent_;
/*     */   private String _varname_;
/* 208 */   private static volatile boolean _xdb_verify_ = false;
/*     */ 
/*     */   public XBean(XBean paramXBean, String paramString)
/*     */   {
/*  23 */     this._parent_ = paramXBean;
/*  24 */     this._varname_ = paramString;
/*     */   }
/*     */ 
/*     */   final void xdbParent(XBean paramXBean, String paramString, boolean paramBoolean)
/*     */   {
/*  34 */     if (null != paramXBean) {
/*  35 */       if (null != this._parent_) {
/*  36 */         throw new XManagedError();
/*     */       }
/*     */     }
/*  39 */     else if (null == this._parent_) {
/*  40 */       throw new XManagedError("not managed");
/*     */     }
/*  42 */     if (paramBoolean)
/*  43 */       Transaction.currentSavepoint().addIfAbsent(new LogKey(this, "_parent_"), new LogXP());
/*  44 */     this._parent_ = paramXBean;
/*  45 */     this._varname_ = paramString;
/*     */   }
/*     */ 
/*     */   public final boolean xdbManaged()
/*     */   {
/*  72 */     return this._parent_ != null;
/*     */   }
/*     */ 
/*     */   public final String xdbVarname()
/*     */   {
/*  77 */     return this._varname_;
/*     */   }
/*     */ 
/*     */   public final Bean xdbParent()
/*     */   {
/*  82 */     return this._parent_;
/*     */   }
/*     */ 
/*     */   void xdbLogNotify(LogNotify paramLogNotify) {
/*  86 */     if (null != this._parent_)
/*  87 */       this._parent_.xdbLogNotify(paramLogNotify.push(new LogKey(this._parent_, xdbVarname())));
/*     */   }
/*     */ 
/*     */   public final Long xdbObjId()
/*     */   {
/*  92 */     return this._objid_;
/*     */   }
/*     */ 
/*     */   public OctetsStream marshal(OctetsStream paramOctetsStream)
/*     */   {
/*  97 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public OctetsStream unmarshal(OctetsStream paramOctetsStream) throws MarshalException
/*     */   {
/* 102 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Bean toConst()
/*     */   {
/* 107 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean isConst()
/*     */   {
/* 112 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isData()
/*     */   {
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */   public Listenable newListenable() {
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */   public final Forefathers xdbForefathers()
/*     */   {
/* 129 */     Forefathers localForefathers = new Forefathers();
/* 130 */     xdbForefathers(localForefathers);
/* 131 */     return localForefathers;
/*     */   }
/*     */ 
/*     */   public final void xdbForefathers(Forefathers paramForefathers)
/*     */   {
/* 139 */     if (null != this._parent_) {
/* 140 */       paramForefathers.forefathers.add(this._parent_);
/* 141 */       this._parent_.xdbForefathers(paramForefathers);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void _set_xdb_verify_(boolean paramBoolean)
/*     */   {
/* 211 */     _xdb_verify_ = paramBoolean;
/*     */   }
/*     */ 
/*     */   public static boolean _is_xdb_verify_() {
/* 215 */     return _xdb_verify_;
/*     */   }
/*     */ 
/*     */   public final void _xdb_verify_unsafe_()
/*     */   {
/* 223 */     if (false == _xdb_verify_) {
/* 224 */       return;
/*     */     }
/*     */ 
/* 227 */     if (false == Xdb.getInstance().getTables().isHeldFlushWriteLockByCurrentThread()) {
/* 228 */       Lockey localLockey = xdbForefathers().getLockey();
/* 229 */       if ((null != localLockey) && (false == localLockey.isHeldByCurrentThread()))
/* 230 */         throw new UnfilialError(getClass().getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class UnfilialError extends Error {
/*     */     private static final long serialVersionUID = -2377572699783238493L;
/*     */ 
/*     */     public UnfilialError(String paramString) {
/* 238 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final class Forefathers
/*     */   {
/* 149 */     private List<Bean> forefathers = new ArrayList();
/*     */ 
/*     */     public Forefathers() {
/*     */     }
/*     */ 
/*     */     public Bean getBean() {
/* 155 */       return XBean.this;
/*     */     }
/*     */ 
/*     */     public List<Bean> getForefathers()
/*     */     {
/* 162 */       return this.forefathers;
/*     */     }
/*     */ 
/*     */     public Table getTable()
/*     */     {
/* 169 */       if (this.forefathers.isEmpty())
/* 170 */         return null;
/* 171 */       Bean localBean = (Bean)this.forefathers.get(this.forefathers.size() - 1);
/* 172 */       if ((localBean instanceof Table))
/* 173 */         return (Table)localBean;
/* 174 */       return null;
/*     */     }
/*     */ 
/*     */     public TRecord<?, ?> getRecord()
/*     */     {
/* 181 */       if (this.forefathers.size() < 2)
/* 182 */         return null;
/* 183 */       Bean localBean = (Bean)this.forefathers.get(this.forefathers.size() - 2);
/* 184 */       if ((localBean instanceof TRecord))
/* 185 */         return (TRecord)localBean;
/* 186 */       return null;
/*     */     }
/*     */ 
/*     */     public Lockey getLockey()
/*     */     {
/* 194 */       TRecord localTRecord = getRecord();
/* 195 */       if (null != localTRecord)
/* 196 */         return localTRecord.getLockey();
/* 197 */       return null;
/*     */     }
/*     */ 
/*     */     public boolean isHeldByXdb()
/*     */     {
/* 204 */       return null != getTable();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class LogXP
/*     */     implements Log
/*     */   {
/*     */     private XBean parent;
/*     */     private String varname;
/*     */ 
/*     */     LogXP()
/*     */     {
/*  53 */       this.parent = XBean.this._parent_;
/*  54 */       this.varname = XBean.this._varname_;
/*     */     }
/*     */ 
/*     */     public void commit()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void rollback()
/*     */     {
/*  65 */       XBean.this._parent_ = this.parent;
/*  66 */       XBean.this._varname_ = this.varname;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.XBean
 * JD-Core Version:    0.6.2
 */