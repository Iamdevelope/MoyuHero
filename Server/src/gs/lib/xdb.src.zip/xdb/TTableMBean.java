package xdb;

public abstract interface TTableMBean
{
  public abstract String getTableName();

  public abstract String getLockName();

  public abstract String getPersistenceName();

  public abstract int getCacheCapacity();

  public abstract void setCacheCapacity(int paramInt);

  public abstract int getCacheSize();

  public abstract String getCacheClassName();

  public abstract long getCountAdd();

  public abstract long getCountAddMiss();

  public abstract long getCountAddStorageMiss();

  public abstract long getCountGet();

  public abstract long getCountGetMiss();

  public abstract long getCountGetStorageMiss();

  public abstract long getCountRemove();

  public abstract long getCountRemoveMiss();

  public abstract long getCountRemoveStorageMiss();

  public abstract String getPercentAddHit();

  public abstract String getPercentGetHit();

  public abstract String getPercentRemoveHit();

  public abstract String getPercentCacheHit();

  public abstract long getStorageCountMarshal0();

  public abstract long getStorageCountMarshalN();

  public abstract long getStorageCountMarshalNTryFail();

  public abstract long getStorageCountFlush();

  public abstract long getStorageCountSnapshot();

  public abstract long getStorageFlushKeySize();

  public abstract long getStorageFlushValueSize();
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.TTableMBean
 * JD-Core Version:    0.6.2
 */