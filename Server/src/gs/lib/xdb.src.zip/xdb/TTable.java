/*     */ package xdb;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.MarshalException;
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import com.goldhuman.Common.Octets;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import javax.management.ObjectName;
/*     */ import xdb.logs.Listenable;
/*     */ import xdb.logs.ListenableChanged;
/*     */ import xdb.logs.Listener;
/*     */ import xdb.logs.ListenerMap;
/*     */ import xdb.logs.LogNotify;
/*     */ import xdb.logs.LogRecord;
/*     */ import xdb.logs.VarNames;
/*     */ import xdb.util.AutoKey;
/*     */ import xdb.util.MBeans.Manager;
/*     */ 
/*     */ public abstract class TTable<K, V> extends Table
/*     */   implements TTableMBean
/*     */ {
/*     */   private String lockname;
/*     */   private int lockId;
/*     */   private TableConf conf;
/*     */   private AutoKey<K> autoKey;
/*  30 */   private ObjectName mbeanObjectName = null;
/*  31 */   private Listenable recordListenableSeed = (newValue() instanceof XBean) ? ((XBean)newValue()).newListenable() : new ListenableChanged();
/*     */ 
/* 308 */   private ThreadLocal<LogRecord<K, V>> logRecord = new ThreadLocal()
/*     */   {
/*     */     protected LogRecord<K, V> initialValue()
/*     */     {
/* 313 */       return new LogRecord(TTable.this);
/*     */     }
/* 308 */   };
/*     */ 
/* 318 */   private ListenerMap listenerMap = new ListenerMap();
/*     */   private TTableCache<K, V> cache;
/*     */   private TStorage<K, V> storage;
/* 542 */   private AtomicLong countAdd = new AtomicLong();
/* 543 */   private AtomicLong countAddMiss = new AtomicLong();
/* 544 */   private AtomicLong countAddStorageMiss = new AtomicLong();
/*     */ 
/* 546 */   private AtomicLong countGet = new AtomicLong();
/* 547 */   private AtomicLong countGetMiss = new AtomicLong();
/* 548 */   private AtomicLong countGetStorageMiss = new AtomicLong();
/*     */ 
/* 550 */   private AtomicLong countRemove = new AtomicLong();
/* 551 */   private AtomicLong countRemoveMiss = new AtomicLong();
/* 552 */   private AtomicLong countRemoveStorageMiss = new AtomicLong();
/*     */ 
/*     */   public Listenable getRecordListenableSeed()
/*     */   {
/*  36 */     return this.recordListenableSeed;
/*     */   }
/*     */ 
/*     */   public final K nextKey()
/*     */   {
/*  41 */     return this.autoKey.next();
/*     */   }
/*     */ 
/*     */   public final AutoKey<K> getAutoKey() {
/*  45 */     return this.autoKey;
/*     */   }
/*     */ 
/*     */   public final V get(K paramK)
/*     */   {
/*  57 */     return get(paramK, true);
/*     */   }
/*     */ 
/*     */   public final V get(K paramK, V paramV)
/*     */   {
/*  70 */     Object localObject = get(paramK, false);
/*  71 */     if (null != localObject)
/*  72 */       return localObject;
/*  73 */     return paramV;
/*     */   }
/*     */ 
/*     */   public final void insert(K paramK, V paramV)
/*     */   {
/*  82 */     if (false == add(paramK, paramV))
/*  83 */       throw new XError("insert key=" + paramK + " value=" + paramV);
/*     */   }
/*     */ 
/*     */   public final void delete(K paramK)
/*     */   {
/*  91 */     if (false == remove(paramK))
/*  92 */       throw new XError("delete key=" + paramK);
/*     */   }
/*     */ 
/*     */   public final boolean update(K paramK, V paramV)
/*     */   {
/* 103 */     Object localObject = get(paramK, false);
/* 104 */     if (null == localObject)
/* 105 */       return false;
/* 106 */     delete(paramK);
/* 107 */     insert(paramK, paramV);
/* 108 */     return true;
/*     */   }
/*     */ 
/*     */   public final V put(K paramK, V paramV)
/*     */   {
/* 118 */     Object localObject = get(paramK, true);
/* 119 */     if (null == localObject) {
/* 120 */       insert(paramK, paramV);
/* 121 */       return null;
/*     */     }
/* 123 */     delete(paramK);
/* 124 */     insert(paramK, paramV);
/* 125 */     return localObject;
/*     */   }
/*     */ 
/*     */   public final V putIfAbsent(K paramK, V paramV)
/*     */   {
/* 139 */     Object localObject = get(paramK, true);
/* 140 */     if (null == localObject) {
/* 141 */       insert(paramK, paramV);
/* 142 */       return null;
/*     */     }
/* 144 */     return localObject;
/*     */   }
/*     */ 
/*     */   public final boolean add(K paramK, V paramV)
/*     */   {
/* 158 */     if (null == paramK)
/* 159 */       throw new NullPointerException("key is null");
/* 160 */     if (null == paramV) {
/* 161 */       throw new NullPointerException("value is null");
/*     */     }
/* 163 */     if (null != this.autoKey) {
/* 164 */       this.autoKey.accept(paramK);
/*     */     }
/* 166 */     this.countAdd.incrementAndGet();
/* 167 */     Lockey localLockey = Lockeys.get(this, paramK);
/* 168 */     localLockey.lock();
/*     */     try {
/* 170 */       TRecord localTRecord = this.cache.get(paramK);
/*     */       boolean bool;
/* 171 */       if (null != localTRecord) {
/* 172 */         Transaction.current().add(localLockey);
/* 173 */         return localTRecord.add(paramV);
/*     */       }
/*     */ 
/* 176 */       this.countAddMiss.incrementAndGet();
/* 177 */       if (_exist(paramK)) {
/* 178 */         this.countAddStorageMiss.incrementAndGet();
/* 179 */         return false;
/*     */       }
/*     */ 
/* 182 */       this.cache.add(paramK, new TRecord(this, paramV, localLockey, TRecord.State.ADD));
/* 183 */       Transaction.current().add(localLockey);
/* 184 */       return true;
/*     */     } finally {
/* 186 */       localLockey.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final boolean remove(K paramK)
/*     */   {
/* 197 */     if (null == paramK) {
/* 198 */       throw new NullPointerException("key is null");
/*     */     }
/* 200 */     this.countRemove.incrementAndGet();
/* 201 */     Lockey localLockey = Lockeys.get(this, paramK);
/* 202 */     localLockey.lock();
/*     */     try {
/* 204 */       TRecord localTRecord = this.cache.get(paramK);
/* 205 */       if (null != localTRecord) {
/* 206 */         Transaction.current().add(localLockey);
/*     */ 
/* 208 */         return localTRecord.remove();
/*     */       }
/*     */ 
/* 211 */       this.countRemoveMiss.incrementAndGet();
/* 212 */       boolean bool1 = _exist(paramK);
/* 213 */       if (false == bool1)
/* 214 */         this.countRemoveStorageMiss.incrementAndGet();
/* 215 */       this.cache.add(paramK, new TRecord(this, null, localLockey, bool1));
/* 216 */       Transaction.current().add(localLockey);
/* 217 */       return bool1;
/*     */     } finally {
/* 219 */       localLockey.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final V get(K paramK, boolean paramBoolean)
/*     */   {
/* 232 */     if (null == paramK) {
/* 233 */       throw new NullPointerException("key is null");
/*     */     }
/* 235 */     this.countGet.incrementAndGet();
/*     */ 
/* 237 */     TRecord localTRecord1 = Transaction.current().getCachedTRecord(this, paramK);
/* 238 */     if (localTRecord1 != null) return localTRecord1.getValue();
/*     */ 
/* 240 */     Lockey localLockey = Lockeys.get(this, paramK);
/* 241 */     localLockey.lock();
/*     */     try {
/* 243 */       TRecord localTRecord2 = this.cache.get(paramK);
/*     */       Object localObject1;
/* 244 */       if (null == localTRecord2) {
/* 245 */         this.countGetMiss.incrementAndGet();
/* 246 */         localObject1 = _find(paramK);
/* 247 */         if (null == localObject1) {
/* 248 */           this.countGetStorageMiss.incrementAndGet();
/* 249 */           if (paramBoolean)
/* 250 */             Transaction.current().add(localLockey);
/* 251 */           return null;
/*     */         }
/*     */ 
/* 254 */         localTRecord2 = new TRecord(this, localObject1, localLockey, TRecord.State.INDB_GET);
/* 255 */         this.cache.addNoLog(paramK, localTRecord2);
/*     */       }
/*     */ 
/* 258 */       Transaction.current().add(localLockey);
/* 259 */       Transaction.current().addCachedTRecord(this, localTRecord2);
/* 260 */       return localTRecord2.getValue();
/*     */     } finally {
/* 262 */       localLockey.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final <F> F select(K paramK, TField<V, F> paramTField)
/*     */   {
/* 278 */     if (null == paramK) {
/* 279 */       throw new NullPointerException("key is null");
/*     */     }
/* 281 */     this.countGet.incrementAndGet();
/* 282 */     Lockey localLockey = Lockeys.get(this, paramK);
/* 283 */     localLockey.lock();
/*     */     try {
/* 285 */       TRecord localTRecord = this.cache.get(paramK);
/*     */       Object localObject2;
/* 286 */       if (null == localTRecord) {
/* 287 */         this.countGetMiss.incrementAndGet();
/* 288 */         localObject1 = _find(paramK);
/* 289 */         if (null == localObject1) {
/* 290 */           this.countGetStorageMiss.incrementAndGet();
/* 291 */           return null;
/*     */         }
/*     */ 
/* 294 */         localTRecord = new TRecord(this, localObject1, localLockey, TRecord.State.INDB_GET);
/* 295 */         this.cache.addNoLog(paramK, localTRecord);
/*     */       }
/*     */ 
/* 298 */       Object localObject1 = localTRecord.getValue();
/* 299 */       if (null == localObject1)
/* 300 */         return null;
/* 301 */       return paramTField.get(localObject1);
/*     */     } finally {
/* 303 */       localLockey.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final String toFullVarName(String[] paramArrayOfString)
/*     */   {
/* 322 */     VarNames localVarNames = new VarNames(paramArrayOfString);
/* 323 */     return new LogRecord(this).toFullVarName(localVarNames);
/*     */   }
/*     */ 
/*     */   public final void removeListener(Listener paramListener, String[] paramArrayOfString) {
/* 327 */     this.listenerMap.remove(toFullVarName(paramArrayOfString), paramListener);
/*     */   }
/*     */ 
/*     */   public final String addListener(Listener paramListener, String[] paramArrayOfString) {
/* 331 */     return this.listenerMap.add(toFullVarName(paramArrayOfString), paramListener);
/*     */   }
/*     */ 
/*     */   public final boolean hasListener() {
/* 335 */     return this.listenerMap.hasListener();
/*     */   }
/*     */ 
/*     */   final void logNotify()
/*     */   {
/*     */     try {
/* 341 */       ((LogRecord)this.logRecord.get()).logNotify(this.listenerMap);
/*     */     }
/*     */     catch (Throwable localThrowable) {
/* 344 */       this.logRecord.remove();
/* 345 */       Trace.fatal("TTable.logNotify", localThrowable);
/*     */     }
/*     */   }
/*     */ 
/*     */   public final TTableCache<K, V> getCache()
/*     */   {
/* 354 */     return this.cache;
/*     */   }
/*     */ 
/*     */   final TStorage<K, V> getStorage()
/*     */   {
/* 362 */     return this.storage;
/*     */   }
/*     */ 
/*     */   final void onRecordChanged(TRecord<K, V> paramTRecord, LogNotify paramLogNotify)
/*     */   {
/* 367 */     ((LogRecord)this.logRecord.get()).onChanged(this, paramTRecord, paramLogNotify);
/*     */ 
/* 369 */     if (paramTRecord.getState() == TRecord.State.REMOVE) {
/* 370 */       this.cache.remove(paramTRecord.getKey());
/*     */     }
/* 372 */     if (null != this.storage)
/* 373 */       this.storage.onRecordChange(paramTRecord);
/*     */   }
/*     */ 
/*     */   protected final void initialize(Tables paramTables)
/*     */   {
/* 378 */     this.autoKey = bindAutoKey();
/* 379 */     this.lockId = Lockeys.getInstance().getLockId(this.lockname);
/*     */   }
/*     */ 
/*     */   protected AutoKey<K> bindAutoKey()
/*     */   {
/* 386 */     return null;
/*     */   }
/*     */ 
/*     */   public TableConf getConf() {
/* 390 */     return this.conf;
/*     */   }
/*     */ 
/*     */   final Storage open(XdbConf paramXdbConf, Logger paramLogger)
/*     */   {
/* 395 */     if (null != this.storage) {
/* 396 */       throw new XError("table has opened : " + getName());
/*     */     }
/* 398 */     this.conf = paramXdbConf.getTableConf(getName());
/* 399 */     if (null == this.conf) {
/* 400 */       throw new XError("no configuration for table '" + getName() + "'");
/*     */     }
/* 402 */     this.lockname = this.conf.getLockName();
/* 403 */     this.cache = TTableCache.newInstance(this, this.conf);
/*     */ 
/* 405 */     switch (4.$SwitchMap$xdb$Table$Persistence[this.conf.getPersistence().ordinal()]) { case 1:
/* 406 */       this.storage = null; break;
/*     */     case 2:
/* 407 */       this.storage = new TStorage(paramLogger, paramXdbConf, this.conf);
/*     */     }
/* 409 */     this.mbeanObjectName = Xdb.mbeans().register(this, "xdb:type=Tables,name=" + getName());
/* 410 */     return this.storage;
/*     */   }
/*     */ 
/*     */   final void close()
/*     */   {
/* 415 */     if (null != this.storage) {
/* 416 */       this.storage.close();
/* 417 */       this.storage = null;
/*     */     }
/* 419 */     Xdb.mbeans().unregister(this.mbeanObjectName); } 
/*     */   public abstract V newValue();
/*     */ 
/*     */   public abstract OctetsStream marshalKey(K paramK);
/*     */ 
/*     */   public abstract OctetsStream marshalValue(V paramV);
/*     */ 
/*     */   public abstract K unmarshalKey(OctetsStream paramOctetsStream) throws MarshalException;
/*     */ 
/*     */   public abstract V unmarshalValue(OctetsStream paramOctetsStream) throws MarshalException;
/*     */ 
/* 429 */   private final boolean _exist(K paramK) { if (null != this.storage)
/* 430 */       return this.storage.exist(paramK, this);
/* 431 */     return false; }
/*     */ 
/*     */   private final V _find(K paramK)
/*     */   {
/* 435 */     if (null != this.storage)
/* 436 */       return this.storage.find(paramK, this);
/* 437 */     return null;
/*     */   }
/*     */ 
/*     */   public final void walk(final IWalk<K, V> paramIWalk)
/*     */   {
/* 463 */     if (null == paramIWalk)
/* 464 */       throw new NullPointerException();
/* 465 */     if (null != this.storage) {
/* 466 */       Lock localLock1 = Xdb.getInstance().getTables().flushReadLock();
/* 467 */       Lock localLock2 = Xdb.getInstance().getTables().checkpointLock();
/* 468 */       localLock1.lock();
/* 469 */       localLock2.lock();
/*     */       try {
/* 471 */         this.storage.walk(new Storage.IWalk()
/*     */         {
/*     */           public boolean onRecord(byte[] paramAnonymousArrayOfByte1, byte[] paramAnonymousArrayOfByte2) {
/*     */             try {
/* 475 */               Object localObject1 = TTable.this.unmarshalKey(OctetsStream.wrap(Octets.wrap(paramAnonymousArrayOfByte1, paramAnonymousArrayOfByte1.length)));
/* 476 */               Object localObject2 = TTable.this.unmarshalValue(OctetsStream.wrap(Octets.wrap(paramAnonymousArrayOfByte2, paramAnonymousArrayOfByte2.length)));
/* 477 */               return paramIWalk.onRecord(localObject1, localObject2);
/*     */             } catch (Throwable localThrowable) {
/* 479 */               Trace.error("table:" + TTable.this.getTableName() + ",walk:" + paramIWalk.getClass().getName() + ",error:", localThrowable);
/* 480 */               if ((paramIWalk instanceof TTable.IWalkDetail))
/* 481 */                 return ((TTable.IWalkDetail)paramIWalk).onError(paramAnonymousArrayOfByte1, paramAnonymousArrayOfByte2);
/*     */             }
/* 483 */             return true;
/*     */           }
/*     */         });
/*     */       }
/*     */       finally {
/* 488 */         localLock1.unlock();
/* 489 */         localLock2.unlock();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void browse(IWalk<K, V> paramIWalk)
/*     */   {
/* 500 */     browse(paramIWalk, 128);
/*     */   }
/*     */ 
/*     */   public final void browse(final IWalk<K, V> paramIWalk, int paramInt)
/*     */   {
/* 512 */     if (null == paramIWalk)
/* 513 */       throw new NullPointerException();
/* 514 */     if (null != this.storage) {
/* 515 */       Lock localLock = Xdb.getInstance().getTables().checkpointLock();
/* 516 */       localLock.lock();
/*     */       try {
/* 518 */         this.storage.browse(new Storage.IWalk()
/*     */         {
/*     */           public boolean onRecord(byte[] paramAnonymousArrayOfByte1, byte[] paramAnonymousArrayOfByte2) {
/*     */             try {
/* 522 */               Object localObject1 = TTable.this.unmarshalKey(OctetsStream.wrap(Octets.wrap(paramAnonymousArrayOfByte1, paramAnonymousArrayOfByte1.length)));
/* 523 */               Object localObject2 = TTable.this.unmarshalValue(OctetsStream.wrap(Octets.wrap(paramAnonymousArrayOfByte2, paramAnonymousArrayOfByte2.length)));
/* 524 */               return paramIWalk.onRecord(localObject1, localObject2);
/*     */             } catch (Throwable localThrowable) {
/* 526 */               Trace.error("table:" + TTable.this.getTableName() + ",browse:" + paramIWalk.getClass().getName() + ",error:", localThrowable);
/* 527 */               if ((paramIWalk instanceof TTable.IWalkDetail))
/* 528 */                 return ((TTable.IWalkDetail)paramIWalk).onError(paramAnonymousArrayOfByte1, paramAnonymousArrayOfByte2);
/*     */             }
/* 530 */             return true;
/*     */           }
/*     */         }
/*     */         , paramInt);
/*     */       }
/*     */       finally
/*     */       {
/* 535 */         localLock.unlock();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getTableName()
/*     */   {
/* 556 */     return getName();
/*     */   }
/*     */ 
/*     */   public String getLockName()
/*     */   {
/* 561 */     return this.lockname;
/*     */   }
/*     */ 
/*     */   int getLockId() {
/* 565 */     return this.lockId;
/*     */   }
/*     */ 
/*     */   public Table.Persistence getPersistence()
/*     */   {
/* 570 */     return this.conf.getPersistence();
/*     */   }
/*     */ 
/*     */   public String getPersistenceName()
/*     */   {
/* 575 */     return this.conf.getPersistence().name();
/*     */   }
/*     */ 
/*     */   public void setCacheCapacity(int paramInt)
/*     */   {
/* 580 */     this.cache.setCapacity(paramInt);
/*     */   }
/*     */ 
/*     */   public int getCacheCapacity()
/*     */   {
/* 585 */     return this.cache.getCapacity();
/*     */   }
/*     */ 
/*     */   public String getCacheClassName()
/*     */   {
/* 590 */     return this.cache.getClass().getName();
/*     */   }
/*     */ 
/*     */   public int getCacheSize()
/*     */   {
/* 595 */     return this.cache.getSize();
/*     */   }
/*     */ 
/*     */   public long getCountAdd()
/*     */   {
/* 600 */     return this.countAdd.get();
/*     */   }
/*     */ 
/*     */   public long getCountAddMiss()
/*     */   {
/* 605 */     return this.countAddMiss.get();
/*     */   }
/*     */ 
/*     */   public long getCountAddStorageMiss()
/*     */   {
/* 610 */     return this.countAddStorageMiss.get();
/*     */   }
/*     */ 
/*     */   public long getCountGet()
/*     */   {
/* 615 */     return this.countGet.get();
/*     */   }
/*     */ 
/*     */   public long getCountGetMiss()
/*     */   {
/* 620 */     return this.countGetMiss.get();
/*     */   }
/*     */ 
/*     */   public long getCountGetStorageMiss()
/*     */   {
/* 625 */     return this.countGetStorageMiss.get();
/*     */   }
/*     */ 
/*     */   public long getCountRemove()
/*     */   {
/* 630 */     return this.countRemove.get();
/*     */   }
/*     */ 
/*     */   public long getCountRemoveMiss()
/*     */   {
/* 635 */     return this.countRemoveMiss.get();
/*     */   }
/*     */ 
/*     */   public long getCountRemoveStorageMiss()
/*     */   {
/* 640 */     return this.countRemoveStorageMiss.get();
/*     */   }
/*     */ 
/*     */   private String format(long paramLong1, long paramLong2)
/*     */   {
/* 645 */     return String.format("%.2f", new Object[] { Double.valueOf((paramLong2 - paramLong1) / paramLong2) });
/*     */   }
/*     */ 
/*     */   public String getPercentAddHit()
/*     */   {
/* 650 */     return format(getCountAddMiss(), getCountAdd());
/*     */   }
/*     */ 
/*     */   public String getPercentGetHit()
/*     */   {
/* 655 */     return format(getCountGetMiss(), getCountGet());
/*     */   }
/*     */ 
/*     */   public String getPercentRemoveHit()
/*     */   {
/* 660 */     return format(getCountRemoveMiss(), getCountRemove());
/*     */   }
/*     */ 
/*     */   public String getPercentCacheHit()
/*     */   {
/* 665 */     return format(getCountAddMiss() + getCountRemoveMiss() + getCountGetMiss(), getCountAdd() + getCountRemove() + getCountGet());
/*     */   }
/*     */ 
/*     */   public long getStorageCountFlush()
/*     */   {
/* 671 */     return null != this.storage ? this.storage.getCountFlush() : -1L;
/*     */   }
/*     */ 
/*     */   public long getStorageCountMarshal0()
/*     */   {
/* 676 */     return null != this.storage ? this.storage.getCountMarshal0() : -1L;
/*     */   }
/*     */ 
/*     */   public long getStorageCountMarshalN()
/*     */   {
/* 681 */     return null != this.storage ? this.storage.getCountMarshalN() : -1L;
/*     */   }
/*     */ 
/*     */   public long getStorageCountMarshalNTryFail()
/*     */   {
/* 686 */     return null != this.storage ? this.storage.getCountMarshalNTryFail() : -1L;
/*     */   }
/*     */ 
/*     */   public long getStorageCountSnapshot()
/*     */   {
/* 691 */     return null != this.storage ? this.storage.getCountSnapshot() : -1L;
/*     */   }
/*     */ 
/*     */   public long getStorageFlushKeySize()
/*     */   {
/* 696 */     return null != this.storage ? this.storage.flushKeySize : -1L;
/*     */   }
/*     */ 
/*     */   public long getStorageFlushValueSize()
/*     */   {
/* 701 */     return null != this.storage ? this.storage.flushValueSize : -1L;
/*     */   }
/*     */ 
/*     */   public static abstract interface IWalkDetail<K, V> extends TTable.IWalk<K, V>
/*     */   {
/*     */     public abstract boolean onError(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*     */   }
/*     */ 
/*     */   public static abstract interface IWalk<K, V>
/*     */   {
/*     */     public abstract boolean onRecord(K paramK, V paramV);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.TTable
 * JD-Core Version:    0.6.2
 */