/*     */ package xdb;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import xdb.util.Misc;
/*     */ 
/*     */ public class TTableCacheConcurrentMap<K, V> extends TTableCache<K, V>
/*     */ {
/*     */   private ConcurrentMap<K, TRecord<K, V>> map;
/*     */ 
/*     */   public TTableCacheConcurrentMap()
/*     */   {
/*  17 */     this.map = Misc.newConcurrentMap();
/*     */   }
/*     */ 
/*     */   void initialize(TTable<K, V> paramTTable, TableConf paramTableConf) {
/*  21 */     super.initialize(paramTTable, paramTableConf);
/*     */ 
/*  25 */     int i = 3600000;
/*     */ 
/*  27 */     int j = Xdb.random().nextInt(i);
/*  28 */     Xdb.executor().scheduleWithFixedDelay(new Runnable()
/*     */     {
/*     */       public void run() {
/*  31 */         TTableCacheConcurrentMap.this.clean();
/*     */       }
/*     */     }
/*     */     , j, i, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   private final void clean()
/*     */   {
/*  37 */     int i = super.getCapacity();
/*  38 */     if (i <= 0) {
/*  39 */       return;
/*     */     }
/*  41 */     int j = getSize();
/*  42 */     if (j < i) {
/*  43 */       return;
/*     */     }
/*  45 */     Object[] arrayOfObject = this.map.values().toArray();
/*  46 */     Arrays.sort(arrayOfObject, TRecordComparator.singleton);
/*     */ 
/*  49 */     int k = Math.min(j - i + 255, j);
/*  50 */     for (int m = 0; m < k; m++)
/*     */     {
/*  52 */       TRecord localTRecord = (TRecord)arrayOfObject[m];
/*  53 */       super.tryRemoveRecord(localTRecord);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  70 */     if (super.getTable().getPersistence() != Table.Persistence.MEMORY)
/*  71 */       throw new UnsupportedOperationException();
/*  72 */     this.map.clear();
/*     */   }
/*     */ 
/*     */   public void walk(CacheQuery<K, V> paramCacheQuery)
/*     */   {
/*  77 */     super._walk_notify_query(this.map.values().toArray(), paramCacheQuery);
/*     */   }
/*     */ 
/*     */   int getSize()
/*     */   {
/*  82 */     return this.map.size();
/*     */   }
/*     */ 
/*     */   TRecord<K, V> get(K paramK)
/*     */   {
/*  88 */     TRecord localTRecord = (TRecord)this.map.get(paramK);
/*  89 */     if (null != localTRecord)
/*  90 */       localTRecord.access();
/*  91 */     return localTRecord;
/*     */   }
/*     */ 
/*     */   void addNoLog(K paramK, TRecord<K, V> paramTRecord)
/*     */   {
/*  96 */     if (null != this.map.putIfAbsent(paramK, paramTRecord))
/*  97 */       throw new XError("cache.addNoLog duplicate record");
/*     */   }
/*     */ 
/*     */   void add(K paramK, TRecord<K, V> paramTRecord)
/*     */   {
/* 102 */     if (null != this.map.putIfAbsent(paramK, paramTRecord))
/* 103 */       throw new XError("cache.addNoLog duplicate record");
/* 104 */     super.logAddRemove(paramK, paramTRecord);
/*     */   }
/*     */ 
/*     */   TRecord<K, V> remove(K paramK)
/*     */   {
/* 113 */     return (TRecord)this.map.remove(paramK);
/*     */   }
/*     */ 
/*     */   static class TRecordComparator
/*     */     implements Comparator<Object>
/*     */   {
/*  65 */     static TRecordComparator singleton = new TRecordComparator();
/*     */ 
/*     */     public int compare(Object paramObject1, Object paramObject2)
/*     */     {
/*  61 */       long l1 = ((TRecord)paramObject1).getLastAccessTime();
/*  62 */       long l2 = ((TRecord)paramObject2).getLastAccessTime();
/*  63 */       return l1 == l2 ? 0 : l1 < l2 ? -1 : 1;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.TTableCacheConcurrentMap
 * JD-Core Version:    0.6.2
 */