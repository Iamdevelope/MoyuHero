/*     */ package xdb;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.MonitorInfo;
/*     */ import java.lang.management.ThreadInfo;
/*     */ import java.lang.management.ThreadMXBean;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executors;
/*     */ import xdb.util.TimeoutManager;
/*     */ import xdb.util.TimeoutManager.Timeout;
/*     */ 
/*     */ public final class Angel extends ThreadHelper
/*     */ {
/*  61 */   private final ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
/*     */   private final ThreadGroup rootThreadGroup;
/*  63 */   private volatile int interruptCount = 0;
/*     */   private static final int MAXDEPTH = 255;
/*     */ 
/*     */   public static ThreadGroup getRootThreadGroup()
/*     */   {
/*  23 */     Object localObject = Thread.currentThread().getThreadGroup();
/*  24 */     for (ThreadGroup localThreadGroup = ((ThreadGroup)localObject).getParent(); null != localThreadGroup; localThreadGroup = localThreadGroup.getParent())
/*  25 */       localObject = localThreadGroup;
/*  26 */     return localObject;
/*     */   }
/*     */ 
/*     */   public static Map<Long, Thread> getAllThreads()
/*     */   {
/*  33 */     return enumerate(getRootThreadGroup(), true);
/*     */   }
/*     */ 
/*     */   public static Map<Long, Thread> enumerate(ThreadGroup paramThreadGroup, boolean paramBoolean)
/*     */   {
/*  44 */     Thread[] arrayOfThread = new Thread[256];
/*     */     while (true) {
/*  46 */       int i = paramThreadGroup.enumerate(arrayOfThread, paramBoolean);
/*  47 */       if (i < arrayOfThread.length) {
/*  48 */         HashMap localHashMap = new HashMap();
/*  49 */         for (int j = 0; j < i; j++) {
/*  50 */           Thread localThread = arrayOfThread[j];
/*  51 */           if (null != localThread)
/*  52 */             localHashMap.put(Long.valueOf(localThread.getId()), localThread);
/*     */         }
/*  54 */         return localHashMap;
/*     */       }
/*  56 */       arrayOfThread = new Thread[arrayOfThread.length * 2];
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getInterruptCount()
/*     */   {
/*  66 */     return this.interruptCount;
/*     */   }
/*     */ 
/*     */   Angel() {
/*  70 */     super("xdb.Angel");
/*  71 */     this.rootThreadGroup = getRootThreadGroup();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  76 */     while (isRunning())
/*     */       try {
/*  78 */         detect();
/*  79 */         sleepIdle(Xdb.getInstance().getConf().getAngelPeriod());
/*     */       } catch (Throwable localThrowable) {
/*  81 */         Trace.error(new StringBuilder().append("angel run ").append(localThrowable).toString());
/*     */       }
/*     */   }
/*     */ 
/*     */   private final void detect()
/*     */   {
/*  96 */     long[] arrayOfLong = this.threadMXBean.findDeadlockedThreads();
/*  97 */     if (null == arrayOfLong) {
/*  98 */       return;
/*     */     }
/*     */ 
/* 101 */     HashMap localHashMap1 = new HashMap();
/*     */     Object localObject2;
/* 102 */     for (localObject2 : this.threadMXBean.getThreadInfo(arrayOfLong, this.threadMXBean.isObjectMonitorUsageSupported(), this.threadMXBean.isSynchronizerUsageSupported()))
/*     */     {
/*     */       try
/*     */       {
/* 109 */         if ((null != localObject2) && (((ThreadInfo)localObject2).getLockOwnerId() != -1L))
/* 110 */           localHashMap1.put(Long.valueOf(((ThreadInfo)localObject2).getThreadId()), localObject2);
/*     */       }
/*     */       catch (Exception localException) {
/* 113 */         if (Trace.isInfoEnabled()) {
/* 114 */           Trace.info("angel critical exeption");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 124 */     ??? = null;
/*     */ 
/* 127 */     while (!localHashMap1.isEmpty()) {
/* 128 */       HashMap localHashMap2 = new HashMap();
/* 129 */       ThreadInfo localThreadInfo1 = (ThreadInfo)((Map.Entry)localHashMap1.entrySet().iterator().next()).getValue();
/*     */       do
/* 131 */         if (null != localHashMap2.put(Long.valueOf(localThreadInfo1.getThreadId()), localThreadInfo1))
/*     */         {
/* 135 */           localObject2 = (ThreadInfo[])localHashMap2.values().toArray(new ThreadInfo[localHashMap2.size()]);
/* 136 */           ThreadInfo localThreadInfo2 = localObject2[Xdb.random().nextInt(localObject2.length)];
/*     */ 
/* 139 */           StringBuilder localStringBuilder = new StringBuilder("Angel.interrupt thread \"");
/* 140 */           localStringBuilder.append(localThreadInfo2.getThreadName()).append("\" Id=").append(localThreadInfo2.getThreadId());
/* 141 */           localStringBuilder.append(" in cycle:\n");
/* 142 */           for (ThreadInfo localThreadInfo3 : localObject2)
/* 143 */             dumpThreadInfoTo(localThreadInfo3, localStringBuilder);
/* 144 */           Trace.fatal(localStringBuilder);
/*     */ 
/* 147 */           ??? = interrupt(localThreadInfo2, (Map)???);
/*     */ 
/* 150 */           break;
/*     */         }
/* 152 */       while ((localThreadInfo1 = (ThreadInfo)localHashMap1.get(Long.valueOf(localThreadInfo1.getLockOwnerId()))) != null);
/*     */ 
/* 154 */       localHashMap1.keySet().removeAll(localHashMap2.keySet());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void dumpThreadInfoTo(ThreadInfo paramThreadInfo, StringBuilder paramStringBuilder) {
/* 159 */     paramStringBuilder.append(new StringBuilder().append("\"").append(paramThreadInfo.getThreadName()).append("\"").append(" Id=").append(paramThreadInfo.getThreadId()).append(" ").append(paramThreadInfo.getThreadState()).toString());
/*     */ 
/* 161 */     if (paramThreadInfo.getLockName() != null) {
/* 162 */       paramStringBuilder.append(new StringBuilder().append(" on ").append(paramThreadInfo.getLockName()).toString());
/*     */     }
/* 164 */     if (paramThreadInfo.getLockOwnerName() != null) {
/* 165 */       paramStringBuilder.append(new StringBuilder().append(" owned by \"").append(paramThreadInfo.getLockOwnerName()).append("\" Id=").append(paramThreadInfo.getLockOwnerId()).toString());
/*     */     }
/* 167 */     if (paramThreadInfo.isSuspended()) {
/* 168 */       paramStringBuilder.append(" (suspended)");
/*     */     }
/* 170 */     if (paramThreadInfo.isInNative()) {
/* 171 */       paramStringBuilder.append(" (in native)");
/*     */     }
/* 173 */     paramStringBuilder.append('\n');
/* 174 */     StackTraceElement[] arrayOfStackTraceElement = paramThreadInfo.getStackTrace();
/*     */     Object localObject2;
/*     */     Object localObject3;
/* 175 */     for (int i = 0; 
/* 176 */       (i < arrayOfStackTraceElement.length) && (i < 255); i++) {
/* 177 */       localObject1 = arrayOfStackTraceElement[i];
/* 178 */       paramStringBuilder.append(new StringBuilder().append("\tat ").append(((StackTraceElement)localObject1).toString()).toString());
/* 179 */       paramStringBuilder.append('\n');
/* 180 */       if ((i == 0) && (paramThreadInfo.getLockInfo() != null)) {
/* 181 */         localObject2 = paramThreadInfo.getThreadState();
/* 182 */         switch (1.$SwitchMap$java$lang$Thread$State[localObject2.ordinal()]) {
/*     */         case 1:
/* 184 */           paramStringBuilder.append(new StringBuilder().append("\t-  blocked on ").append(paramThreadInfo.getLockInfo()).toString());
/* 185 */           paramStringBuilder.append('\n');
/* 186 */           break;
/*     */         case 2:
/* 188 */           paramStringBuilder.append(new StringBuilder().append("\t-  waiting on ").append(paramThreadInfo.getLockInfo()).toString());
/* 189 */           paramStringBuilder.append('\n');
/* 190 */           break;
/*     */         case 3:
/* 192 */           paramStringBuilder.append(new StringBuilder().append("\t-  waiting on ").append(paramThreadInfo.getLockInfo()).toString());
/* 193 */           paramStringBuilder.append('\n');
/* 194 */           break;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 199 */       for (localObject3 : paramThreadInfo.getLockedMonitors()) {
/* 200 */         if (localObject3.getLockedStackDepth() == i) {
/* 201 */           paramStringBuilder.append(new StringBuilder().append("\t-  locked ").append(localObject3).toString());
/* 202 */           paramStringBuilder.append('\n');
/*     */         }
/*     */       }
/*     */     }
/* 206 */     if (i < arrayOfStackTraceElement.length) {
/* 207 */       paramStringBuilder.append("\t...");
/* 208 */       paramStringBuilder.append('\n');
/*     */     }
/*     */ 
/* 211 */     Object localObject1 = paramThreadInfo.getLockedSynchronizers();
/* 212 */     if (localObject1.length > 0) {
/* 213 */       paramStringBuilder.append(new StringBuilder().append("\n\tNumber of locked synchronizers = ").append(localObject1.length).toString());
/* 214 */       paramStringBuilder.append('\n');
/* 215 */       for (localObject3 : localObject1) {
/* 216 */         paramStringBuilder.append(new StringBuilder().append("\t- ").append(localObject3).toString());
/* 217 */         paramStringBuilder.append('\n');
/*     */       }
/*     */     }
/* 220 */     paramStringBuilder.append('\n');
/*     */   }
/*     */ 
/*     */   private final Map<Long, Thread> interrupt(ThreadInfo paramThreadInfo, Map<Long, Thread> paramMap)
/*     */   {
/*     */     try
/*     */     {
/* 228 */       Worker localWorker = Worker.get(Long.valueOf(paramThreadInfo.getThreadId()));
/* 229 */       if (localWorker != null) {
/* 230 */         localWorker.angelInterrupt();
/* 231 */         this.interruptCount += 1;
/* 232 */         return paramMap;
/*     */       }
/*     */ 
/* 236 */       if (null == paramMap) {
/* 237 */         paramMap = enumerate(this.rootThreadGroup, true);
/*     */       }
/* 239 */       Thread localThread = (Thread)paramMap.get(Long.valueOf(paramThreadInfo.getThreadId()));
/* 240 */       if (null != localThread) {
/* 241 */         localThread.interrupt();
/* 242 */         this.interruptCount += 1;
/* 243 */         return paramMap;
/*     */       }
/* 245 */       if (Trace.isInfoEnabled())
/* 246 */         Trace.info(new StringBuilder().append("Angle.logonly: thread not found. ").append(paramThreadInfo).toString());
/*     */     }
/*     */     catch (Throwable localThrowable) {
/* 249 */       Trace.fatal(new StringBuilder().append("Angle.interrupt ").append(paramThreadInfo).toString(), localThrowable);
/*     */     }
/* 251 */     return paramMap;
/*     */   }
/*     */ 
/*     */   public static <V> Callable<V> decorate(Callable<V> paramCallable, long paramLong)
/*     */   {
/* 263 */     return paramLong > 0L ? new TimeoutCallable(paramCallable, paramLong) : paramCallable;
/*     */   }
/*     */ 
/*     */   public static <V> Callable<V> decorate(Runnable paramRunnable, V paramV, long paramLong)
/*     */   {
/* 275 */     Callable localCallable = Executors.callable(paramRunnable, paramV);
/* 276 */     return paramLong > 0L ? new TimeoutCallable(localCallable, paramLong) : localCallable;
/*     */   }
/*     */ 
/*     */   public static Callable<?> decorateCallable(Runnable paramRunnable, long paramLong)
/*     */   {
/* 288 */     return decorate(paramRunnable, null, paramLong);
/*     */   }
/*     */ 
/*     */   public static Runnable decorateRunnable(Runnable paramRunnable, long paramLong)
/*     */   {
/* 300 */     return paramLong > 0L ? new TimeoutRunnable(paramRunnable, paramLong) : paramRunnable;
/*     */   }
/*     */ 
/*     */   static class TimeoutCallable<V>
/*     */     implements Callable<V>, TimeoutManager.Timeout
/*     */   {
/*     */     private final Callable<V> inner;
/*     */     private final long timeout;
/*     */     private volatile Thread runner;
/*     */ 
/*     */     public TimeoutCallable(Callable<V> paramCallable, long paramLong)
/*     */     {
/* 350 */       if (null == paramCallable)
/* 351 */         throw new NullPointerException();
/* 352 */       this.inner = paramCallable;
/* 353 */       this.timeout = paramLong;
/*     */     }
/*     */ 
/*     */     public V call()
/*     */       throws Exception
/*     */     {
/* 359 */       if (this.timeout > 0L) {
/* 360 */         this.runner = Thread.currentThread();
/* 361 */         TimeoutManager localTimeoutManager = TimeoutManager.getInstance();
/* 362 */         localTimeoutManager.schedule(this, this.timeout);
/*     */         try {
/* 364 */           return this.inner.call();
/*     */         } finally {
/* 366 */           localTimeoutManager.remove(this);
/* 367 */           this.runner = null;
/*     */         }
/*     */       }
/* 370 */       return this.inner.call();
/*     */     }
/*     */ 
/*     */     public void onTimeout()
/*     */     {
/* 375 */       Thread localThread = this.runner;
/* 376 */       if (localThread != null)
/* 377 */         if ((localThread instanceof Worker))
/* 378 */           ((Worker)localThread).angelInterrupt();
/*     */         else
/* 380 */           localThread.interrupt();
/*     */     }
/*     */   }
/*     */ 
/*     */   static class TimeoutRunnable
/*     */     implements Runnable, TimeoutManager.Timeout
/*     */   {
/*     */     private final Runnable inner;
/*     */     private final long timeout;
/*     */     private volatile Thread runner;
/*     */ 
/*     */     public TimeoutRunnable(Runnable paramRunnable, long paramLong)
/*     */     {
/* 309 */       if (null == paramRunnable)
/* 310 */         throw new NullPointerException();
/* 311 */       this.inner = paramRunnable;
/* 312 */       this.timeout = paramLong;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 318 */       if (this.timeout > 0L) {
/* 319 */         this.runner = Thread.currentThread();
/* 320 */         TimeoutManager localTimeoutManager = TimeoutManager.getInstance();
/* 321 */         localTimeoutManager.schedule(this, this.timeout);
/*     */         try {
/* 323 */           this.inner.run();
/*     */         } finally {
/* 325 */           localTimeoutManager.remove(this);
/* 326 */           this.runner = null;
/*     */         }
/*     */       } else {
/* 329 */         this.inner.run();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void onTimeout() {
/* 334 */       Thread localThread = this.runner;
/* 335 */       if (localThread != null)
/* 336 */         if ((localThread instanceof Worker))
/* 337 */           ((Worker)localThread).angelInterrupt();
/*     */         else
/* 339 */           localThread.interrupt();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Angel
 * JD-Core Version:    0.6.2
 */