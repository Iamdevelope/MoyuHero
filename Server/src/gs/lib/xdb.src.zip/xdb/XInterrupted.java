/*    */ package xdb;
/*    */ 
/*    */ public class XInterrupted extends RuntimeException
/*    */ {
/*    */   static final long serialVersionUID = -7927226240291624476L;
/*    */ 
/*    */   public XInterrupted()
/*    */   {
/*    */   }
/*    */ 
/*    */   public XInterrupted(String paramString)
/*    */   {
/* 16 */     super(paramString);
/*    */   }
/*    */ 
/*    */   public XInterrupted(Throwable paramThrowable) {
/* 20 */     super(paramThrowable);
/*    */   }
/*    */ 
/*    */   public XInterrupted(String paramString, Throwable paramThrowable) {
/* 24 */     super(paramString, paramThrowable);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.XInterrupted
 * JD-Core Version:    0.6.2
 */