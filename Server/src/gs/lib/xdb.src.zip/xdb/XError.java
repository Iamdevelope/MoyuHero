/*    */ package xdb;
/*    */ 
/*    */ public class XError extends Error
/*    */ {
/*    */   private static final long serialVersionUID = -2753495176885937511L;
/*    */ 
/*    */   XError()
/*    */   {
/*    */   }
/*    */ 
/*    */   XError(String paramString)
/*    */   {
/* 16 */     super(paramString);
/*    */   }
/*    */ 
/*    */   XError(Throwable paramThrowable) {
/* 20 */     super(paramThrowable);
/*    */   }
/*    */ 
/*    */   XError(String paramString, Throwable paramThrowable) {
/* 24 */     super(paramString, paramThrowable);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.XError
 * JD-Core Version:    0.6.2
 */