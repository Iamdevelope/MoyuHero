/*    */ package xdb;
/*    */ 
/*    */ public class ThreadHelper extends Thread
/*    */ {
/*  4 */   private volatile boolean running = true;
/*  5 */   private boolean idle = true;
/*    */ 
/*    */   public ThreadHelper(String paramString) {
/*  8 */     super(paramString);
/*  9 */     setDaemon(true);
/*    */   }
/*    */ 
/*    */   public ThreadHelper(String paramString, boolean paramBoolean) {
/* 13 */     super(paramString);
/* 14 */     setDaemon(paramBoolean);
/*    */   }
/*    */ 
/*    */   public final boolean isRunning() {
/* 18 */     return this.running;
/*    */   }
/*    */ 
/*    */   public final void joinAssuring()
/*    */   {
/*    */     while (true)
/*    */       try
/*    */       {
/* 27 */         join();
/*    */       }
/*    */       catch (Throwable localThrowable) {
/* 30 */         Trace.warn(getClass().getName() + "shutdown. ignore ex=" + localThrowable);
/*    */       }
/*    */   }
/*    */ 
/*    */   public void shutdown()
/*    */   {
/* 36 */     this.running = false;
/* 37 */     wakeup();
/* 38 */     joinAssuring();
/*    */   }
/*    */ 
/*    */   public synchronized void wakeup() {
/* 42 */     this.idle = false;
/* 43 */     notify();
/*    */   }
/*    */ 
/*    */   public final synchronized void sleepIdle(long paramLong)
/*    */   {
/*    */     try
/*    */     {
/* 56 */       if (this.idle)
/* 57 */         wait(paramLong);
/*    */     } catch (InterruptedException localInterruptedException) {
/* 59 */       Trace.warn(getClass().getName() + "sleepOut. ex=" + localInterruptedException);
/*    */     } finally {
/* 61 */       this.idle = true;
/*    */     }
/*    */   }
/*    */ 
/*    */   Runnable cock() {
/* 66 */     return new Runnable()
/*    */     {
/*    */       public void run() {
/* 69 */         ThreadHelper.this.wakeup();
/*    */       }
/*    */     };
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.ThreadHelper
 * JD-Core Version:    0.6.2
 */