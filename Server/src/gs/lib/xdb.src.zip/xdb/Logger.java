/*     */ package xdb;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public final class Logger
/*     */ {
/*     */   private long handle;
/*     */   private int type;
/*     */   public static final int TypeNull = 0;
/*     */   public static final int TypePage = 1;
/*     */   public static final int TypeGlobal = 2;
/*     */ 
/*     */   public Logger()
/*     */   {
/*  22 */     this(null, 0);
/*     */   }
/*     */ 
/*     */   public Logger(String paramString, int paramInt) {
/*  26 */     if (paramInt < 0) {
/*  27 */       throw new IllegalArgumentException();
/*     */     }
/*  29 */     this.handle = create(paramString, paramInt);
/*  30 */     if (0L == this.handle) {
/*  31 */       throw new XError("Logger(" + paramString + ", " + paramInt + ")");
/*     */     }
/*     */ 
/*  34 */     this.type = (0 == paramInt ? 0 : null != paramString ? 2 : 1);
/*     */   }
/*     */ 
/*     */   public int getType() {
/*  38 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*  45 */     if (0L == this.handle) {
/*  46 */       throw new XError("logger has closed");
/*     */     }
/*  48 */     close(this.handle);
/*  49 */     this.handle = 0L;
/*     */   }
/*     */ 
/*     */   protected void finalize() throws Throwable
/*     */   {
/*  54 */     if (0L != this.handle)
/*  55 */       close(this.handle);
/*  56 */     super.finalize();
/*     */   }
/*     */ 
/*     */   long getHandle() {
/*  60 */     return this.handle;
/*     */   }
/*     */ 
/*     */   public void prepare() {
/*  64 */     if (0L == this.handle) {
/*  65 */       throw new XError("logger has closed");
/*     */     }
/*  67 */     if (false == prepare(this.handle))
/*  68 */       throw new XError("checkpoint prepare faild");
/*     */   }
/*     */ 
/*     */   public void commit(long paramLong) {
/*  72 */     if (0L == this.handle) {
/*  73 */       throw new XError("logger has closed");
/*     */     }
/*  75 */     if (false == commit(this.handle, paramLong))
/*  76 */       throw new XError("checkpoint commit faild");
/*     */   }
/*     */ 
/*     */   public int verify()
/*     */   {
/*  81 */     if (0L == this.handle) {
/*  82 */       throw new XError("logger has closed");
/*     */     }
/*  84 */     return verify(this.handle);
/*     */   }
/*     */ 
/*     */   public long loggerid()
/*     */   {
/*  91 */     if (0L == this.handle)
/*  92 */       throw new XError("logger has closed");
/*  93 */     return loggerid(this.handle);
/*     */   }
/*     */ 
/*     */   public void removeOlder() {
/*  97 */     long l = loggerid();
/*  98 */     for (File localFile : listFiles())
/*     */     {
/* 100 */       String str = localFile.getName().substring(4);
/* 101 */       if (Long.parseLong(str, 16) < l)
/* 102 */         localFile.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final boolean isLogFile(File paramFile) {
/*     */     try {
/* 108 */       String str1 = paramFile.getName();
/* 109 */       if (!str1.startsWith("log."))
/* 110 */         return false;
/* 111 */       String str2 = str1.substring(4);
/* 112 */       if (str2.length() != 8)
/* 113 */         return false;
/* 114 */       Long.parseLong(str2, 16);
/* 115 */       return true; } catch (Exception localException) {
/*     */     }
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */   public static final List<File> listFiles()
/*     */   {
/* 122 */     return listFiles(Xdb.getInstance().getConf().getLogHome());
/*     */   }
/*     */ 
/*     */   public static final List<File> listFiles(File paramFile) {
/* 126 */     ArrayList localArrayList = new ArrayList();
/* 127 */     File[] arrayOfFile1 = paramFile.listFiles();
/* 128 */     if (null != arrayOfFile1) {
/* 129 */       for (File localFile : arrayOfFile1) {
/* 130 */         if ((localFile.isFile()) && (isLogFile(localFile)))
/* 131 */           localArrayList.add(localFile);
/*     */       }
/*     */     }
/* 134 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public static SortedMap<String, File> sortedFiles(File paramFile) {
/* 138 */     TreeMap localTreeMap = new TreeMap();
/* 139 */     File[] arrayOfFile1 = paramFile.listFiles();
/* 140 */     if (null != arrayOfFile1) {
/* 141 */       for (File localFile : arrayOfFile1) {
/* 142 */         if ((localFile.isFile()) && (isLogFile(localFile)))
/* 143 */           localTreeMap.put(localFile.getName(), localFile);
/*     */       }
/*     */     }
/* 146 */     return localTreeMap;
/*     */   }
/*     */ 
/*     */   private native long create(String paramString, int paramInt);
/*     */ 
/*     */   private native int verify(long paramLong);
/*     */ 
/*     */   private native void close(long paramLong);
/*     */ 
/*     */   private native boolean prepare(long paramLong);
/*     */ 
/*     */   private native boolean commit(long paramLong1, long paramLong2);
/*     */ 
/*     */   private native long loggerid(long paramLong);
/*     */ 
/*     */   public final void checkpoint(Storage paramStorage, long paramLong)
/*     */   {
/* 172 */     checkpoint(Arrays.asList(new Storage[] { paramStorage }), paramLong);
/*     */   }
/*     */ 
/*     */   public final void checkpoint(Collection<Storage> paramCollection, long paramLong)
/*     */   {
/* 180 */     for (Iterator localIterator = paramCollection.iterator(); localIterator.hasNext(); ) { localStorage = (Storage)localIterator.next();
/* 181 */       localStorage.lock();
/*     */     }
/* 184 */     Storage localStorage;
/* 184 */     for (localIterator = paramCollection.iterator(); localIterator.hasNext(); ) { localStorage = (Storage)localIterator.next();
/* 185 */       localStorage.snapshot_create();
/* 186 */       localStorage.unlock();
/*     */     }
/*     */ 
/* 189 */     prepare();
/* 190 */     commit(paramLong);
/*     */ 
/* 192 */     for (localIterator = paramCollection.iterator(); localIterator.hasNext(); ) { localStorage = (Storage)localIterator.next();
/* 193 */       localStorage.lock();
/* 194 */       localStorage.snapshot_release();
/* 195 */       localStorage.unlock();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Logger
 * JD-Core Version:    0.6.2
 */