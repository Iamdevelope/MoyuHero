/*     */ package xdb;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Future;
/*     */ import xio.Protocol;
/*     */ import xio.Xio;
/*     */ 
/*     */ public class Procedure
/*     */ {
/*     */   private volatile ProcedureConf conf;
/* 264 */   private volatile boolean success = false;
/*     */   private volatile Throwable exception;
/* 342 */   private static ThreadLocal<ArrayList<Task>> ptasks = new ThreadLocal() {
/*     */     protected ArrayList<Procedure.Task> initialValue() {
/* 344 */       return new ArrayList();
/*     */     }
/* 342 */   };
/*     */ 
/* 348 */   private ArrayList<Task> tasks = null;
/*     */ 
/* 416 */   private static volatile IOnlines onlines = null;
/*     */ 
/*     */   protected final void begin()
/*     */   {
/*  57 */     Transaction.current().begin();
/*     */   }
/*     */ 
/*     */   protected final int beginAndSavepoint() {
/*  61 */     Transaction localTransaction = Transaction.current();
/*  62 */     localTransaction.begin();
/*  63 */     return localTransaction.savepoint();
/*     */   }
/*     */ 
/*     */   protected final void commit() {
/*  67 */     Transaction.current().commit();
/*     */   }
/*     */ 
/*     */   protected final int savepoint() {
/*  71 */     return Transaction.current().savepoint();
/*     */   }
/*     */ 
/*     */   protected final void rollback(int paramInt)
/*     */   {
/*  89 */     Transaction.current().rollback(paramInt);
/*     */   }
/*     */ 
/*     */   protected final int trancount() {
/*  93 */     return Transaction.current().trancount();
/*     */   }
/*     */ 
/*     */   protected final void rollbackAll() {
/*  97 */     throw new XError("rollbackAll");
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   protected void lock(String paramString, Object[] paramArrayOfObject)
/*     */   {
/* 105 */     int i = Lockeys.getInstance().getLockId(paramString);
/* 106 */     Lockey[] arrayOfLockey = new Lockey[paramArrayOfObject.length];
/* 107 */     int j = 0;
/* 108 */     for (Object localObject : paramArrayOfObject)
/* 109 */       arrayOfLockey[(j++)] = Lockeys.get(paramString, i, localObject);
/* 110 */     lock(arrayOfLockey);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   protected void lock(String paramString, Collection<?> paramCollection)
/*     */   {
/* 118 */     int i = Lockeys.getInstance().getLockId(paramString);
/* 119 */     Lockey[] arrayOfLockey = new Lockey[paramCollection.size()];
/* 120 */     int j = 0;
/* 121 */     for (Iterator localIterator = paramCollection.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 122 */       arrayOfLockey[(j++)] = Lockeys.get(paramString, i, localObject); }
/* 123 */     lock(arrayOfLockey);
/*     */   }
/*     */ 
/*     */   protected void lock(TTable<?, ?> paramTTable, Collection<?> paramCollection) {
/* 127 */     Lockeys.lock(paramTTable, paramCollection);
/*     */   }
/*     */ 
/*     */   protected void lock(Lockey[] paramArrayOfLockey)
/*     */   {
/* 136 */     Lockeys.lock(paramArrayOfLockey);
/*     */   }
/*     */ 
/*     */   public boolean call()
/*     */   {
/* 146 */     if (Transaction.current() == null)
/*     */     {
/*     */       try {
/* 149 */         Transaction.create().perform(this);
/*     */       } catch (Throwable localThrowable) {
/*     */       }
/*     */       finally {
/* 153 */         Transaction.destroy();
/* 154 */         fetchTasks();
/*     */       }
/* 156 */       return isSuccess();
/*     */     }
/*     */ 
/* 159 */     int i = beginAndSavepoint();
/*     */     try
/*     */     {
/* 164 */       if (process()) {
/* 165 */         commit();
/* 166 */         setSuccess(true);
/* 167 */         return true;
/*     */       }
/*     */     } catch (Exception localException) {
/* 170 */       setException(localException);
/* 171 */       Trace.log(getConf().getTrace(), "Procedure execute", localException);
/*     */     }
/*     */ 
/* 174 */     rollback(i);
/* 175 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean process()
/*     */     throws Exception
/*     */   {
/* 191 */     return false;
/*     */   }
/*     */ 
/*     */   private static void verify()
/*     */   {
/* 197 */     if (Transaction.current() != null)
/* 198 */       throw new IllegalStateException("can not submit in transaction.");
/*     */   }
/*     */ 
/*     */   public final Future<Procedure> submit()
/*     */   {
/* 207 */     verify();
/* 208 */     return new ProcedureFuture(this);
/*     */   }
/*     */ 
/*     */   public static <P extends Procedure> Future<P> submit(P paramP)
/*     */   {
/* 219 */     verify();
/* 220 */     return new ProcedureFuture(paramP);
/*     */   }
/*     */ 
/*     */   public static <P extends Procedure> void execute(P paramP, Done<P> paramDone)
/*     */   {
/* 240 */     new ProcedureFuture(paramP, paramDone);
/*     */   }
/*     */ 
/*     */   public static void execute(Procedure paramProcedure)
/*     */   {
/* 249 */     new ProcedureFuture(paramProcedure, null);
/*     */   }
/*     */ 
/*     */   public void execute()
/*     */   {
/* 256 */     new ProcedureFuture(this, null);
/*     */   }
/*     */ 
/*     */   public Procedure()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Procedure(ProcedureConf paramProcedureConf)
/*     */   {
/* 271 */     this.conf = paramProcedureConf;
/*     */   }
/*     */ 
/*     */   public final ProcedureConf getConf() {
/* 275 */     if (null != this.conf) {
/* 276 */       return this.conf;
/*     */     }
/* 278 */     return Xdb.getInstance().getConf().getProcedureConf();
/*     */   }
/*     */ 
/*     */   public final synchronized void setConf(ProcedureConf paramProcedureConf) {
/* 282 */     this.conf = paramProcedureConf;
/*     */   }
/*     */ 
/*     */   public final boolean isSuccess() {
/* 286 */     return this.success;
/*     */   }
/*     */ 
/*     */   public final void setSuccess(boolean paramBoolean) {
/* 290 */     this.success = paramBoolean;
/*     */   }
/*     */ 
/*     */   public final Throwable getException() {
/* 294 */     return this.exception;
/*     */   }
/*     */ 
/*     */   public final void setException(Throwable paramThrowable)
/*     */   {
/* 299 */     this.exception = paramThrowable;
/*     */   }
/*     */ 
/*     */   public static void ppost(Task paramTask)
/*     */   {
/* 355 */     ((ArrayList)ptasks.get()).add(paramTask);
/*     */   }
/*     */ 
/*     */   void fetchTasks()
/*     */   {
/* 362 */     this.tasks = ((ArrayList)ptasks.get());
/* 363 */     ptasks.remove();
/*     */   }
/*     */ 
/*     */   public ArrayList<Task> getLastTasks()
/*     */   {
/* 371 */     return this.tasks;
/*     */   }
/*     */ 
/*     */   public void runLastTasks()
/*     */   {
/* 380 */     if (null != this.tasks)
/* 381 */       for (Task localTask : this.tasks)
/*     */         try {
/* 383 */           localTask.process();
/*     */         }
/*     */         catch (Throwable localThrowable)
/*     */         {
/* 387 */           Trace.error("Procedure.runTasks", localThrowable);
/*     */         }
/*     */   }
/*     */ 
/*     */   public static void ppostWhileCommit(Task paramTask)
/*     */   {
/* 393 */     paramTask.setExpected(true);
/* 394 */     Transaction.currentSavepoint().add(new LogKey(new XBean(null, null), ""), paramTask);
/* 395 */     ppost(paramTask);
/*     */   }
/*     */ 
/*     */   public static void ppostWhileRollback(Task paramTask) {
/* 399 */     paramTask.setExpected(false);
/* 400 */     Transaction.currentSavepoint().add(new LogKey(new XBean(null, null), ""), paramTask);
/* 401 */     ppost(paramTask);
/*     */   }
/*     */ 
/*     */   protected static IOnlines getOlines()
/*     */   {
/* 419 */     return onlines;
/*     */   }
/*     */ 
/*     */   public static void setOlines(IOnlines paramIOnlines) {
/* 423 */     onlines = paramIOnlines;
/*     */   }
/*     */ 
/*     */   public static void psend(long paramLong, Protocol paramProtocol)
/*     */   {
/* 429 */     ppost(new SendToRole(paramLong, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void psend(long paramLong1, long paramLong2, Protocol paramProtocol) {
/* 433 */     ppost(new SendToRoles(paramLong1, paramLong2, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void psend(Collection<Long> paramCollection, Protocol paramProtocol) {
/* 437 */     ppost(new SendToRoles(paramCollection, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void psendResponse(Protocol paramProtocol1, Protocol paramProtocol2) {
/* 441 */     ppost(new SendResponse(paramProtocol1, paramProtocol2));
/*     */   }
/*     */ 
/*     */   public static void pbroadcast(Protocol paramProtocol, int paramInt) {
/* 445 */     ppost(new Broadcast(paramProtocol, paramInt));
/*     */   }
/*     */ 
/*     */   public static void psend(Xio paramXio, Protocol paramProtocol) {
/* 449 */     ppost(new SendToXio(paramXio, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void pexecute(Procedure paramProcedure) {
/* 453 */     ppost(new ExecuteProcedure(paramProcedure));
/*     */   }
/*     */ 
/*     */   public static void pexecute(Runnable paramRunnable) {
/* 457 */     ppost(new ExecuteRunnable(paramRunnable));
/*     */   }
/*     */ 
/*     */   public static void psendWhileCommit(long paramLong, Protocol paramProtocol)
/*     */   {
/* 464 */     ppostWhileCommit(new SendToRole(paramLong, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void psendWhileCommit(long paramLong1, long paramLong2, Protocol paramProtocol) {
/* 468 */     ppostWhileCommit(new SendToRoles(paramLong1, paramLong2, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void psendWhileCommit(Collection<Long> paramCollection, Protocol paramProtocol) {
/* 472 */     ppostWhileCommit(new SendToRoles(paramCollection, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void psendResponseWhileCommit(Protocol paramProtocol1, Protocol paramProtocol2) {
/* 476 */     ppostWhileCommit(new SendResponse(paramProtocol1, paramProtocol2));
/*     */   }
/*     */ 
/*     */   public static void pbroadcastWhileCommit(Protocol paramProtocol, int paramInt) {
/* 480 */     ppostWhileCommit(new Broadcast(paramProtocol, paramInt));
/*     */   }
/*     */ 
/*     */   public static void psendWhileCommit(Xio paramXio, Protocol paramProtocol) {
/* 484 */     ppostWhileCommit(new SendToXio(paramXio, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void pexecuteWhileCommit(Procedure paramProcedure) {
/* 488 */     ppostWhileCommit(new ExecuteProcedure(paramProcedure));
/*     */   }
/*     */ 
/*     */   public static void pexecuteWhileCommit(Runnable paramRunnable) {
/* 492 */     ppostWhileCommit(new ExecuteRunnable(paramRunnable));
/*     */   }
/*     */ 
/*     */   public static void psendWhileRollback(long paramLong, Protocol paramProtocol)
/*     */   {
/* 498 */     ppostWhileRollback(new SendToRole(paramLong, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void psendWhileRollback(long paramLong1, long paramLong2, Protocol paramProtocol) {
/* 502 */     ppostWhileRollback(new SendToRoles(paramLong1, paramLong2, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void psendWhileRollback(Collection<Long> paramCollection, Protocol paramProtocol) {
/* 506 */     ppostWhileRollback(new SendToRoles(paramCollection, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void psendResponseWhileRollback(Protocol paramProtocol1, Protocol paramProtocol2) {
/* 510 */     ppostWhileRollback(new SendResponse(paramProtocol1, paramProtocol2));
/*     */   }
/*     */ 
/*     */   public static void pbroadcastWhileRollback(Protocol paramProtocol, int paramInt) {
/* 514 */     ppostWhileRollback(new Broadcast(paramProtocol, paramInt));
/*     */   }
/*     */ 
/*     */   public static void psendWhileRollback(Xio paramXio, Protocol paramProtocol) {
/* 518 */     ppostWhileRollback(new SendToXio(paramXio, paramProtocol));
/*     */   }
/*     */ 
/*     */   public static void pexecuteWhileRollback(Procedure paramProcedure) {
/* 522 */     ppostWhileRollback(new ExecuteProcedure(paramProcedure));
/*     */   }
/*     */ 
/*     */   public static void pexecuteWhileRollback(Runnable paramRunnable) {
/* 526 */     ppostWhileRollback(new ExecuteRunnable(paramRunnable));
/*     */   }
/*     */ 
/*     */   public static class ExecuteRunnable extends Procedure.Task
/*     */   {
/*     */     private Runnable command;
/*     */ 
/*     */     public ExecuteRunnable(Runnable paramRunnable)
/*     */     {
/* 634 */       this.command = paramRunnable;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 639 */       Xdb.executor().execute(this.command);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class ExecuteProcedure extends Procedure.Task
/*     */   {
/*     */     private Procedure proc;
/*     */ 
/*     */     public ExecuteProcedure(Procedure paramProcedure)
/*     */     {
/* 621 */       this.proc = paramProcedure;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 626 */       this.proc.execute();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class SendToXio extends Procedure.Task
/*     */   {
/*     */     private Xio conn;
/*     */     private Protocol p;
/*     */ 
/*     */     public SendToXio(Xio paramXio, Protocol paramProtocol)
/*     */     {
/* 607 */       this.conn = paramXio;
/* 608 */       this.p = paramProtocol;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 613 */       this.p.send(this.conn);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Broadcast extends Procedure.Task
/*     */   {
/*     */     private Protocol p;
/*     */     private int timems;
/*     */ 
/*     */     public Broadcast(Protocol paramProtocol)
/*     */     {
/* 587 */       this.p = paramProtocol;
/* 588 */       this.timems = 0;
/*     */     }
/*     */ 
/*     */     public Broadcast(Protocol paramProtocol, int paramInt) {
/* 592 */       this.p = paramProtocol;
/* 593 */       this.timems = paramInt;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 598 */       Procedure.getOlines().broadcast(this.p, this.timems);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class SendResponse extends Procedure.Task
/*     */   {
/*     */     private Protocol pFromLink;
/*     */     private Protocol p;
/*     */ 
/*     */     public SendResponse(Protocol paramProtocol1, Protocol paramProtocol2)
/*     */     {
/* 572 */       this.pFromLink = paramProtocol1;
/* 573 */       this.p = paramProtocol2;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 578 */       Procedure.getOlines().sendResponse(this.pFromLink, this.p);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class SendToRoles extends Procedure.Task
/*     */   {
/* 547 */     private HashSet<Long> roleids = new HashSet();
/*     */     private Protocol p;
/*     */ 
/*     */     public SendToRoles(Collection<Long> paramCollection, Protocol paramProtocol)
/*     */     {
/* 551 */       this.roleids.addAll(paramCollection);
/* 552 */       this.p = paramProtocol;
/*     */     }
/*     */ 
/*     */     public SendToRoles(long paramLong1, long paramLong2, Protocol paramProtocol) {
/* 556 */       this.roleids.add(Long.valueOf(paramLong1));
/* 557 */       this.roleids.add(Long.valueOf(paramLong2));
/* 558 */       this.p = paramProtocol;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 563 */       Procedure.getOlines().send(this.roleids, this.p);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class SendToRole extends Procedure.Task
/*     */   {
/*     */     private long roleid;
/*     */     private Protocol p;
/*     */ 
/*     */     public SendToRole(long paramLong, Protocol paramProtocol)
/*     */     {
/* 536 */       this.roleid = paramLong;
/* 537 */       this.p = paramProtocol;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 542 */       Procedure.getOlines().send(Long.valueOf(this.roleid), this.p);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface IOnlines
/*     */   {
/*     */     public abstract boolean sendResponse(Protocol paramProtocol1, Protocol paramProtocol2);
/*     */ 
/*     */     public abstract boolean send(Long paramLong, Protocol paramProtocol);
/*     */ 
/*     */     public abstract boolean send(Set<Long> paramSet, Protocol paramProtocol);
/*     */ 
/*     */     public abstract void broadcast(Protocol paramProtocol, int paramInt);
/*     */   }
/*     */ 
/*     */   public static abstract class Task
/*     */     implements Runnable, Log
/*     */   {
/* 309 */     private boolean actived = true;
/* 310 */     private boolean expected = true;
/*     */ 
/*     */     public final void setActived(boolean paramBoolean) {
/* 313 */       this.actived = paramBoolean;
/*     */     }
/*     */ 
/*     */     public final void setExpected(boolean paramBoolean) {
/* 317 */       this.expected = paramBoolean;
/*     */     }
/*     */ 
/*     */     public final void process()
/*     */     {
/* 324 */       if (this.actived)
/* 325 */         run();
/*     */     }
/*     */ 
/*     */     public void commit()
/*     */     {
/* 330 */       setActived(this.expected);
/*     */     }
/*     */ 
/*     */     public void rollback()
/*     */     {
/* 335 */       setActived(!this.expected);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface Done<P extends Procedure>
/*     */   {
/*     */     public abstract void doDone(P paramP);
/*     */   }
/*     */ 
/*     */   public class Locks
/*     */   {
/*  21 */     private List<Lockey> locks = new ArrayList();
/*     */ 
/*     */     public Locks() {
/*     */     }
/*     */ 
/*     */     public final Locks add(Lockey paramLockey) {
/*  27 */       this.locks.add(paramLockey);
/*  28 */       return this;
/*     */     }
/*     */ 
/*     */     public final Locks add(TTable<?, ?> paramTTable, Object paramObject) {
/*  32 */       this.locks.add(Lockeys.get(paramTTable, paramObject));
/*  33 */       return this;
/*     */     }
/*     */ 
/*     */     public final Locks add(TTable<?, ?> paramTTable, Collection<Object> paramCollection) {
/*  37 */       for (Lockey localLockey : Lockeys.get(paramTTable, paramCollection))
/*  38 */         this.locks.add(localLockey);
/*  39 */       return this;
/*     */     }
/*     */ 
/*     */     public final Locks add(TTable<?, ?> paramTTable, Object[] paramArrayOfObject) {
/*  43 */       for (Lockey localLockey : Lockeys.get(paramTTable, paramArrayOfObject))
/*  44 */         this.locks.add(localLockey);
/*  45 */       return this;
/*     */     }
/*     */ 
/*     */     public final void lock()
/*     */     {
/*  52 */       Procedure.this.lock((Lockey[])this.locks.toArray(new Lockey[this.locks.size()]));
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Procedure
 * JD-Core Version:    0.6.2
 */