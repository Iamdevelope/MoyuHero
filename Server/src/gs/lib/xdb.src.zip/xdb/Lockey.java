/*     */ package xdb;
/*     */ 
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ public final class Lockey
/*     */   implements Comparable<Lockey>
/*     */ {
/*     */   private final String name;
/*     */   private final int id;
/*     */   private final Object key;
/*     */   private final int hashcode;
/*     */   private ReentrantLock lock;
/*     */ 
/*     */   Lockey(String paramString, int paramInt, Object paramObject)
/*     */   {
/*  20 */     this.name = paramString;
/*  21 */     this.id = paramInt;
/*  22 */     this.key = paramObject;
/*     */ 
/*  24 */     int i = paramObject.hashCode();
/*  25 */     this.hashcode = (paramInt ^ i ^ i >> 12);
/*     */   }
/*     */ 
/*     */   final void alloc() {
/*  29 */     if (null != this.lock)
/*  30 */       throw new XError("xdb : xlock alloc");
/*  31 */     this.lock = new ReentrantLock();
/*     */   }
/*     */ 
/*     */   public final boolean isHeldByCurrentThread()
/*     */   {
/*  39 */     return this.lock.isHeldByCurrentThread();
/*     */   }
/*     */ 
/*     */   public final String getName() {
/*  43 */     return this.name;
/*     */   }
/*     */ 
/*     */   public int getId() {
/*  47 */     return this.id;
/*     */   }
/*     */ 
/*     */   public final Object getKey() {
/*  51 */     return this.key;
/*     */   }
/*     */ 
/*     */   public final void unlock() {
/*  55 */     this.lock.unlock();
/*     */   }
/*     */ 
/*     */   public final boolean tryLock() {
/*  59 */     return this.lock.tryLock();
/*     */   }
/*     */ 
/*     */   public final boolean tryLock(long paramLong) {
/*  63 */     return tryLock(paramLong, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   final void _lock()
/*     */   {
/*  70 */     this.lock.lock();
/*     */   }
/*     */ 
/*     */   public final void lock() {
/*     */     try {
/*  75 */       this.lock.lockInterruptibly();
/*     */     } catch (InterruptedException localInterruptedException) {
/*  77 */       if (Worker.angelInterrupted())
/*  78 */         throw new XLockDead();
/*  79 */       throw new XLockInterrupted(toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public final boolean tryLock(long paramLong, TimeUnit paramTimeUnit) {
/*     */     try {
/*  85 */       return this.lock.tryLock(paramLong, paramTimeUnit);
/*     */     }
/*     */     catch (InterruptedException localInterruptedException) {
/*     */     }
/*  89 */     throw new XLockInterrupted(toString());
/*     */   }
/*     */ 
/*     */   public int compareTo(Lockey paramLockey)
/*     */   {
/*  95 */     if (this.id < paramLockey.id) return -1;
/*  96 */     if (this.id > paramLockey.id) return 1;
/*     */ 
/* 100 */     Comparable localComparable = (Comparable)this.key;
/* 101 */     return localComparable.compareTo(paramLockey.key);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 106 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object paramObject)
/*     */   {
/* 111 */     if (this == paramObject)
/* 112 */       return true;
/* 113 */     if ((paramObject instanceof Lockey)) {
/* 114 */       Lockey localLockey = (Lockey)paramObject;
/* 115 */       return (this.id == localLockey.id) && (this.key.equals(localLockey.key));
/*     */     }
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 122 */     return this.key.toString() + "@" + this.name;
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Lockey
 * JD-Core Version:    0.6.2
 */