/*    */ package xdb;
/*    */ 
/*    */ public class XManagedError extends XError
/*    */ {
/*    */   static final long serialVersionUID = 7269011645942640931L;
/*    */ 
/*    */   XManagedError()
/*    */   {
/*    */   }
/*    */ 
/*    */   XManagedError(String paramString)
/*    */   {
/* 25 */     super(paramString);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.XManagedError
 * JD-Core Version:    0.6.2
 */