package xdb;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public abstract interface ExecutorMBean
{
  public abstract long getExecutorTaskCount();

  public abstract long getExecutorCompletedTaskCount();

  public abstract int getExecutorActiveCount();

  public abstract int getExecutorPoolSize();

  public abstract String getExecutorState();

  public abstract long getProcedureTaskCount();

  public abstract long getProcedureCompletedTaskCount();

  public abstract int getProcedureActiveCount();

  public abstract int getProcedurePoolSize();

  public abstract String getProcedureState();

  public abstract long getScheduledTaskCount();

  public abstract long getScheduledCompletedTaskCount();

  public abstract int getScheduledActiveCount();

  public abstract int getScheduledPoolSize();

  public abstract String getScheduledState();

  public abstract void purgeExecutor(String paramString);

  public abstract void purgeScheduled(String paramString);

  public abstract void purgeProcedure(String paramString);

  public abstract int getExecutorCorePoolSize();

  public abstract void setExecutorCorePoolSize(int paramInt);

  public abstract int getProcedureCorePoolSize();

  public abstract void setProcedureCorePoolSize(int paramInt);

  public abstract int getScheduledCorePoolSize();

  public abstract void setScheduledCorePoolSize(int paramInt);

  public abstract long getExecutorDefaultTimeout();

  public abstract void setExecutorDefaultTimeout(long paramLong);

  public abstract long getScheduledDefaultTimeout();

  public abstract void setScheduledDefaultTimeout(long paramLong);

  public abstract long getProcedureDefaultTimeout();

  public abstract void setProcedureDefaultTimeout(long paramLong);

  public abstract void testAlive(long paramLong)
    throws InterruptedException, ExecutionException, TimeoutException;
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.ExecutorMBean
 * JD-Core Version:    0.6.2
 */