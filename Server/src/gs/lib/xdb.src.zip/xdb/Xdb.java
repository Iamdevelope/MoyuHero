/*     */ package xdb;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import java.util.Timer;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import xdb.util.DatabaseMetaData;
/*     */ import xdb.util.Dbx;
/*     */ import xdb.util.Dbx.Manager;
/*     */ import xdb.util.MBeans.Manager;
/*     */ import xdb.util.StackTrace;
/*     */ import xdb.util.UniqName;
/*     */ import xio.Engine;
/*     */ 
/*     */ public final class Xdb
/*     */   implements XdbMBean
/*     */ {
/*     */   private volatile XdbConf conf;
/*     */   private volatile Tables tables;
/*     */   private volatile Angel angel;
/*     */   private volatile Checkpoint checkpoint;
/*  22 */   private volatile boolean isOpen = false;
/*     */ 
/*  24 */   private static Timer timer = new Timer("xdb.Timer", true);
/*     */ 
/*  26 */   private Random random = new Random(System.currentTimeMillis());
/*  27 */   private static Xdb xdbinstance = new Xdb();
/*     */ 
/*  29 */   private MBeans.Manager xdbmbeans = new MBeans.Manager();
/*     */   public static final int NETWORK = 1;
/*     */   public static final int UNIQNAME = 2;
/*     */   private File inuseFile;
/*     */   public static final String XDBINUSEFILENAME = "xdb.inuse";
/* 290 */   private volatile StopHandle stopHandle = null;
/*     */ 
/*     */   public static MBeans.Manager mbeans()
/*     */   {
/*  32 */     return xdbinstance.xdbmbeans;
/*     */   }
/*     */ 
/*     */   public static Xdb getInstance() {
/*  36 */     return xdbinstance;
/*     */   }
/*     */ 
/*     */   final Angel getAngel()
/*     */   {
/*  41 */     return this.angel;
/*     */   }
/*     */ 
/*     */   public final Tables getTables()
/*     */   {
/*  50 */     return this.tables;
/*     */   }
/*     */ 
/*     */   public static Timer timer() {
/*  54 */     return timer;
/*     */   }
/*     */ 
/*     */   public static Random random() {
/*  58 */     return xdbinstance.random;
/*     */   }
/*     */ 
/*     */   public final Executor getExecutor() {
/*  62 */     return Executor.getInstance();
/*     */   }
/*     */ 
/*     */   public static Executor executor() {
/*  66 */     return Executor.getInstance();
/*     */   }
/*     */ 
/*     */   public static boolean isOpen() {
/*  70 */     return xdbinstance.isOpen;
/*     */   }
/*     */ 
/*     */   private Xdb() {
/*  74 */     Runtime.getRuntime().addShutdownHook(new Thread("xdb.ShutdownHook")
/*     */     {
/*     */       public void run() {
/*  77 */         Trace.fatal("xdb stop from ShutdownHook.");
/*  78 */         Xdb.this.stop();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public final void setConf(XdbConf paramXdbConf)
/*     */   {
/*  85 */     if (null == paramXdbConf)
/*  86 */       throw new NullPointerException();
/*  87 */     Trace.set(paramXdbConf.getTrace());
/*  88 */     this.conf = paramXdbConf;
/*  89 */     Executor localExecutor = Executor.getInstance();
/*  90 */     if (null != localExecutor)
/*  91 */       localExecutor.setCorePoolSize(paramXdbConf.getCorePoolSize(), paramXdbConf.getProcPoolSize(), paramXdbConf.getSchedPoolSize());
/*  92 */     XBean._set_xdb_verify_(paramXdbConf.isXdbVerify());
/*     */   }
/*     */ 
/*     */   public final XdbConf getConf() {
/*  96 */     return this.conf;
/*     */   }
/*     */ 
/*     */   public final boolean start() {
/* 100 */     return start(false);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public final boolean startWithNetwork()
/*     */   {
/* 114 */     return start(true);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public final boolean start(boolean paramBoolean)
/*     */   {
/* 121 */     return start(paramBoolean ? 2 : 0);
/*     */   }
/*     */ 
/*     */   private final int translateOptions(int paramInt)
/*     */   {
/* 140 */     if (0 != (0x2 & paramInt))
/* 141 */       return paramInt | 0x1;
/* 142 */     return paramInt;
/*     */   }
/*     */ 
/*     */   private void deleteInuseFile()
/*     */   {
/* 150 */     this.inuseFile.delete();
/*     */   }
/*     */   private final void createInuseFile() {
/*     */     try {
/* 154 */       this.inuseFile = new File(this.conf.getDbHome(), "xdb.inuse");
/* 155 */       if (false == this.inuseFile.createNewFile()) {
/* 156 */         throw new XError("xdb is still in active use(never use simultaneously) OR\n\t\tnot stop normally: 1 verify and repair the db(commendatory), 2 delete the file '" + this.inuseFile.getPath() + "', " + "3 start again)");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/* 162 */       throw new XError(localIOException);
/*     */     }
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public final synchronized boolean start(int paramInt)
/*     */   {
/* 171 */     if (Dbx.getManager().isOpen()) {
/* 172 */       throw new IllegalAccessError("i hate dbx.");
/*     */     }
/* 174 */     if (this.isOpen) {
/* 175 */       return false;
/*     */     }
/* 177 */     if (null == this.conf) {
/* 178 */       setConf(new XdbConf("../test/xdb.xml"));
/*     */     }
/* 180 */     this.conf.getTableHome().mkdirs();
/* 181 */     this.conf.getLogHome().mkdirs();
/*     */ 
/* 184 */     if (!DatabaseMetaData.getInstance().isSame(this.conf.getDbHome()))
/* 185 */       throw new RuntimeException("Compare metadata fail,should run xtransform?");
/* 186 */     DatabaseMetaData.getInstance().createXML(this.conf.getDbHome());
/*     */ 
/* 188 */     Trace.open(this.conf);
/* 189 */     createInuseFile();
/* 190 */     Trace.fatal("xdb start begin");
/*     */ 
/* 194 */     Lockeys.getInstance();
/* 195 */     new XBean(null, null);
/*     */ 
/* 198 */     paramInt = translateOptions(paramInt);
/*     */     try {
/* 200 */       Class localClass = Class.forName("xtable._Tables_");
/* 201 */       Object localObject = localClass.newInstance();
/* 202 */       if (!(localObject instanceof Tables)) {
/* 203 */         throw new XError("invalid xtable.Tables");
/*     */       }
/* 205 */       Executor.start(this.conf.getProcedureConf().getMaxExecutionTime(), this.conf.getCorePoolSize(), this.conf.getProcPoolSize(), this.conf.getSchedPoolSize(), this.conf.getTimeoutPeriod());
/*     */ 
/* 210 */       this.tables = ((Tables)localObject);
/* 211 */       this.tables.open(this.conf);
/*     */ 
/* 213 */       this.checkpoint = new Checkpoint(this.tables);
/* 214 */       this.angel = new Angel();
/*     */ 
/* 216 */       this.isOpen = true;
/*     */ 
/* 218 */       if (0 != (0x2 & paramInt))
/* 219 */         UniqName.initialize();
/* 220 */       if (0 != (0x1 & paramInt)) {
/* 221 */         Engine.getInstance().open();
/*     */       }
/* 223 */       mbeans().register(this, "xdb:type=Xdb");
/*     */ 
/* 225 */       this.checkpoint.start();
/* 226 */       this.angel.start();
/*     */ 
/* 228 */       Trace.fatal("xdb start end");
/* 229 */       return true;
/*     */     }
/*     */     catch (XError localXError) {
/* 232 */       close();
/* 233 */       throw localXError;
/*     */     } catch (Throwable localThrowable) {
/* 235 */       close();
/* 236 */       throw new XError(localThrowable);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void startNetwork()
/*     */   {
/* 244 */     UniqName.initialize();
/* 245 */     Engine.getInstance().open();
/*     */   }
/*     */ 
/*     */   private final synchronized void close() {
/* 249 */     this.isOpen = false;
/* 250 */     Trace.fatal("xdb stop begin");
/* 251 */     mbeans().unregisterAll();
/* 252 */     UniqName.uninitialize();
/* 253 */     Engine.getInstance().close();
/*     */ 
/* 255 */     Executor.stop();
/*     */ 
/* 257 */     if (null != this.angel) {
/* 258 */       this.angel.shutdown();
/* 259 */       this.angel = null;
/*     */     }
/*     */ 
/* 262 */     if (null != this.checkpoint) {
/* 263 */       this.checkpoint.shutdown();
/* 264 */       this.checkpoint = null;
/*     */     }
/*     */ 
/* 267 */     if (null != this.tables) {
/* 268 */       this.tables.close();
/* 269 */       this.tables = null;
/*     */     }
/* 271 */     deleteInuseFile();
/* 272 */     Trace.fatal("xdb stop end");
/*     */   }
/*     */ 
/*     */   public final void stop()
/*     */   {
/* 277 */     synchronized (this) {
/* 278 */       if (false == this.isOpen)
/* 279 */         return;
/* 280 */       this.isOpen = false;
/*     */     }
/* 282 */     ??? = this.stopHandle;
/* 283 */     if (null != ???)
/* 284 */       ((StopHandle)???).beforeStop();
/* 285 */     close();
/* 286 */     if (null != ???)
/* 287 */       ((StopHandle)???).afterStop();
/*     */   }
/*     */ 
/*     */   public void setStopHandle(StopHandle paramStopHandle)
/*     */   {
/* 292 */     this.stopHandle = paramStopHandle;
/*     */   }
/*     */ 
/*     */   public void shutdown(String paramString)
/*     */   {
/* 311 */     if (paramString.equals("iamsure")) {
/* 312 */       stop();
/* 313 */       Trace.fatal("halt program from jmx");
/* 314 */       Runtime.getRuntime().halt(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getAngleInterruptCount()
/*     */   {
/* 320 */     return this.angel.getInterruptCount();
/*     */   }
/*     */ 
/*     */   public long getTransactionCount()
/*     */   {
/* 325 */     return Transaction.getTotalCount();
/*     */   }
/*     */ 
/*     */   public long getTransactionFalse()
/*     */   {
/* 330 */     return Transaction.getTotalFalse();
/*     */   }
/*     */ 
/*     */   public long getTransactionException()
/*     */   {
/* 335 */     return Transaction.getTotalException();
/*     */   }
/*     */ 
/*     */   public void testAlive(long paramLong)
/*     */     throws InterruptedException, ExecutionException, TimeoutException
/*     */   {
/* 341 */     getExecutor().testAlive(paramLong);
/*     */   }
/*     */ 
/*     */   public CheckpointMBean getCheckpointMBean()
/*     */   {
/* 346 */     return this.checkpoint;
/*     */   }
/*     */ 
/*     */   public Map<String, AtomicInteger> top(String paramString1, String paramString2)
/*     */   {
/* 351 */     return new StackTrace(paramString1, paramString2).top();
/*     */   }
/*     */ 
/*     */   public static abstract interface StopHandle
/*     */   {
/*     */     public abstract void beforeStop();
/*     */ 
/*     */     public abstract void afterStop();
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Xdb
 * JD-Core Version:    0.6.2
 */