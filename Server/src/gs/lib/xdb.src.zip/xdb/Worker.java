/*    */ package xdb;
/*    */ 
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import java.util.concurrent.ThreadPoolExecutor;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import xdb.util.Misc;
/*    */ 
/*    */ public final class Worker extends Thread
/*    */ {
/*    */   private ThreadFactory threadFactory;
/* 39 */   private static ConcurrentMap<Long, Worker> workers = Misc.newConcurrentMap();
/*    */ 
/* 45 */   private AtomicBoolean angel = new AtomicBoolean(false);
/*    */ 
/*    */   private Worker(ThreadFactory paramThreadFactory, String paramString, Runnable paramRunnable)
/*    */   {
/* 11 */     super(paramRunnable);
/* 12 */     this.threadFactory = paramThreadFactory;
/* 13 */     setDaemon(true);
/* 14 */     setName("xdb.Worker." + paramString + "." + getId());
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/* 29 */     workers.put(Long.valueOf(getId()), this);
/*    */     try {
/* 31 */       super.run();
/*    */     } catch (Throwable localThrowable) {
/* 33 */       Trace.error("worker catch Exception", localThrowable);
/*    */     } finally {
/* 35 */       workers.remove(Long.valueOf(getId()));
/*    */     }
/*    */   }
/*    */ 
/*    */   static Worker get(Long paramLong)
/*    */   {
/* 42 */     return (Worker)workers.get(paramLong);
/*    */   }
/*    */ 
/*    */   void angelInterrupt()
/*    */   {
/* 48 */     this.angel.set(true);
/* 49 */     super.interrupt();
/*    */   }
/*    */ 
/*    */   static boolean angelInterrupted() {
/* 53 */     Thread localThread = Thread.currentThread();
/* 54 */     if ((localThread instanceof Worker)) {
/* 55 */       return ((Worker)localThread).angel.getAndSet(false);
/*    */     }
/* 57 */     return false;
/*    */   }
/*    */ 
/*    */   public static ThreadFactory newFactory(String paramString)
/*    */   {
/* 78 */     return new WorkerFactory(paramString);
/*    */   }
/*    */ 
/*    */   public static final void debugHunger(ThreadPoolExecutor paramThreadPoolExecutor)
/*    */   {
/* 94 */     if (Trace.isDebugEnabled()) {
/* 95 */       Thread localThread = Thread.currentThread();
/* 96 */       if ((localThread instanceof Worker)) {
/* 97 */         Worker localWorker = (Worker)localThread;
/* 98 */         if (localWorker.threadFactory == paramThreadPoolExecutor.getThreadFactory())
/* 99 */           throw new RuntimeException("Say no to hunger!");
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   private static class WorkerFactory
/*    */     implements ThreadFactory
/*    */   {
/*    */     private final String executorName;
/*    */ 
/*    */     WorkerFactory(String paramString)
/*    */     {
/* 63 */       this.executorName = paramString;
/*    */     }
/*    */ 
/*    */     public Thread newThread(Runnable paramRunnable) {
/* 67 */       return new Worker(this, this.executorName, paramRunnable, null);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Worker
 * JD-Core Version:    0.6.2
 */