package xdb;

public abstract interface CheckpointMBean
{
  public abstract int getCountCheckpoint();

  public abstract long getCountMarshalN();

  public abstract long getCountMarshal0();

  public abstract long getCountFlush();

  public abstract long getCountSnapshot();

  public abstract long getTotalTimeMarshalN();

  public abstract long getTotalTimeSnapshot();

  public abstract long getTotalTimeFlush();

  public abstract long getTotalTimeCheckpoint();

  public abstract String getTimeOfNextFlush();

  public abstract String getTimeOfNextCheckpoint();

  public abstract String getTimeOfNextFullBackup();

  public abstract String getTimeOfNextIncBackup();

  public abstract void fullBackup(long paramLong)
    throws InterruptedException;

  public abstract void checkpoint(long paramLong)
    throws InterruptedException;

  public abstract boolean isAllowBackup();

  public abstract void setAllowBackup(boolean paramBoolean);

  public abstract int getPeriodCheckpoint();

  public abstract void setPeriodCheckpoint(int paramInt);
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.CheckpointMBean
 * JD-Core Version:    0.6.2
 */