/*     */ package xdb;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import xdb.util.Elapse;
/*     */ import xdb.util.MBeans.Manager;
/*     */ 
/*     */ final class Checkpoint extends ThreadHelper
/*     */   implements CheckpointMBean
/*     */ {
/*     */   private Tables tables;
/*  47 */   private volatile long marshalNCount = 0L;
/*  48 */   private volatile long marshal0Count = 0L;
/*  49 */   private volatile long snapshotCount = 0L;
/*  50 */   private volatile long flushCount = 0L;
/*  51 */   private volatile int checkpointCount = 0;
/*     */ 
/*  53 */   private volatile long marshalNTotalTime = 0L;
/*  54 */   private volatile long snapshotTotalTime = 0L;
/*  55 */   private volatile long flushTotalTime = 0L;
/*  56 */   private volatile long checkpointTotalTime = 0L;
/*     */   private volatile long nextMarshalTime;
/*     */   private volatile long nextCheckpointTime;
/*     */   private volatile long nextFullBackupTime;
/*     */   private volatile long nextIncBackupTime;
/*     */   private Backup backup;
/*  65 */   private boolean fullBackupNow = false;
/*  66 */   private Object fullBackupWaitQueue = new Object();
/*  67 */   private boolean checkpointNow = false;
/*  68 */   private Object checkpointWaitQueue = new Object();
/*     */ 
/*  70 */   private volatile boolean allowBackup = true;
/*     */ 
/*  73 */   private boolean allowCheckpointXXX = true;
/*     */ 
/* 216 */   private final Elapse elapse = new Elapse();
/*     */ 
/*     */   public boolean isAllowBackup()
/*     */   {
/*  77 */     return this.allowBackup;
/*     */   }
/*     */ 
/*     */   public void setAllowBackup(boolean paramBoolean)
/*     */   {
/*  82 */     this.allowBackup = paramBoolean;
/*  83 */     if (false == paramBoolean)
/*  84 */       fullBackupDone();
/*     */   }
/*     */ 
/*     */   public void fullBackup(long paramLong) throws InterruptedException
/*     */   {
/*  89 */     if (false == this.allowBackup) {
/*  90 */       throw new IllegalStateException("backup disabled");
/*     */     }
/*  92 */     synchronized (this.fullBackupWaitQueue) {
/*  93 */       this.fullBackupNow = true;
/*  94 */       wakeup();
/*  95 */       if (paramLong >= 0L) {
/*  96 */         this.fullBackupWaitQueue.wait(paramLong);
/*     */       }
/*     */     }
/*  99 */     if (false == this.allowBackup)
/* 100 */       throw new IllegalStateException("backup disabled");
/*     */   }
/*     */ 
/*     */   private boolean fullBackupNow() {
/* 104 */     synchronized (this.fullBackupWaitQueue) { return this.fullBackupNow; }
/*     */   }
/*     */ 
/*     */   private void fullBackupDone() {
/* 108 */     synchronized (this.fullBackupWaitQueue) {
/* 109 */       this.fullBackupNow = false;
/* 110 */       this.fullBackupWaitQueue.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void checkpoint(long paramLong) throws InterruptedException
/*     */   {
/* 116 */     synchronized (this.checkpointWaitQueue) {
/* 117 */       this.checkpointNow = true;
/* 118 */       wakeup();
/* 119 */       if (paramLong >= 0L)
/* 120 */         this.checkpointWaitQueue.wait(paramLong);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean checkpointNow() {
/* 125 */     synchronized (this.checkpointWaitQueue) { return this.checkpointNow; }
/*     */   }
/*     */ 
/*     */   private void checkpointDone() {
/* 129 */     synchronized (this.checkpointWaitQueue) {
/* 130 */       this.checkpointNow = false;
/* 131 */       this.checkpointWaitQueue.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   Checkpoint(Tables paramTables)
/*     */   {
/* 161 */     super("xdb.Checkpoint");
/*     */ 
/* 163 */     this.tables = paramTables;
/*     */ 
/* 165 */     long l = System.currentTimeMillis();
/* 166 */     XdbConf localXdbConf = Xdb.getInstance().getConf();
/*     */ 
/* 168 */     this.nextMarshalTime = (l + localXdbConf.getMarshalPeriod());
/* 169 */     this.nextCheckpointTime = (l + localXdbConf.getCheckpointPeriod());
/* 170 */     this.nextFullBackupTime = fixedRateFullTime(l, localXdbConf);
/* 171 */     this.nextIncBackupTime = fixedRateIncTime(l, localXdbConf);
/* 172 */     this.allowBackup = localXdbConf.isAllowBackup();
/* 173 */     this.allowCheckpointXXX = localXdbConf.isAllowCheckpointXXX();
/*     */ 
/* 175 */     Xdb.mbeans().register(this, "xdb:type=Xdb,name=Checkpoint");
/*     */   }
/*     */ 
/*     */   private final long fixedRateFullTime(long paramLong, XdbConf paramXdbConf) {
/* 179 */     int i = paramXdbConf.getBackupFullPeriod();
/* 180 */     return paramLong / i * i + i;
/*     */   }
/*     */ 
/*     */   private final long fixedRateIncTime(long paramLong, XdbConf paramXdbConf) {
/* 184 */     int i = paramXdbConf.getBackupFullPeriod();
/* 185 */     int j = paramXdbConf.getBackupIncPeriod();
/* 186 */     return paramLong / i * i + paramLong % i / j * j + j;
/*     */   }
/*     */ 
/*     */   private void checkpoint(long paramLong, XdbConf paramXdbConf) {
/*     */     try {
/* 191 */       if ((paramXdbConf.getMarshalPeriod() >= 0) && (this.nextMarshalTime <= paramLong) && (paramXdbConf.isAutoMarshal())) {
/* 192 */         this.nextMarshalTime = (paramLong + paramXdbConf.getMarshalPeriod());
/* 193 */         long l = System.nanoTime();
/* 194 */         int j = 0;
/* 195 */         for (Storage localStorage : this.tables.getStorages())
/* 196 */           j += localStorage.marshalN();
/* 197 */         this.marshalNCount += j;
/* 198 */         this.marshalNTotalTime += System.nanoTime() - l;
/* 199 */         Trace.info("marshalN=*/" + j);
/*     */       }
/*     */ 
/* 203 */       int i = paramXdbConf.getCheckpointPeriod();
/* 204 */       if ((i >= 0) && (false == backuping()) && ((checkpointNow()) || (this.nextCheckpointTime <= paramLong)))
/*     */       {
/* 206 */         this.nextCheckpointTime = (paramLong + i);
/* 207 */         checkpoint(paramXdbConf);
/*     */       }
/*     */     }
/*     */     catch (Throwable localThrowable) {
/* 211 */       Trace.fatal("halt program", localThrowable);
/* 212 */       Runtime.getRuntime().halt(54321);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkpoint(XdbConf paramXdbConf)
/*     */   {
/* 219 */     Trace.info("---------------- begin ----------------");
/* 220 */     List localList = this.tables.getStorages();
/*     */ 
/* 224 */     if (paramXdbConf.getMarshalN() < 1) {
/* 225 */       Trace.warn("marshalN disabled");
/*     */     }
/* 227 */     this.elapse.reset();
/*     */     Object localObject3;
/* 228 */     for (int i = 1; i <= paramXdbConf.getMarshalN(); i++) {
/* 229 */       j = 0;
/* 230 */       for (localObject2 = localList.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject3 = (Storage)((Iterator)localObject2).next();
/* 231 */         j += ((Storage)localObject3).marshalN(); }
/* 232 */       this.marshalNCount += j;
/* 233 */       Trace.info("marshalN=" + i + "/" + j);
/*     */     }
/* 235 */     this.marshalNTotalTime += this.elapse.elapsed();
/*     */ 
/* 240 */     i = 0;
/* 241 */     int j = 0;
/* 242 */     Object localObject2 = this.tables.flushWriteLock();
/* 243 */     ((Lock)localObject2).lock();
/* 244 */     this.elapse.reset();
/*     */     try {
/* 246 */       for (localObject3 = localList.iterator(); ((Iterator)localObject3).hasNext(); ) { localStorage = (Storage)((Iterator)localObject3).next();
/* 247 */         j += localStorage.marshal0(); }
/* 248 */       for (localObject3 = localList.iterator(); ((Iterator)localObject3).hasNext(); ) { localStorage = (Storage)((Iterator)localObject3).next();
/* 249 */         i += localStorage.snapshot();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Storage localStorage;
/* 251 */       ((Lock)localObject2).unlock();
/*     */     }
/*     */ 
/* 254 */     long l = this.elapse.elapsedAndReset();
/* 255 */     if (l / 100000L > paramXdbConf.getSnapshotFatalTime()) {
/* 256 */       Trace.fatal("snapshot time=" + l + " snapshot=" + i + " marshal0=" + j);
/*     */     }
/* 258 */     this.marshal0Count += j;
/* 259 */     this.snapshotTotalTime += l;
/* 260 */     this.snapshotCount += i;
/* 261 */     Trace.info("snapshot=" + i + " marshal0=" + j);
/*     */ 
/* 266 */     i = 0;
/* 267 */     for (Object localObject1 = localList.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Storage)((Iterator)localObject1).next();
/* 268 */       i += ((Storage)localObject2).flush(); }
/* 269 */     this.flushCount += i;
/* 270 */     this.flushTotalTime += this.elapse.elapsedAndReset();
/* 271 */     Trace.info("flush=" + i);
/*     */ 
/* 275 */     if ((i > 0) && (this.allowCheckpointXXX)) {
/* 276 */       localObject1 = this.tables.checkpointLock();
/* 277 */       ((Lock)localObject1).lock();
/*     */       try {
/* 279 */         this.tables.getLogger().checkpoint(localList, System.currentTimeMillis());
/*     */       } finally {
/* 281 */         ((Lock)localObject1).unlock();
/*     */       }
/* 283 */       this.checkpointTotalTime += this.elapse.elapsedAndReset();
/* 284 */       Trace.info("checkpoint");
/*     */     }
/* 286 */     this.checkpointCount += 1;
/* 287 */     checkpointDone();
/* 288 */     Trace.info("----------------- end -----------------");
/*     */   }
/*     */ 
/*     */   private boolean backuping() {
/* 292 */     if (null == this.backup)
/* 293 */       return false;
/* 294 */     if (this.backup.isAlive())
/* 295 */       return true;
/* 296 */     this.backup.joinAssuring();
/* 297 */     this.backup = null;
/* 298 */     return false;
/*     */   }
/*     */ 
/*     */   private final void backup(long paramLong, XdbConf paramXdbConf)
/*     */   {
/*     */     try {
/* 304 */       if ((fullBackupNow()) || (this.nextFullBackupTime <= paramLong)) {
/* 305 */         this.nextFullBackupTime = fixedRateFullTime(paramLong, paramXdbConf);
/*     */ 
/* 307 */         this.nextIncBackupTime = fixedRateIncTime(paramLong, paramXdbConf);
/* 308 */         this.backup = new Backup(true);
/* 309 */       } else if (this.nextIncBackupTime <= paramLong) {
/* 310 */         this.nextIncBackupTime = fixedRateIncTime(paramLong, paramXdbConf);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Throwable localThrowable)
/*     */     {
/* 319 */       Trace.error("backup", localThrowable);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 325 */     XdbConf localXdbConf = Xdb.getInstance().getConf();
/* 326 */     long l1 = System.currentTimeMillis() + localXdbConf.getBackupDelay();
/* 327 */     while (super.isRunning()) {
/* 328 */       long l2 = System.currentTimeMillis();
/* 329 */       checkpoint(l2, localXdbConf);
/*     */ 
/* 331 */       if ((this.allowBackup) && (l2 > l1) && (!backuping())) {
/* 332 */         backup(l2, localXdbConf);
/*     */       }
/* 334 */       super.sleepIdle(100L);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 341 */       if (backuping()) {
/* 342 */         Trace.fatal("wait backup done ...");
/* 343 */         this.backup.joinAssuring();
/* 344 */         this.backup = null;
/*     */       }
/*     */     } catch (Throwable localThrowable) {
/* 347 */       Trace.error("backup", localThrowable);
/*     */     }
/*     */ 
/* 351 */     Trace.fatal("final checkpoint begin");
/* 352 */     checkpoint(localXdbConf);
/* 353 */     Trace.fatal("final checkpoint end");
/*     */   }
/*     */ 
/*     */   public long getCountMarshalN()
/*     */   {
/* 360 */     return this.marshalNCount;
/*     */   }
/*     */ 
/*     */   public long getCountMarshal0()
/*     */   {
/* 365 */     return this.marshal0Count;
/*     */   }
/*     */ 
/*     */   public long getCountFlush()
/*     */   {
/* 370 */     return this.flushCount;
/*     */   }
/*     */ 
/*     */   public long getTotalTimeCheckpoint()
/*     */   {
/* 375 */     return this.checkpointTotalTime;
/*     */   }
/*     */ 
/*     */   public long getTotalTimeFlush()
/*     */   {
/* 380 */     return this.flushTotalTime;
/*     */   }
/*     */ 
/*     */   public long getTotalTimeSnapshot()
/*     */   {
/* 385 */     return this.snapshotTotalTime;
/*     */   }
/*     */ 
/*     */   public int getCountCheckpoint()
/*     */   {
/* 390 */     return this.checkpointCount;
/*     */   }
/*     */ 
/*     */   public long getTotalTimeMarshalN()
/*     */   {
/* 395 */     return this.marshalNTotalTime;
/*     */   }
/*     */ 
/*     */   public long getNextFlushTime() {
/* 399 */     return this.nextMarshalTime;
/*     */   }
/*     */ 
/*     */   public long getNextCheckpointTime() {
/* 403 */     return this.nextCheckpointTime;
/*     */   }
/*     */ 
/*     */   public long getNextFullBackupTime() {
/* 407 */     return this.nextFullBackupTime;
/*     */   }
/*     */ 
/*     */   public long getNextIncBackupTime() {
/* 411 */     return this.nextIncBackupTime;
/*     */   }
/*     */ 
/*     */   public String getTimeOfNextCheckpoint()
/*     */   {
/* 416 */     return Trace.dateFormat.format(Long.valueOf(getNextCheckpointTime()));
/*     */   }
/*     */ 
/*     */   public String getTimeOfNextFlush()
/*     */   {
/* 421 */     return Trace.dateFormat.format(Long.valueOf(getNextFlushTime()));
/*     */   }
/*     */ 
/*     */   public String getTimeOfNextFullBackup()
/*     */   {
/* 426 */     return Trace.dateFormat.format(Long.valueOf(getNextFullBackupTime()));
/*     */   }
/*     */ 
/*     */   public String getTimeOfNextIncBackup()
/*     */   {
/* 431 */     return Trace.dateFormat.format(Long.valueOf(getNextIncBackupTime()));
/*     */   }
/*     */ 
/*     */   public int getPeriodCheckpoint()
/*     */   {
/* 436 */     return Xdb.getInstance().getConf().getCheckpointPeriod();
/*     */   }
/*     */ 
/*     */   public void setPeriodCheckpoint(int paramInt)
/*     */   {
/* 441 */     Xdb.getInstance().getConf().setCheckpointPeriod(paramInt);
/*     */   }
/*     */ 
/*     */   public long getCountSnapshot()
/*     */   {
/* 446 */     return this.snapshotCount;
/*     */   }
/*     */ 
/*     */   private class Backup extends ThreadHelper
/*     */   {
/*     */     private boolean isFull;
/*     */ 
/*     */     Backup(boolean arg2)
/*     */     {
/* 139 */       super();
/*     */       boolean bool;
/* 140 */       this.isFull = bool;
/* 141 */       super.start();
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/* 148 */         if (this.isFull) {
/* 149 */           Checkpoint.this.tables.backupFull();
/* 150 */           Checkpoint.this.fullBackupDone();
/*     */         } else {
/* 152 */           Checkpoint.this.tables.backupInc();
/*     */         }
/*     */       } catch (Throwable localThrowable) {
/* 155 */         Trace.error("backup", localThrowable);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Checkpoint
 * JD-Core Version:    0.6.2
 */