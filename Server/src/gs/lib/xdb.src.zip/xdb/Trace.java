/*     */ package xdb;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ public enum Trace
/*     */ {
/*  20 */   DEBUG, INFO, WARN, ERROR, FATAL;
/*     */ 
/*  22 */   private static volatile Trace logger = INFO;
/*     */ 
/* 189 */   private static Lock loglock = new ReentrantLock();
/* 190 */   private static Log log = null;
/*     */ 
/* 238 */   public static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
/*     */ 
/*     */   public static final boolean isDebugEnabled()
/*     */   {
/*  24 */     return logger.ordinal() <= DEBUG.ordinal(); } 
/*  25 */   public static final boolean isInfoEnabled() { return logger.ordinal() <= INFO.ordinal(); } 
/*  26 */   public static final boolean isWarnEnabled() { return logger.ordinal() <= WARN.ordinal(); } 
/*  27 */   public static final boolean isErrorEnabled() { return logger.ordinal() <= ERROR.ordinal(); } 
/*  28 */   public static final boolean isFatalEnabled() { return logger.ordinal() <= FATAL.ordinal(); } 
/*     */   public static final void debug(Object paramObject) {
/*  30 */     logger.trace(DEBUG, null, paramObject); } 
/*  31 */   public static final void info(Object paramObject) { logger.trace(INFO, null, paramObject); } 
/*  32 */   public static final void warn(Object paramObject) { logger.trace(WARN, null, paramObject); } 
/*  33 */   public static final void error(Object paramObject) { logger.trace(ERROR, null, paramObject); } 
/*  34 */   public static final void fatal(Object paramObject) { logger.trace(FATAL, null, paramObject); } 
/*     */   public static final void debug(Object paramObject, Throwable paramThrowable) {
/*  36 */     logger.trace(DEBUG, paramThrowable, paramObject); } 
/*  37 */   public static final void info(Object paramObject, Throwable paramThrowable) { logger.trace(INFO, paramThrowable, paramObject); } 
/*  38 */   public static final void warn(Object paramObject, Throwable paramThrowable) { logger.trace(WARN, paramThrowable, paramObject); } 
/*  39 */   public static final void error(Object paramObject, Throwable paramThrowable) { logger.trace(ERROR, paramThrowable, paramObject); } 
/*  40 */   public static final void fatal(Object paramObject, Throwable paramThrowable) { logger.trace(FATAL, paramThrowable, paramObject); } 
/*     */   public static final void log(Trace paramTrace, Object paramObject) {
/*  42 */     logger.trace(paramTrace, null, paramObject); } 
/*  43 */   public static final void log(Trace paramTrace, Object paramObject, Throwable paramThrowable) { logger.trace(paramTrace, paramThrowable, paramObject); }
/*     */ 
/*     */   public static final void set(Trace paramTrace) {
/*  46 */     logger = paramTrace;
/*     */   }
/*     */ 
/*     */   public static final Trace get() {
/*  50 */     return logger;
/*     */   }
/*     */ 
/*     */   public static void open(XdbConf paramXdbConf)
/*     */   {
/* 164 */     openNew(paramXdbConf.getDbHome(), paramXdbConf.getTraceTo(), paramXdbConf.getTraceRotateHourOfDay(), paramXdbConf.getTraceRotateMinute());
/*     */   }
/*     */ 
/*     */   public static Log openNew()
/*     */   {
/* 172 */     return openNew(new File("."), ":file:out", -1, -1);
/*     */   }
/*     */ 
/*     */   public static Log openIf()
/*     */   {
/* 179 */     loglock.lock();
/*     */     try
/*     */     {
/*     */       Log localLog;
/* 181 */       if (null != log)
/* 182 */         return log;
/* 183 */       return openNew();
/*     */     } finally {
/* 185 */       loglock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void close()
/*     */   {
/* 193 */     loglock.lock();
/*     */     try {
/* 195 */       if (null != log)
/* 196 */         log.close();
/* 197 */       log = null;
/*     */     } finally {
/* 199 */       loglock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Log openNew(File paramFile, String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 212 */     File localFile = paramString.indexOf(":file") != -1 ? paramFile : null;
/* 213 */     boolean bool = paramString.indexOf(":out") != -1;
/* 214 */     loglock.lock();
/*     */     try {
/* 216 */       if (null != log)
/* 217 */         log.close();
/* 218 */       log = new Log(localFile, bool, paramInt1, paramInt2);
/* 219 */       return log;
/*     */     } finally {
/* 221 */       loglock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Log getLog()
/*     */   {
/* 230 */     loglock.lock();
/*     */     try {
/* 232 */       return log;
/*     */     } finally {
/* 234 */       loglock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final String traceName(Trace paramTrace)
/*     */   {
/* 241 */     String str = paramTrace.toString();
/* 242 */     return str.length() == 4 ? str + " " : str;
/*     */   }
/*     */ 
/*     */   private final void trace(Trace paramTrace, Throwable paramThrowable, Object paramObject) {
/* 246 */     Log localLog = getLog();
/* 247 */     if ((null != localLog) && (paramTrace.ordinal() >= ordinal())) {
/* 248 */       StringBuilder localStringBuilder = new StringBuilder();
/*     */ 
/* 250 */       localStringBuilder.append(dateFormat.format(Calendar.getInstance().getTime()));
/* 251 */       localStringBuilder.append(' ').append(traceName(paramTrace)).append(' ');
/* 252 */       localStringBuilder.append('<').append(Thread.currentThread().getName()).append('>');
/* 253 */       localStringBuilder.append(' ').append(paramObject);
/*     */ 
/* 255 */       localLog.println(localStringBuilder.toString(), paramThrowable);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Log extends TimerTask
/*     */   {
/*  55 */     private final Lock lock = new ReentrantLock();
/*     */     private final File home;
/*     */     private boolean console;
/*     */     private PrintStream ps;
/*     */ 
/*     */     public Log(File paramFile, boolean paramBoolean, int paramInt1, int paramInt2)
/*     */     {
/*  61 */       this.home = paramFile;
/*  62 */       this.console = paramBoolean;
/*     */       try {
/*  64 */         if (null != paramFile) {
/*  65 */           File localFile = new File(paramFile, "trace.log");
/*     */ 
/*  67 */           this.ps = new PrintStream(new FileOutputStream(localFile, true), false, "GBK");
/*     */         }
/*     */       } catch (Exception localException) {
/*  70 */         localException.printStackTrace();
/*  71 */         this.ps = null;
/*     */       }
/*     */ 
/*  74 */       if ((paramInt1 < 0) || (paramInt2 < 0) || (null == this.ps)) {
/*  75 */         return;
/*     */       }
/*  77 */       Calendar localCalendar = Calendar.getInstance();
/*  78 */       localCalendar.add(5, 1);
/*  79 */       localCalendar.set(11, paramInt1);
/*  80 */       localCalendar.set(12, paramInt2);
/*  81 */       localCalendar.set(13, 0);
/*  82 */       localCalendar.set(14, 0);
/*     */ 
/*  86 */       Xdb.timer().schedule(this, localCalendar.getTime(), 86400000L);
/*     */     }
/*     */ 
/*     */     public boolean rotate()
/*     */     {
/*  94 */       this.lock.lock();
/*     */       try {
/*  96 */         if (null == this.ps) {
/*  97 */           return false;
/*     */         }
/*  99 */         File localFile1 = new File(this.home, "trace." + new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss.SSS").format(Calendar.getInstance().getTime()) + ".log");
/*     */ 
/* 102 */         if (localFile1.exists()) {
/* 103 */           return false;
/*     */         }
/* 105 */         File localFile2 = new File(this.home, "trace.log");
/* 106 */         this.ps.close();
/* 107 */         boolean bool3 = localFile2.renameTo(localFile1);
/*     */ 
/* 109 */         this.ps = new PrintStream(new FileOutputStream(localFile2, !bool3), false, "GBK");
/* 110 */         return bool3;
/*     */       } catch (Exception localException) {
/* 112 */         localException.printStackTrace();
/* 113 */         this.ps = null;
/*     */       } finally {
/* 115 */         this.lock.unlock();
/*     */       }
/* 117 */       return false;
/*     */     }
/*     */ 
/*     */     public void println(String paramString, Throwable paramThrowable) {
/* 121 */       this.lock.lock();
/*     */       try {
/* 123 */         if (null != this.ps) {
/* 124 */           this.ps.println(paramString);
/* 125 */           if (null != paramThrowable)
/* 126 */             paramThrowable.printStackTrace(this.ps);
/*     */         }
/* 128 */         if (this.console) {
/* 129 */           System.out.println(paramString);
/* 130 */           if (null != paramThrowable)
/* 131 */             paramThrowable.printStackTrace(System.out);
/*     */         }
/*     */       } finally {
/* 134 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void close() {
/* 139 */       this.lock.lock();
/*     */       try {
/* 141 */         if (null != this.ps) {
/* 142 */           this.ps.close();
/* 143 */           this.ps = null;
/*     */         }
/* 145 */         this.console = false;
/* 146 */         cancel();
/*     */       } finally {
/* 148 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 154 */       rotate();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Trace
 * JD-Core Version:    0.6.2
 */