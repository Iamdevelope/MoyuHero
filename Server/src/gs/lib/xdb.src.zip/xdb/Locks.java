/*     */ package xdb;
/*     */ 
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import xdb.util.WeakHashSet;
/*     */ 
/*     */ public final class Locks
/*     */ {
/*     */   private static final int MAX_SEGMENTS = 65536;
/*     */   private final int segmentShift;
/*     */   private final int segmentMask;
/*     */   private Segment[] segments;
/*     */ 
/*     */   private final Segment segmentFor(Lockey paramLockey)
/*     */   {
/*  41 */     int i = paramLockey.hashCode();
/*  42 */     i += (i << 15 ^ 0xFFFFCD7D);
/*  43 */     i ^= i >>> 10;
/*  44 */     i += (i << 3);
/*  45 */     i ^= i >>> 6;
/*  46 */     i += (i << 2) + (i << 14);
/*  47 */     int j = i ^ i >>> 16;
/*     */ 
/*  49 */     int k = j >>> this.segmentShift & this.segmentMask;
/*  50 */     return this.segments[k];
/*     */   }
/*     */ 
/*     */   public Locks() {
/*  54 */     this(1024);
/*     */   }
/*     */ 
/*     */   public Locks(int paramInt) {
/*  58 */     if (paramInt <= 0) {
/*  59 */       throw new IllegalArgumentException();
/*     */     }
/*  61 */     if (paramInt > 65536) {
/*  62 */       paramInt = 65536;
/*     */     }
/*     */ 
/*  65 */     int i = 0;
/*  66 */     int j = 1;
/*  67 */     while (j < paramInt) {
/*  68 */       i++;
/*  69 */       j <<= 1;
/*     */     }
/*  71 */     this.segmentShift = (32 - i);
/*  72 */     this.segmentMask = (j - 1);
/*  73 */     this.segments = new Segment[j];
/*  74 */     for (int k = 0; k < this.segments.length; k++)
/*  75 */       this.segments[k] = new Segment();
/*     */   }
/*     */ 
/*     */   public boolean exist(Lockey paramLockey)
/*     */   {
/* 115 */     return segmentFor(paramLockey).exist(paramLockey);
/*     */   }
/*     */ 
/*     */   public Lockey get(Lockey paramLockey) {
/* 119 */     return segmentFor(paramLockey).get(paramLockey);
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 127 */     int i = 0;
/* 128 */     for (Segment localSegment : this.segments)
/* 129 */       i += localSegment.size();
/* 130 */     return i;
/*     */   }
/*     */ 
/*     */   static final class Segment
/*     */   {
/*     */     private final WeakHashSet<Lockey> locks;
/*  81 */     private final Lock sync = new ReentrantLock();
/*     */ 
/*     */     Segment() {
/*  84 */       this.locks = new WeakHashSet();
/*     */     }
/*     */ 
/*     */     boolean exist(Lockey paramLockey)
/*     */     {
/*  89 */       this.sync.lock();
/*     */       try {
/*  91 */         return this.locks.get(paramLockey) != null;
/*     */       } finally {
/*  93 */         this.sync.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     Lockey get(Lockey paramLockey) {
/*  98 */       this.sync.lock();
/*     */       try {
/* 100 */         Lockey localLockey1 = (Lockey)this.locks.add(paramLockey);
/* 101 */         if (paramLockey == localLockey1)
/* 102 */           paramLockey.alloc();
/* 103 */         return localLockey1;
/*     */       } finally {
/* 105 */         this.sync.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     int size() {
/* 110 */       return this.locks.size();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Locks
 * JD-Core Version:    0.6.2
 */