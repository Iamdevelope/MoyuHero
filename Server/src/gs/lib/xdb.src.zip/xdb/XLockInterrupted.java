/*    */ package xdb;
/*    */ 
/*    */ public class XLockInterrupted extends XError
/*    */ {
/*    */   static final long serialVersionUID = -7927226240291624476L;
/*    */ 
/*    */   public XLockInterrupted()
/*    */   {
/*    */   }
/*    */ 
/*    */   public XLockInterrupted(String paramString)
/*    */   {
/* 13 */     super(paramString);
/*    */   }
/*    */ 
/*    */   public XLockInterrupted(Throwable paramThrowable) {
/* 17 */     super(paramThrowable);
/*    */   }
/*    */ 
/*    */   public XLockInterrupted(String paramString, Throwable paramThrowable) {
/* 21 */     super(paramString, paramThrowable);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.XLockInterrupted
 * JD-Core Version:    0.6.2
 */