/*     */ package xdb;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import xdb.util.UniqNameConf;
/*     */ import xgen.Define;
/*     */ 
/*     */ public final class XdbConf
/*     */ {
/*     */   public static final String DATADIR = "dbdata";
/*     */   public static final String LOGSDIR = "dblogs";
/*     */   private String defaultTableCache;
/*     */   private int serialKey;
/*     */   private int logpages;
/*     */   private volatile File dbhome;
/*     */   private volatile File loghome;
/*     */   private volatile File tablehome;
/*     */   private volatile Trace trace;
/*     */   private String traceTo;
/*     */   private int traceRotateHourOfDay;
/*     */   private int traceRotateMinute;
/*     */   private boolean xdbVerify;
/*     */   private int corePoolSize;
/*     */   private int procPoolSize;
/*     */   private int schedPoolSize;
/*     */   private volatile int timeoutPeriod;
/*     */   private volatile long snapshotFatalTime;
/*     */   private volatile int marshalPeriod;
/*     */   private volatile int marshalN;
/*     */   private boolean allowCheckpointXXX;
/*     */   private volatile int checkpointPeriod;
/*     */   private int angelPeriod;
/*     */   private volatile File backupDir;
/*     */   private int backupFullPeriod;
/*     */   private int backupIncPeriod;
/*     */   private volatile int backupDelay;
/*     */   private volatile boolean allowBackup;
/*     */   private UniqNameConf uniqNameConf;
/*     */   private ProcedureConf procedureConf;
/* 148 */   private Map<String, TableConf> tableconf = new HashMap();
/*     */ 
/* 287 */   private volatile boolean autoMarshal = true;
/*     */ 
/* 359 */   private volatile File libdbPath = null;
/*     */ 
/*     */   public XdbConf(String paramString)
/*     */   {
/*     */     try
/*     */     {
/*  16 */       Document localDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(paramString);
/*  17 */       parse(localDocument.getDocumentElement());
/*     */     } catch (Exception localException) {
/*  19 */       throw new RuntimeException(localException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getString(Element paramElement, String paramString1, String paramString2) {
/*  24 */     String str = paramElement.getAttribute(paramString1);
/*  25 */     return str.isEmpty() ? paramString2 : str;
/*     */   }
/*     */ 
/*     */   public static int getInt(Element paramElement, String paramString, int paramInt) {
/*  29 */     String str = paramElement.getAttribute(paramString);
/*  30 */     return str.isEmpty() ? paramInt : Integer.parseInt(str);
/*     */   }
/*     */ 
/*     */   public static boolean getBoolean(Element paramElement, String paramString, boolean paramBoolean) {
/*  34 */     String str = paramElement.getAttribute(paramString);
/*  35 */     return str.isEmpty() ? paramBoolean : Boolean.parseBoolean(str);
/*     */   }
/*     */ 
/*     */   private static void deprecatedAttribute(Element paramElement, String paramString) {
/*  39 */     if (false == paramElement.getAttribute(paramString).isEmpty())
/*  40 */       System.out.println("Deprecated attribute \"" + paramString + "\" in node \"" + paramElement.getNodeName() + "\"");
/*     */   }
/*     */ 
/*     */   private void parse(Element paramElement) throws Exception
/*     */   {
/*  45 */     String str1 = paramElement.getAttribute("dbhome");
/*  46 */     this.dbhome = new File(str1);
/*  47 */     if ((str1.isEmpty()) || (!this.dbhome.isDirectory()) || (!this.dbhome.exists())) {
/*  48 */       throw new XError("dbhome : " + this.dbhome + " (!isDirectory || !exists())");
/*     */     }
/*  50 */     this.tablehome = new File(this.dbhome, "dbdata").getAbsoluteFile();
/*  51 */     this.loghome = new File(this.dbhome, "dblogs").getAbsoluteFile();
/*     */ 
/*  53 */     this.logpages = Integer.parseInt(paramElement.getAttribute("logpages"));
/*  54 */     this.trace = Trace.valueOf(paramElement.getAttribute("trace").toUpperCase());
/*  55 */     this.traceTo = paramElement.getAttribute("traceTo");
/*  56 */     this.traceRotateHourOfDay = getInt(paramElement, "traceRotateHourOfDay", 6);
/*  57 */     this.traceRotateMinute = getInt(paramElement, "traceRotateMinute", 30);
/*     */ 
/*  59 */     this.corePoolSize = Integer.parseInt(paramElement.getAttribute("corePoolSize"));
/*  60 */     this.procPoolSize = getInt(paramElement, "procPoolSize", this.corePoolSize);
/*  61 */     this.schedPoolSize = getInt(paramElement, "schedPoolSize", this.corePoolSize / 11 + 1);
/*  62 */     this.timeoutPeriod = getInt(paramElement, "timeoutPeriod", 2000);
/*     */ 
/*  64 */     String str2 = paramElement.getAttribute("backupDir");
/*  65 */     this.backupDir = new File(str2);
/*  66 */     if ((str2.isEmpty()) || (!this.backupDir.isDirectory()) || (!this.backupDir.exists()))
/*  67 */       throw new XError("backupDir : " + this.backupDir + " (!isDirectory || !exists())");
/*  68 */     this.backupFullPeriod = Integer.parseInt(paramElement.getAttribute("backupFullPeriod"));
/*  69 */     this.backupIncPeriod = Integer.parseInt(paramElement.getAttribute("backupIncPeriod"));
/*  70 */     this.backupDelay = getInt(paramElement, "backupDelay", 0);
/*  71 */     this.allowBackup = getBoolean(paramElement, "allowBackup", true);
/*     */ 
/*  73 */     deprecatedAttribute(paramElement, "flushFatalTime");
/*  74 */     deprecatedAttribute(paramElement, "flushPeriod");
/*  75 */     this.snapshotFatalTime = getInt(paramElement, "snapshotFatalTime", 2000);
/*  76 */     this.marshalPeriod = getInt(paramElement, "marshalPeriod", -1);
/*  77 */     this.marshalN = getInt(paramElement, "marshalN", 1);
/*  78 */     this.checkpointPeriod = Integer.parseInt(paramElement.getAttribute("checkpointPeriod"));
/*  79 */     this.allowCheckpointXXX = getBoolean(paramElement, "allowCheckpointXXX", true);
/*  80 */     this.angelPeriod = Integer.parseInt(paramElement.getAttribute("angelPeriod"));
/*  81 */     this.xdbVerify = getBoolean(paramElement, "xdbVerify", false);
/*     */ 
/*  83 */     this.serialKey = getInt(paramElement, "serialKey", 1024);
/*     */ 
/*  85 */     this.defaultTableCache = paramElement.getAttribute("defaultTableCache").trim();
/*     */ 
/*  87 */     NodeList localNodeList = paramElement.getChildNodes();
/*  88 */     for (int i = 0; i < localNodeList.getLength(); i++) {
/*  89 */       Node localNode = localNodeList.item(i);
/*  90 */       if (1 == localNode.getNodeType())
/*     */       {
/*  93 */         Element localElement = (Element)localNode;
/*  94 */         String str3 = localElement.getNodeName();
/*  95 */         if ((str3.equals("table")) || (str3.equals("TableSysConf"))) {
/*  96 */           TableConf localTableConf = new TableConf(localElement);
/*  97 */           this.tableconf.put(localTableConf.getName(), localTableConf);
/*  98 */         } else if (str3.equals("ProcedureConf")) {
/*  99 */           this.procedureConf = new ProcedureConf(localElement);
/* 100 */         } else if (str3.equals("UniqNameConf")) {
/* 101 */           this.uniqNameConf = new UniqNameConf(localElement);
/* 102 */         } else if (str3.equals("define")) {
/* 103 */           Define.getInstance().parse(localElement);
/*     */         }
/*     */       }
/*     */     }
/* 107 */     if (null == this.procedureConf)
/* 108 */       this.procedureConf = new ProcedureConf();
/*     */   }
/*     */ 
/*     */   public String getDefaultTableCache() {
/* 112 */     return this.defaultTableCache;
/*     */   }
/*     */ 
/*     */   public int getTimeoutPeriod()
/*     */   {
/* 151 */     return this.timeoutPeriod;
/*     */   }
/*     */ 
/*     */   public synchronized void setTimeoutPeriod(int paramInt)
/*     */   {
/* 159 */     this.timeoutPeriod = paramInt;
/*     */   }
/*     */ 
/*     */   public int getSerialKey() {
/* 163 */     return this.serialKey;
/*     */   }
/*     */ 
/*     */   public long getSnapshotFatalTime() {
/* 167 */     return this.snapshotFatalTime;
/*     */   }
/*     */ 
/*     */   public synchronized void setSnapshotFatalTime(long paramLong)
/*     */   {
/* 175 */     this.snapshotFatalTime = paramLong;
/*     */   }
/*     */ 
/*     */   public boolean isXdbVerify() {
/* 179 */     return this.xdbVerify;
/*     */   }
/*     */ 
/*     */   boolean isAllowCheckpointXXX() {
/* 183 */     return this.allowCheckpointXXX;
/*     */   }
/*     */ 
/*     */   public boolean isAllowBackup() {
/* 187 */     return this.allowBackup;
/*     */   }
/*     */ 
/*     */   public synchronized void setAllowBackup(boolean paramBoolean)
/*     */   {
/* 196 */     this.allowBackup = paramBoolean;
/*     */   }
/*     */ 
/*     */   public synchronized void setCheckpointPeriod(int paramInt)
/*     */   {
/* 205 */     if (paramInt < 0)
/* 206 */       throw new IllegalArgumentException();
/* 207 */     this.checkpointPeriod = paramInt;
/*     */   }
/*     */ 
/*     */   public int getTraceRotateHourOfDay() {
/* 211 */     return this.traceRotateHourOfDay;
/*     */   }
/*     */ 
/*     */   public int getTraceRotateMinute() {
/* 215 */     return this.traceRotateMinute;
/*     */   }
/*     */ 
/*     */   public int getSchedPoolSize() {
/* 219 */     return this.schedPoolSize;
/*     */   }
/*     */ 
/*     */   public UniqNameConf getUniqNameConf() {
/* 223 */     return this.uniqNameConf;
/*     */   }
/*     */ 
/*     */   public String getTraceTo() {
/* 227 */     return this.traceTo;
/*     */   }
/*     */ 
/*     */   public int getBackupIncPeriod() {
/* 231 */     return this.backupIncPeriod;
/*     */   }
/*     */ 
/*     */   public File getBackupDir() {
/* 235 */     return this.backupDir;
/*     */   }
/*     */ 
/*     */   public int getBackupDelay() {
/* 239 */     return this.backupDelay;
/*     */   }
/*     */ 
/*     */   public int getAngelPeriod() {
/* 243 */     return this.angelPeriod;
/*     */   }
/*     */ 
/*     */   public ProcedureConf getProcedureConf() {
/* 247 */     return this.procedureConf;
/*     */   }
/*     */ 
/*     */   public int getCorePoolSize() {
/* 251 */     return this.corePoolSize;
/*     */   }
/*     */ 
/*     */   public int getProcPoolSize() {
/* 255 */     return this.procPoolSize;
/*     */   }
/*     */ 
/*     */   public final int getMarshalN() {
/* 259 */     return this.marshalN;
/*     */   }
/*     */ 
/*     */   public synchronized void setMarshalN(int paramInt)
/*     */   {
/* 271 */     this.marshalN = paramInt;
/*     */   }
/*     */ 
/*     */   public int getMarshalPeriod() {
/* 275 */     return this.marshalPeriod;
/*     */   }
/*     */ 
/*     */   public synchronized void setMarshalPeriod(int paramInt)
/*     */   {
/* 284 */     this.marshalPeriod = paramInt;
/*     */   }
/*     */ 
/*     */   public boolean isAutoMarshal()
/*     */   {
/* 289 */     return this.autoMarshal;
/*     */   }
/*     */ 
/*     */   public synchronized void setAutoMarshal(boolean paramBoolean)
/*     */   {
/* 296 */     this.autoMarshal = paramBoolean;
/*     */   }
/*     */ 
/*     */   public int getCheckpointPeriod() {
/* 300 */     return this.checkpointPeriod;
/*     */   }
/*     */ 
/*     */   public int getBackupFullPeriod() {
/* 304 */     return this.backupFullPeriod;
/*     */   }
/*     */ 
/*     */   public Map<String, TableConf> getTableConfs() {
/* 308 */     return this.tableconf;
/*     */   }
/*     */ 
/*     */   public TableConf getTableConf(String paramString) {
/* 312 */     return (TableConf)this.tableconf.get(paramString);
/*     */   }
/*     */ 
/*     */   public File getDbHome() {
/* 316 */     return this.dbhome;
/*     */   }
/*     */ 
/*     */   public File getTableHome() {
/* 320 */     return this.tablehome;
/*     */   }
/*     */ 
/*     */   public File getLogHome() {
/* 324 */     return this.loghome;
/*     */   }
/*     */ 
/*     */   public int getLogPages() {
/* 328 */     return this.logpages;
/*     */   }
/*     */ 
/*     */   public Trace getTrace() {
/* 332 */     return this.trace;
/*     */   }
/*     */ 
/*     */   public synchronized void setDbhome(File paramFile)
/*     */   {
/* 339 */     if ((!paramFile.isDirectory()) || (!paramFile.exists()))
/* 340 */       throw new XError("dbhome : " + paramFile + " (!isDirectory || !exists())");
/* 341 */     this.dbhome = paramFile;
/* 342 */     this.tablehome = new File(paramFile, "dbdata").getAbsoluteFile();
/* 343 */     this.loghome = new File(paramFile, "dblogs").getAbsoluteFile();
/* 344 */     if ((!this.tablehome.isDirectory()) || (!this.tablehome.exists()))
/* 345 */       throw new XError("tablehome : " + this.tablehome + " (!isDirectory || !exists())");
/* 346 */     if ((!this.loghome.isDirectory()) || (!this.loghome.exists()))
/* 347 */       throw new XError("loghome : " + this.loghome + " (!isDirectory || !exists())");
/*     */   }
/*     */ 
/*     */   public synchronized void setBackupDir(File paramFile)
/*     */   {
/* 354 */     if ((!paramFile.isDirectory()) || (!paramFile.exists()))
/* 355 */       throw new XError("backupDir : " + paramFile + " (!isDirectory || !exists())");
/* 356 */     this.backupDir = paramFile;
/*     */   }
/*     */ 
/*     */   public File getLibdbPath()
/*     */   {
/* 362 */     return this.libdbPath;
/*     */   }
/*     */ 
/*     */   public synchronized void setLibdbPath(File paramFile)
/*     */   {
/* 369 */     if ((!paramFile.isDirectory()) || (!paramFile.exists()))
/* 370 */       throw new XError("libpath : " + paramFile + " (!isDirectory || !exists())");
/* 371 */     this.libdbPath = paramFile;
/*     */   }
/*     */ 
/*     */   public synchronized void setBackupDelay(int paramInt)
/*     */   {
/* 381 */     this.backupDelay = paramInt;
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.XdbConf
 * JD-Core Version:    0.6.2
 */