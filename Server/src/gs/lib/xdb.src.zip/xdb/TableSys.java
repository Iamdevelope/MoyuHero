/*     */ package xdb;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import xdb.util.AutoKeys;
/*     */ import xdb.util.UniqNameConf;
/*     */ 
/*     */ public final class TableSys extends Table
/*     */ {
/*     */   private StorageSys storage;
/*     */   private AutoKeys autoKeys;
/*     */ 
/*     */   public AutoKeys getAutoKeys()
/*     */   {
/*  11 */     return this.autoKeys;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  17 */     return "_sys_";
/*     */   }
/*     */ 
/*     */   public Table.Persistence getPersistence()
/*     */   {
/*  22 */     return Table.Persistence.DB;
/*     */   }
/*     */ 
/*     */   Storage open(XdbConf paramXdbConf, Logger paramLogger)
/*     */   {
/*  27 */     if (null != this.storage) {
/*  28 */       throw new XError("TableSys has opened : " + getName());
/*     */     }
/*  30 */     TableConf localTableConf = paramXdbConf.getTableConf(getName());
/*  31 */     if (null == localTableConf) {
/*  32 */       localTableConf = new TableConf(getName(), 1, 1);
/*     */     }
/*  34 */     this.storage = new StorageSys(paramLogger, paramXdbConf, localTableConf);
/*     */ 
/*  37 */     this.autoKeys = this.storage.loadAutoKeys(paramXdbConf, localTableConf);
/*     */ 
/*  41 */     return this.storage;
/*     */   }
/*     */ 
/*     */   void close()
/*     */   {
/*  46 */     if (null != this.storage) {
/*  47 */       this.storage.close();
/*  48 */       this.storage = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class StorageSys extends Storage
/*     */   {
/*  87 */     private OctetsStream keyOfAutoKeys = null;
/*     */ 
/*  95 */     private OctetsStream snapshotValue = null;
/*     */ 
/*     */     StorageSys(Logger paramXdbConf, XdbConf paramTableConf, TableConf arg4)
/*     */     {
/*  54 */       super(paramTableConf, localTableConf);
/*     */     }
/*     */ 
/*     */     AutoKeys loadAutoKeys(XdbConf paramXdbConf, TableConf paramTableConf) {
/*  58 */       UniqNameConf localUniqNameConf = Xdb.getInstance().getConf().getUniqNameConf();
/*  59 */       if (localUniqNameConf == null) {
/*  60 */         return null;
/*     */       }
/*  62 */       int i = localUniqNameConf.getLocalId();
/*  63 */       if (i < 0) {
/*  64 */         return null;
/*     */       }
/*  66 */       this.keyOfAutoKeys = new OctetsStream().marshal("xdb.util.AutoKeys." + String.valueOf(i), "UTF-16LE");
/*  67 */       OctetsStream localOctetsStream1 = super.find(this.keyOfAutoKeys);
/*     */ 
/*  71 */       OctetsStream localOctetsStream2 = new OctetsStream().marshal("xdb.util.AutoKeys", "UTF-16LE");
/*  72 */       OctetsStream localOctetsStream3 = super.find(localOctetsStream2);
/*  73 */       if (null != localOctetsStream3) {
/*  74 */         if (null != localOctetsStream1) {
/*  75 */           throw new XError("autoKeys corrupt: new? old?");
/*     */         }
/*  77 */         super.replaceUnsafe(this.keyOfAutoKeys, localOctetsStream3);
/*  78 */         super.removeUnsafe(localOctetsStream2);
/*     */ 
/*  81 */         return new AutoKeys(localOctetsStream3, i, true);
/*     */       }
/*     */ 
/*  84 */       return new AutoKeys(localOctetsStream1, i, false);
/*     */     }
/*     */ 
/*     */     int marshalN()
/*     */     {
/*  99 */       if ((null != TableSys.this.autoKeys) && (TableSys.this.autoKeys.isDirty())) {
/* 100 */         this.snapshotValue = TableSys.this.autoKeys.encodeValue(-1922908697795782568L);
/* 101 */         return 1;
/*     */       }
/* 103 */       return 0;
/*     */     }
/*     */ 
/*     */     int marshal0()
/*     */     {
/* 108 */       return 0;
/*     */     }
/*     */ 
/*     */     int snapshot()
/*     */     {
/* 113 */       return null != this.snapshotValue ? 1 : 0;
/*     */     }
/*     */ 
/*     */     int flush()
/*     */     {
/* 118 */       if (null != this.snapshotValue) {
/* 119 */         super.replaceUnsafe(this.keyOfAutoKeys, this.snapshotValue);
/* 120 */         this.snapshotValue = null;
/* 121 */         return 1;
/*     */       }
/* 123 */       return 0;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.TableSys
 * JD-Core Version:    0.6.2
 */