/*     */ package xdb;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Delayed;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import xdb.util.MBeans.Manager;
/*     */ import xdb.util.ScheduledTimeoutExecutor;
/*     */ import xdb.util.TimeoutExecutor;
/*     */ import xdb.util.TimeoutManager;
/*     */ 
/*     */ public final class Executor extends TimeoutExecutor
/*     */   implements ScheduledExecutorService, ExecutorMBean
/*     */ {
/*     */   private final ScheduledTimeoutExecutor scheduled;
/*     */   private final TimeoutExecutor procedure;
/*  29 */   private MBeans.Manager mbeans = new MBeans.Manager();
/*     */ 
/*  31 */   private static Object lock = new Object();
/*     */   private static Executor instance;
/* 195 */   private boolean shutdown_protected = true;
/*     */ 
/*     */   public static void start(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*     */   {
/*  38 */     synchronized (lock) {
/*  39 */       if (null == instance)
/*  40 */         instance = new Executor(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void stop()
/*     */   {
/*  52 */     synchronized (lock) {
/*  53 */       if (null != instance) {
/*  54 */         instance.shutdown_protected = false;
/*  55 */         instance.shutdown();
/*  56 */         instance = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Executor getInstance() {
/*  62 */     return instance;
/*     */   }
/*     */ 
/*     */   private Executor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*     */   {
/*  70 */     super(paramInt1, paramInt2, Worker.newFactory(""));
/*     */ 
/*  72 */     this.procedure = new TimeoutExecutor(paramInt1, paramInt3, Worker.newFactory("procedure"));
/*     */ 
/*  75 */     this.scheduled = new ScheduledTimeoutExecutor(paramInt1, paramInt4, Worker.newFactory("scheduled"));
/*     */ 
/*  79 */     this.scheduled.scheduleWithFixedDelay(TimeoutManager.getInstance(), paramInt5, paramInt5, TimeUnit.MILLISECONDS);
/*     */ 
/*  83 */     this.mbeans.register(this, "xdb:type=Xdb,name=Executor");
/*     */   }
/*     */ 
/*     */   public ScheduledTimeoutExecutor getScheduledTimeoutExecutor()
/*     */   {
/*  93 */     return this.scheduled;
/*     */   }
/*     */ 
/*     */   public TimeoutExecutor getProcedureTimeoutExecutor()
/*     */   {
/* 103 */     return this.procedure;
/*     */   }
/*     */ 
/*     */   public void setCorePoolSize(int paramInt1, int paramInt2, int paramInt3)
/*     */   {
/* 114 */     super.setCorePoolSize(paramInt1);
/* 115 */     this.procedure.setCorePoolSize(paramInt2);
/* 116 */     this.scheduled.setCorePoolSize(paramInt3);
/*     */   }
/*     */ 
/*     */   public boolean remove(Runnable paramRunnable)
/*     */   {
/* 162 */     if ((paramRunnable instanceof ScheduledFuture))
/* 163 */       return super.remove(paramRunnable);
/* 164 */     return this.scheduled.remove(paramRunnable);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> schedule(Runnable paramRunnable, long paramLong, TimeUnit paramTimeUnit)
/*     */   {
/* 170 */     if (paramLong <= 0L)
/* 171 */       return new ScheduledFutureWrapper(super.submit(paramRunnable));
/* 172 */     return this.scheduled.schedule(paramRunnable, paramLong, paramTimeUnit);
/*     */   }
/*     */ 
/*     */   public <V> ScheduledFuture<V> schedule(Callable<V> paramCallable, long paramLong, TimeUnit paramTimeUnit)
/*     */   {
/* 177 */     if (paramLong <= 0L)
/* 178 */       return new ScheduledFutureWrapper(super.submit(paramCallable));
/* 179 */     return this.scheduled.schedule(paramCallable, paramLong, paramTimeUnit);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable paramRunnable, long paramLong1, long paramLong2, TimeUnit paramTimeUnit)
/*     */   {
/* 184 */     return this.scheduled.scheduleAtFixedRate(paramRunnable, paramLong1, paramLong2, paramTimeUnit);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable paramRunnable, long paramLong1, long paramLong2, TimeUnit paramTimeUnit)
/*     */   {
/* 189 */     return this.scheduled.scheduleWithFixedDelay(paramRunnable, paramLong1, paramLong2, paramTimeUnit);
/*     */   }
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 200 */     if (this.shutdown_protected) {
/* 201 */       throw new IllegalStateException("shutdown protected");
/*     */     }
/*     */ 
/* 204 */     super.shutdownNow();
/* 205 */     this.scheduled.shutdownNow();
/* 206 */     this.procedure.shutdownNow();
/*     */ 
/* 208 */     TimeoutManager.getInstance().clear();
/* 209 */     await(this, "");
/* 210 */     await(this.scheduled, "scheduled");
/* 211 */     await(this.procedure, "procedure");
/*     */ 
/* 213 */     this.mbeans.unregisterAll();
/*     */   }
/*     */ 
/*     */   public List<Runnable> shutdownNow()
/*     */   {
/* 219 */     if (this.shutdown_protected) {
/* 220 */       throw new IllegalStateException("shutdown protected");
/*     */     }
/* 222 */     List localList = super.shutdownNow();
/* 223 */     localList.addAll(this.scheduled.shutdownNow());
/* 224 */     localList.addAll(this.procedure.shutdownNow());
/*     */ 
/* 226 */     TimeoutManager.getInstance().clear();
/* 227 */     await(this, "");
/* 228 */     await(this.scheduled, "scheduled");
/* 229 */     await(this.procedure, "procedure");
/*     */ 
/* 231 */     this.mbeans.unregisterAll();
/*     */ 
/* 233 */     return localList;
/*     */   }
/*     */ 
/*     */   private void await(ThreadPoolExecutor paramThreadPoolExecutor, String paramString) {
/*     */     while (true)
/*     */       try {
/* 239 */         if (paramThreadPoolExecutor.awaitTermination(5L, TimeUnit.SECONDS))
/* 240 */           return;
/* 241 */         Trace.warn("Executor." + paramString + ".shutdown timeout. queue.size=" + paramThreadPoolExecutor.getQueue().size());
/*     */       } catch (InterruptedException localInterruptedException) {
/* 243 */         Trace.warn("Executor." + paramString + ".shutdown inprocess. skip InterruptedException");
/*     */       }
/*     */   }
/*     */ 
/*     */   public int getExecutorActiveCount()
/*     */   {
/* 251 */     return super.getActiveCount();
/*     */   }
/*     */ 
/*     */   public long getExecutorCompletedTaskCount()
/*     */   {
/* 256 */     return super.getCompletedTaskCount();
/*     */   }
/*     */ 
/*     */   public int getExecutorPoolSize()
/*     */   {
/* 261 */     return super.getPoolSize();
/*     */   }
/*     */ 
/*     */   public String getExecutorState()
/*     */   {
/* 266 */     if (super.isShutdown())
/* 267 */       return super.isTerminated() ? "TERMINATED" : "TERMINATING";
/* 268 */     return "RUNNING";
/*     */   }
/*     */ 
/*     */   public long getExecutorTaskCount()
/*     */   {
/* 273 */     return super.getTaskCount();
/*     */   }
/*     */ 
/*     */   public int getProcedureActiveCount()
/*     */   {
/* 279 */     return this.procedure.getActiveCount();
/*     */   }
/*     */ 
/*     */   public long getProcedureCompletedTaskCount()
/*     */   {
/* 284 */     return this.procedure.getCompletedTaskCount();
/*     */   }
/*     */ 
/*     */   public int getProcedurePoolSize()
/*     */   {
/* 289 */     return this.procedure.getPoolSize();
/*     */   }
/*     */ 
/*     */   public String getProcedureState()
/*     */   {
/* 294 */     if (this.procedure.isShutdown())
/* 295 */       return this.procedure.isTerminated() ? "TERMINATED" : "TERMINATING";
/* 296 */     return "RUNNING";
/*     */   }
/*     */ 
/*     */   public long getProcedureTaskCount()
/*     */   {
/* 301 */     return this.procedure.getTaskCount();
/*     */   }
/*     */ 
/*     */   public int getScheduledActiveCount()
/*     */   {
/* 307 */     return this.scheduled.getActiveCount();
/*     */   }
/*     */ 
/*     */   public long getScheduledCompletedTaskCount()
/*     */   {
/* 312 */     return this.scheduled.getCompletedTaskCount();
/*     */   }
/*     */ 
/*     */   public int getScheduledPoolSize()
/*     */   {
/* 317 */     return this.scheduled.getPoolSize();
/*     */   }
/*     */ 
/*     */   public String getScheduledState()
/*     */   {
/* 322 */     if (this.scheduled.isShutdown())
/* 323 */       return this.scheduled.isTerminated() ? "TERMINATED" : "TERMINATING";
/* 324 */     return "RUNNING";
/*     */   }
/*     */ 
/*     */   public long getScheduledTaskCount()
/*     */   {
/* 329 */     return this.scheduled.getTaskCount();
/*     */   }
/*     */ 
/*     */   public void purgeExecutor(String paramString)
/*     */   {
/* 335 */     if (paramString.equals("iamsure"))
/* 336 */       super.purge();
/*     */   }
/*     */ 
/*     */   public void purgeScheduled(String paramString)
/*     */   {
/* 341 */     if (paramString.equals("iamsure"))
/* 342 */       this.scheduled.purge();
/*     */   }
/*     */ 
/*     */   public void purgeProcedure(String paramString)
/*     */   {
/* 347 */     if (paramString.equals("iamsure"))
/* 348 */       this.procedure.purge();
/*     */   }
/*     */ 
/*     */   public void setExecutorCorePoolSize(int paramInt)
/*     */   {
/* 354 */     super.setCorePoolSize(paramInt);
/*     */   }
/*     */ 
/*     */   public void setScheduledCorePoolSize(int paramInt)
/*     */   {
/* 359 */     this.scheduled.setCorePoolSize(paramInt);
/*     */   }
/*     */ 
/*     */   public int getProcedureCorePoolSize()
/*     */   {
/* 364 */     return this.procedure.getCorePoolSize();
/*     */   }
/*     */ 
/*     */   public void setProcedureCorePoolSize(int paramInt)
/*     */   {
/* 369 */     this.procedure.setCorePoolSize(paramInt);
/*     */   }
/*     */ 
/*     */   public int getExecutorCorePoolSize()
/*     */   {
/* 374 */     return super.getCorePoolSize();
/*     */   }
/*     */ 
/*     */   public int getScheduledCorePoolSize()
/*     */   {
/* 379 */     return this.scheduled.getCorePoolSize();
/*     */   }
/*     */ 
/*     */   public void testAlive(long paramLong)
/*     */     throws InterruptedException, ExecutionException, TimeoutException
/*     */   {
/* 385 */     if (paramLong < 500L) {
/* 386 */       paramLong = 500L;
/*     */     }
/* 388 */     Runnable local1 = new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/*     */       }
/*     */     };
/* 391 */     super.submit(local1).get(paramLong, TimeUnit.MILLISECONDS);
/* 392 */     this.scheduled.submit(local1).get(paramLong, TimeUnit.MILLISECONDS);
/* 393 */     this.procedure.submit(local1).get(paramLong, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   public long getExecutorDefaultTimeout()
/*     */   {
/* 398 */     return super.getDefaultTimeout();
/*     */   }
/*     */ 
/*     */   public long getScheduledDefaultTimeout()
/*     */   {
/* 403 */     return this.scheduled.getDefaultTimeout();
/*     */   }
/*     */ 
/*     */   public void setExecutorDefaultTimeout(long paramLong)
/*     */   {
/* 408 */     super.setDefaultTimeout(paramLong);
/*     */   }
/*     */ 
/*     */   public void setScheduledDefaultTimeout(long paramLong)
/*     */   {
/* 413 */     this.scheduled.setDefaultTimeout(paramLong);
/*     */   }
/*     */ 
/*     */   public long getProcedureDefaultTimeout()
/*     */   {
/* 418 */     return this.procedure.getDefaultTimeout();
/*     */   }
/*     */ 
/*     */   public void setProcedureDefaultTimeout(long paramLong)
/*     */   {
/* 423 */     this.procedure.setDefaultTimeout(paramLong);
/*     */   }
/*     */ 
/*     */   private static class ScheduledFutureWrapper<V>
/*     */     implements ScheduledFuture<V>
/*     */   {
/*     */     private final Future<V> future;
/*     */ 
/*     */     ScheduledFutureWrapper(Future<V> paramFuture)
/*     */     {
/* 125 */       this.future = paramFuture;
/*     */     }
/*     */ 
/*     */     public long getDelay(TimeUnit paramTimeUnit)
/*     */     {
/* 130 */       return 0L;
/*     */     }
/*     */ 
/*     */     public int compareTo(Delayed paramDelayed) {
/* 134 */       long l = paramDelayed.getDelay(TimeUnit.NANOSECONDS);
/* 135 */       return l > 0L ? -1 : l == 0L ? 0 : 1;
/*     */     }
/*     */ 
/*     */     public boolean cancel(boolean paramBoolean) {
/* 139 */       return this.future.cancel(paramBoolean);
/*     */     }
/*     */ 
/*     */     public V get() throws InterruptedException, ExecutionException {
/* 143 */       return this.future.get();
/*     */     }
/*     */ 
/*     */     public V get(long paramLong, TimeUnit paramTimeUnit) throws InterruptedException, ExecutionException, TimeoutException {
/* 147 */       return this.future.get(paramLong, paramTimeUnit);
/*     */     }
/*     */ 
/*     */     public boolean isCancelled() {
/* 151 */       return this.future.isCancelled();
/*     */     }
/*     */ 
/*     */     public boolean isDone() {
/* 155 */       return this.future.isDone();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Executor
 * JD-Core Version:    0.6.2
 */