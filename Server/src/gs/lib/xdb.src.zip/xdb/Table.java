/*    */ package xdb;
/*    */ 
/*    */ public abstract class Table extends XBean
/*    */ {
/*    */   Table()
/*    */   {
/* 18 */     super(null, null);
/*    */   }
/*    */ 
/*    */   abstract Storage open(XdbConf paramXdbConf, Logger paramLogger);
/*    */ 
/*    */   abstract void close();
/*    */ 
/*    */   public abstract String getName();
/*    */ 
/*    */   public abstract Persistence getPersistence();
/*    */ 
/*    */   protected void initialize(Tables paramTables)
/*    */   {
/*    */   }
/*    */ 
/*    */   void logNotify()
/*    */   {
/*    */   }
/*    */ 
/*    */   public static enum Persistence
/*    */   {
/* 14 */     MEMORY, DB;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Table
 * JD-Core Version:    0.6.2
 */