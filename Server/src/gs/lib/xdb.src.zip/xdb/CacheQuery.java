package xdb;

public abstract interface CacheQuery<K, V>
{
  public abstract void onQuery(K paramK, V paramV);
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.CacheQuery
 * JD-Core Version:    0.6.2
 */