/*     */ package xdb;
/*     */ 
/*     */ import xdb.logs.AddRemoveInfo;
/*     */ import xdb.logs.LogNotify;
/*     */ 
/*     */ public abstract class TTableCache<K, V>
/*     */ {
/*     */   private volatile TTable<K, V> table;
/*     */   private volatile CacheRemovedHandle<K, V> removedhandle;
/*     */   private volatile int capacity;
/*     */ 
/*     */   void initialize(TTable<K, V> paramTTable, TableConf paramTableConf)
/*     */   {
/*  33 */     this.table = paramTTable;
/*  34 */     this.capacity = paramTableConf.getCacheCapacity();
/*     */   }
/*     */ 
/*     */   static <K, V> TTableCache<K, V> newInstance(TTable<K, V> paramTTable, TableConf paramTableConf)
/*     */   {
/*  45 */     String str = paramTableConf.getOtherAttr("cacheClass").trim();
/*  46 */     if (str.isEmpty()) {
/*  47 */       str = Xdb.getInstance().getConf().getDefaultTableCache();
/*  48 */       if (str.isEmpty())
/*     */       {
/*  50 */         str = "xdb.TTableCacheLRU";
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/*  55 */       TTableCache localTTableCache = (TTableCache)Class.forName(str).newInstance();
/*  56 */       localTTableCache.initialize(paramTTable, paramTableConf);
/*  57 */       return localTTableCache;
/*     */     } catch (Throwable localThrowable) {
/*  59 */       throw new XError(localThrowable);
/*     */     }
/*     */   }
/*     */ 
/*     */   public abstract void clear();
/*     */ 
/*     */   public abstract void walk(CacheQuery<K, V> paramCacheQuery);
/*     */ 
/*     */   abstract int getSize();
/*     */ 
/*     */   public final TTable<K, V> getTable()
/*     */   {
/*  85 */     return this.table;
/*     */   }
/*     */ 
/*     */   public final int getCapacity()
/*     */   {
/*  92 */     return this.capacity;
/*     */   }
/*     */ 
/*     */   public synchronized void setCapacity(int paramInt)
/*     */   {
/* 100 */     this.capacity = paramInt;
/*     */   }
/*     */ 
/*     */   public synchronized void setRemovedhandle(CacheRemovedHandle<K, V> paramCacheRemovedHandle)
/*     */   {
/* 112 */     this.removedhandle = paramCacheRemovedHandle;
/*     */   }
/*     */ 
/*     */   public final CacheRemovedHandle<K, V> getRemovedhandle()
/*     */   {
/* 120 */     return this.removedhandle;
/*     */   }
/*     */ 
/*     */   abstract TRecord<K, V> get(K paramK);
/*     */ 
/*     */   abstract void addNoLog(K paramK, TRecord<K, V> paramTRecord);
/*     */ 
/*     */   abstract void add(K paramK, TRecord<K, V> paramTRecord);
/*     */ 
/*     */   abstract TRecord<K, V> remove(K paramK);
/*     */ 
/*     */   final void _walk_notify_query(Object[] paramArrayOfObject, CacheQuery<K, V> paramCacheQuery)
/*     */   {
/* 135 */     for (Object localObject1 : paramArrayOfObject)
/*     */     {
/* 137 */       TRecord localTRecord = (TRecord)localObject1;
/* 138 */       Lockey localLockey = localTRecord.getLockey();
/* 139 */       localLockey.lock();
/*     */       try {
/* 141 */         Object localObject2 = localTRecord.getValue();
/* 142 */         if (null != localObject2)
/* 143 */           paramCacheQuery.onQuery(Consts.toConst(localTRecord.getKey()), Consts.toConst(localObject2));
/*     */       } finally {
/* 145 */         localLockey.unlock();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   final void logAddRemove(K paramK, TRecord<K, V> paramTRecord)
/*     */   {
/* 157 */     Transaction.currentSavepoint().add(paramTRecord.getLogKey(), new LogAddRemove(paramK, paramTRecord));
/*     */   }
/*     */ 
/*     */   final boolean tryRemoveRecord(TRecord<K, V> paramTRecord)
/*     */   {
/* 196 */     Lockey localLockey = paramTRecord.getLockey();
/* 197 */     Object localObject1 = paramTRecord.getKey();
/* 198 */     if (false == localLockey.tryLock()) {
/* 199 */       Trace.debug("cleaner IS IT RARE? " + paramTRecord + " size=" + getSize());
/*     */ 
/* 202 */       return false;
/*     */     }
/*     */     try {
/* 205 */       TStorage localTStorage = paramTRecord.getTable().getStorage();
/*     */       boolean bool;
/* 206 */       if (null == localTStorage)
/*     */       {
/* 208 */         remove(localObject1);
/*     */ 
/* 210 */         notifyRemovedhandle(paramTRecord);
/* 211 */         return true;
/*     */       }
/*     */ 
/* 214 */       if (localTStorage.isChangedOrUnknown(localObject1))
/*     */       {
/* 218 */         return false;
/*     */       }
/*     */ 
/* 222 */       remove(localObject1);
/* 223 */       return true;
/*     */     } finally {
/* 225 */       localLockey.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   final void notifyRemovedhandle(TRecord<K, V> paramTRecord) {
/* 230 */     CacheRemovedHandle localCacheRemovedHandle = getRemovedhandle();
/* 231 */     if (null != localCacheRemovedHandle)
/* 232 */       Xdb.executor().execute(new Removed(paramTRecord, localCacheRemovedHandle)); 
/*     */   }
/*     */   private static class Removed<K, V> implements Runnable {
/*     */     K key;
/*     */     V value;
/*     */     CacheRemovedHandle<K, V> handle;
/*     */ 
/* 241 */     Removed(TRecord<K, V> paramTRecord, CacheRemovedHandle<K, V> paramCacheRemovedHandle) { this.key = paramTRecord.getKey();
/* 242 */       this.value = paramTRecord.getValue();
/* 243 */       this.handle = paramCacheRemovedHandle;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 248 */       this.handle.recordRemoved(this.key, this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class LogAddRemove
/*     */     implements Log
/*     */   {
/*     */     private K key;
/*     */     private TRecord.State saved_state;
/*     */     private TRecord<K, V> record;
/*     */ 
/*     */     LogAddRemove(TRecord<K, V> arg2)
/*     */     {
/*     */       Object localObject1;
/* 166 */       this.key = localObject1;
/*     */       Object localObject2;
/* 167 */       this.record = localObject2;
/* 168 */       this.saved_state = localObject2.getState();
/*     */     }
/*     */ 
/*     */     public void commit()
/*     */     {
/* 174 */       if (!this.record.commit())
/* 175 */         TTableCache.this.remove(this.key);
/* 176 */       this.record.getTable().onRecordChanged(this.record, new LogNotify(new AddRemoveInfo(true, this.saved_state)));
/*     */     }
/*     */ 
/*     */     public void rollback()
/*     */     {
/* 181 */       if (this.record.rollback())
/* 182 */         TTableCache.this.remove(this.key);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.TTableCache
 * JD-Core Version:    0.6.2
 */