/*    */ package xdb;
/*    */ 
/*    */ public class LogKey
/*    */   implements Comparable<LogKey>
/*    */ {
/*    */   private final XBean xbean;
/*    */   private final String varname;
/*    */ 
/*    */   public LogKey(XBean paramXBean, String paramString)
/*    */   {
/*  8 */     this.xbean = paramXBean;
/*  9 */     this.varname = paramString;
/*    */   }
/*    */ 
/*    */   protected Log create() {
/* 13 */     return null;
/*    */   }
/*    */ 
/*    */   public final XBean getXBean() {
/* 17 */     return this.xbean;
/*    */   }
/*    */ 
/*    */   public final String getVarname() {
/* 21 */     return this.varname;
/*    */   }
/*    */ 
/*    */   public final int hashCode()
/*    */   {
/* 26 */     return this.xbean.xdbObjId().hashCode() ^ this.varname.hashCode();
/*    */   }
/*    */ 
/*    */   public final boolean equals(Object paramObject)
/*    */   {
/* 31 */     if ((paramObject instanceof LogKey)) {
/* 32 */       LogKey localLogKey = (LogKey)paramObject;
/* 33 */       return (this.xbean.xdbObjId().equals(localLogKey.xbean.xdbObjId())) && (this.varname.equals(localLogKey.varname));
/*    */     }
/* 35 */     return false;
/*    */   }
/*    */ 
/*    */   public int compareTo(LogKey paramLogKey)
/*    */   {
/* 40 */     long l = this.xbean.xdbObjId().longValue() - paramLogKey.xbean.xdbObjId().longValue();
/* 41 */     if (l > 0L) return 1;
/* 42 */     if (l < 0L) return -1;
/* 43 */     return this.varname.compareTo(paramLogKey.varname);
/*    */   }
/*    */ 
/*    */   public final String toString()
/*    */   {
/* 48 */     return this.xbean.getClass().getSimpleName() + "." + this.varname;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.LogKey
 * JD-Core Version:    0.6.2
 */