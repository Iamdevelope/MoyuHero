/*    */ package xdb.util;
/*    */ 
/*    */ public class CapacityConf
/*    */ {
/*  7 */   private Integer capacity = null;
/*  8 */   private Integer key = null;
/*  9 */   private Integer value = null;
/*    */ 
/*    */   public Integer getCapacity() {
/* 12 */     return this.capacity;
/*    */   }
/*    */ 
/*    */   public Integer getKey() {
/* 16 */     return this.key;
/*    */   }
/*    */ 
/*    */   public Integer getValue() {
/* 20 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void throwIf(boolean paramBoolean, String paramString) {
/* 24 */     if (paramBoolean)
/* 25 */       throw new IllegalArgumentException(new StringBuilder().append("invalid capacity!").append(paramString).toString());
/*    */   }
/*    */ 
/*    */   public CapacityConf(Integer paramInteger1, Integer paramInteger2, Integer paramInteger3) {
/* 29 */     this.capacity = paramInteger1;
/* 30 */     this.key = paramInteger2;
/* 31 */     this.value = paramInteger3;
/*    */   }
/*    */ 
/*    */   public CapacityConf(String paramString) {
/* 35 */     for (String str : paramString.split(";"))
/* 36 */       if (!str.trim().isEmpty())
/*    */       {
/* 39 */         String[] arrayOfString2 = str.split(":");
/* 40 */         for (int k = 0; k < arrayOfString2.length; k++) {
/* 41 */           arrayOfString2[k] = arrayOfString2[k].trim();
/*    */         }
/*    */ 
/* 44 */         if (arrayOfString2.length == 1) {
/* 45 */           throwIf((null != this.capacity) || (arrayOfString2[0].isEmpty()), "[capacity] has present or isEmpty.");
/* 46 */           this.capacity = Integer.valueOf(arrayOfString2[0]);
/* 47 */           throwIf(this.capacity.intValue() < 0, "collection capacity is negative");
/*    */         }
/* 52 */         else if (arrayOfString2[0].equals("key")) {
/* 53 */           throwIf((null != this.key) || (arrayOfString2[1].isEmpty()), "capacity.key has present or isEmpty.");
/* 54 */           this.key = Integer.valueOf(arrayOfString2[1]);
/* 55 */           throwIf(this.key.intValue() < 0, "key capacity is negative");
/*    */         }
/* 60 */         else if (arrayOfString2[0].equals("value")) {
/* 61 */           throwIf((null != this.value) || (arrayOfString2[1].isEmpty()), "capacity.value has present or isEmpty.");
/* 62 */           this.value = Integer.valueOf(arrayOfString2[1]);
/* 63 */           throwIf(this.value.intValue() < 0, "value capacity is negative");
/*    */         }
/*    */         else
/*    */         {
/* 67 */           throwIf(true, "unkown token.");
/*    */         }
/*    */       }
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 73 */     StringBuilder localStringBuilder = new StringBuilder();
/* 74 */     int i = 1;
/*    */ 
/* 76 */     if (null != this.capacity) {
/* 77 */       localStringBuilder.append(this.capacity);
/* 78 */       if (i == 0)
/* 79 */         localStringBuilder.append(";");
/* 80 */       i = 0;
/*    */     }
/*    */ 
/* 83 */     if (null != this.key) {
/* 84 */       if (i == 0)
/* 85 */         localStringBuilder.append(";");
/* 86 */       localStringBuilder.append("key:").append(this.key);
/* 87 */       i = 0;
/*    */     }
/*    */ 
/* 90 */     if (null != this.value) {
/* 91 */       if (i == 0)
/* 92 */         localStringBuilder.append(";");
/* 93 */       localStringBuilder.append("value:").append(this.value);
/* 94 */       i = 0;
/*    */     }
/* 96 */     return localStringBuilder.toString();
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.CapacityConf
 * JD-Core Version:    0.6.2
 */