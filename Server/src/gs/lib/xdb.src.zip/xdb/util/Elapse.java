/*    */ package xdb.util;
/*    */ 
/*    */ public final class Elapse
/*    */ {
/*  7 */   long start = System.nanoTime();
/*    */ 
/*    */   public long elapsed()
/*    */   {
/* 13 */     return System.nanoTime() - this.start;
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */   {
/* 20 */     this.start = System.nanoTime();
/*    */   }
/*    */ 
/*    */   public long elapsedAndReset()
/*    */   {
/* 27 */     long l1 = System.nanoTime();
/* 28 */     long l2 = l1 - this.start;
/* 29 */     this.start = l1;
/* 30 */     return l2;
/*    */   }
/*    */ 
/*    */   public long now()
/*    */   {
/* 37 */     return System.nanoTime();
/*    */   }
/*    */ 
/*    */   public long getStart() {
/* 41 */     return this.start;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.Elapse
 * JD-Core Version:    0.6.2
 */