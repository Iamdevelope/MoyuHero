package xdb.util;

import com.goldhuman.Common.Marshal.OctetsStream;

public abstract interface AutoKey<T>
{
  public abstract T next();

  public abstract T current();

  public abstract String getName();

  public abstract OctetsStream marshal(OctetsStream paramOctetsStream);

  public abstract void accept(T paramT);
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.AutoKey
 * JD-Core Version:    0.6.2
 */