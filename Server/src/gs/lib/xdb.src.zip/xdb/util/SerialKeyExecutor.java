/*     */ package xdb.util;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import xdb.Xdb;
/*     */ 
/*     */ public final class SerialKeyExecutor<K>
/*     */   implements Executor
/*     */ {
/*     */   private final ExecutorService service;
/*     */   private final SerialKeyExecutor<K>[].Serial serials;
/* 253 */   private static Callable<Object> dummyHeader = new Callable() {
/*     */     public Object call() {
/* 255 */       throw new IllegalStateException("SerialKeyExecutor.header");
/*     */     }
/* 253 */   };
/*     */ 
/*     */   public SerialKeyExecutor()
/*     */   {
/*  68 */     this(Xdb.executor());
/*     */   }
/*     */ 
/*     */   public SerialKeyExecutor(ExecutorService paramExecutorService)
/*     */   {
/*  77 */     this(paramExecutorService, 1024);
/*     */   }
/*     */ 
/*     */   public SerialKeyExecutor(ExecutorService paramExecutorService, int paramInt)
/*     */   {
/*  87 */     if ((paramInt < 0) || (paramInt > 1073741824))
/*  88 */       throw new IllegalArgumentException("Illegal concurrencyLevel: " + paramInt);
/*  89 */     if (null == paramExecutorService)
/*  90 */       throw new NullPointerException();
/*  91 */     this.service = paramExecutorService;
/*  92 */     int i = 1;
/*  93 */     while (i < paramInt)
/*  94 */       i <<= 1;
/*  95 */     this.serials = new Serial[i];
/*  96 */     for (int j = 0; j < this.serials.length; j++)
/*  97 */       this.serials[j] = new Serial();
/*     */   }
/*     */ 
/*     */   public ExecutorService getExecutorService()
/*     */   {
/* 104 */     return this.service;
/*     */   }
/*     */ 
/*     */   public void execute(K paramK, Runnable paramRunnable)
/*     */   {
/* 116 */     submit(paramK, paramRunnable);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(K paramK, Runnable paramRunnable)
/*     */   {
/* 126 */     return submit(paramK, Executors.callable(paramRunnable));
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(K paramK, Runnable paramRunnable, T paramT)
/*     */   {
/* 137 */     return submit(paramK, Executors.callable(paramRunnable, paramT));
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(K paramK, Callable<T> paramCallable)
/*     */   {
/* 150 */     if (this.service.isShutdown())
/* 151 */       throw new RejectedExecutionException();
/* 152 */     return serialFor(paramK).submit(paramK, paramCallable);
/*     */   }
/*     */ 
/*     */   public void execute(Runnable paramRunnable)
/*     */   {
/* 160 */     this.service.execute(paramRunnable);
/*     */   }
/*     */ 
/*     */   public int cancel(K paramK)
/*     */   {
/* 171 */     return serialFor(paramK).cancel(paramK);
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 183 */     int i = 0;
/* 184 */     for (Serial localSerial : this.serials)
/* 185 */       i += localSerial.size();
/* 186 */     return i;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public int purge()
/*     */   {
/* 195 */     if (false == this.service.isTerminated())
/* 196 */       throw new IllegalStateException("service is still running.");
/* 197 */     int i = 0;
/* 198 */     for (Serial localSerial : this.serials)
/* 199 */       i += localSerial.purge();
/* 200 */     return i;
/*     */   }
/*     */ 
/*     */   static int hash(int paramInt)
/*     */   {
/* 215 */     paramInt ^= paramInt >>> 20 ^ paramInt >>> 12;
/* 216 */     return paramInt ^ paramInt >>> 7 ^ paramInt >>> 4;
/*     */   }
/*     */ 
/*     */   static int indexFor(int paramInt1, int paramInt2)
/*     */   {
/* 223 */     return paramInt1 & paramInt2 - 1;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SerialKeyExecutor<K>.Serial serialFor(K paramK)
/*     */   {
/* 232 */     return this.serials[indexFor(hash(paramK.hashCode()), this.serials.length)];
/*     */   }
/*     */ 
/*     */   public boolean remove(Future<?> paramFuture)
/*     */   {
/* 247 */     if ((paramFuture instanceof SerialKeyExecutor.Serial.Task)) {
/* 248 */       return ((SerialKeyExecutor.Serial.Task)paramFuture).remove();
/*     */     }
/* 250 */     throw new RuntimeException("SerialKeyExecutor.remove: future is not a serial task.");
/*     */   }
/*     */ 
/*     */   public final class Serial
/*     */   {
/*     */     private final SerialKeyExecutor<K>.Serial.Task<?> header;
/* 261 */     private int size = 0;
/* 262 */     private final Lock lock = new ReentrantLock();
/*     */ 
/*     */     Serial() {
/* 265 */       this.header = new Task(null, SerialKeyExecutor.dummyHeader);
/* 266 */       reset();
/*     */     }
/*     */ 
/*     */     <T> Future<T> submit(K paramK, Callable<T> paramCallable)
/*     */     {
/* 271 */       this.lock.lock();
/*     */       try {
/* 273 */         Task localTask1 = addLast(new Task(paramK, paramCallable));
/* 274 */         if (this.size == 1) {
/*     */           try {
/* 276 */             SerialKeyExecutor.this.execute(localTask1);
/*     */           } catch (RejectedExecutionException localRejectedExecutionException) {
/* 278 */             remove(localTask1);
/* 279 */             throw localRejectedExecutionException;
/*     */           } catch (Throwable localThrowable) {
/* 281 */             remove(localTask1);
/* 282 */             throw new RejectedExecutionException(localThrowable);
/*     */           }
/*     */         }
/* 285 */         return localTask1;
/*     */       } finally {
/* 287 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     void scheduleNext(SerialKeyExecutor<K>.Serial.Task<?> paramSerialKeyExecutor)
/*     */     {
/* 293 */       assert (paramSerialKeyExecutor == getFirst());
/* 294 */       remove(paramSerialKeyExecutor);
/*     */ 
/* 301 */       while ((this.size > 0) && (getFirst().isCancelled())) removeFirst();
/*     */ 
/* 307 */       while (this.size > 0) {
/* 308 */         Task localTask = getFirst();
/*     */         try {
/* 310 */           SerialKeyExecutor.this.execute(localTask);
/*     */         }
/*     */         catch (Throwable localThrowable)
/*     */         {
/* 314 */           while (this.size > 0) removeFirst().setException(localThrowable);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     int cancel(K paramK)
/*     */     {
/* 327 */       this.lock.lock();
/*     */       try {
/* 329 */         if (this.size == 0) {
/* 330 */           return 0;
/*     */         }
/* 332 */         Task localTask1 = 0;
/*     */ 
/* 334 */         if (this.header.next.cancel(false)) {
/* 335 */           localTask1++;
/*     */         }
/* 337 */         Object localObject1 = Task.access$100(this.header).next;
/*     */         Task localTask2;
/* 338 */         while (localObject1 != this.header) {
/* 339 */           localTask2 = ((Task)localObject1).next;
/* 340 */           if ((((Task)localObject1).key.equals(paramK)) && (((Task)localObject1).cancel(false))) {
/* 341 */             remove((Task)localObject1);
/* 342 */             localTask1++;
/*     */           }
/* 344 */           localObject1 = localTask2;
/*     */         }
/* 346 */         return localTask1;
/*     */       } finally {
/* 348 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     int purge()
/*     */     {
/* 354 */       this.lock.lock();
/*     */       try {
/* 356 */         Task localTask1 = 0;
/* 357 */         for (Task localTask2 = this.header.next; localTask2 != this.header; localTask2 = localTask2.next) {
/* 358 */           if (localTask2.cancel(false))
/* 359 */             localTask1++;
/*     */         }
/* 361 */         reset();
/* 362 */         return localTask1;
/*     */       } finally {
/* 364 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public int size() {
/* 369 */       this.lock.lock();
/*     */       try {
/* 371 */         return this.size;
/*     */       } finally {
/* 373 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     SerialKeyExecutor<K>.Serial.Task<?> getFirst()
/*     */     {
/* 435 */       if (this.size == 0)
/* 436 */         throw new NoSuchElementException();
/* 437 */       return this.header.next;
/*     */     }
/*     */ 
/*     */     SerialKeyExecutor<K>.Serial.Task<?> removeFirst() {
/* 441 */       return remove(getFirst());
/*     */     }
/*     */ 
/*     */     private SerialKeyExecutor<K>.Serial.Task<?> remove(SerialKeyExecutor<K>.Serial.Task<?> paramSerialKeyExecutor) {
/* 445 */       paramSerialKeyExecutor.previous.next = paramSerialKeyExecutor.next;
/* 446 */       paramSerialKeyExecutor.next.previous = paramSerialKeyExecutor.previous;
/* 447 */       paramSerialKeyExecutor.next = Task.access$602(paramSerialKeyExecutor, null);
/* 448 */       this.size -= 1;
/* 449 */       return paramSerialKeyExecutor;
/*     */     }
/*     */ 
/*     */     private <T> SerialKeyExecutor<K>.Serial.Task<T> addLast(SerialKeyExecutor<K>.Serial.Task<T> paramSerialKeyExecutor) {
/* 453 */       paramSerialKeyExecutor.next = this.header;
/* 454 */       paramSerialKeyExecutor.previous = this.header.previous;
/* 455 */       this.header.previous.next = paramSerialKeyExecutor;
/* 456 */       this.header.previous = paramSerialKeyExecutor;
/* 457 */       this.size += 1;
/* 458 */       return paramSerialKeyExecutor;
/*     */     }
/*     */ 
/*     */     void reset()
/*     */     {
/* 465 */       this.header.next = Task.access$602(this.header, this.header);
/* 466 */       this.size = 0;
/*     */     }
/*     */ 
/*     */     final class Task<T> extends FutureTask<T>
/*     */     {
/* 378 */       private SerialKeyExecutor<K>.Serial.Task<?> next = null;
/* 379 */       private SerialKeyExecutor<K>.Serial.Task<?> previous = null;
/*     */       private final K key;
/*     */ 
/*     */       Task(Callable<T> arg2)
/*     */       {
/* 383 */         super();
/*     */         Object localObject;
/* 384 */         this.key = localObject;
/*     */       }
/*     */ 
/*     */       public boolean remove()
/*     */       {
/* 389 */         if (super.cancel(false))
/*     */         {
/* 391 */           SerialKeyExecutor.Serial.this.lock.lock();
/*     */           try
/*     */           {
/* 398 */             if ((this != SerialKeyExecutor.Serial.this.header.next) && (null != this.next))
/* 399 */               SerialKeyExecutor.Serial.this.remove(this);
/*     */           } finally {
/* 401 */             SerialKeyExecutor.Serial.this.lock.unlock();
/*     */           }
/* 403 */           return true;
/*     */         }
/* 405 */         return false;
/*     */       }
/*     */ 
/*     */       public void run()
/*     */       {
/*     */         try
/*     */         {
/* 414 */           super.run();
/*     */         } finally {
/* 416 */           SerialKeyExecutor.Serial.this.lock.lock();
/*     */           try {
/* 418 */             SerialKeyExecutor.Serial.this.scheduleNext(this);
/*     */           } finally {
/* 420 */             SerialKeyExecutor.Serial.this.lock.unlock();
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */       protected void setException(Throwable paramThrowable)
/*     */       {
/* 428 */         super.setException(paramThrowable);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.SerialKeyExecutor
 * JD-Core Version:    0.6.2
 */