/*     */ package xdb.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.remote.JMXConnectorServer;
/*     */ import javax.management.remote.JMXConnectorServerFactory;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ 
/*     */ public class JMXServer
/*     */ {
/*     */   private JMXConnectorServer cs;
/*     */ 
/*     */   public JMXServer()
/*     */     throws IOException
/*     */   {
/*  43 */     this(1098);
/*     */   }
/*     */ 
/*     */   public JMXServer(int paramInt)
/*     */     throws IOException
/*     */   {
/*  53 */     this(paramInt, paramInt + 1, "127.0.0.1", null, null);
/*     */   }
/*     */ 
/*     */   public JMXServer(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3)
/*     */     throws IOException
/*     */   {
/*  69 */     if (null != paramString1) {
/*  70 */       System.setProperty("java.rmi.server.hostname", paramString1);
/*     */     }
/*  72 */     LocateRegistry.createRegistry(paramInt1);
/*     */ 
/*  74 */     JMXServiceURL localJMXServiceURL = new JMXServiceURL(String.format("service:jmx:rmi://localhost:%d/jndi/rmi://localhost:%d/jmxrmi", new Object[] { Integer.valueOf(paramInt2), Integer.valueOf(paramInt1) }));
/*     */ 
/*  78 */     HashMap localHashMap = new HashMap();
/*     */ 
/*  80 */     if (null != paramString2)
/*  81 */       localHashMap.put("jmx.remote.x.password.file", paramString2);
/*  82 */     if (null != paramString3) {
/*  83 */       localHashMap.put("jmx.remote.x.access.file", paramString3);
/*     */     }
/*  85 */     MBeanServer localMBeanServer = ManagementFactory.getPlatformMBeanServer();
/*  86 */     this.cs = JMXConnectorServerFactory.newJMXConnectorServer(localJMXServiceURL, localHashMap, localMBeanServer);
/*     */   }
/*     */ 
/*     */   public void start() throws IOException {
/*  90 */     this.cs.start();
/*     */   }
/*     */   public void stop() {
/*     */     try {
/*  94 */       this.cs.stop(); } catch (Exception localException) { localException.printStackTrace(); }
/*     */ 
/*     */   }
/*     */ 
/*     */   private static int getPropertyInt(String paramString, int paramInt)
/*     */   {
/* 100 */     return Integer.parseInt(System.getProperty(paramString, String.valueOf(paramInt)));
/*     */   }
/*     */ 
/*     */   public static void premain(String paramString)
/*     */     throws IOException
/*     */   {
/* 110 */     int i = getPropertyInt("xdb.util.jmxserver.rmi.port", 1098);
/* 111 */     int j = getPropertyInt("xdb.util.jmxserver.port", i + 1);
/* 112 */     String str1 = System.getProperty("java.rmi.server.hostname") == null ? "127.0.0.1" : null;
/* 113 */     String str2 = System.getProperty("xdb.util.jmxserver.password.file");
/* 114 */     String str3 = System.getProperty("xdb.util.jmxserver.access.file");
/*     */ 
/* 116 */     JMXServer localJMXServer = new JMXServer(i, j, str1, str2, str3);
/* 117 */     localJMXServer.start();
/*     */   }
/*     */ 
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/* 121 */     String str = "127.0.0.1";
/* 122 */     int i = 1098;
/* 123 */     int j = 1099;
/* 124 */     if (paramArrayOfString.length > 0) str = paramArrayOfString[0];
/* 125 */     if (paramArrayOfString.length > 1) { i = Integer.parseInt(paramArrayOfString[1]); j = i + 1; }
/* 126 */     if (paramArrayOfString.length > 2) j = Integer.parseInt(paramArrayOfString[2]);
/*     */ 
/* 128 */     System.out.println("hostname=" + str + " rmpport=" + i + " serviceport=" + j);
/* 129 */     JMXServer localJMXServer = new JMXServer(i, j, str, null, null);
/*     */     try
/*     */     {
/* 132 */       localJMXServer.start();
/*     */ 
/* 134 */       MBeans.Manager localManager = new MBeans.Manager();
/* 135 */       Counter localCounter = new Counter(localManager, "xtest", "TestCounter");
/* 136 */       localCounter.increment("test");
/* 137 */       System.out.println("jmx service started!");
/* 138 */       System.in.read();
/* 139 */       localManager.unregisterAll();
/* 140 */       System.out.println("jmx service stop ... ");
/*     */     } finally {
/* 142 */       localJMXServer.stop();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.JMXServer
 * JD-Core Version:    0.6.2
 */