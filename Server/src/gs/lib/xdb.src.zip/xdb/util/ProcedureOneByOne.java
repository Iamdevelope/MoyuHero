/*    */ package xdb.util;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import xdb.Procedure;
/*    */ import xdb.Procedure.Done;
/*    */ 
/*    */ public class ProcedureOneByOne
/*    */ {
/*    */   private int maxsize;
/* 23 */   private LinkedList<Procedure> onebyone = new LinkedList();
/* 24 */   private Procedure.Done<Procedure> done = new Object()
/*    */   {
/*    */     public void doDone(Procedure paramAnonymousProcedure) {
/* 27 */       synchronized (ProcedureOneByOne.this) {
/* 28 */         Procedure localProcedure = (Procedure)ProcedureOneByOne.this.onebyone.removeFirst();
/* 29 */         assert (localProcedure == paramAnonymousProcedure);
/* 30 */         if (ProcedureOneByOne.this.onebyone.size() > 0)
/* 31 */           Procedure.execute((Procedure)ProcedureOneByOne.this.onebyone.peekFirst(), ProcedureOneByOne.this.done);
/*    */       }
/*    */     }
/* 24 */   };
/*    */ 
/*    */   public ProcedureOneByOne()
/*    */   {
/* 37 */     this.maxsize = 0;
/*    */   }
/*    */ 
/*    */   public ProcedureOneByOne(int paramInt) {
/* 41 */     this.maxsize = paramInt;
/*    */   }
/*    */ 
/*    */   public void add(Procedure paramProcedure) {
/* 45 */     synchronized (this) {
/* 46 */       if ((this.maxsize > 0) && (this.onebyone.size() > this.maxsize))
/* 47 */         throw new RuntimeException("out of capacity! maxsize=" + this.maxsize);
/* 48 */       this.onebyone.addLast(paramProcedure);
/* 49 */       if (this.onebyone.size() == 1)
/* 50 */         Procedure.execute((Procedure)this.onebyone.peekFirst(), this.done);
/*    */     }
/*    */   }
/*    */ 
/*    */   public Procedure peekDebugOnly()
/*    */   {
/* 57 */     synchronized (this) {
/* 58 */       return (Procedure)this.onebyone.peekFirst();
/*    */     }
/*    */   }
/*    */ 
/*    */   public int sizeDebugOnly() {
/* 63 */     synchronized (this) {
/* 64 */       return this.onebyone.size();
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.ProcedureOneByOne
 * JD-Core Version:    0.6.2
 */