/*     */ package xdb.util;
/*     */ 
/*     */ import java.io.Console;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileLock;
/*     */ 
/*     */ public class Status
/*     */ {
/*     */   public static void main(String[] paramArrayOfString)
/*     */     throws Exception
/*     */   {
/*     */     File localFile;
/*     */     Object localObject1;
/*     */     Object localObject2;
/*     */     Object localObject3;
/*  33 */     if (paramArrayOfString.length > 0)
/*     */     {
/*  35 */       localFile = new File("filename");
/*  36 */       localObject1 = new RandomAccessFile(localFile, "rw");
/*  37 */       localObject2 = ((RandomAccessFile)localObject1).getChannel();
/*     */ 
/*  41 */       localObject3 = paramArrayOfString[0];
/*  42 */       Console localConsole = System.console();
/*  43 */       for (int j = 0; j < 2; j++) {
/*  44 */         System.out.println("press enter to lock!");
/*  45 */         localConsole.readLine();
/*  46 */         FileLock localFileLock = ((FileChannel)localObject2).lock();
/*  47 */         System.out.println("lock successed!");
/*  48 */         ByteBuffer localByteBuffer = ByteBuffer.allocate(4096);
/*  49 */         ((FileChannel)localObject2).position(0L);
/*  50 */         int k = ((FileChannel)localObject2).read(localByteBuffer);
/*  51 */         System.out.println("--- rc=" + k);
/*  52 */         if (k > 0) {
/*  53 */           System.out.println(new String(localByteBuffer.array(), 0, k));
/*     */         }
/*  55 */         System.out.println("---");
/*  56 */         localByteBuffer.clear();
/*  57 */         System.out.println((String)localObject3);
/*  58 */         System.out.println("---");
/*  59 */         localByteBuffer.put(((String)localObject3).getBytes());
/*  60 */         ((FileChannel)localObject2).truncate(0L);
/*  61 */         localByteBuffer.flip();
/*  62 */         ((FileChannel)localObject2).write(localByteBuffer);
/*     */ 
/*  64 */         System.out.println("press enter to release lock!");
/*  65 */         localConsole.readLine();
/*     */ 
/*  67 */         localFileLock.release();
/*  68 */         localObject3 = (String)localObject3 + (String)localObject3;
/*     */       }
/*     */ 
/*  72 */       ((FileChannel)localObject2).close();
/*     */     }
/*     */     else {
/*  75 */       localFile = new File("filename");
/*  76 */       localObject1 = new RandomAccessFile(localFile, "rw").getChannel();
/*     */ 
/*  80 */       localObject2 = ((FileChannel)localObject1).tryLock();
/*  81 */       if (null != localObject2) {
/*  82 */         System.out.println("tryLock successed!");
/*  83 */         localObject3 = ByteBuffer.allocate(4096);
/*  84 */         int i = ((FileChannel)localObject1).read((ByteBuffer)localObject3);
/*  85 */         System.out.println("--- content rc=" + i);
/*  86 */         if (i > 0) {
/*  87 */           System.out.println(new String(((ByteBuffer)localObject3).array(), 0, i));
/*     */         }
/*  89 */         System.out.println("---");
/*     */ 
/*  91 */         ((FileLock)localObject2).release();
/*     */       } else {
/*  93 */         System.out.println("tryLock failed!");
/*     */       }
/*     */ 
/*  96 */       ((FileChannel)localObject1).close();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean tryReadLock(String paramString)
/*     */   {
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   protected void readUnlock(String paramString)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setXdbRunning()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setBackup()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setRestore()
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.Status
 * JD-Core Version:    0.6.2
 */