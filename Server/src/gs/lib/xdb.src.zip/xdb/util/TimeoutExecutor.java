/*     */ package xdb.util;
/*     */ 
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import xdb.Angel;
/*     */ import xdb.Worker;
/*     */ 
/*     */ public class TimeoutExecutor extends ThreadPoolExecutor
/*     */ {
/*     */   private volatile long defaultTimeout;
/*     */ 
/*     */   public synchronized void setDefaultTimeout(long paramLong)
/*     */   {
/*  23 */     this.defaultTimeout = paramLong;
/*     */   }
/*     */ 
/*     */   public long getDefaultTimeout() {
/*  27 */     return this.defaultTimeout;
/*     */   }
/*     */ 
/*     */   public TimeoutExecutor(long paramLong, int paramInt, ThreadFactory paramThreadFactory)
/*     */   {
/*  33 */     super(paramInt, paramInt, 0L, TimeUnit.NANOSECONDS, new LinkedBlockingQueue(), paramThreadFactory);
/*     */ 
/*  35 */     this.defaultTimeout = paramLong;
/*     */   }
/*     */ 
/*     */   public TimeoutExecutor(long paramLong, int paramInt, BlockingQueue<Runnable> paramBlockingQueue, ThreadFactory paramThreadFactory)
/*     */   {
/*  48 */     super(paramInt, paramInt, 0L, TimeUnit.NANOSECONDS, paramBlockingQueue, paramThreadFactory);
/*  49 */     this.defaultTimeout = paramLong;
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable paramRunnable, long paramLong)
/*     */   {
/*  58 */     Worker.debugHunger(this);
/*  59 */     return super.submit(Angel.decorateCallable(paramRunnable, paramLong));
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Runnable paramRunnable, T paramT, long paramLong)
/*     */   {
/*  66 */     Worker.debugHunger(this);
/*  67 */     return super.submit(Angel.decorate(paramRunnable, paramT, paramLong));
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> paramCallable, long paramLong)
/*     */   {
/*  74 */     Worker.debugHunger(this);
/*  75 */     return super.submit(Angel.decorate(paramCallable, paramLong));
/*     */   }
/*     */ 
/*     */   public void execute(Runnable paramRunnable, long paramLong)
/*     */   {
/*  82 */     super.execute(Angel.decorateRunnable(paramRunnable, paramLong));
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable paramRunnable)
/*     */   {
/*  90 */     Worker.debugHunger(this);
/*  91 */     return super.submit(Angel.decorateCallable(paramRunnable, this.defaultTimeout));
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Runnable paramRunnable, T paramT)
/*     */   {
/*  96 */     Worker.debugHunger(this);
/*  97 */     return super.submit(Angel.decorate(paramRunnable, paramT, this.defaultTimeout));
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> paramCallable)
/*     */   {
/* 102 */     Worker.debugHunger(this);
/* 103 */     return super.submit(Angel.decorate(paramCallable, this.defaultTimeout));
/*     */   }
/*     */ 
/*     */   public void execute(Runnable paramRunnable)
/*     */   {
/* 108 */     super.execute(Angel.decorateRunnable(paramRunnable, this.defaultTimeout));
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.TimeoutExecutor
 * JD-Core Version:    0.6.2
 */