/*     */ package xdb.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.PriorityQueue;
/*     */ import java.util.concurrent.Delayed;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.RunnableScheduledFuture;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public final class TimerWheel
/*     */ {
/*     */   private final ScheduledExecutorService service;
/*     */   private final Wheel[] wheels;
/*     */   private volatile int cursor;
/*  25 */   private final int WHEEL = 500;
/*     */ 
/*     */   public TimerWheel(ScheduledExecutorService paramScheduledExecutorService, int paramInt) {
/*  28 */     if ((paramInt < 0) || (paramInt > 1073741824)) {
/*  29 */       throw new IllegalArgumentException("Illegal initial capacity: " + paramInt);
/*     */     }
/*  31 */     int i = 1;
/*  32 */     while (i < paramInt) {
/*  33 */       i <<= 1;
/*     */     }
/*  35 */     this.service = paramScheduledExecutorService;
/*  36 */     this.wheels = new Wheel[i];
/*     */   }
/*     */ 
/*     */   ScheduledFuture<?> schedule(Runnable paramRunnable, long paramLong)
/*     */   {
/*  41 */     return schedule(paramRunnable, paramLong, TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   ScheduledFuture<?> schedule(Runnable paramRunnable, long paramLong, TimeUnit paramTimeUnit) {
/*  45 */     if ((paramRunnable == null) || (paramTimeUnit == null)) {
/*  46 */       throw new NullPointerException();
/*     */     }
/*  48 */     if (paramLong < 0L) paramLong = 0L;
/*  49 */     long l = paramLong / 500L;
/*  50 */     if (l >= this.wheels.length) {
/*  51 */       return this.service.schedule(paramRunnable, paramLong, paramTimeUnit);
/*     */     }
/*  53 */     Task localTask = new Task(paramRunnable, paramLong);
/*  54 */     this.wheels[((int)l + this.cursor & this.wheels.length - 1)].add(localTask);
/*  55 */     return localTask;
/*     */   }
/*     */ 
/*     */   public static void main(String[] paramArrayOfString)
/*     */     throws Exception
/*     */   {
/* 147 */     long l1 = 9223372036854775807L;
/* 148 */     long l2 = 0L;
/* 149 */     long l3 = 0L;
/* 150 */     long l4 = 1000L;
/* 151 */     long l5 = System.currentTimeMillis();
/* 152 */     for (int i = 0; i < l4; i++) {
/* 153 */       long l6 = System.currentTimeMillis();
/* 154 */       Thread.sleep(1L);
/* 155 */       long l7 = System.currentTimeMillis() - l6;
/* 156 */       if (l7 < l1) l1 = l7;
/* 157 */       if (l7 > l2) l2 = l7;
/* 158 */       l3 += l7;
/*     */     }
/* 160 */     l5 = System.currentTimeMillis() - l5;
/* 161 */     System.out.println("min=" + l1);
/* 162 */     System.out.println("max=" + l2);
/* 163 */     System.out.println("count=" + l4);
/* 164 */     System.out.println("total=" + l3);
/* 165 */     System.out.println("elapsed=" + l5);
/*     */   }
/*     */ 
/*     */   static final class WheelPriority
/*     */     implements TimerWheel.Wheel
/*     */   {
/* 133 */     private final PriorityQueue<TimerWheel.Task<?>> tasks = new PriorityQueue();
/*     */ 
/* 135 */     public WheelPriority(TimerWheel.WheelList paramWheelList) { for (TimerWheel.Task localTask : TimerWheel.WheelList.access$000(paramWheelList))
/* 136 */         this.tasks.add(localTask); }
/*     */ 
/*     */     public void add(TimerWheel.Task<?> paramTask) {
/* 139 */       this.tasks.add(paramTask);
/*     */     }
/*     */     public void remove(TimerWheel.Task<?> paramTask) {
/* 142 */       this.tasks.remove(paramTask);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class WheelList
/*     */     implements TimerWheel.Wheel
/*     */   {
/* 123 */     private final List<TimerWheel.Task<?>> tasks = new LinkedList();
/*     */ 
/* 125 */     public void add(TimerWheel.Task<?> paramTask) { this.tasks.add(paramTask); }
/*     */ 
/*     */     public void remove(TimerWheel.Task<?> paramTask) {
/* 128 */       this.tasks.remove(paramTask);
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface Wheel
/*     */   {
/*     */     public abstract void add(TimerWheel.Task<?> paramTask);
/*     */ 
/*     */     public abstract void remove(TimerWheel.Task<?> paramTask);
/*     */   }
/*     */ 
/*     */   static final class Task<V> extends FutureTask<V>
/*     */     implements RunnableScheduledFuture<V>
/*     */   {
/*     */     private final long period;
/*     */ 
/*     */     Task(Runnable paramRunnable, long paramLong)
/*     */     {
/*  62 */       super(null);
/*  63 */       this.period = paramLong;
/*     */     }
/*     */ 
/*     */     public boolean isPeriodic()
/*     */     {
/*  68 */       return 0L != this.period;
/*     */     }
/*     */ 
/*     */     public long getDelay(TimeUnit paramTimeUnit)
/*     */     {
/*  73 */       return 0L;
/*     */     }
/*     */ 
/*     */     public int compareTo(Delayed paramDelayed)
/*     */     {
/*  78 */       return 0;
/*     */     }
/*     */ 
/*     */     private void runPeriodic()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 110 */       if (isPeriodic())
/* 111 */         runPeriodic();
/*     */       else
/* 113 */         super.run();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.TimerWheel
 * JD-Core Version:    0.6.2
 */