/*     */ package xdb.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.management.LockInfo;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.ThreadInfo;
/*     */ import java.lang.management.ThreadMXBean;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ public class StackTrace
/*     */ {
/*     */   private final String[] nsClass;
/*     */   private final String[] nsLock;
/*     */ 
/*     */   public StackTrace(String paramString1, String paramString2)
/*     */   {
/*  18 */     this(paramString1.split("[;,]"), paramString2.split("[;,]"));
/*     */   }
/*     */ 
/*     */   private String[] foo(String[] paramArrayOfString) {
/*  22 */     ArrayList localArrayList = new ArrayList();
/*  23 */     for (String str : paramArrayOfString) {
/*  24 */       localArrayList.add(str.trim());
/*     */     }
/*  26 */     return (String[])localArrayList.toArray(new String[localArrayList.size()]);
/*     */   }
/*     */ 
/*     */   public StackTrace(String[] paramArrayOfString1, String[] paramArrayOfString2) {
/*  30 */     this.nsClass = foo(paramArrayOfString1);
/*  31 */     this.nsLock = foo(paramArrayOfString2);
/*     */   }
/*     */ 
/*     */   private String findNsClass(StackTraceElement paramStackTraceElement) {
/*  35 */     for (String str : this.nsClass)
/*  36 */       if (paramStackTraceElement.getClassName().startsWith(str))
/*  37 */         return str;
/*  38 */     return null;
/*     */   }
/*     */ 
/*     */   private String findNsLock(StackTraceElement paramStackTraceElement) {
/*  42 */     for (String str : this.nsLock)
/*  43 */       if (paramStackTraceElement.getClassName().startsWith(str))
/*  44 */         return str;
/*  45 */     return null;
/*     */   }
/*     */ 
/*     */   private void increment(Map<String, AtomicInteger> paramMap, String paramString) {
/*  49 */     if (null != paramString) {
/*  50 */       AtomicInteger localAtomicInteger = (AtomicInteger)paramMap.get(paramString);
/*  51 */       if (null == localAtomicInteger)
/*  52 */         paramMap.put(paramString, localAtomicInteger = new AtomicInteger(0));
/*  53 */       localAtomicInteger.incrementAndGet();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map<String, AtomicInteger> top()
/*     */   {
/*  61 */     HashMap localHashMap = new HashMap();
/*     */ 
/*  63 */     ThreadMXBean localThreadMXBean = ManagementFactory.getThreadMXBean();
/*  64 */     for (ThreadInfo localThreadInfo : localThreadMXBean.getThreadInfo(localThreadMXBean.getAllThreadIds(), 2147483647))
/*  65 */       if (null != localThreadInfo)
/*     */       {
/*  69 */         increment(localHashMap, buildLockKeyFor(localThreadInfo));
/*     */ 
/*  72 */         String str = null;
/*  73 */         int k = 0;
/*  74 */         for (StackTraceElement localStackTraceElement : localThreadInfo.getStackTrace()) {
/*  75 */           str = findNsClass(localStackTraceElement);
/*  76 */           if (null != str)
/*     */             break;
/*  78 */           k++;
/*     */         }
/*     */ 
/*  81 */         increment(localHashMap, buildClassKeyFor(localThreadInfo, str, k));
/*     */       }
/*  83 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   public String buildLockKeyFor(ThreadInfo paramThreadInfo) {
/*  87 */     if (null != paramThreadInfo.getLockInfo()) {
/*  88 */       for (StackTraceElement localStackTraceElement : paramThreadInfo.getStackTrace()) {
/*  89 */         String str = findNsLock(localStackTraceElement);
/*  90 */         if (null != str) {
/*  91 */           return new StringBuilder().append(" - ").append(localStackTraceElement.getClassName()).append(".").append(localStackTraceElement.getMethodName()).append(" (").append(paramThreadInfo.getLockInfo().getClassName()).append(")").toString();
/*     */         }
/*     */       }
/*     */ 
/*  95 */       return null;
/*     */     }
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */   public String buildClassKeyFor(ThreadInfo paramThreadInfo, String paramString, int paramInt)
/*     */   {
/* 109 */     if (null == paramString)
/*     */     {
/* 112 */       return "[Others]";
/*     */     }
/* 114 */     StackTraceElement[] arrayOfStackTraceElement = paramThreadInfo.getStackTrace();
/* 115 */     StringBuilder localStringBuilder = new StringBuilder();
/*     */ 
/* 118 */     localStringBuilder.append(arrayOfStackTraceElement[paramInt].getClassName()).append(".").append(arrayOfStackTraceElement[paramInt].getMethodName());
/*     */ 
/* 123 */     if (paramInt > 0) {
/* 124 */       localStringBuilder.append(" (");
/* 125 */       localStringBuilder.append(arrayOfStackTraceElement[0].getClassName()).append('.').append(arrayOfStackTraceElement[0].getMethodName());
/* 126 */       localStringBuilder.append(")");
/*     */     }
/*     */ 
/* 132 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/* 136 */     String str1 = "x, b,";
/* 137 */     for (String str2 : str1.split("[;,]"))
/* 138 */       System.out.println(new StringBuilder().append("-").append(str2).toString());
/* 139 */     for (int i = 0; i < 1; i++) {
/* 140 */       for (Map.Entry localEntry : new StackTrace("", "").top().entrySet())
/* 141 */         System.out.println(localEntry);
/* 142 */       System.out.println();
/* 143 */       Thread.sleep(100L);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.StackTrace
 * JD-Core Version:    0.6.2
 */