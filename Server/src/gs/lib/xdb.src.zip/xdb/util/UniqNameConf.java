/*    */ package xdb.util;
/*    */ 
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import xio.XioConf;
/*    */ 
/*    */ public final class UniqNameConf
/*    */ {
/*    */   private int localId;
/*    */   private XioConf xioConf;
/*    */ 
/*    */   public UniqNameConf(Element paramElement)
/*    */     throws Exception
/*    */   {
/* 11 */     this.localId = Integer.parseInt(paramElement.getAttribute("localId"));
/* 12 */     this.xioConf = XioConf.loadInChildNodes(paramElement);
/*    */   }
/*    */ 
/*    */   public static UniqNameConf load(String paramString)
/*    */     throws Exception
/*    */   {
/* 23 */     Document localDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(paramString);
/* 24 */     return new UniqNameConf(localDocument.getDocumentElement());
/*    */   }
/*    */ 
/*    */   public XioConf getXioConf() {
/* 28 */     return this.xioConf;
/*    */   }
/*    */ 
/*    */   public int getLocalId() {
/* 32 */     return this.localId;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.UniqNameConf
 * JD-Core Version:    0.6.2
 */