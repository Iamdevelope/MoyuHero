/*     */ package xdb.util;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import xdb.Trace;
/*     */ 
/*     */ public class MBeans
/*     */ {
/*  92 */   private static Manager local = new Manager();
/*     */ 
/*     */   public static ObjectName newObjectName(String paramString)
/*     */   {
/*     */     try
/*     */     {
/*  23 */       return new ObjectName(paramString);
/*     */     } catch (Throwable localThrowable) {
/*  25 */       throw new RuntimeException(localThrowable);
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static ObjectName register(Object paramObject, String paramString)
/*     */   {
/* 101 */     return local.register(paramObject, paramString);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void unregisterAll()
/*     */   {
/* 109 */     local.unregisterAll();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static void unregister(ObjectName paramObjectName)
/*     */   {
/* 119 */     local.unregister(paramObjectName);
/*     */   }
/*     */ 
/*     */   public static class Manager
/*     */   {
/*  30 */     private Set<ObjectName> mbeans = new HashSet();
/*     */ 
/*     */     public ObjectName register(Object paramObject, String paramString)
/*     */     {
/*  37 */       synchronized (this.mbeans) {
/*  38 */         ObjectName localObjectName = MBeans.newObjectName(paramString);
/*     */ 
/*  40 */         if (false == this.mbeans.add(localObjectName))
/*  41 */           throw new RuntimeException("duplicate mbean name of '" + localObjectName + "'");
/*     */         try
/*     */         {
/*  44 */           MBeanServer localMBeanServer = ManagementFactory.getPlatformMBeanServer();
/*  45 */           localMBeanServer.registerMBean(paramObject, localObjectName);
/*  46 */           return localObjectName;
/*     */         } catch (Throwable localThrowable) {
/*  48 */           this.mbeans.remove(localObjectName);
/*  49 */           throw new RuntimeException("see xdb.Xdb.registerMBean", localThrowable);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public void unregisterAll()
/*     */     {
/*  58 */       synchronized (this.mbeans) {
/*  59 */         MBeanServer localMBeanServer = ManagementFactory.getPlatformMBeanServer();
/*  60 */         for (ObjectName localObjectName : this.mbeans) {
/*     */           try {
/*  62 */             localMBeanServer.unregisterMBean(localObjectName);
/*     */           } catch (Throwable localThrowable) {
/*  64 */             Trace.error("unregisterMBean name=" + localObjectName, localThrowable);
/*     */           }
/*     */         }
/*  67 */         this.mbeans.clear();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void unregister(ObjectName paramObjectName)
/*     */     {
/*  77 */       synchronized (this.mbeans) {
/*     */         try {
/*  79 */           if (this.mbeans.remove(paramObjectName)) {
/*  80 */             MBeanServer localMBeanServer = ManagementFactory.getPlatformMBeanServer();
/*  81 */             localMBeanServer.unregisterMBean(paramObjectName);
/*     */           }
/*     */         } catch (Throwable localThrowable) {
/*  84 */           Trace.error("unregisterMBean name=" + paramObjectName, localThrowable);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.MBeans
 * JD-Core Version:    0.6.2
 */