/*    */ package xdb.util;
/*    */ 
/*    */ public class ForeignConf
/*    */ {
/*  7 */   private String key = null;
/*  8 */   private String value = null;
/*    */ 
/*    */   public String getKey() {
/* 11 */     return this.key;
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 15 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void throwIf(boolean paramBoolean, String paramString) {
/* 19 */     if (paramBoolean)
/* 20 */       throw new IllegalArgumentException(new StringBuilder().append("invalid conf!").append(paramString).toString());
/*    */   }
/*    */ 
/*    */   public ForeignConf(String paramString1, String paramString2) {
/* 24 */     this.key = paramString1;
/* 25 */     this.value = paramString2;
/*    */   }
/*    */ 
/*    */   public ForeignConf(String paramString) {
/* 29 */     for (String str : paramString.split(";"))
/* 30 */       if (!str.trim().isEmpty())
/*    */       {
/* 33 */         String[] arrayOfString2 = str.split(":");
/* 34 */         for (int k = 0; k < arrayOfString2.length; k++) {
/* 35 */           arrayOfString2[k] = arrayOfString2[k].trim();
/*    */         }
/*    */ 
/* 38 */         if (arrayOfString2.length == 1) {
/* 39 */           throwIf((null != this.value) || (arrayOfString2[0].isEmpty()), "[value] has present or isEmpty.");
/* 40 */           this.value = arrayOfString2[0];
/*    */         }
/* 45 */         else if (arrayOfString2[0].equals("key")) {
/* 46 */           throwIf((null != this.key) || (arrayOfString2[1].isEmpty()), "key isEmpty.");
/* 47 */           this.key = arrayOfString2[1];
/*    */         }
/* 52 */         else if (arrayOfString2[0].equals("value")) {
/* 53 */           throwIf((null != this.value) || (arrayOfString2[1].isEmpty()), "value isEmpty.");
/* 54 */           this.value = arrayOfString2[1];
/*    */         }
/*    */         else
/*    */         {
/* 58 */           throwIf(true, "unkown token.");
/*    */         }
/*    */       }
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 66 */     StringBuilder localStringBuilder = new StringBuilder();
/* 67 */     if (null != this.key)
/* 68 */       localStringBuilder.append("key:").append(this.key);
/* 69 */     if (null != this.value) {
/* 70 */       if (null != this.key)
/* 71 */         localStringBuilder.append(";");
/* 72 */       localStringBuilder.append("value:").append(this.value);
/*    */     }
/* 74 */     return localStringBuilder.toString();
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.ForeignConf
 * JD-Core Version:    0.6.2
 */