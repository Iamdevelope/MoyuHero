/*     */ package xdb.util;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.MarshalException;
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import xdb.Transaction;
/*     */ 
/*     */ public final class AutoKeys
/*     */ {
/*     */   private final int localInitValue;
/*  13 */   private HashMap<AutoKey, AutoKey> autoKeys = new HashMap();
/*     */ 
/*  15 */   private boolean dirty = false;
/*     */   public static final byte TYPEID_LONG = 1;
/*     */ 
/*     */   public synchronized AutoKeyLong getAutoKeyLong(String paramString)
/*     */   {
/*  28 */     AutoKeyLong localAutoKeyLong = new AutoKeyLong(paramString, this.localInitValue);
/*     */ 
/*  30 */     AutoKey localAutoKey = (AutoKey)this.autoKeys.get(localAutoKeyLong);
/*  31 */     if (null != localAutoKey)
/*  32 */       return (AutoKeyLong)localAutoKey;
/*  33 */     add(localAutoKeyLong);
/*  34 */     this.dirty = true;
/*  35 */     return localAutoKeyLong;
/*     */   }
/*     */ 
/*     */   public synchronized boolean isDirty() {
/*  39 */     return this.dirty;
/*     */   }
/*     */ 
/*     */   public synchronized Object[] toArray() {
/*  43 */     return this.autoKeys.keySet().toArray();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  48 */     Object[] arrayOfObject = toArray();
/*  49 */     String[] arrayOfString = new String[arrayOfObject.length];
/*  50 */     for (int i = 0; i < arrayOfObject.length; i++)
/*  51 */       arrayOfString[i] = arrayOfObject[i].toString();
/*  52 */     Arrays.sort(arrayOfString);
/*  53 */     return Arrays.toString(arrayOfString);
/*     */   }
/*     */ 
/*     */   public synchronized OctetsStream encodeValue(long paramLong)
/*     */   {
/*  62 */     OctetsStream localOctetsStream = new OctetsStream();
/*  63 */     localOctetsStream.marshal(this.autoKeys.size());
/*     */ 
/*  65 */     Iterator localIterator = this.autoKeys.keySet().iterator();
/*  66 */     while (localIterator.hasNext()) {
/*  67 */       ((AutoKey)localIterator.next()).marshal(localOctetsStream);
/*     */     }
/*  69 */     if (paramLong == -1922908697795782568L)
/*  70 */       this.dirty = false;
/*  71 */     return localOctetsStream;
/*     */   }
/*     */ 
/*     */   private void add(AutoKey paramAutoKey)
/*     */   {
/*  77 */     if (null != this.autoKeys.put(paramAutoKey, paramAutoKey))
/*  78 */       throw new IllegalStateException("Duplicate AutoKey Found");
/*     */   }
/*     */ 
/*     */   public AutoKeys(OctetsStream paramOctetsStream, int paramInt, boolean paramBoolean) {
/*  82 */     this.localInitValue = paramInt;
/*  83 */     this.dirty = paramBoolean;
/*  84 */     if (paramOctetsStream != null)
/*     */       try {
/*  86 */         for (int i = paramOctetsStream.unmarshal_int(); i > 0; i--)
/*  87 */           switch (paramOctetsStream.unmarshal_byte()) { case 1:
/*  88 */             add(new AutoKeyLong(paramOctetsStream)); }
/*     */       }
/*     */       catch (MarshalException localMarshalException)
/*     */       {
/*  92 */         throw new IllegalStateException(localMarshalException);
/*     */       }
/*     */   }
/*     */ 
/*     */   private final synchronized void setDirty()
/*     */   {
/*  98 */     this.dirty = true;
/*     */   }
/*     */ 
/*     */   private final class AutoKeyLong implements AutoKey<Long> {
/*     */     private final String name;
/*     */     private final int initValue;
/*     */     public static final int STEP = 4096;
/*     */     public static final int STEP_MASK = 4095;
/*     */     private long next;
/*     */ 
/*     */     public void accept(Long paramLong) {
/* 113 */       if (((paramLong.longValue() & 0xFFF) != this.initValue) || (paramLong.longValue() <= 0L)) {
/* 114 */         throw new IllegalArgumentException("invalid autokey " + String.valueOf(paramLong));
/*     */       }
/* 116 */       synchronized (this) {
/* 117 */         if (paramLong.longValue() <= this.next)
/* 118 */           return;
/* 119 */         this.next = paramLong.longValue();
/*     */       }
/* 121 */       AutoKeys.this.setDirty();
/*     */     }
/*     */ 
/*     */     public Long next()
/*     */     {
/* 126 */       Transaction.verify();
/* 127 */       AutoKeys.this.setDirty();
/* 128 */       synchronized (this) {
/* 129 */         long l = this.next + 4096L;
/* 130 */         if (l <= 0L)
/* 131 */           throw new IllegalStateException("autokey expired!");
/* 132 */         this.next = l;
/* 133 */         return Long.valueOf(this.next);
/*     */       }
/*     */     }
/*     */ 
/*     */     public Long current()
/*     */     {
/* 139 */       synchronized (this) { return Long.valueOf(this.next); }
/*     */     }
/*     */ 
/*     */     public String getName()
/*     */     {
/* 144 */       return this.name;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object paramObject)
/*     */     {
/* 149 */       if ((paramObject instanceof AutoKeyLong)) {
/* 150 */         AutoKeyLong localAutoKeyLong = (AutoKeyLong)paramObject;
/* 151 */         return (this.initValue == localAutoKeyLong.initValue) && (this.name.equals(localAutoKeyLong.name));
/*     */       }
/* 153 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 158 */       return this.initValue ^ this.name.hashCode();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 163 */       return "(" + this.name + "," + this.initValue + "," + current() + ")";
/*     */     }
/*     */ 
/*     */     public OctetsStream marshal(OctetsStream paramOctetsStream)
/*     */     {
/* 171 */       paramOctetsStream.marshal((byte)1);
/* 172 */       paramOctetsStream.marshal(this.name, "UTF-16LE");
/* 173 */       paramOctetsStream.marshal(this.initValue);
/* 174 */       paramOctetsStream.marshal(current().longValue());
/* 175 */       return paramOctetsStream;
/*     */     }
/*     */ 
/*     */     public AutoKeyLong(OctetsStream arg2)
/*     */       throws MarshalException
/*     */     {
/*     */       Object localObject;
/* 180 */       this.name = localObject.unmarshal_String("UTF-16LE");
/* 181 */       this.initValue = localObject.unmarshal_int();
/* 182 */       this.next = localObject.unmarshal_long();
/*     */     }
/*     */ 
/*     */     public AutoKeyLong(String paramInt, int arg3)
/*     */     {
/*     */       int i;
/* 186 */       if ((i < 0) || (i >= 4096)) {
/* 187 */         throw new IllegalArgumentException("AutoKey Invalid initValue=" + i);
/*     */       }
/* 189 */       this.name = paramInt;
/* 190 */       this.initValue = i;
/* 191 */       this.next = i;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.AutoKeys
 * JD-Core Version:    0.6.2
 */