/*     */ package xdb.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import xdb.Storage.IWalk;
/*     */ 
/*     */ public class Stat
/*     */ {
/*     */   private int threadPoolSize;
/*     */   private int capacityOfQueue;
/*     */   private boolean isConcurrent;
/*     */   private DatabaseMetaData databaseMetaData;
/*     */   private Dbx dbx;
/* 122 */   private static int DEFAULT_THREADPOOLSIZE = 4;
/* 123 */   private static int DEFAULT_CAPACITYOFQUEUE = 1024;
/*     */ 
/* 475 */   private Lock concurrentLock = new ReentrantLock();
/* 476 */   private int debugLevel = 5;
/*     */ 
/*     */   public static void main(String[] paramArrayOfString)
/*     */     throws Exception
/*     */   {
/*  41 */     String str1 = "xdb";
/*  42 */     String str2 = ".";
/*  43 */     int i = -1;
/*  44 */     for (int j = 0; j < paramArrayOfString.length; j++) {
/*  45 */       if (paramArrayOfString[j].equals("-db")) str1 = paramArrayOfString[(++j)];
/*  46 */       else if (paramArrayOfString[j].equals("-lib")) str2 = paramArrayOfString[(++j)];
/*  47 */       else if (paramArrayOfString[j].equals("-d")) i = Integer.parseInt(paramArrayOfString[(++j)]);
/*     */ 
/*     */     }
/*     */ 
/*  51 */     Stat localStat = new Stat(str2, str1, true);
/*  52 */     if (i > 0) localStat.setDebugLevel(i);
/*  53 */     List localList = localStat.initializeSample();
/*     */ 
/*  56 */     Elapse localElapse = new Elapse();
/*  57 */     perform(localList, 2);
/*     */ 
/*  60 */     System.out.println("total time=" + localElapse.elapsed());
/*  61 */     reportSample(localList);
/*     */   }
/*     */ 
/*     */   private List<TableBrowser> initializeSample()
/*     */   {
/*  68 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/*  71 */     for (DatabaseMetaData.Table localTable : this.databaseMetaData.getTables()) {
/*  72 */       if (localTable.isPersistence())
/*     */       {
/*  75 */         localArrayList.add(newTableBrowser(localTable.getName(), new TableHandle()
/*     */         {
/*     */           public void process(Object paramAnonymousObject1, Object paramAnonymousObject2)
/*     */           {
/*  80 */             if (getTableBrowser().getWalker().getTable().getName().equals("flush3"))
/*  81 */               throw new RuntimeException("process exception test.");
/*     */           }
/*     */         }));
/*     */       }
/*     */     }
/*  86 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public static void reportSample(List<TableBrowser> paramList) {
/*  90 */     for (TableBrowser localTableBrowser : paramList) {
/*  91 */       Walker localWalker = localTableBrowser.getWalker();
/*  92 */       Dbx.Table localTable = localWalker.getTable();
/*  93 */       if (localTableBrowser.getException() != null) {
/*  94 */         System.out.println(localTable.getName() + " <EXCEPTION>");
/*  95 */         localTableBrowser.getException().printStackTrace();
/*     */       }
/*     */       else
/*     */       {
/* 100 */         Sum localSum1 = new Sum();
/* 101 */         for (localIterator2 = localWalker.getSums().iterator(); localIterator2.hasNext(); ) { localSum2 = (Sum)localIterator2.next();
/* 102 */           localSum1.add(localSum2);
/*     */         }
/*     */ 
/* 105 */         if (localSum1.recordCount != 0L)
/*     */         {
/* 108 */           System.out.println(localTable.getName() + " file(" + localWalker.getTableFileSize() + ") " + localSum1);
/* 109 */           for (localIterator2 = localWalker.getSums().iterator(); localIterator2.hasNext(); ) { localSum2 = (Sum)localIterator2.next();
/* 110 */             System.out.println("\t\t" + localSum2);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     Iterator localIterator2;
/*     */     Sum localSum2;
/*     */   }
/*     */ 
/*     */   public Stat(String paramString1, String paramString2, boolean paramBoolean)
/*     */   {
/* 130 */     this(paramString1, paramString2, DEFAULT_THREADPOOLSIZE, DEFAULT_CAPACITYOFQUEUE, paramBoolean, DatabaseMetaData.getInstance());
/*     */   }
/*     */ 
/*     */   public Stat(String paramString1, String paramString2, int paramInt1, int paramInt2, boolean paramBoolean, DatabaseMetaData paramDatabaseMetaData)
/*     */   {
/* 143 */     this.threadPoolSize = paramInt1;
/* 144 */     this.capacityOfQueue = paramInt2;
/* 145 */     this.isConcurrent = paramBoolean;
/* 146 */     this.databaseMetaData = paramDatabaseMetaData;
/*     */ 
/* 148 */     Dbx.start(paramString1);
/* 149 */     this.dbx = Dbx.open(new File(paramString2), paramDatabaseMetaData);
/*     */   }
/*     */ 
/*     */   public TableBrowser newTableBrowser(String paramString, TableHandle paramTableHandle)
/*     */   {
/* 163 */     if (null == paramTableHandle) {
/* 164 */       throw new NullPointerException();
/*     */     }
/* 166 */     DatabaseMetaData.Table localTable = this.databaseMetaData.getTable(paramString);
/*     */ 
/* 168 */     if (null == localTable) {
/* 169 */       throw new RuntimeException("table not found: " + paramString);
/*     */     }
/*     */ 
/* 172 */     if (!localTable.isPersistence()) {
/* 173 */       throw new RuntimeException("table is not persistence: " + paramString);
/*     */     }
/* 175 */     Dbx.Table localTable1 = this.dbx.openTable(paramString);
/* 176 */     Walker localWalker = newWalker(this, localTable1, paramTableHandle);
/* 177 */     TableBrowser localTableBrowser = new TableBrowser(localWalker);
/* 178 */     paramTableHandle.tableBrowser = localTableBrowser;
/* 179 */     return localTableBrowser;
/*     */   }
/*     */ 
/*     */   public static void perform(List<TableBrowser> paramList, int paramInt)
/*     */     throws InterruptedException
/*     */   {
/*     */     Object localObject1;
/*     */     Object localObject2;
/* 217 */     if (paramInt > 1) {
/* 218 */       localObject1 = new ThreadPoolExecutor(paramInt, paramInt, 0L, TimeUnit.NANOSECONDS, new LinkedBlockingQueue());
/*     */ 
/* 221 */       for (localObject2 = paramList.iterator(); ((Iterator)localObject2).hasNext(); ) { TableBrowser localTableBrowser = (TableBrowser)((Iterator)localObject2).next();
/* 222 */         ((ThreadPoolExecutor)localObject1).execute(localTableBrowser); }
/* 223 */       ((ThreadPoolExecutor)localObject1).shutdown();
/* 224 */       ((ThreadPoolExecutor)localObject1).awaitTermination(9223372036854775807L, TimeUnit.NANOSECONDS);
/*     */     } else {
/* 226 */       for (localObject1 = paramList.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (TableBrowser)((Iterator)localObject1).next();
/* 227 */         ((TableBrowser)localObject2).run(); }
/*     */     }
/*     */   }
/*     */ 
/*     */   public DatabaseMetaData getDatabaseMetaData() {
/* 232 */     return this.databaseMetaData;
/*     */   }
/*     */ 
/*     */   public int getCapacityOfQueue() {
/* 236 */     return this.capacityOfQueue;
/*     */   }
/*     */ 
/*     */   public int getThreadPoolSize() {
/* 240 */     return this.threadPoolSize;
/*     */   }
/*     */ 
/*     */   public boolean isConcurrent() {
/* 244 */     return this.isConcurrent;
/*     */   }
/*     */ 
/*     */   protected Walker newWalker(Stat paramStat, Dbx.Table paramTable, TableHandle paramTableHandle) {
/* 248 */     return new Walker(paramStat, paramTable, paramTableHandle);
/*     */   }
/*     */ 
/*     */   protected Task newTask(Walker paramWalker) {
/* 252 */     return new Task(paramWalker);
/*     */   }
/*     */ 
/*     */   public void lockConcurrent()
/*     */   {
/* 479 */     this.concurrentLock.lock();
/*     */   }
/*     */ 
/*     */   public void unlockConcurrent() {
/* 483 */     this.concurrentLock.unlock();
/*     */   }
/*     */ 
/*     */   public void setDebugLevel(int paramInt)
/*     */   {
/* 491 */     this.debugLevel = paramInt;
/*     */   }
/*     */ 
/*     */   public int getDebugLevel() {
/* 495 */     return this.debugLevel;
/*     */   }
/*     */ 
/*     */   public static class Task
/*     */     implements Runnable
/*     */   {
/*     */     private static final int BULKCOUNT = 1024;
/* 391 */     private byte[][] keys = new byte[1024][];
/* 392 */     private byte[][] values = new byte[1024][];
/* 393 */     private int size = 0;
/*     */     private Stat.Walker walker;
/*     */ 
/*     */     public Task(Stat.Walker paramWalker)
/*     */     {
/* 398 */       this.walker = paramWalker;
/*     */     }
/*     */ 
/*     */     public Stat.Walker getWalker() {
/* 402 */       return this.walker;
/*     */     }
/*     */ 
/*     */     public boolean prepare(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
/*     */     {
/* 411 */       this.keys[this.size] = paramArrayOfByte1;
/* 412 */       this.values[this.size] = paramArrayOfByte2;
/* 413 */       this.size += 1;
/* 414 */       return 1024 == this.size;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       try {
/* 420 */         _run();
/*     */       } catch (Throwable localThrowable) {
/* 422 */         getWalker().setFirstTaskException(localThrowable);
/* 423 */         if (getWalker().getStat().getDebugLevel() >= 5)
/* 424 */           localThrowable.printStackTrace();
/*     */       }
/*     */     }
/*     */ 
/*     */     private void _run() {
/* 429 */       Stat.Sum localSum = getWalker().getThreadLocalSum();
/*     */ 
/* 431 */       Elapse localElapse = new Elapse();
/* 432 */       localSum.recordCount += this.size;
/*     */ 
/* 435 */       byte[][] arrayOfByte = new byte[this.size][];
/* 436 */       for (int i = 0; i < this.size; i++) {
/* 437 */         localSum.totalKeySize += this.keys[i].length;
/* 438 */         localSum.totalCompressedValueSize += this.values[i].length;
/* 439 */         arrayOfByte[i] = Dbx.Table._uncompress(this.values[i], this.values[i].length);
/* 440 */         localSum.totalValueSize += arrayOfByte[i].length;
/*     */       }
/* 442 */       localSum.totalUncompressTime += localElapse.elapsedAndReset();
/*     */ 
/* 445 */       Dbx.Table localTable = getWalker().getTable();
/* 446 */       DatabaseMetaData.Type localType1 = localTable.getMetaData().getKeyType();
/* 447 */       DatabaseMetaData.Type localType2 = localTable.getMetaData().getValueType();
/* 448 */       Object[] arrayOfObject1 = new Object[this.size];
/* 449 */       Object[] arrayOfObject2 = new Object[this.size];
/* 450 */       for (int j = 0; j < this.size; j++) {
/* 451 */         arrayOfObject1[j] = localType1.unmarshal(this.keys[j]);
/* 452 */         arrayOfObject2[j] = localType2.unmarshal(arrayOfByte[j]);
/*     */       }
/* 454 */       localSum.totalUnmarshalTime += localElapse.elapsed();
/*     */ 
/* 457 */       boolean bool = getWalker().getStat().isConcurrent();
/* 458 */       Stat.TableHandle localTableHandle = getWalker().getTableHandle();
/* 459 */       if (bool)
/* 460 */         getWalker().getStat().lockConcurrent();
/*     */       try
/*     */       {
/* 463 */         localElapse.reset();
/* 464 */         for (int k = 0; k < this.size; k++) {
/* 465 */           localTableHandle.process(arrayOfObject1[k], arrayOfObject2[k]);
/*     */         }
/* 467 */         localSum.totalProcessTime += localElapse.elapsed();
/*     */       } finally {
/* 469 */         if (bool)
/* 470 */           getWalker().getStat().unlockConcurrent();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Walker
/*     */     implements Storage.IWalk
/*     */   {
/*     */     private Stat stat;
/*     */     private Dbx.Table table;
/*     */     private Stat.TableHandle handle;
/*     */     private ThreadPoolExecutor executor;
/* 299 */     private Stat.Task task = null;
/* 300 */     private volatile Throwable firstTaskException = null;
/*     */ 
/* 302 */     private List<Stat.Sum> sums = Collections.synchronizedList(new ArrayList());
/* 303 */     private ThreadLocal<Stat.Sum> threadLocalSum = new ThreadLocal()
/*     */     {
/*     */       protected Stat.Sum initialValue() {
/* 306 */         Stat.Sum localSum = new Stat.Sum();
/* 307 */         Stat.Walker.this.sums.add(localSum);
/* 308 */         return localSum;
/*     */       }
/* 303 */     };
/*     */ 
/*     */     Stat.Sum getThreadLocalSum()
/*     */     {
/* 313 */       return (Stat.Sum)this.threadLocalSum.get();
/*     */     }
/*     */ 
/*     */     public Walker(Stat paramStat, Dbx.Table paramTable, Stat.TableHandle paramTableHandle) {
/* 317 */       this.stat = paramStat;
/* 318 */       this.table = paramTable;
/* 319 */       this.handle = paramTableHandle;
/* 320 */       int i = paramStat.getThreadPoolSize();
/* 321 */       this.executor = new ThreadPoolExecutor(i, i, 0L, TimeUnit.NANOSECONDS, new LinkedBlockingQueue(paramStat.getCapacityOfQueue()));
/*     */     }
/*     */ 
/*     */     public long getTableFileSize()
/*     */     {
/* 327 */       return this.table.getFile().length();
/*     */     }
/*     */ 
/*     */     public Stat getStat() {
/* 331 */       return this.stat;
/*     */     }
/*     */ 
/*     */     public Dbx.Table getTable() {
/* 335 */       return this.table;
/*     */     }
/*     */ 
/*     */     public Stat.TableHandle getTableHandle() {
/* 339 */       return this.handle;
/*     */     }
/*     */ 
/*     */     public boolean onRecord(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
/*     */     {
/* 347 */       if (null == this.task) {
/* 348 */         this.task = this.stat.newTask(this);
/*     */       }
/* 350 */       if (this.task.prepare(paramArrayOfByte1, paramArrayOfByte2)) {
/* 351 */         this.executor.execute(this.task);
/* 352 */         this.task = null;
/*     */       }
/* 354 */       return null == this.firstTaskException;
/*     */     }
/*     */ 
/*     */     void setFirstTaskException(Throwable paramThrowable) {
/* 358 */       synchronized (this) {
/* 359 */         if (null != this.firstTaskException)
/* 360 */           return;
/* 361 */         this.firstTaskException = paramThrowable;
/*     */       }
/* 363 */       this.executor.shutdownNow();
/*     */     }
/*     */ 
/*     */     public Throwable getFirstTaskException() {
/* 367 */       return this.firstTaskException;
/*     */     }
/*     */ 
/*     */     public void awaitTermination() throws InterruptedException {
/* 371 */       if (null != this.task) {
/* 372 */         if (null == this.firstTaskException) try {
/* 373 */             this.executor.execute(this.task);
/*     */           } catch (Throwable localThrowable) {
/*     */           } this.task = null;
/*     */       }
/* 377 */       this.executor.shutdown();
/* 378 */       this.executor.awaitTermination(9223372036854775807L, TimeUnit.SECONDS);
/*     */     }
/*     */ 
/*     */     public List<Stat.Sum> getSums() {
/* 382 */       if (!this.executor.isTerminated())
/* 383 */         throw new IllegalStateException("walker is not terminated! table=" + this.table.getName());
/* 384 */       return this.sums;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Sum
/*     */   {
/* 259 */     public long recordCount = 0L;
/*     */ 
/* 261 */     public long totalKeySize = 0L;
/* 262 */     public long totalCompressedValueSize = 0L;
/* 263 */     public long totalValueSize = 0L;
/*     */ 
/* 265 */     public long totalUncompressTime = 0L;
/* 266 */     public long totalUnmarshalTime = 0L;
/* 267 */     public long totalProcessTime = 0L;
/*     */ 
/*     */     public void add(Sum paramSum) {
/* 270 */       this.recordCount += paramSum.recordCount;
/*     */ 
/* 272 */       this.totalKeySize += paramSum.totalKeySize;
/* 273 */       this.totalCompressedValueSize += paramSum.totalCompressedValueSize;
/* 274 */       this.totalValueSize += paramSum.totalValueSize;
/*     */ 
/* 276 */       this.totalUncompressTime += paramSum.totalUncompressTime;
/* 277 */       this.totalUnmarshalTime += paramSum.totalUnmarshalTime;
/* 278 */       this.totalProcessTime += paramSum.totalProcessTime;
/*     */     }
/*     */ 
/*     */     public static String headers() {
/* 282 */       return "RecordCount\tKeySize\tCompressedValueSize\tValueSize\tUncompressTime\tUnmarshalTime\tProcessTime";
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 287 */       return String.format("%d\t%d\t%d\t%d\t%d\t%d\t%d", new Object[] { Long.valueOf(this.recordCount), Long.valueOf(this.totalKeySize), Long.valueOf(this.totalCompressedValueSize), Long.valueOf(this.totalValueSize), Long.valueOf(this.totalUncompressTime), Long.valueOf(this.totalUnmarshalTime), Long.valueOf(this.totalProcessTime) });
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class TableBrowser
/*     */     implements Runnable
/*     */   {
/*     */     private Stat.Walker walker;
/* 184 */     private Throwable exception = null;
/*     */ 
/*     */     public TableBrowser(Stat.Walker paramWalker) {
/* 187 */       this.walker = paramWalker;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       try {
/* 193 */         this.walker.getTable()._browse(this.walker);
/* 194 */         this.walker.awaitTermination();
/* 195 */         this.exception = this.walker.getFirstTaskException();
/*     */       } catch (Throwable localThrowable) {
/* 197 */         this.exception = localThrowable;
/*     */       }
/*     */     }
/*     */ 
/*     */     public Stat.Walker getWalker() {
/* 202 */       return this.walker;
/*     */     }
/*     */ 
/*     */     public Throwable getException() {
/* 206 */       return this.exception;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class TableHandle
/*     */   {
/*     */     Stat.TableBrowser tableBrowser;
/*     */ 
/*     */     public Stat.TableBrowser getTableBrowser()
/*     */     {
/* 156 */       return this.tableBrowser;
/*     */     }
/*     */ 
/*     */     public abstract void process(Object paramObject1, Object paramObject2);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.Stat
 * JD-Core Version:    0.6.2
 */