/*    */ package xdb.util;
/*    */ 
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ 
/*    */ public class Misc
/*    */ {
/* 12 */   private static Misc misc = new Misc();
/*    */ 
/* 24 */   private volatile int concurrencyLevel = 256;
/*    */ 
/*    */   public static Misc getInstance()
/*    */   {
/* 15 */     return misc;
/*    */   }
/*    */ 
/*    */   public synchronized void setConcurrencyLevel(int paramInt)
/*    */   {
/* 30 */     this.concurrencyLevel = paramInt;
/*    */   }
/*    */ 
/*    */   public static <K, V> ConcurrentMap<K, V> newConcurrentMap() {
/* 34 */     return new ConcurrentHashMap(16, 0.75F, misc.concurrencyLevel);
/*    */   }
/*    */ 
/*    */   public static <K, V> ConcurrentMap<K, V> newConcurrentMap(int paramInt) {
/* 38 */     return new ConcurrentHashMap(paramInt, 0.75F, misc.concurrencyLevel);
/*    */   }
/*    */ 
/*    */   public static <K, V> ConcurrentMap<K, V> newConcurrentMap(int paramInt1, float paramFloat, int paramInt2)
/*    */   {
/* 43 */     return new ConcurrentHashMap(paramInt1, paramFloat, paramInt2);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.Misc
 * JD-Core Version:    0.6.2
 */