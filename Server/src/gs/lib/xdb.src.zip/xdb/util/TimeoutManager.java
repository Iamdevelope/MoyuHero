/*    */ package xdb.util;
/*    */ 
/*    */ import java.util.Map.Entry;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import xdb.Trace;
/*    */ 
/*    */ public final class TimeoutManager
/*    */   implements Runnable
/*    */ {
/* 21 */   private static TimeoutManager instance = new TimeoutManager();
/*    */ 
/* 32 */   private ConcurrentMap<Timeout, Long> targets = Misc.newConcurrentMap();
/*    */ 
/*    */   /** @deprecated */
/*    */   public static TimeoutManager getInstance()
/*    */   {
/* 28 */     return instance;
/*    */   }
/*    */ 
/*    */   public Timeout schedule(Timeout paramTimeout, long paramLong)
/*    */   {
/* 51 */     if (paramTimeout == null) {
/* 52 */       throw new NullPointerException();
/*    */     }
/* 54 */     if (paramLong < 0L) {
/* 55 */       paramLong = 0L;
/*    */     }
/* 57 */     this.targets.put(paramTimeout, Long.valueOf(System.currentTimeMillis() + paramLong));
/* 58 */     return paramTimeout;
/*    */   }
/*    */ 
/*    */   public boolean remove(Timeout paramTimeout)
/*    */   {
/* 67 */     return null != this.targets.remove(paramTimeout);
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public void run()
/*    */   {
/* 74 */     long l = System.currentTimeMillis();
/* 75 */     for (Map.Entry localEntry : this.targets.entrySet()) {
/* 76 */       Timeout localTimeout = (Timeout)localEntry.getKey();
/* 77 */       if ((((Long)localEntry.getValue()).longValue() <= l) && (remove(localTimeout)))
/*    */         try {
/* 79 */           localTimeout.onTimeout();
/*    */         } catch (Throwable localThrowable) {
/* 81 */           Trace.error("Timeout.target.run", localThrowable);
/*    */         }
/*    */     }
/*    */   }
/*    */ 
/*    */   public int size()
/*    */   {
/* 91 */     return this.targets.size();
/*    */   }
/*    */ 
/*    */   public void clear() {
/* 95 */     this.targets.clear();
/*    */   }
/*    */ 
/*    */   public static abstract interface Timeout
/*    */   {
/*    */     public abstract void onTimeout();
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.TimeoutManager
 * JD-Core Version:    0.6.2
 */