/*     */ package xdb.util;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ 
/*     */ public final class WeakHashSet<K>
/*     */ {
/*     */   private static final int DEFAULT_INITIAL_CAPACITY = 256;
/*     */   private static final int MAXIMUM_CAPACITY = 1073741824;
/*     */   private static final float DEFAULT_LOAD_FACTOR = 0.75F;
/*     */   private Entry[] table;
/*     */   private int size;
/*     */   private int threshold;
/*     */   private final float loadFactor;
/*     */ 
/*     */   public WeakHashSet(int paramInt, float paramFloat)
/*     */   {
/*  54 */     if (paramInt < 0) {
/*  55 */       throw new IllegalArgumentException("Illegal Initial Capacity: " + paramInt);
/*     */     }
/*  57 */     if (paramInt > 1073741824) {
/*  58 */       paramInt = 1073741824;
/*     */     }
/*  60 */     if ((paramFloat <= 0.0F) || (Float.isNaN(paramFloat))) {
/*  61 */       throw new IllegalArgumentException("Illegal Load factor: " + paramFloat);
/*     */     }
/*  63 */     int i = 1;
/*  64 */     while (i < paramInt)
/*  65 */       i <<= 1;
/*  66 */     this.table = new Entry[i];
/*  67 */     this.loadFactor = paramFloat;
/*  68 */     this.threshold = ((int)(i * paramFloat));
/*     */   }
/*     */ 
/*     */   public WeakHashSet(int paramInt)
/*     */   {
/*  79 */     this(paramInt, 0.75F);
/*     */   }
/*     */ 
/*     */   public WeakHashSet()
/*     */   {
/*  87 */     this.loadFactor = 0.75F;
/*  88 */     this.threshold = 256;
/*  89 */     this.table = new Entry[256];
/*     */   }
/*     */ 
/*     */   private static int hash(int paramInt)
/*     */   {
/* 103 */     paramInt ^= paramInt >>> 20 ^ paramInt >>> 12;
/* 104 */     return paramInt ^ paramInt >>> 7 ^ paramInt >>> 4;
/*     */   }
/*     */ 
/*     */   private static int indexFor(int paramInt1, int paramInt2)
/*     */   {
/* 111 */     return paramInt1 & paramInt2 - 1;
/*     */   }
/*     */ 
/*     */   private void expungeStaleEntries()
/*     */   {
/* 119 */     int i = this.table.length;
/* 120 */     for (int j = 0; j < i; j++) {
/* 121 */       Object localObject1 = this.table[j];
/* 122 */       if (localObject1 != null)
/*     */       {
/* 124 */         Object localObject2 = null;
/* 125 */         while (localObject1 != null) {
/* 126 */           Object localObject3 = ((Entry)localObject1).get();
/* 127 */           Entry localEntry = ((Entry)localObject1).next;
/* 128 */           if (localObject3 == null) {
/* 129 */             if (localObject2 == null)
/* 130 */               this.table[j] = localEntry;
/*     */             else
/* 132 */               ((Entry)localObject2).next = localEntry;
/* 133 */             ((Entry)localObject1).next = null;
/* 134 */             this.size -= 1;
/*     */           } else {
/* 136 */             localObject2 = localObject1;
/*     */           }
/* 138 */           localObject1 = localEntry;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 150 */     return this.size;
/*     */   }
/*     */ 
/*     */   public K get(K paramK)
/*     */   {
/* 161 */     if (paramK == null) throw new NullPointerException();
/* 162 */     int i = hash(paramK.hashCode());
/* 163 */     int j = indexFor(i, this.table.length);
/* 164 */     Object localObject1 = null;
/* 165 */     Object localObject2 = this.table[j];
/* 166 */     while (localObject2 != null) {
/* 167 */       Object localObject3 = ((Entry)localObject2).get();
/* 168 */       Entry localEntry = ((Entry)localObject2).next;
/* 169 */       if (localObject3 == null) {
/* 170 */         this.size -= 1;
/* 171 */         ((Entry)localObject2).next = null;
/*     */ 
/* 173 */         if (localObject1 == null)
/* 174 */           this.table[j] = localEntry;
/*     */         else
/* 176 */           ((Entry)localObject1).next = localEntry;
/*     */       } else {
/* 178 */         if ((i == ((Entry)localObject2).hash) && (paramK.equals(localObject3)))
/* 179 */           return localObject3;
/* 180 */         localObject1 = localObject2;
/*     */       }
/* 182 */       localObject2 = localEntry;
/*     */     }
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */   public K add(K paramK)
/*     */   {
/* 200 */     if (paramK == null) throw new NullPointerException();
/* 201 */     int i = hash(paramK.hashCode());
/* 202 */     int j = indexFor(i, this.table.length);
/* 203 */     Object localObject1 = null;
/* 204 */     Object localObject2 = this.table[j];
/* 205 */     while (localObject2 != null) {
/* 206 */       Object localObject3 = ((Entry)localObject2).get();
/* 207 */       Entry localEntry = ((Entry)localObject2).next;
/* 208 */       if (localObject3 == null) {
/* 209 */         this.size -= 1;
/* 210 */         ((Entry)localObject2).next = null;
/*     */ 
/* 212 */         if (localObject1 == null)
/* 213 */           this.table[j] = localEntry;
/*     */         else
/* 215 */           ((Entry)localObject1).next = localEntry;
/*     */       } else {
/* 217 */         if ((i == ((Entry)localObject2).hash) && (paramK.equals(localObject3)))
/* 218 */           return localObject3;
/* 219 */         localObject1 = localObject2;
/*     */       }
/* 221 */       localObject2 = localEntry;
/*     */     }
/*     */ 
/* 224 */     this.table[j] = new Entry(paramK, i, this.table[j]);
/* 225 */     if (++this.size >= this.threshold) {
/* 226 */       expungeStaleEntries();
/* 227 */       if (this.size >= this.threshold)
/* 228 */         resize();
/*     */     }
/* 230 */     return paramK;
/*     */   }
/*     */ 
/*     */   private void resize()
/*     */   {
/* 249 */     int i = this.table.length;
/* 250 */     if (i == 1073741824) {
/* 251 */       this.threshold = 2147483647;
/* 252 */       return;
/*     */     }
/* 254 */     int j = i + i;
/* 255 */     Entry[] arrayOfEntry = new Entry[j];
/*     */ 
/* 257 */     for (int k = 0; k < i; k++) {
/* 258 */       Object localObject1 = this.table[k];
/* 259 */       while (localObject1 != null) {
/* 260 */         Entry localEntry = ((Entry)localObject1).next;
/* 261 */         Object localObject2 = ((Entry)localObject1).get();
/* 262 */         if (localObject2 == null) {
/* 263 */           ((Entry)localObject1).next = null;
/* 264 */           this.size -= 1;
/*     */         } else {
/* 266 */           int m = indexFor(((Entry)localObject1).hash, j);
/* 267 */           ((Entry)localObject1).next = arrayOfEntry[m];
/* 268 */           arrayOfEntry[m] = localObject1;
/*     */         }
/* 270 */         localObject1 = localEntry;
/*     */       }
/*     */     }
/* 273 */     this.table = arrayOfEntry;
/* 274 */     this.threshold = ((int)(j * this.loadFactor));
/*     */   }
/*     */ 
/*     */   private static final class Entry<K> extends WeakReference<K>
/*     */   {
/*     */     private final int hash;
/*     */     private Entry<K> next;
/*     */ 
/*     */     Entry(K paramK, int paramInt, Entry<K> paramEntry)
/*     */     {
/* 289 */       super();
/* 290 */       this.hash = paramInt;
/* 291 */       this.next = paramEntry;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.WeakHashSet
 * JD-Core Version:    0.6.2
 */