/*     */ package xdb.util;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import xdb.Angel;
/*     */ import xdb.Worker;
/*     */ 
/*     */ public class ScheduledTimeoutExecutor extends ScheduledThreadPoolExecutor
/*     */ {
/*     */   private volatile long defaultTimeout;
/*     */ 
/*     */   public synchronized void setDefaultTimeout(long paramLong)
/*     */   {
/*  18 */     this.defaultTimeout = paramLong;
/*     */   }
/*     */ 
/*     */   public long getDefaultTimeout() {
/*  22 */     return this.defaultTimeout;
/*     */   }
/*     */ 
/*     */   public ScheduledTimeoutExecutor(long paramLong, int paramInt, ThreadFactory paramThreadFactory)
/*     */   {
/*  27 */     super(paramInt);
/*  28 */     super.setThreadFactory(paramThreadFactory);
/*  29 */     this.defaultTimeout = paramLong;
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable paramRunnable, long paramLong)
/*     */   {
/*  44 */     Worker.debugHunger(this);
/*  45 */     return super.schedule(Angel.decorateCallable(paramRunnable, paramLong), 0L, TimeUnit.NANOSECONDS);
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Runnable paramRunnable, T paramT, long paramLong)
/*     */   {
/*  52 */     Worker.debugHunger(this);
/*  53 */     return super.schedule(Angel.decorate(paramRunnable, paramT, paramLong), 0L, TimeUnit.NANOSECONDS);
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> paramCallable, long paramLong)
/*     */   {
/*  60 */     Worker.debugHunger(this);
/*  61 */     return super.schedule(Angel.decorate(paramCallable, paramLong), 0L, TimeUnit.NANOSECONDS);
/*     */   }
/*     */ 
/*     */   public void execute(Runnable paramRunnable, long paramLong)
/*     */   {
/*  68 */     super.schedule(Angel.decorateCallable(paramRunnable, paramLong), 0L, TimeUnit.NANOSECONDS);
/*     */   }
/*     */ 
/*     */   public <V> ScheduledFuture<V> schedule(Callable<V> paramCallable, long paramLong1, TimeUnit paramTimeUnit, long paramLong2)
/*     */   {
/*  75 */     return super.schedule(Angel.decorate(paramCallable, paramLong2), paramLong1, paramTimeUnit);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> schedule(Runnable paramRunnable, long paramLong1, TimeUnit paramTimeUnit, long paramLong2)
/*     */   {
/*  82 */     return super.schedule(Angel.decorateCallable(paramRunnable, paramLong2), paramLong1, paramTimeUnit);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable paramRunnable, long paramLong1, long paramLong2, TimeUnit paramTimeUnit, long paramLong3)
/*     */   {
/*  89 */     return super.scheduleAtFixedRate(Angel.decorateRunnable(paramRunnable, paramLong3), paramLong1, paramLong2, paramTimeUnit);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable paramRunnable, long paramLong1, long paramLong2, TimeUnit paramTimeUnit, long paramLong3)
/*     */   {
/*  96 */     return super.scheduleWithFixedDelay(Angel.decorateRunnable(paramRunnable, paramLong3), paramLong1, paramLong2, paramTimeUnit);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable paramRunnable)
/*     */   {
/* 104 */     Worker.debugHunger(this);
/* 105 */     return super.schedule(Angel.decorateCallable(paramRunnable, this.defaultTimeout), 0L, TimeUnit.NANOSECONDS);
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Runnable paramRunnable, T paramT)
/*     */   {
/* 110 */     Worker.debugHunger(this);
/* 111 */     return super.schedule(Angel.decorate(paramRunnable, paramT, this.defaultTimeout), 0L, TimeUnit.NANOSECONDS);
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> paramCallable)
/*     */   {
/* 116 */     Worker.debugHunger(this);
/* 117 */     return super.schedule(Angel.decorate(paramCallable, this.defaultTimeout), 0L, TimeUnit.NANOSECONDS);
/*     */   }
/*     */ 
/*     */   public void execute(Runnable paramRunnable)
/*     */   {
/* 122 */     super.schedule(Angel.decorateCallable(paramRunnable, this.defaultTimeout), 0L, TimeUnit.NANOSECONDS);
/*     */   }
/*     */ 
/*     */   public <V> ScheduledFuture<V> schedule(Callable<V> paramCallable, long paramLong, TimeUnit paramTimeUnit)
/*     */   {
/* 127 */     return super.schedule(Angel.decorate(paramCallable, this.defaultTimeout), paramLong, paramTimeUnit);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> schedule(Runnable paramRunnable, long paramLong, TimeUnit paramTimeUnit)
/*     */   {
/* 132 */     return super.schedule(Angel.decorateCallable(paramRunnable, this.defaultTimeout), paramLong, paramTimeUnit);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable paramRunnable, long paramLong1, long paramLong2, TimeUnit paramTimeUnit)
/*     */   {
/* 137 */     return super.scheduleAtFixedRate(Angel.decorateRunnable(paramRunnable, this.defaultTimeout), paramLong1, paramLong2, paramTimeUnit);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable paramRunnable, long paramLong1, long paramLong2, TimeUnit paramTimeUnit)
/*     */   {
/* 142 */     return super.scheduleWithFixedDelay(Angel.decorateRunnable(paramRunnable, this.defaultTimeout), paramLong1, paramLong2, paramTimeUnit);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.ScheduledTimeoutExecutor
 * JD-Core Version:    0.6.2
 */