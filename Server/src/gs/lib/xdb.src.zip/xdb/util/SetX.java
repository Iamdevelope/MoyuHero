/*    */ package xdb.util;
/*    */ 
/*    */ import java.util.AbstractSet;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 
/*    */ public final class SetX<E> extends AbstractSet<E>
/*    */   implements Set<E>
/*    */ {
/*    */   private transient HashMap<E, E> map;
/*    */ 
/*    */   public SetX()
/*    */   {
/* 17 */     this.map = new HashMap();
/*    */   }
/*    */ 
/*    */   public SetX(int paramInt) {
/* 21 */     this.map = new HashMap(paramInt);
/*    */   }
/*    */ 
/*    */   public SetX(int paramInt, float paramFloat) {
/* 25 */     this.map = new HashMap(paramInt, paramFloat);
/*    */   }
/*    */ 
/*    */   public Iterator<E> iterator()
/*    */   {
/* 30 */     return this.map.keySet().iterator();
/*    */   }
/*    */ 
/*    */   public int size()
/*    */   {
/* 35 */     return this.map.size();
/*    */   }
/*    */ 
/*    */   public boolean isEmpty()
/*    */   {
/* 40 */     return this.map.isEmpty();
/*    */   }
/*    */ 
/*    */   public boolean contains(Object paramObject)
/*    */   {
/* 45 */     return this.map.containsKey(paramObject);
/*    */   }
/*    */ 
/*    */   public boolean add(E paramE)
/*    */   {
/* 50 */     if (null == paramE)
/* 51 */       throw new NullPointerException();
/* 52 */     if (this.map.containsKey(paramE))
/* 53 */       return false;
/* 54 */     this.map.put(paramE, paramE);
/* 55 */     return true;
/*    */   }
/*    */ 
/*    */   public E removex(Object paramObject) {
/* 59 */     return this.map.remove(paramObject);
/*    */   }
/*    */ 
/*    */   public boolean remove(Object paramObject)
/*    */   {
/* 64 */     return null != removex(paramObject);
/*    */   }
/*    */ 
/*    */   public void clear()
/*    */   {
/* 69 */     this.map.clear();
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.SetX
 * JD-Core Version:    0.6.2
 */