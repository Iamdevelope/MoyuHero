/*     */ package xdb.util;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import xdb.Logger;
/*     */ import xdb.Storage;
/*     */ import xdb.Storage.IWalk;
/*     */ import xdb.TableConf;
/*     */ import xdb.Trace;
/*     */ import xdb.XLockInterrupted;
/*     */ import xdb.Xdb;
/*     */ 
/*     */ public class Dbx
/*     */ {
/* 216 */   private static final Manager manager = new Manager();
/*     */ 
/* 238 */   private final Lock dbLock = new ReentrantLock();
/*     */   private final File home;
/*     */   private final File tableHome;
/*     */   private final File logHome;
/*     */   private final DatabaseMetaData metaData;
/* 243 */   private final Map<String, Table> tables = new HashMap();
/* 244 */   private boolean closed = false;
/*     */ 
/* 735 */   private TimerTask autoSaveTask = null;
/*     */ 
/*     */   public static void load(File paramFile1, File paramFile2, String paramString)
/*     */   {
/*  27 */     if (null == paramString) {
/*  28 */       paramString = System.mapLibraryName("db_" + System.getProperty("os.arch"));
/*     */     }
/*  30 */     InputStream localInputStream = ClassLoader.getSystemClassLoader().getResourceAsStream(paramString);
/*  31 */     if (null != localInputStream) {
/*     */       try {
/*  33 */         String str1 = paramString;
/*  34 */         String str3 = null;
/*  35 */         int i = paramString.lastIndexOf(".");
/*  36 */         if (-1 != i) {
/*  37 */           str1 = paramString.substring(0, i);
/*  38 */           str3 = paramString.substring(i);
/*     */         }
/*  40 */         File localFile = File.createTempFile(str1, str3, new File(System.getProperty("java.io.tmpdir")));
/*  41 */         String str4 = localFile.getAbsolutePath();
/*  42 */         FileOutputStream localFileOutputStream = new FileOutputStream(localFile);
/*     */         try {
/*  44 */           byte[] arrayOfByte = new byte[8192];
/*  45 */           int j = 0;
/*  46 */           while ((j = localInputStream.read(arrayOfByte)) > 0) {
/*  47 */             localFileOutputStream.write(arrayOfByte, 0, j);
/*     */           }
/*  49 */           Trace.info("System.load(" + str4 + ")");
/*  50 */           System.load(str4);
/*     */         } finally {
/*  52 */           localFileOutputStream.close();
/*  53 */           localFile.delete();
/*     */         }
/*     */       } catch (IOException localIOException2) {
/*  56 */         throw new RuntimeException(localIOException2);
/*     */       } finally {
/*     */         try {
/*  59 */           localInputStream.close();
/*     */         } catch (IOException localIOException3) {
/*     */         }
/*     */       }
/*     */     } else {
/*  64 */       String str2 = null != paramFile1 ? new File(paramFile1, paramString).getAbsolutePath() : new File(paramFile2.getParentFile(), paramString).getAbsolutePath();
/*     */ 
/*  67 */       Trace.info("System.load(" + str2 + ")");
/*  68 */       System.load(str2);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void load(File paramFile1, File paramFile2) {
/*  73 */     load(paramFile1, paramFile2, null);
/*     */   }
/*     */ 
/*     */   public static void load(String paramString) {
/*  77 */     load(new File(paramString), null, null);
/*     */   }
/*     */ 
/*     */   public static Manager getManager()
/*     */   {
/* 219 */     return manager;
/*     */   }
/*     */ 
/*     */   public static boolean start(String paramString) {
/* 223 */     return manager.start(paramString, true);
/*     */   }
/*     */ 
/*     */   public static void stop() {
/* 227 */     manager.stop();
/*     */   }
/*     */ 
/*     */   public static Dbx open(File paramFile, DatabaseMetaData paramDatabaseMetaData) {
/* 231 */     if (!manager.isOpen())
/* 232 */       throw new IllegalStateException("Dbx is stopped");
/* 233 */     return manager.open(paramFile, paramDatabaseMetaData);
/*     */   }
/*     */ 
/*     */   private Dbx(File paramFile, DatabaseMetaData paramDatabaseMetaData)
/*     */   {
/* 545 */     if (Xdb.isOpen()) {
/* 546 */       throw new IllegalAccessError("i hate xdb.");
/*     */     }
/* 548 */     if (new File(paramFile, "xdb.inuse").exists()) {
/* 549 */       throw new IllegalAccessError("xdb inuse.");
/*     */     }
/*     */ 
/* 553 */     new Integrity(null, paramFile).verify();
/*     */ 
/* 559 */     this.home = paramFile;
/* 560 */     this.tableHome = new File(paramFile, "dbdata");
/* 561 */     this.logHome = new File(paramFile, "dblogs");
/* 562 */     this.metaData = paramDatabaseMetaData;
/*     */ 
/* 564 */     this.tableHome.mkdirs();
/* 565 */     this.logHome.mkdirs();
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 572 */     this.dbLock.lock();
/*     */     try {
/* 574 */       if (false == this.closed)
/*     */       {
/* 576 */         for (Table localTable : getTables())
/* 577 */           localTable.destroy();
/* 578 */         getManager().removeDbx(this);
/* 579 */         this.closed = true;
/*     */       }
/*     */     } finally {
/* 582 */       this.dbLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 590 */     this.dbLock.lock();
/*     */     try {
/* 592 */       if (false == this.closed)
/*     */       {
/* 603 */         for (Table localTable : getTables()) {
/* 604 */           localTable.close();
/*     */         }
/* 606 */         getManager().removeDbx(this);
/* 607 */         this.closed = true;
/* 608 */         if ((!$assertionsDisabled) && (!this.tables.isEmpty())) throw new AssertionError(); 
/*     */       }
/*     */     }
/* 611 */     finally { this.dbLock.unlock(); }
/*     */ 
/*     */   }
/*     */ 
/*     */   public boolean isClosed()
/*     */   {
/* 620 */     this.dbLock.lock();
/*     */     try {
/* 622 */       return this.closed;
/*     */     } finally {
/* 624 */       this.dbLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public File getHome()
/*     */   {
/* 632 */     return this.home;
/*     */   }
/*     */ 
/*     */   public DatabaseMetaData getMetaData() {
/* 636 */     return this.metaData;
/*     */   }
/*     */ 
/*     */   public Table[] getTables()
/*     */   {
/* 644 */     this.dbLock.lock();
/*     */     try {
/* 646 */       return (Table[])this.tables.values().toArray(new Table[this.tables.size()]);
/*     */     } finally {
/* 648 */       this.dbLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Table getTable(String paramString) {
/* 653 */     this.dbLock.lock();
/*     */     try {
/* 655 */       return (Table)this.tables.get(paramString);
/*     */     } finally {
/* 657 */       this.dbLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final Table removeTable(String paramString) {
/* 662 */     this.dbLock.lock();
/*     */     try {
/* 664 */       return (Table)this.tables.remove(paramString);
/*     */     } finally {
/* 666 */       this.dbLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Table openTable(String paramString)
/*     */   {
/* 673 */     return openTable(paramString, 512, 128);
/*     */   }
/*     */ 
/*     */   public Table openTable(TableConf paramTableConf)
/*     */   {
/* 680 */     return openTable(paramTableConf.getName(), paramTableConf.getCacheHigh(), paramTableConf.getCacheLow());
/*     */   }
/*     */ 
/*     */   public Table newTable(String paramString)
/*     */   {
/* 689 */     return newTable(paramString, 512, 128);
/*     */   }
/*     */ 
/*     */   public Table newTable(String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 700 */     if (null != this.metaData.getTable(paramString))
/* 701 */       throw new IllegalStateException("table in MetaData: " + paramString);
/* 702 */     return _openTable(paramString, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   public Table openTable(String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 709 */     if (null == this.metaData.getTable(paramString))
/* 710 */       throw new IllegalStateException("table not found in MetaData: " + paramString);
/* 711 */     return _openTable(paramString, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   private Table _openTable(String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 718 */     this.dbLock.lock();
/*     */     try {
/* 720 */       if (this.closed)
/* 721 */         throw new IllegalStateException("Database has closed.");
/* 722 */       Table localTable1 = (Table)this.tables.get(paramString);
/* 723 */       if (null == localTable1) {
/* 724 */         localTable1 = new Table(new Logger(), paramString, paramInt1, paramInt2);
/* 725 */         this.tables.put(paramString, localTable1);
/*     */       }
/* 727 */       return localTable1;
/*     */     } finally {
/* 729 */       this.dbLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void save()
/*     */   {
/* 742 */     this.dbLock.lock();
/*     */     try {
/* 744 */       if (this.closed) {
/* 745 */         throw new IllegalStateException("Database has closed.");
/*     */       }
/* 747 */       for (Table localTable : this.tables.values())
/* 748 */         localTable.save();
/*     */     } finally {
/* 750 */       this.dbLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void lock() {
/* 755 */     this.dbLock.lock();
/*     */   }
/*     */ 
/*     */   public final void lockInterruptibly() {
/*     */     try {
/* 760 */       this.dbLock.lockInterruptibly();
/*     */     } catch (InterruptedException localInterruptedException) {
/* 762 */       throw new XLockInterrupted("DBNullLogger:" + this.tableHome);
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void unlock() {
/* 767 */     this.dbLock.unlock();
/*     */   }
/*     */ 
/*     */   public void setAutoSave(long paramLong)
/*     */   {
/* 776 */     this.dbLock.lock();
/*     */     try {
/* 778 */       if (null != this.autoSaveTask) {
/* 779 */         this.autoSaveTask.cancel();
/* 780 */         this.autoSaveTask = null;
/*     */       }
/* 782 */       if (paramLong > 0L) {
/* 783 */         this.autoSaveTask = new TimerTask()
/*     */         {
/*     */           public void run() {
/* 786 */             Dbx.this.save();
/*     */           }
/*     */         };
/* 789 */         getManager().getTimer().schedule(this.autoSaveTask, paramLong, paramLong);
/*     */       }
/*     */     } finally {
/* 792 */       this.dbLock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public class Table extends Storage
/*     */   {
/*     */     private final String name;
/*     */     private final DatabaseMetaData.Table metaData;
/* 253 */     private boolean walking = false;
/* 254 */     private boolean browsing = false;
/*     */ 
/*     */     Table(Logger paramString, String paramInt1, int paramInt2, int arg5) {
/* 257 */       super(Dbx.this.tableHome, paramInt1, paramInt2, i);
/* 258 */       this.name = paramInt1;
/* 259 */       this.metaData = Dbx.this.getMetaData().getTable(paramInt1);
/*     */     }
/*     */ 
/*     */     public Dbx getDatabase()
/*     */     {
/* 267 */       return Dbx.this;
/*     */     }
/*     */ 
/*     */     public DatabaseMetaData.Table getMetaData() {
/* 271 */       return this.metaData;
/*     */     }
/*     */ 
/*     */     public String getName()
/*     */     {
/* 277 */       return this.name;
/*     */     }
/*     */ 
/*     */     private void assertNotWalking()
/*     */     {
/* 284 */       if (this.walking)
/* 285 */         throw new ConcurrentModificationException("walking!");
/*     */     }
/*     */ 
/*     */     private void assertNotWalkingAndBrowsing()
/*     */     {
/* 300 */       if ((this.walking) || (this.browsing))
/* 301 */         throw new ConcurrentModificationException("walking or browsering!");
/*     */     }
/*     */ 
/*     */     public void save()
/*     */     {
/* 308 */       super.lock();
/*     */       try {
/* 310 */         assertNotWalkingAndBrowsing();
/*     */         try {
/* 312 */           getLogger().checkpoint(this, System.currentTimeMillis());
/*     */         } catch (Throwable localThrowable) {
/* 314 */           Trace.fatal("Table.save: halt program", localThrowable);
/* 315 */           Runtime.getRuntime().halt(54321);
/*     */         }
/*     */       } finally {
/* 318 */         super.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void destroy()
/*     */     {
/* 326 */       super.lock();
/*     */       try {
/* 328 */         assertNotWalkingAndBrowsing();
/* 329 */         Dbx.this.removeTable(getName());
/* 330 */         super.close();
/*     */       } finally {
/* 332 */         super.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/* 341 */       super.lock();
/*     */       try {
/* 343 */         assertNotWalkingAndBrowsing();
/* 344 */         save();
/* 345 */         Dbx.this.removeTable(getName());
/* 346 */         super.close();
/*     */       } finally {
/* 348 */         super.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean _insert(OctetsStream paramOctetsStream1, OctetsStream paramOctetsStream2)
/*     */     {
/* 359 */       super.lock();
/*     */       try {
/* 361 */         assertNotWalking();
/* 362 */         return super._insert(paramOctetsStream1, paramOctetsStream2);
/*     */       } finally {
/* 364 */         super.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean _replace(OctetsStream paramOctetsStream1, OctetsStream paramOctetsStream2)
/*     */     {
/* 375 */       super.lock();
/*     */       try {
/* 377 */         assertNotWalking();
/* 378 */         return super._replace(paramOctetsStream1, paramOctetsStream2);
/*     */       } finally {
/* 380 */         super.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean replace(OctetsStream paramOctetsStream1, OctetsStream paramOctetsStream2)
/*     */     {
/* 390 */       super.lock();
/*     */       try {
/* 392 */         assertNotWalking();
/* 393 */         return super.replace(paramOctetsStream1, paramOctetsStream2);
/*     */       } finally {
/* 395 */         super.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean insert(OctetsStream paramOctetsStream1, OctetsStream paramOctetsStream2)
/*     */     {
/* 405 */       super.lock();
/*     */       try {
/* 407 */         assertNotWalking();
/* 408 */         return super.insert(paramOctetsStream1, paramOctetsStream2);
/*     */       } finally {
/* 410 */         super.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean remove(OctetsStream paramOctetsStream)
/*     */     {
/* 420 */       super.lock();
/*     */       try {
/* 422 */         assertNotWalking();
/* 423 */         return super.remove(paramOctetsStream);
/*     */       } finally {
/* 425 */         super.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void _browse(Storage.IWalk paramIWalk, int paramInt)
/*     */     {
/* 436 */       super.lock();
/*     */       try
/*     */       {
/* 440 */         assertNotWalkingAndBrowsing();
/* 441 */         this.browsing = true;
/*     */         try {
/* 443 */           super._browse(paramIWalk, paramInt);
/*     */         } finally {
/* 445 */           this.browsing = false;
/*     */         }
/*     */       } finally {
/* 448 */         super.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void _browse(Storage.IWalk paramIWalk)
/*     */     {
/* 458 */       _browse(paramIWalk, 128);
/*     */     }
/*     */ 
/*     */     public void browse(Storage.IWalk paramIWalk)
/*     */     {
/* 467 */       browse(paramIWalk, 128);
/*     */     }
/*     */ 
/*     */     public void browse(Storage.IWalk paramIWalk, int paramInt)
/*     */     {
/* 477 */       super.lock();
/*     */       try
/*     */       {
/* 481 */         assertNotWalkingAndBrowsing();
/* 482 */         this.browsing = true;
/*     */         try {
/* 484 */           super.browse(paramIWalk, paramInt);
/*     */         } finally {
/* 486 */           this.browsing = false;
/*     */         }
/*     */       } finally {
/* 489 */         super.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void _walk(Storage.IWalk paramIWalk)
/*     */     {
/* 499 */       super.lock();
/*     */       try
/*     */       {
/* 503 */         assertNotWalkingAndBrowsing();
/* 504 */         this.walking = true;
/*     */         try {
/* 506 */           super._walk(paramIWalk);
/*     */         } finally {
/* 508 */           this.walking = false;
/*     */         }
/*     */       } finally {
/* 511 */         super.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void walk(Storage.IWalk paramIWalk)
/*     */     {
/* 521 */       super.lock();
/*     */       try
/*     */       {
/* 525 */         assertNotWalkingAndBrowsing();
/* 526 */         this.walking = true;
/*     */         try {
/* 528 */           super.walk(paramIWalk);
/*     */         } finally {
/* 530 */           this.walking = false;
/*     */         }
/*     */       } finally {
/* 533 */         super.unlock();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Manager
/*     */   {
/*  83 */     private final Lock lock = new ReentrantLock();
/*  84 */     private Map<String, Dbx> dbxs = new HashMap();
/*     */     private volatile Timer timer;
/*  86 */     private boolean opened = false;
/*  87 */     private volatile boolean saveAtExit = true;
/*     */ 
/*     */     public Manager() {
/*  90 */       Runtime.getRuntime().addShutdownHook(new Thread("xdb.util.Dbx.ShutdownHook")
/*     */       {
/*     */         public void run() {
/*  93 */           Dbx.Manager.this.stop();
/*     */         }
/*     */       });
/*     */     }
/*     */ 
/*     */     public boolean isOpen() {
/*  99 */       this.lock.lock();
/*     */       try {
/* 101 */         return this.opened;
/*     */       } finally {
/* 103 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean start(String paramString, boolean paramBoolean)
/*     */     {
/* 113 */       Trace.openIf();
/* 114 */       this.lock.lock();
/*     */       try
/*     */       {
/*     */         boolean bool;
/* 116 */         if (this.opened)
/* 117 */           return false;
/* 118 */         Trace.info("xdb.util.Dbx start ...");
/* 119 */         this.saveAtExit = paramBoolean;
/* 120 */         Dbx.load(paramString);
/* 121 */         this.timer = new Timer("xdb.util.Dbx.Timer", true);
/* 122 */         this.opened = true;
/* 123 */         return true;
/*     */       } finally {
/* 125 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void stop() {
/* 130 */       stop(this.saveAtExit);
/*     */     }
/*     */ 
/*     */     public void stop(boolean paramBoolean) {
/* 134 */       this.lock.lock();
/*     */       try {
/* 136 */         if (this.opened) {
/* 137 */           Trace.info("xdb.util.Dbx stop begin");
/*     */           Dbx localDbx;
/* 139 */           if (paramBoolean)
/* 140 */             for (localDbx : getDbxs()) localDbx.close();
/*     */           else
/* 142 */             for (localDbx : getDbxs()) localDbx.destroy();
/* 143 */           assert (getDbxs().length == 0);
/*     */ 
/* 145 */           this.timer.cancel();
/* 146 */           this.timer = null;
/* 147 */           this.opened = false;
/* 148 */           Trace.info("xdb.util.Dbx stop end");
/*     */         }
/*     */       } finally {
/* 151 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void setSaveAtExit(boolean paramBoolean) {
/* 156 */       this.saveAtExit = paramBoolean;
/*     */     }
/*     */ 
/*     */     public Timer getTimer() {
/* 160 */       return this.timer;
/*     */     }
/*     */ 
/*     */     public Dbx open(File paramFile, DatabaseMetaData paramDatabaseMetaData)
/*     */     {
/* 170 */       String str = toCanonicalPath(paramFile);
/* 171 */       this.lock.lock();
/*     */       try {
/* 173 */         Dbx localDbx1 = (Dbx)this.dbxs.get(str);
/* 174 */         if (null == localDbx1) {
/* 175 */           localDbx1 = new Dbx(paramFile, paramDatabaseMetaData, null);
/* 176 */           this.dbxs.put(str, localDbx1);
/*     */         }
/* 178 */         return localDbx1;
/*     */       } finally {
/* 180 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     private static String toCanonicalPath(File paramFile)
/*     */     {
/*     */       try {
/* 187 */         return paramFile.getCanonicalPath();
/*     */       } catch (IOException localIOException) {
/* 189 */         throw new RuntimeException(localIOException);
/*     */       }
/*     */     }
/*     */ 
/*     */     public Dbx[] getDbxs() {
/* 194 */       this.lock.lock();
/*     */       try {
/* 196 */         return (Dbx[])this.dbxs.values().toArray(new Dbx[this.dbxs.size()]);
/*     */       } finally {
/* 198 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     private void removeDbx(Dbx paramDbx)
/*     */     {
/* 205 */       String str = toCanonicalPath(paramDbx.getHome());
/* 206 */       this.lock.lock();
/*     */       try {
/* 208 */         this.dbxs.remove(str);
/*     */       } finally {
/* 210 */         this.lock.unlock();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.Dbx
 * JD-Core Version:    0.6.2
 */