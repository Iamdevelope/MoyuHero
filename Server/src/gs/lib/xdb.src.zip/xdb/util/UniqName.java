/*     */ package xdb.util;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.Marshal;
/*     */ import com.goldhuman.Common.Marshal.MarshalException;
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import com.goldhuman.Common.Octets;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import xdb.Log;
/*     */ import xdb.LogKey;
/*     */ import xdb.Savepoint;
/*     */ import xdb.Trace;
/*     */ import xdb.Transaction;
/*     */ import xdb.XBean;
/*     */ import xdb.Xdb;
/*     */ import xdb.XdbConf;
/*     */ import xio.Engine;
/*     */ import xio.Manager;
/*     */ import xio.Rpc;
/*     */ import xio.Rpc.FutureX;
/*     */ import xio.XioConf;
/*     */ import xio.rpc.Int;
/*     */ import xio.rpc.LongInt;
/*     */ 
/*     */ public final class UniqName
/*     */ {
/*     */   private static volatile UniqNameConf conf;
/*     */   private static volatile Manager manager;
/* 175 */   private static Map<String, XBean> virtual = new HashMap();
/*     */   public static final int RPC_OK = 12345;
/*     */   public static final int RPC_DUPLICATE = 1;
/*     */   public static final int RPC_NOT_EXISTS = 2;
/*     */   public static final int RPC_EXCEPTION = 4;
/*     */   public static final int RPC_GROUP_NOT_EXISTS = 5;
/*     */   public static final int RPC_CONFIRM_STATE = 6;
/*     */   public static final int RPC_ALLOCID_ERROR = 7;
/*     */ 
/*     */   public static void initialize()
/*     */   {
/*  19 */     initialize(Xdb.getInstance().getConf().getUniqNameConf());
/*     */   }
/*     */ 
/*     */   public static void initialize(UniqNameConf paramUniqNameConf)
/*     */   {
/*  29 */     conf = paramUniqNameConf;
/*  30 */     manager = paramUniqNameConf.getXioConf().getManager("Client");
/*  31 */     Engine.getInstance().register(paramUniqNameConf.getXioConf());
/*     */   }
/*     */ 
/*     */   public static void uninitialize() {
/*  35 */     conf = null;
/*  36 */     manager = null;
/*     */   }
/*     */ 
/*     */   public static boolean allocate(String paramString1, String paramString2)
/*     */   {
/*  51 */     GroupName localGroupName = new GroupName(paramString1, paramString2);
/*  52 */     int i = ((Int)new Allocate(localGroupName).submit(manager).get()).getValue();
/*  53 */     if (12345 == i)
/*     */     {
/*  57 */       Savepoint localSavepoint = Transaction.currentSavepoint();
/*  58 */       localSavepoint.addIfAbsent(new LogKey(getVirtualBean(paramString1), paramString2), new NameLog(localGroupName));
/*  59 */       return true;
/*     */     }
/*  61 */     Trace.warn("UniqName.Allocate " + localGroupName + " rc=" + i);
/*  62 */     return false;
/*     */   }
/*     */ 
/*     */   public static void release(String paramString1, String paramString2)
/*     */   {
/*  74 */     release(new GroupName(paramString1, paramString2));
/*     */   }
/*     */ 
/*     */   public static void release(GroupName paramGroupName)
/*     */   {
/*     */     try
/*     */     {
/*  85 */       int i = ((Int)new Release(paramGroupName).submit(manager).get()).getValue();
/*  86 */       if (i != 12345)
/*  87 */         Trace.error("UniqName.Release " + paramGroupName + " rc=" + i);
/*     */     }
/*     */     catch (Throwable localThrowable) {
/*  90 */       Trace.error("UniqName.Release " + paramGroupName, localThrowable);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int exist(String paramString1, String paramString2)
/*     */   {
/* 103 */     return ((Int)new Exist(paramString1, paramString2).submit(manager).get()).getValue();
/*     */   }
/*     */ 
/*     */   public static Long allocateId(String paramString, long paramLong)
/*     */   {
/* 122 */     LongInt localLongInt = (LongInt)new AllocateId(paramString, paramLong).submit(manager).get();
/* 123 */     if (12345 == localLongInt.getCode())
/*     */     {
/* 126 */       Savepoint localSavepoint = Transaction.currentSavepoint();
/* 127 */       localSavepoint.addIfAbsent(new LogKey(getVirtualBean(paramString), String.valueOf(localLongInt.getValue())), new IdLog(new GroupId(paramString, localLongInt.getValue())));
/*     */ 
/* 129 */       return Long.valueOf(localLongInt.getValue());
/*     */     }
/* 131 */     if (Trace.isInfoEnabled())
/* 132 */       Trace.info("UniqName.AllocateId(" + paramString + "," + paramLong + ") rc=" + localLongInt.getCode());
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   public static Long allocateId(String paramString)
/*     */   {
/* 147 */     return allocateId(paramString, 0L);
/*     */   }
/*     */ 
/*     */   public static void releaseId(String paramString, long paramLong)
/*     */   {
/* 156 */     releaseId(new GroupId(paramString, paramLong));
/*     */   }
/*     */ 
/*     */   public static void releaseId(GroupId paramGroupId)
/*     */   {
/*     */     try
/*     */     {
/* 165 */       int i = ((Int)new ReleaseId(paramGroupId).submit(manager).get()).getValue();
/* 166 */       if (i != 12345)
/* 167 */         Trace.error("UniqName.ReleaseId " + paramGroupId + " rc=" + i);
/*     */     }
/*     */     catch (Throwable localThrowable) {
/* 170 */       Trace.error("UniqName.ReleaseId " + paramGroupId, localThrowable);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static XBean getVirtualBean(String paramString)
/*     */   {
/* 178 */     synchronized (virtual) {
/* 179 */       XBean localXBean = (XBean)virtual.get(paramString);
/* 180 */       if (null == localXBean)
/* 181 */         virtual.put(paramString, localXBean = new XBean(null, null));
/* 182 */       return localXBean;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class ReleaseId extends Rpc<UniqName.GroupId, Int>
/*     */   {
/*     */     public ReleaseId()
/*     */     {
/* 428 */       setArgument(new UniqName.GroupId()).setResult(new Int());
/*     */     }
/*     */     public ReleaseId(String paramString, long paramLong) {
/* 431 */       setArgument(new UniqName.GroupId(paramString, paramLong)).setResult(new Int());
/*     */     }
/*     */     public ReleaseId(UniqName.GroupId paramGroupId) {
/* 434 */       setArgument(paramGroupId).setResult(new Int());
/*     */     }
/*     */ 
/*     */     public int getType() {
/* 438 */       return 11;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class AllocateId extends Rpc<UniqName.GroupId, LongInt>
/*     */   {
/*     */     public AllocateId()
/*     */     {
/* 412 */       setArgument(new UniqName.GroupId()).setResult(new LongInt());
/*     */     }
/*     */     public AllocateId(String paramString, long paramLong) {
/* 415 */       setArgument(new UniqName.GroupId(paramString, paramLong)).setResult(new LongInt());
/*     */     }
/*     */     public AllocateId(UniqName.GroupId paramGroupId) {
/* 418 */       setArgument(paramGroupId).setResult(new LongInt());
/*     */     }
/*     */ 
/*     */     public int getType() {
/* 422 */       return 10;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class GroupId
/*     */     implements Marshal
/*     */   {
/*     */     private String group;
/*     */     private long id;
/*     */     private int localid;
/* 364 */     private Octets reserve = new Octets();
/*     */ 
/*     */     public GroupId() {
/*     */     }
/*     */ 
/*     */     public GroupId(String paramString, long paramLong) {
/* 370 */       this.group = paramString;
/* 371 */       this.id = paramLong;
/* 372 */       this.localid = UniqName.conf.getLocalId();
/*     */     }
/*     */ 
/*     */     public String getGroup() {
/* 376 */       return this.group;
/*     */     }
/*     */ 
/*     */     public long getId() {
/* 380 */       return this.id;
/*     */     }
/*     */ 
/*     */     public int getLocalid() {
/* 384 */       return this.localid;
/*     */     }
/*     */ 
/*     */     public OctetsStream marshal(OctetsStream paramOctetsStream)
/*     */     {
/* 389 */       paramOctetsStream.marshal(this.group, "UTF-16LE");
/* 390 */       paramOctetsStream.marshal(this.id);
/* 391 */       paramOctetsStream.marshal(this.localid);
/* 392 */       paramOctetsStream.marshal(this.reserve);
/* 393 */       return paramOctetsStream;
/*     */     }
/*     */ 
/*     */     public OctetsStream unmarshal(OctetsStream paramOctetsStream) throws MarshalException {
/* 397 */       this.group = paramOctetsStream.unmarshal_String("UTF-16LE");
/* 398 */       this.id = paramOctetsStream.unmarshal_long();
/* 399 */       this.localid = paramOctetsStream.unmarshal_int();
/* 400 */       this.reserve = paramOctetsStream.unmarshal_Octets();
/* 401 */       return paramOctetsStream;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 406 */       return "(" + this.group + ":" + this.id + ":" + this.localid + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Release extends Rpc<UniqName.GroupName, Int>
/*     */   {
/*     */     public Release()
/*     */     {
/* 344 */       setArgument(new UniqName.GroupName()).setResult(new Int());
/*     */     }
/*     */     public Release(UniqName.GroupName paramGroupName) {
/* 347 */       setArgument(paramGroupName).setResult(new Int());
/*     */     }
/*     */     public Release(String paramString1, String paramString2) {
/* 350 */       setArgument(new UniqName.GroupName(paramString1, paramString2)).setResult(new Int());
/*     */     }
/*     */ 
/*     */     public int getType() {
/* 354 */       return 4;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Confirm extends Rpc<UniqName.GroupName, Int>
/*     */   {
/*     */     public Confirm()
/*     */     {
/* 328 */       setArgument(new UniqName.GroupName()).setResult(new Int());
/*     */     }
/*     */     public Confirm(UniqName.GroupName paramGroupName) {
/* 331 */       setArgument(paramGroupName).setResult(new Int());
/*     */     }
/*     */     public Confirm(String paramString1, String paramString2) {
/* 334 */       setArgument(new UniqName.GroupName(paramString1, paramString2)).setResult(new Int());
/*     */     }
/*     */ 
/*     */     public int getType() {
/* 338 */       return 3;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Allocate extends Rpc<UniqName.GroupName, Int>
/*     */   {
/*     */     public Allocate()
/*     */     {
/* 312 */       setArgument(new UniqName.GroupName()).setResult(new Int());
/*     */     }
/*     */     public Allocate(UniqName.GroupName paramGroupName) {
/* 315 */       setArgument(paramGroupName).setResult(new Int());
/*     */     }
/*     */     public Allocate(String paramString1, String paramString2) {
/* 318 */       setArgument(new UniqName.GroupName(paramString1, paramString2)).setResult(new Int());
/*     */     }
/*     */ 
/*     */     public int getType() {
/* 322 */       return 2;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Exist extends Rpc<UniqName.GroupName, Int>
/*     */   {
/*     */     public Exist()
/*     */     {
/* 296 */       setArgument(new UniqName.GroupName()).setResult(new Int());
/*     */     }
/*     */     public Exist(UniqName.GroupName paramGroupName) {
/* 299 */       setArgument(paramGroupName).setResult(new Int());
/*     */     }
/*     */     public Exist(String paramString1, String paramString2) {
/* 302 */       setArgument(new UniqName.GroupName(paramString1, paramString2)).setResult(new Int());
/*     */     }
/*     */ 
/*     */     public int getType() {
/* 306 */       return 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class GroupName
/*     */     implements Marshal
/*     */   {
/*     */     private String group;
/*     */     private String name;
/*     */     private int localid;
/* 248 */     private Octets reserve = new Octets();
/*     */ 
/*     */     public GroupName() {
/*     */     }
/*     */ 
/*     */     public GroupName(String paramString1, String paramString2) {
/* 254 */       this.group = paramString1;
/* 255 */       this.name = paramString2;
/* 256 */       this.localid = UniqName.conf.getLocalId();
/*     */     }
/*     */ 
/*     */     public String getGroup() {
/* 260 */       return this.group;
/*     */     }
/*     */ 
/*     */     public String getName() {
/* 264 */       return this.name;
/*     */     }
/*     */ 
/*     */     public int getLocalid() {
/* 268 */       return this.localid;
/*     */     }
/*     */ 
/*     */     public OctetsStream marshal(OctetsStream paramOctetsStream)
/*     */     {
/* 273 */       paramOctetsStream.marshal(this.group, "UTF-16LE");
/* 274 */       paramOctetsStream.marshal(this.name, "UTF-16LE");
/* 275 */       paramOctetsStream.marshal(this.localid);
/* 276 */       paramOctetsStream.marshal(this.reserve);
/* 277 */       return paramOctetsStream;
/*     */     }
/*     */ 
/*     */     public OctetsStream unmarshal(OctetsStream paramOctetsStream) throws MarshalException {
/* 281 */       this.group = paramOctetsStream.unmarshal_String("UTF-16LE");
/* 282 */       this.name = paramOctetsStream.unmarshal_String("UTF-16LE");
/* 283 */       this.localid = paramOctetsStream.unmarshal_int();
/* 284 */       this.reserve = paramOctetsStream.unmarshal_Octets();
/* 285 */       return paramOctetsStream;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 290 */       return "(" + this.group + ":" + this.name + ":" + this.localid + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class IdLog
/*     */     implements Log
/*     */   {
/*     */     private final UniqName.GroupId g;
/*     */ 
/*     */     IdLog(UniqName.GroupId paramGroupId)
/*     */     {
/* 220 */       this.g = paramGroupId;
/*     */     }
/*     */ 
/*     */     public void commit()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void rollback() {
/* 228 */       UniqName.releaseId(this.g);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class NameLog
/*     */     implements Log
/*     */   {
/*     */     private final UniqName.GroupName a;
/*     */ 
/*     */     NameLog(UniqName.GroupName paramGroupName)
/*     */     {
/* 190 */       this.a = paramGroupName;
/*     */     }
/*     */ 
/*     */     public void commit()
/*     */     {
/* 197 */       int i = ((Int)new UniqName.Confirm(this.a).submit(UniqName.manager).get()).getValue();
/* 198 */       if (i != 12345)
/*     */       {
/* 206 */         Trace.error("UniqName.Confirm " + this.a + " rc=" + i);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void rollback()
/*     */     {
/* 212 */       UniqName.release(this.a);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.UniqName
 * JD-Core Version:    0.6.2
 */