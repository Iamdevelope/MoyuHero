/*     */ package xdb.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import xdb.Logger;
/*     */ import xdb.Storage;
/*     */ 
/*     */ public class Integrity
/*     */ {
/*     */   private final File logHome;
/*     */   private final File tableHome;
/*     */   private Logger logger;
/*  24 */   private List<Storage> tables = new ArrayList();
/*  25 */   private DatabaseMetaData metaData = null;
/*     */ 
/*     */   public Integrity(String paramString, File paramFile)
/*     */   {
/*  34 */     this(paramString, paramFile, null);
/*     */   }
/*     */ 
/*     */   public Integrity(String paramString, File paramFile, DatabaseMetaData paramDatabaseMetaData)
/*     */   {
/*  48 */     if (null != paramString) {
/*  49 */       Dbx.load(paramString);
/*     */     }
/*  51 */     if ((!paramFile.isDirectory()) || (!paramFile.exists())) {
/*  52 */       throw new IllegalStateException("dbhome : " + paramFile + " (!isDirectory || !exists())");
/*     */     }
/*  54 */     this.logHome = new File(paramFile, "dblogs").getAbsoluteFile();
/*  55 */     this.tableHome = new File(paramFile, "dbdata");
/*  56 */     this.metaData = paramDatabaseMetaData;
/*     */   }
/*     */ 
/*     */   public boolean checkMetaData()
/*     */   {
/*  75 */     return this.metaData.isSame(this.tableHome.getParentFile());
/*     */   }
/*     */ 
/*     */   public void verify()
/*     */   {
/*  83 */     int i = 0;
/*  84 */     if (this.logHome.exists()) i++;
/*  85 */     if (this.tableHome.exists()) i += 2;
/*     */ 
/*  87 */     switch (i) {
/*     */     case 0:
/*  89 */       println("ok! it is an empty db."); return;
/*     */     case 1:
/*     */     case 2:
/*  91 */       throw new RuntimeException("is it a dbhome?");
/*     */     case 3:
/*     */     }
/*     */ 
/*  98 */     HashSet localHashSet = new HashSet();
/*     */     Object localObject3;
/*  99 */     for (localObject3 : this.tableHome.listFiles())
/* 100 */       if (!((File)localObject3).isFile()) {
/* 101 */         println(localObject3 + " is not a file! skip.");
/*     */       }
/*     */       else
/* 104 */         localHashSet.add(((File)localObject3).getName());
/*     */     Object localObject2;
/* 106 */     if (null != this.metaData) {
/* 107 */       ??? = new HashSet();
/* 108 */       for (Iterator localIterator = this.metaData.getTables().iterator(); localIterator.hasNext(); ) { localObject2 = (DatabaseMetaData.Table)localIterator.next();
/* 109 */         if (((DatabaseMetaData.Table)localObject2).isPersistence())
/* 110 */           ((Set)???).add(((DatabaseMetaData.Table)localObject2).getName());
/*     */       }
/* 112 */       if (!localHashSet.equals(???)) {
/* 113 */         throw new RuntimeException("DatabaseMetaData?");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 118 */     ??? = this.logHome.toString() + File.separator;
/*     */     try
/*     */     {
/* 122 */       for (int k = 0; k < 2; k++) {
/* 123 */         this.logger = new Logger((String)???, 4096);
/* 124 */         for (localObject2 = localHashSet.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject3 = (String)((Iterator)localObject2).next();
/* 125 */           this.tables.add(new Table(this.logger, this.tableHome, (String)localObject3, 512, 128));
/*     */         }
/* 127 */         int n = this.logger.verify();
/* 128 */         if (0 == n) {
/* 129 */           println("verify success!");
/* 130 */           break;
/*     */         }
/* 132 */         if (1 == n) {
/* 133 */           println("redo success! verify again.");
/* 134 */           close();
/*     */         }
/*     */         else {
/* 137 */           throw new RuntimeException("db corrupt @" + k);
/*     */         }
/*     */       }
/*     */     } finally { close(); }
/*     */   }
/*     */ 
/*     */   private void close()
/*     */   {
/* 145 */     for (Storage localStorage : this.tables)
/*     */     {
/* 147 */       localStorage.close();
/*     */     }
/* 149 */     this.tables.clear();
/*     */ 
/* 151 */     if (null != this.logger) {
/* 152 */       this.logger.close();
/* 153 */       this.logger = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void println(Object paramObject) {
/* 158 */     System.out.println(paramObject);
/*     */   }
/*     */ 
/*     */   public static void main(String[] paramArrayOfString) {
/* 162 */     new Integrity("../test", new File("../test/xdb")).verify();
/*     */   }
/*     */ 
/*     */   private class Table extends Storage
/*     */   {
/*     */     Table(Logger paramFile, File paramString, String paramInt1, int paramInt2, int arg6)
/*     */     {
/*  66 */       super(paramString, paramInt1, paramInt2, i);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.Integrity
 * JD-Core Version:    0.6.2
 */