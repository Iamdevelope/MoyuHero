/*      */ package xdb.util;
/*      */ 
/*      */ import com.goldhuman.Common.Marshal.Marshal;
/*      */ import com.goldhuman.Common.Marshal.MarshalException;
/*      */ import com.goldhuman.Common.Marshal.OctetsStream;
/*      */ import com.goldhuman.Common.Octets;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.TreeMap;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.transform.Transformer;
/*      */ import javax.xml.transform.TransformerConfigurationException;
/*      */ import javax.xml.transform.TransformerException;
/*      */ import javax.xml.transform.TransformerFactory;
/*      */ import javax.xml.transform.dom.DOMSource;
/*      */ import javax.xml.transform.stream.StreamResult;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.SAXException;
/*      */ import xdb.Table.Persistence;
/*      */ import xdb.Trace;
/*      */ 
/*      */ public class DatabaseMetaData
/*      */ {
/*   28 */   private final Map<String, Table> tables = new HashMap();
/*      */ 
/*   33 */   private final Map<String, Bean> beans = new HashMap();
/*      */ 
/*   38 */   private final Map<String, Type> types = new HashMap();
/*      */   private static DatabaseMetaData instance;
/*  245 */   private static Object lock = new Object();
/*      */ 
/*      */   protected DatabaseMetaData()
/*      */   {
/*   44 */     addType(new Boolean_(null));
/*   45 */     addType(new Short_(null));
/*   46 */     addType(new Int_(null));
/*   47 */     addType(new Long_(null));
/*   48 */     addType(new String_(null));
/*   49 */     addType(new Float_(null));
/*   50 */     addType(new List_(null));
/*   51 */     addType(new Vector_(null));
/*   52 */     addType(new Set_(null));
/*   53 */     addType(new Map_(null));
/*   54 */     addType(new Treemap_(null));
/*   55 */     addType(new Binary_(null));
/*      */   }
/*      */ 
/*      */   DatabaseMetaData(Element paramElement)
/*      */   {
/*   60 */     this();
/*      */ 
/*   62 */     NodeList localNodeList = paramElement.getElementsByTagName("cbean");
/*      */     Element localElement;
/*   63 */     for (int i = 0; i != localNodeList.getLength(); i++) {
/*   64 */       localElement = (Element)localNodeList.item(i);
/*   65 */       addBean(new Bean(localElement));
/*      */     }
/*      */ 
/*   69 */     localNodeList = paramElement.getElementsByTagName("xbean");
/*   70 */     for (i = 0; i != localNodeList.getLength(); i++) {
/*   71 */       localElement = (Element)localNodeList.item(i);
/*   72 */       addBean(new Bean(localElement));
/*      */     }
/*      */ 
/*   76 */     localNodeList = paramElement.getElementsByTagName("table");
/*   77 */     for (i = 0; i != localNodeList.getLength(); i++) {
/*   78 */       localElement = (Element)localNodeList.item(i);
/*   79 */       addTable(new Table(localElement));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void createXML(File paramFile) {
/*   84 */     File localFile = new File(new StringBuilder().append(paramFile.getAbsolutePath()).append("/metadata.xml").toString());
/*   85 */     if (!localFile.exists())
/*   86 */       saveToFile(localFile);
/*      */   }
/*      */ 
/*      */   public boolean isSame(File paramFile)
/*      */   {
/*   95 */     File localFile = new File(new StringBuilder().append(paramFile.getAbsolutePath()).append("/metadata.xml").toString());
/*   96 */     return (!localFile.exists()) || (getInstance().isSame(loadFromFile(localFile)));
/*      */   }
/*      */ 
/*      */   boolean isSame(DatabaseMetaData paramDatabaseMetaData)
/*      */   {
/*  107 */     for (Iterator localIterator = this.tables.entrySet().iterator(); localIterator.hasNext(); ) { localEntry = (Map.Entry)localIterator.next();
/*  108 */       Table localTable = (Table)paramDatabaseMetaData.tables.get(localEntry.getKey());
/*      */ 
/*  110 */       if (localTable != null)
/*  111 */         if (!((Table)localEntry.getValue()).isSame(localTable)) return false;
/*      */     }
/*  114 */     Map.Entry localEntry;
/*  114 */     for (localIterator = paramDatabaseMetaData.tables.entrySet().iterator(); localIterator.hasNext(); ) { localEntry = (Map.Entry)localIterator.next();
/*  115 */       if ((this.tables.get(localEntry.getKey()) == null) && (((Table)localEntry.getValue()).isPersistence())) {
/*  116 */         return false;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  133 */     return true;
/*      */   }
/*      */ 
/*      */   static DatabaseMetaData loadFromFile(File paramFile) {
/*      */     DocumentBuilder localDocumentBuilder;
/*      */     try {
/*  139 */       localDocumentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*      */     } catch (ParserConfigurationException localParserConfigurationException) {
/*  141 */       Trace.error("err", localParserConfigurationException);
/*  142 */       return null;
/*      */     }
/*      */     Document localDocument;
/*      */     try {
/*  146 */       localDocument = localDocumentBuilder.parse(paramFile);
/*      */     } catch (SAXException localSAXException) {
/*  148 */       return null;
/*      */     } catch (IOException localIOException) {
/*  150 */       return null;
/*      */     }
/*  152 */     return new DatabaseMetaData(localDocument.getDocumentElement()).compile();
/*      */   }
/*      */ 
/*      */   public void toXML(Element paramElement) {
/*  156 */     Document localDocument = paramElement.getOwnerDocument();
/*      */ 
/*  158 */     for (Iterator localIterator = this.beans.entrySet().iterator(); localIterator.hasNext(); ) { localEntry = (Map.Entry)localIterator.next();
/*  159 */       localElement = localDocument.createElement(((Bean)localEntry.getValue()).isConstant() ? "cbean" : "xbean");
/*  160 */       ((Bean)localEntry.getValue()).toXML(localElement);
/*  161 */       paramElement.appendChild(localElement);
/*      */     }
/*  164 */     Map.Entry localEntry;
/*      */     Element localElement;
/*  164 */     for (localIterator = this.tables.entrySet().iterator(); localIterator.hasNext(); ) { localEntry = (Map.Entry)localIterator.next();
/*  165 */       localElement = localDocument.createElement("table");
/*  166 */       ((Table)localEntry.getValue()).toXML(localElement);
/*  167 */       paramElement.appendChild(localElement);
/*      */     }
/*      */   }
/*      */ 
/*      */   void saveToFile(File paramFile)
/*      */   {
/*      */     DocumentBuilder localDocumentBuilder;
/*      */     Transformer localTransformer;
/*      */     try
/*      */     {
/*  189 */       localDocumentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*  190 */       localTransformer = TransformerFactory.newInstance().newTransformer();
/*      */     } catch (ParserConfigurationException localParserConfigurationException) {
/*  192 */       Trace.error("err", localParserConfigurationException);
/*  193 */       return;
/*      */     } catch (TransformerConfigurationException localTransformerConfigurationException) {
/*  195 */       Trace.error("err", localTransformerConfigurationException);
/*  196 */       return;
/*      */     }
/*  198 */     Document localDocument = localDocumentBuilder.newDocument();
/*  199 */     Element localElement = localDocument.createElement("xdb");
/*  200 */     localDocument.appendChild(localElement);
/*  201 */     toXML(localElement);
/*  202 */     localTransformer.setOutputProperty("method", "xml");
/*  203 */     localTransformer.setOutputProperty("encoding", "utf-8");
/*  204 */     localTransformer.setOutputProperty("indent", "yes");
/*      */     try {
/*  206 */       localTransformer.transform(new DOMSource(localDocument), new StreamResult(paramFile));
/*      */     } catch (TransformerException localTransformerException) {
/*  208 */       Trace.error("err", localTransformerException);
/*  209 */       return;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected DatabaseMetaData compile()
/*      */   {
/*      */     Iterator localIterator;
/*      */     Object localObject;
/*  218 */     for (int i = 0; i < 2; i++) {
/*  219 */       for (localIterator = this.beans.values().iterator(); localIterator.hasNext(); ) { localObject = (Bean)localIterator.next();
/*  220 */         ((Bean)localObject).compile(i); }
/*  221 */       for (localIterator = this.tables.values().iterator(); localIterator.hasNext(); ) { localObject = (Table)localIterator.next();
/*  222 */         ((Table)localObject).compile(i); }
/*      */     }
/*  224 */     return this;
/*      */   }
/*      */ 
/*      */   public static DatabaseMetaData load(String paramString) {
/*      */     try {
/*  229 */       Class localClass = Class.forName(paramString);
/*  230 */       Object localObject = localClass.newInstance();
/*  231 */       if ((localObject instanceof DatabaseMetaData)) {
/*  232 */         return ((DatabaseMetaData)localObject).compile();
/*      */       }
/*  234 */       throw new RuntimeException("NOT DatabaseMetaData");
/*      */     } catch (ClassNotFoundException localClassNotFoundException) {
/*  236 */       throw new RuntimeException(localClassNotFoundException);
/*      */     } catch (IllegalAccessException localIllegalAccessException) {
/*  238 */       throw new RuntimeException(localIllegalAccessException);
/*      */     } catch (InstantiationException localInstantiationException) {
/*  240 */       throw new RuntimeException(localInstantiationException);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static DatabaseMetaData getInstance()
/*      */   {
/*  248 */     synchronized (lock) {
/*  249 */       if (null == instance)
/*      */       {
/*  251 */         instance = load("xtable._DatabaseMetaData_");
/*      */       }
/*  253 */       return instance;
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isVerifyXdb()
/*      */   {
/*  264 */     return false;
/*      */   }
/*      */ 
/*      */   public final Table getTable(String paramString) {
/*  268 */     return (Table)this.tables.get(paramString);
/*      */   }
/*      */ 
/*      */   public final Collection<Table> getTables() {
/*  272 */     return Collections.unmodifiableCollection(this.tables.values());
/*      */   }
/*      */ 
/*      */   public final Bean getBean(String paramString) {
/*  276 */     return (Bean)this.beans.get(paramString);
/*      */   }
/*      */ 
/*      */   public final Collection<Bean> getBeans() {
/*  280 */     return Collections.unmodifiableCollection(this.beans.values());
/*      */   }
/*      */ 
/*      */   public final Type getType(String paramString) {
/*  284 */     Type localType = (Type)this.types.get(paramString);
/*  285 */     if (null != localType)
/*  286 */       return localType;
/*  287 */     throw new RuntimeException(new StringBuilder().append("unkown type. name=").append(paramString).toString());
/*      */   }
/*      */ 
/*      */   Type getType(String paramString, boolean paramBoolean) {
/*  291 */     Type localType = (Type)this.types.get(paramString);
/*  292 */     if (null != localType)
/*  293 */       return localType;
/*  294 */     if (paramString.isEmpty())
/*  295 */       return null;
/*  296 */     if (paramBoolean)
/*  297 */       return new Any_(paramString);
/*  298 */     throw new RuntimeException(new StringBuilder().append("unkown type. name=").append(paramString).toString());
/*      */   }
/*      */ 
/*      */   public final Collection<Type> getTypes() {
/*  302 */     return Collections.unmodifiableCollection(this.types.values());
/*      */   }
/*      */ 
/*      */   public final Marshal newBean(String paramString) {
/*  306 */     return (Marshal)getBean(paramString).newInstance();
/*      */   }
/*      */ 
/*      */   public Object newType(String paramString) {
/*  310 */     return getType(paramString).newInstance();
/*      */   }
/*      */ 
/*      */   public Marshal newBean(String paramString, OctetsStream paramOctetsStream) {
/*  314 */     return (Marshal)getBean(paramString).unmarshal(paramOctetsStream);
/*      */   }
/*      */ 
/*      */   public Object newType(String paramString, OctetsStream paramOctetsStream) {
/*  318 */     return getType(paramString).unmarshal(paramOctetsStream);
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  323 */     StringBuilder localStringBuilder = new StringBuilder();
/*  324 */     localStringBuilder.append("beans:\n");
/*  325 */     for (Iterator localIterator = getBeans().iterator(); localIterator.hasNext(); ) { localObject = (Bean)localIterator.next();
/*  326 */       localStringBuilder.append(localObject).append("\n");
/*      */     }
/*  329 */     Object localObject;
/*  328 */     localStringBuilder.append("tables:\n");
/*  329 */     for (localIterator = getTables().iterator(); localIterator.hasNext(); ) { localObject = (Table)localIterator.next();
/*  330 */       localStringBuilder.append(localObject).append("\n");
/*      */     }
/*  332 */     return localStringBuilder.toString();
/*      */   }
/*      */ 
/*      */   protected void addVariableFor(Bean paramBean, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8)
/*      */   {
/*      */     Bean tmp6_5 = paramBean; tmp6_5.getClass(); paramBean.addVariable(new DatabaseMetaData.Bean.Variable(tmp6_5, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramString7, paramString8));
/*      */   }
/*      */ 
/*      */   protected void addBean(Bean paramBean)
/*      */   {
/*  347 */     addType(paramBean);
/*  348 */     if (null != this.beans.put(paramBean.getName(), paramBean))
/*  349 */       throw new RuntimeException(new StringBuilder().append("bean name duplicate!").append(paramBean).toString());
/*      */   }
/*      */ 
/*      */   protected void addTable(Table paramTable) {
/*  353 */     if (null != this.tables.put(paramTable.getName(), paramTable))
/*  354 */       throw new IllegalStateException(new StringBuilder().append("table name duplicate!").append(paramTable).toString());
/*      */   }
/*      */ 
/*      */   protected void addTable(String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4, String paramString5, String paramString6)
/*      */   {
/*  360 */     addTable(new Table(paramString1, paramString2, paramString3, paramBoolean, paramString4, paramString5, paramString6));
/*      */   }
/*      */ 
/*      */   private void addType(Type paramType) {
/*  364 */     if (null != this.types.put(paramType.getName(), paramType))
/*  365 */       throw new IllegalStateException(new StringBuilder().append("type name duplicate!").append(paramType).toString());
/*      */   }
/*      */ 
/*      */   private static final class Any_ extends DatabaseMetaData.Type
/*      */   {
/*      */     private final String name;
/*      */ 
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1719 */       paramDepends.add(this);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1725 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Any_(String paramString)
/*      */     {
/* 1731 */       this.name = paramString;
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1736 */       return this.name;
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1741 */       return this.name;
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1746 */       return false;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1751 */       return DatabaseMetaData.Type.TypeId.ANY;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/*      */       try {
/* 1757 */         return Class.forName(getClassName());
/*      */       } catch (Exception localException) {
/* 1759 */         throw new RuntimeException(localException);
/*      */       }
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1765 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/* 1770 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1775 */       return null != paramInteger ? paramInteger.intValue() : 128L;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Binary_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1666 */       paramDepends.add(this);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1672 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1677 */       return "binary";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1682 */       return "byte[]";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1687 */       return false;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1692 */       return DatabaseMetaData.Type.TypeId.BINARY;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1697 */       return [B.class;
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1702 */       return new OctetsStream().marshal((byte[])paramObject);
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/* 1707 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1712 */       return null != paramInteger ? paramInteger.intValue() : 128L;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Treemap_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1611 */       paramDepends.add(this);
/* 1612 */       paramDepends.top().getValueType().depends(paramDepends);
/* 1613 */       paramDepends.top().getKeyType().depends(paramDepends);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1619 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1624 */       return "treemap";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1629 */       return "java.util.NavigableMap";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1634 */       return false;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1639 */       return DatabaseMetaData.Type.TypeId.TREEMAP;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1644 */       return TreeMap.class;
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1649 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/* 1654 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1659 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Map_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1555 */       paramDepends.add(this);
/* 1556 */       paramDepends.top().getValueType().depends(paramDepends);
/* 1557 */       paramDepends.top().getKeyType().depends(paramDepends);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1563 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1568 */       return "map";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1573 */       return "java.util.Map";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1578 */       return false;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1583 */       return DatabaseMetaData.Type.TypeId.MAP;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1588 */       return HashMap.class;
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1593 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/* 1598 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1603 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Set_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1500 */       paramDepends.add(this);
/* 1501 */       paramDepends.top().getValueType().depends(paramDepends);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1507 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1512 */       return "set";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1517 */       return "java.util.Set";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1522 */       return false;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1527 */       return DatabaseMetaData.Type.TypeId.SET;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1532 */       return HashSet.class;
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1537 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/* 1542 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1547 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Vector_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1445 */       paramDepends.add(this);
/* 1446 */       paramDepends.top().getValueType().depends(paramDepends);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1452 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1457 */       return "vector";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1462 */       return "java.util.Vector";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1467 */       return false;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1472 */       return DatabaseMetaData.Type.TypeId.VECTOR;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1477 */       return ArrayList.class;
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1482 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/* 1487 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1492 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class List_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1390 */       paramDepends.add(this);
/* 1391 */       paramDepends.top().getValueType().depends(paramDepends);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1397 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1402 */       return "list";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1407 */       return "java.util.List";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1412 */       return false;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1417 */       return DatabaseMetaData.Type.TypeId.LIST;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1422 */       return LinkedList.class;
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1427 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/* 1432 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1437 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Float_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1332 */       paramDepends.add(this);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1338 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1343 */       return "float";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1348 */       return "java.lang.Float";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1353 */       return true;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1358 */       return DatabaseMetaData.Type.TypeId.FLOAT;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1363 */       return Float.class;
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1368 */       return new OctetsStream().marshal(((Float)paramObject).floatValue());
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/*      */       try {
/* 1374 */         return Float.valueOf(paramOctetsStream.unmarshal_float());
/*      */       } catch (MarshalException localMarshalException) {
/* 1376 */         throw new RuntimeException(localMarshalException);
/*      */       }
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1382 */       return 4L;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class String_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1275 */       paramDepends.add(this);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1281 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1286 */       return "string";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1291 */       return "java.lang.String";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1296 */       return true;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1301 */       return DatabaseMetaData.Type.TypeId.STRING;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1306 */       return String.class;
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1311 */       return new OctetsStream().marshal((String)paramObject, "UTF-16LE");
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/*      */       try {
/* 1317 */         return paramOctetsStream.unmarshal_String("UTF-16LE");
/*      */       } catch (MarshalException localMarshalException) {
/* 1319 */         throw new RuntimeException(localMarshalException);
/*      */       }
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1325 */       return 2L * (null != paramInteger ? paramInteger.intValue() : 32);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Long_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1218 */       paramDepends.add(this);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1224 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1229 */       return "long";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1234 */       return "java.lang.Long";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1239 */       return true;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1244 */       return DatabaseMetaData.Type.TypeId.LONG;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1249 */       return Long.class;
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1254 */       return new OctetsStream().marshal(((Long)paramObject).longValue());
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/*      */       try {
/* 1260 */         return Long.valueOf(paramOctetsStream.unmarshal_long());
/*      */       } catch (MarshalException localMarshalException) {
/* 1262 */         throw new RuntimeException(localMarshalException);
/*      */       }
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1268 */       return 8L;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Int_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1161 */       paramDepends.add(this);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1167 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1172 */       return "int";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1177 */       return "java.lang.Integer";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1182 */       return true;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1187 */       return DatabaseMetaData.Type.TypeId.INT;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1192 */       return Integer.class;
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1197 */       return new OctetsStream().marshal(((Integer)paramObject).intValue());
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/*      */       try {
/* 1203 */         return Integer.valueOf(paramOctetsStream.unmarshal_int());
/*      */       } catch (MarshalException localMarshalException) {
/* 1205 */         throw new RuntimeException(localMarshalException);
/*      */       }
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1211 */       return 4L;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Short_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1104 */       paramDepends.add(this);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1110 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1115 */       return "short";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1120 */       return "java.lang.Short";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1125 */       return true;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1130 */       return DatabaseMetaData.Type.TypeId.SHORT;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1135 */       return Short.class;
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1140 */       return new OctetsStream().marshal(((Short)paramObject).shortValue());
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/*      */       try {
/* 1146 */         return Short.valueOf(paramOctetsStream.unmarshal_short());
/*      */       } catch (MarshalException localMarshalException) {
/* 1148 */         throw new RuntimeException(localMarshalException);
/*      */       }
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1154 */       return 2L;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class Boolean_ extends DatabaseMetaData.Type
/*      */   {
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/* 1047 */       paramDepends.add(this);
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/* 1053 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/* 1058 */       return "boolean";
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/* 1063 */       return "java.lang.Boolean";
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/* 1068 */       return true;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/* 1073 */       return DatabaseMetaData.Type.TypeId.BOOLEAN;
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/* 1078 */       return Boolean.class;
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/*      */       try {
/* 1084 */         return Boolean.valueOf(paramOctetsStream.unmarshal_boolean());
/*      */       } catch (MarshalException localMarshalException) {
/* 1086 */         throw new RuntimeException(localMarshalException);
/*      */       }
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/* 1092 */       return new OctetsStream().marshal(((Boolean)paramObject).booleanValue());
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/* 1097 */       return 1L;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static abstract class Type
/*      */     implements DatabaseMetaData.MarshalXML
/*      */   {
/*      */     public void toXML(Element paramElement)
/*      */     {
/*  845 */       Document localDocument = paramElement.getOwnerDocument();
/*  846 */       Element localElement = localDocument.createElement("classname");
/*  847 */       localElement.appendChild(localDocument.createTextNode(getClassName()));
/*  848 */       paramElement.appendChild(localElement);
/*      */     }
/*      */ 
/*      */     public boolean isSame(Type paramType) {
/*  852 */       if (!paramType.getTypeId().equals(getTypeId())) return false;
/*      */ 
/*  854 */       return true;
/*      */     }
/*      */ 
/*      */     public abstract String getName();
/*      */ 
/*      */     public abstract String getClassName();
/*      */ 
/*      */     public abstract boolean isConstant();
/*      */ 
/*      */     public boolean isAny()
/*      */     {
/*  884 */       return false;
/*      */     }
/*      */ 
/*      */     public abstract TypeId getTypeId();
/*      */ 
/*      */     public abstract long sizeof(Integer paramInteger);
/*      */ 
/*      */     public long sizeof()
/*      */     {
/*  909 */       return sizeof(null);
/*      */     }
/*      */ 
/*      */     protected abstract void depends(Depends paramDepends);
/*      */ 
/*      */     public abstract Set<Type> depends();
/*      */ 
/*      */     public boolean isBean()
/*      */     {
/*  970 */       return TypeId.BEAN == getTypeId();
/*      */     }
/*      */ 
/*      */     public boolean isBinary()
/*      */     {
/*  979 */       return TypeId.BINARY == getTypeId();
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  984 */       return getName();
/*      */     }
/*      */ 
/*      */     public abstract Class<?> getClazz();
/*      */ 
/*      */     public final Object newInstance()
/*      */     {
/*      */       try
/*      */       {
/* 1003 */         return getClazz().newInstance();
/*      */       } catch (Exception localException) {
/* 1005 */         throw new RuntimeException(localException);
/*      */       }
/*      */     }
/*      */ 
/*      */     public abstract Object unmarshal(OctetsStream paramOctetsStream);
/*      */ 
/*      */     public final Object unmarshal(byte[] paramArrayOfByte)
/*      */     {
/* 1017 */       return unmarshal(OctetsStream.wrap(Octets.wrap(paramArrayOfByte)));
/*      */     }
/*      */ 
/*      */     public abstract OctetsStream marshal(Object paramObject);
/*      */ 
/*      */     @Deprecated
/*      */     public final Object newInstance(OctetsStream paramOctetsStream)
/*      */     {
/* 1032 */       return unmarshal(paramOctetsStream);
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public final Object newInstance(byte[] paramArrayOfByte)
/*      */     {
/* 1040 */       return unmarshal(OctetsStream.wrap(Octets.wrap(paramArrayOfByte)));
/*      */     }
/*      */ 
/*      */     public static final class Depends
/*      */     {
/*      */       private final DatabaseMetaData.Type base;
/*  914 */       private Stack<DatabaseMetaData.Bean.Variable> variableStack = new Stack();
/*  915 */       private Set<DatabaseMetaData.Type> depends = new HashSet();
/*      */ 
/*      */       public Depends()
/*      */       {
/*  919 */         this.base = null;
/*      */       }
/*      */ 
/*      */       Depends(DatabaseMetaData.Type paramType) {
/*  923 */         this.base = paramType;
/*      */       }
/*      */ 
/*      */       void push(DatabaseMetaData.Bean.Variable paramVariable) {
/*  927 */         this.variableStack.push(paramVariable);
/*      */       }
/*      */ 
/*      */       DatabaseMetaData.Bean.Variable top() {
/*  931 */         return (DatabaseMetaData.Bean.Variable)this.variableStack.peek();
/*      */       }
/*      */ 
/*      */       DatabaseMetaData.Bean.Variable pop(DatabaseMetaData.Bean.Variable paramVariable) {
/*  935 */         if (top() != paramVariable) {
/*  936 */           throw new IllegalStateException("pop: It is not top of stack! with " + paramVariable.getOwnerBean() + "." + paramVariable.getName());
/*      */         }
/*  938 */         return (DatabaseMetaData.Bean.Variable)this.variableStack.pop();
/*      */       }
/*      */ 
/*      */       boolean add(DatabaseMetaData.Type paramType) {
/*  942 */         if (this.depends.add(paramType))
/*  943 */           return true;
/*  944 */         if (paramType == this.base)
/*  945 */           throw new RuntimeException("self-depend found! type=" + paramType.getName());
/*  946 */         return false;
/*      */       }
/*      */ 
/*      */       public Set<DatabaseMetaData.Type> getDepends() {
/*  950 */         return this.depends;
/*      */       }
/*      */     }
/*      */ 
/*      */     public static enum TypeId
/*      */     {
/*  888 */       BOOLEAN, SHORT, INT, LONG, STRING, FLOAT, 
/*  889 */       LIST, VECTOR, SET, MAP, TREEMAP, BINARY, 
/*  890 */       BEAN, ANY;
/*      */     }
/*      */   }
/*      */ 
/*      */   public final class Bean extends DatabaseMetaData.Type
/*      */     implements DatabaseMetaData.MarshalXML
/*      */   {
/*      */     private final String name;
/*      */     private final boolean any;
/*      */     private final boolean constant;
/*  518 */     private final List<Variable> variables = new ArrayList();
/*      */ 
/*  521 */     private final Map<String, Variable> variablesByName = new HashMap();
/*      */     private Set<DatabaseMetaData.Type> depends;
/*      */ 
/*      */     public Bean(String paramBoolean1, boolean paramBoolean2, boolean arg4)
/*      */     {
/*  524 */       this.name = paramBoolean1;
/*  525 */       this.any = paramBoolean2;
/*      */       boolean bool;
/*  526 */       this.constant = bool;
/*      */     }
/*      */ 
/*      */     Bean(Element arg2) {
/*  530 */       this(localObject.getAttribute("name"), localObject.getAttribute("any").equals("true"), localObject.getNodeName().equals("cbean"));
/*  531 */       NodeList localNodeList = localObject.getElementsByTagName("variable");
/*  532 */       for (int i = 0; i != localNodeList.getLength(); i++) {
/*  533 */         Element localElement = (Element)localNodeList.item(i);
/*  534 */         addVariable(new Variable(localElement));
/*      */       }
/*      */     }
/*      */ 
/*      */     public void toXML(Element paramElement)
/*      */     {
/*  540 */       Document localDocument = paramElement.getOwnerDocument();
/*  541 */       paramElement.setAttribute("name", this.name);
/*  542 */       if (this.any) paramElement.setAttribute("any", "true");
/*  543 */       for (Variable localVariable : this.variables) {
/*  544 */         Element localElement = localDocument.createElement("variable");
/*  545 */         localVariable.toXML(localElement);
/*  546 */         paramElement.appendChild(localElement);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean isSame(DatabaseMetaData.Type paramType)
/*      */     {
/*  553 */       Bean localBean = (Bean)paramType;
/*  554 */       if ((!this.name.equals(localBean.name)) || (this.any != localBean.any) || (this.constant != localBean.constant))
/*  555 */         return false;
/*  556 */       if (this.variables.size() != localBean.variables.size())
/*  557 */         return false;
/*  558 */       for (int i = 0; i != this.variables.size(); i++) {
/*  559 */         if (!((Variable)this.variables.get(i)).isSame((Variable)localBean.variables.get(i)))
/*  560 */           return false;
/*      */       }
/*  562 */       return true;
/*      */     }
/*      */ 
/*      */     void compile(int paramInt)
/*      */     {
/*  569 */       for (Object localObject = this.variables.iterator(); ((Iterator)localObject).hasNext(); ) { Variable localVariable = (Variable)((Iterator)localObject).next();
/*  570 */         localVariable.compile(paramInt);
/*      */       }
/*  572 */       switch (paramInt) {
/*      */       case 1:
/*  574 */         localObject = new DatabaseMetaData.Type.Depends(this);
/*  575 */         depends((DatabaseMetaData.Type.Depends)localObject);
/*  576 */         this.depends = ((DatabaseMetaData.Type.Depends)localObject).getDepends();
/*      */       }
/*      */     }
/*      */ 
/*      */     public Set<DatabaseMetaData.Type> depends()
/*      */     {
/*  583 */       return this.depends;
/*      */     }
/*      */ 
/*      */     protected void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */     {
/*  588 */       if (paramDepends.add(this))
/*  589 */         for (Variable localVariable : this.variables)
/*  590 */           localVariable.depends(paramDepends);
/*      */     }
/*      */ 
/*      */     public String getName()
/*      */     {
/*  596 */       return this.name;
/*      */     }
/*      */ 
/*      */     public String getClassName()
/*      */     {
/*  601 */       return "xbean.__." + this.name + "$Data";
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type.TypeId getTypeId()
/*      */     {
/*  606 */       return DatabaseMetaData.Type.TypeId.BEAN;
/*      */     }
/*      */ 
/*      */     public boolean isAny()
/*      */     {
/*  611 */       return this.any;
/*      */     }
/*      */ 
/*      */     public boolean isConstant()
/*      */     {
/*  616 */       return this.constant;
/*      */     }
/*      */ 
/*      */     public long sizeof(Integer paramInteger)
/*      */     {
/*  621 */       long l = 0L;
/*  622 */       for (Variable localVariable : this.variables)
/*  623 */         l += localVariable.sizeof();
/*  624 */       return l;
/*      */     }
/*      */ 
/*      */     public Object unmarshal(OctetsStream paramOctetsStream)
/*      */     {
/*  629 */       Marshal localMarshal = (Marshal)newInstance();
/*      */       try {
/*  631 */         localMarshal.unmarshal(paramOctetsStream);
/*  632 */         return localMarshal;
/*      */       } catch (MarshalException localMarshalException) {
/*  634 */         throw new RuntimeException(localMarshalException);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Class<?> getClazz()
/*      */     {
/*      */       try {
/*  641 */         return Class.forName(getClassName());
/*      */       } catch (Exception localException) {
/*  643 */         throw new RuntimeException(localException);
/*      */       }
/*      */     }
/*      */ 
/*      */     public OctetsStream marshal(Object paramObject)
/*      */     {
/*  649 */       getClazz().cast(paramObject);
/*  650 */       return new OctetsStream().marshal((Marshal)paramObject);
/*      */     }
/*      */ 
/*      */     public List<Variable> getVariables() {
/*  654 */       return Collections.unmodifiableList(this.variables);
/*      */     }
/*      */ 
/*      */     public Variable getVariable(String paramString) {
/*  658 */       return (Variable)this.variablesByName.get(paramString);
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData getDatabaseMetaData() {
/*  662 */       return DatabaseMetaData.this;
/*      */     }
/*      */ 
/*      */     void addVariable(Variable paramVariable) {
/*  666 */       if (null != this.variablesByName.put(paramVariable.getName(), paramVariable))
/*  667 */         throw new RuntimeException("duplicate variable: " + paramVariable + "@" + this);
/*  668 */       this.variables.add(paramVariable); } 
/*      */     public final class Variable implements DatabaseMetaData.MarshalXML { private final String name;
/*      */       private final String typeName;
/*      */       private final String keyTypeName;
/*      */       private final String valueTypeName;
/*      */       private final String comparatorClassName;
/*      */       private final String initial;
/*      */       private final ForeignConf foreign;
/*      */       private final CapacityConf capacity;
/*      */       private DatabaseMetaData.Type typeType;
/*      */       private DatabaseMetaData.Type keyType;
/*      */       private DatabaseMetaData.Type valueType;
/*      */ 
/*  689 */       void compile(int paramInt) { if (paramInt == 0) {
/*  690 */           this.typeType = DatabaseMetaData.this.getType(this.typeName, DatabaseMetaData.Bean.this.any);
/*  691 */           this.keyType = DatabaseMetaData.this.getType(this.keyTypeName, DatabaseMetaData.Bean.this.any);
/*  692 */           this.valueType = DatabaseMetaData.this.getType(this.valueTypeName, DatabaseMetaData.Bean.this.any);
/*      */         } }
/*      */ 
/*      */       public boolean isSame(Variable paramVariable)
/*      */       {
/*  697 */         return (this.name.equals(paramVariable.name)) && (this.typeType.isSame(paramVariable.typeType)) && ((this.keyType == null) || (this.keyType.isSame(paramVariable.keyType))) && ((this.valueType == null) || (this.valueType.isSame(paramVariable.valueType))) && (this.comparatorClassName.equals(paramVariable.comparatorClassName));
/*      */       }
/*      */ 
/*      */       public void depends(DatabaseMetaData.Type.Depends paramDepends)
/*      */       {
/*  702 */         paramDepends.push(this);
/*  703 */         getTypeType().depends(paramDepends);
/*  704 */         paramDepends.pop(this);
/*      */       }
/*      */ 
/*      */       public String toString()
/*      */       {
/*  709 */         return this.name + "/" + getTypeType().getClassName();
/*      */       }
/*      */ 
/*      */       public Variable(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String arg9)
/*      */       {
/*  715 */         this.name = paramString1;
/*      */ 
/*  717 */         this.typeName = paramString2;
/*  718 */         this.keyTypeName = paramString3;
/*  719 */         this.valueTypeName = paramString4;
/*  720 */         this.comparatorClassName = paramString5;
/*      */ 
/*  722 */         this.initial = paramString6;
/*  723 */         this.foreign = new ForeignConf(paramString7);
/*      */         String str;
/*  724 */         this.capacity = new CapacityConf(str);
/*      */       }
/*      */ 
/*      */       public DatabaseMetaData.Bean getBean()
/*      */       {
/*  732 */         return DatabaseMetaData.Bean.this;
/*      */       }
/*      */ 
/*      */       public DatabaseMetaData.Bean getOwnerBean()
/*      */       {
/*  739 */         return DatabaseMetaData.Bean.this;
/*      */       }
/*      */ 
/*      */       public String getName() {
/*  743 */         return this.name;
/*      */       }
/*      */ 
/*      */       public String getTypeName() {
/*  747 */         return this.typeName;
/*      */       }
/*      */ 
/*      */       public String getKeyTypeName() {
/*  751 */         return this.keyTypeName;
/*      */       }
/*      */ 
/*      */       public String getValueTypeName() {
/*  755 */         return this.valueTypeName;
/*      */       }
/*      */ 
/*      */       public String getComparatorClassName() {
/*  759 */         return this.comparatorClassName;
/*      */       }
/*      */ 
/*      */       public String getInitial() {
/*  763 */         return this.initial;
/*      */       }
/*      */ 
/*      */       public ForeignConf getForeign()
/*      */       {
/*  774 */         return this.foreign;
/*      */       }
/*      */ 
/*      */       public CapacityConf getCapacity() {
/*  778 */         return this.capacity;
/*      */       }
/*      */ 
/*      */       public DatabaseMetaData.Type getTypeType() {
/*  782 */         return this.typeType;
/*      */       }
/*      */ 
/*      */       public DatabaseMetaData.Type getKeyType() {
/*  786 */         return this.keyType;
/*      */       }
/*      */ 
/*      */       public DatabaseMetaData.Type getValueType() {
/*  790 */         return this.valueType;
/*      */       }
/*      */ 
/*      */       public long sizeof() {
/*  794 */         DatabaseMetaData.Type localType = getTypeType();
/*  795 */         Integer localInteger = this.capacity.getCapacity();
/*  796 */         switch (DatabaseMetaData.1.$SwitchMap$xdb$util$DatabaseMetaData$Type$TypeId[localType.getTypeId().ordinal()]) { case 1:
/*      */         case 2:
/*      */         case 3:
/*  798 */           return (null != localInteger ? localInteger.intValue() : '') * getValueType().sizeof(this.capacity.getValue());
/*      */         case 4:
/*      */         case 5:
/*  802 */           return (null != localInteger ? localInteger.intValue() : '') * (getKeyType().sizeof(this.capacity.getKey()) + getValueType().sizeof(this.capacity.getValue()));
/*      */         }
/*      */ 
/*  808 */         return localType.sizeof(localInteger);
/*      */       }
/*      */ 
/*      */       Variable(Element arg2)
/*      */       {
/*      */         Object localObject;
/*  813 */         this.name = localObject.getAttribute("name");
/*  814 */         this.keyTypeName = localObject.getAttribute("keyTypeName");
/*  815 */         this.typeName = localObject.getAttribute("typeName");
/*  816 */         this.valueTypeName = localObject.getAttribute("valueTypeName");
/*  817 */         this.comparatorClassName = localObject.getAttribute("comparatorClassName");
/*  818 */         this.initial = localObject.getAttribute("initial");
/*  819 */         this.foreign = new ForeignConf(localObject.getAttribute("foreign"));
/*  820 */         this.capacity = new CapacityConf(localObject.getAttribute("capacity"));
/*      */       }
/*      */ 
/*      */       public void toXML(Element paramElement)
/*      */       {
/*  826 */         if (!this.name.isEmpty()) paramElement.setAttribute("name", this.name);
/*  827 */         if (!this.keyTypeName.isEmpty()) paramElement.setAttribute("keyTypeName", this.keyTypeName);
/*  828 */         if (!this.typeName.isEmpty()) paramElement.setAttribute("typeName", this.typeName);
/*  829 */         if (!this.valueTypeName.isEmpty()) paramElement.setAttribute("valueTypeName", this.valueTypeName);
/*  830 */         if (!this.comparatorClassName.isEmpty()) paramElement.setAttribute("comparatorClassName", this.comparatorClassName);
/*  831 */         if (!this.initial.isEmpty()) paramElement.setAttribute("initial", this.initial);
/*  832 */         if (!this.foreign.toString().isEmpty()) paramElement.setAttribute("foreign", this.foreign.toString());
/*  833 */         if (!this.capacity.toString().isEmpty()) paramElement.setAttribute("capacity", this.capacity.toString());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public final class Table
/*      */     implements DatabaseMetaData.MarshalXML
/*      */   {
/*      */     private final String name;
/*      */     private final Table.Persistence persistence;
/*      */     private final String keyName;
/*      */     private final boolean autoKey;
/*      */     private final String valueName;
/*      */     private final ForeignConf foreign;
/*      */     private final CapacityConf capacity;
/*      */     private DatabaseMetaData.Type keyType;
/*      */     private DatabaseMetaData.Type valueType;
/*      */ 
/*      */     boolean isSame(Table paramTable)
/*      */     {
/*  390 */       return (this.name.equals(paramTable.name)) && (this.persistence.equals(paramTable.persistence)) && (this.keyType.isSame(paramTable.keyType)) && (this.autoKey == paramTable.autoKey) && (this.valueType.isSame(paramTable.valueType));
/*      */     }
/*      */ 
/*      */     void compile(int paramInt)
/*      */     {
/*  395 */       switch (paramInt) {
/*      */       case 0:
/*  397 */         this.keyType = DatabaseMetaData.this.getType(this.keyName);
/*  398 */         this.valueType = DatabaseMetaData.this.getType(this.valueName);
/*      */       }
/*      */     }
/*      */ 
/*      */     public Table(String paramString1, String paramString2, String paramBoolean, boolean paramString3, String paramString4, String paramString5, String arg8)
/*      */     {
/*  416 */       this.name = paramString1;
/*  417 */       this.persistence = Table.Persistence.valueOf(paramString2);
/*  418 */       this.keyName = paramBoolean;
/*  419 */       this.autoKey = paramString3;
/*  420 */       this.valueName = paramString4;
/*  421 */       this.foreign = new ForeignConf(paramString5);
/*      */       String str;
/*  422 */       this.capacity = new CapacityConf(str);
/*      */     }
/*      */ 
/*      */     public String getName() {
/*  426 */       return this.name;
/*      */     }
/*      */ 
/*      */     public String getClassName() {
/*  430 */       return new StringBuilder().append("xtable.").append(this.name).toString();
/*      */     }
/*      */ 
/*      */     public String getKeyName() {
/*  434 */       return this.keyName;
/*      */     }
/*      */ 
/*      */     public String getValueName() {
/*  438 */       return this.valueName;
/*      */     }
/*      */ 
/*      */     public Table.Persistence getPersistence() {
/*  442 */       return this.persistence;
/*      */     }
/*      */ 
/*      */     public boolean isPersistence() {
/*  446 */       return this.persistence == Table.Persistence.DB;
/*      */     }
/*      */ 
/*      */     public boolean isAutoKey() {
/*  450 */       return this.autoKey;
/*      */     }
/*      */ 
/*      */     public ForeignConf getForeign() {
/*  454 */       return this.foreign;
/*      */     }
/*      */ 
/*      */     public CapacityConf getCapacity() {
/*  458 */       return this.capacity;
/*      */     }
/*      */ 
/*      */     public long sizeof() {
/*  462 */       return getKeyType().sizeof(this.capacity.getKey()) + getValueType().sizeof(this.capacity.getValue());
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type getKeyType()
/*      */     {
/*  467 */       return this.keyType;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData.Type getValueType() {
/*  471 */       return this.valueType;
/*      */     }
/*      */ 
/*      */     public DatabaseMetaData getDatabaseMetaData() {
/*  475 */       return DatabaseMetaData.this;
/*      */     }
/*      */ 
/*      */     public String getNameEx()
/*      */     {
/*  484 */       return new StringBuilder().append(isPersistence() ? "!" : "").append(this.name).append(this.autoKey ? "+" : "").toString();
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  489 */       return new StringBuilder().append(isPersistence() ? "!" : "").append(this.name).append("<").append(this.keyName).append(this.autoKey ? "+" : "").append(", ").append(this.valueName).append(">").toString();
/*      */     }
/*      */ 
/*      */     public void toXML(Element paramElement)
/*      */     {
/*  496 */       paramElement.setAttribute("name", this.name);
/*  497 */       paramElement.setAttribute("persistence", this.persistence.name());
/*  498 */       paramElement.setAttribute("keyName", this.keyName);
/*  499 */       paramElement.setAttribute("autoKey", this.autoKey ? "true" : "false");
/*  500 */       paramElement.setAttribute("valueName", this.valueName);
/*  501 */       paramElement.setAttribute("capacity", this.capacity.toString());
/*  502 */       paramElement.setAttribute("foreign", this.foreign.toString());
/*      */     }
/*      */ 
/*      */     public Table(Element arg2) {
/*  506 */       this(localObject.getAttribute("name"), localObject.getAttribute("persistence"), localObject.getAttribute("keyName"), localObject.getAttribute("autoKey").equals("true"), localObject.getAttribute("valueName"), localObject.getAttribute("foreign"), localObject.getAttribute("capacity"));
/*      */     }
/*      */   }
/*      */ 
/*      */   static abstract interface MarshalXML
/*      */   {
/*      */     public abstract void toXML(Element paramElement);
/*      */   }
/*      */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.DatabaseMetaData
 * JD-Core Version:    0.6.2
 */