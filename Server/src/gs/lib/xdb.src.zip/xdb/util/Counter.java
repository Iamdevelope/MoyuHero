/*     */ package xdb.util;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.ReflectionException;
/*     */ 
/*     */ public class Counter
/*     */   implements DynamicMBean
/*     */ {
/*  20 */   private volatile Map<String, AtomicLong> noLock = new HashMap();
/*  21 */   private HashMap<String, AtomicLong> underLock = new HashMap();
/*  22 */   private Lock lock = new ReentrantLock();
/*     */ 
/*     */   private AtomicLong open(String paramString)
/*     */   {
/*  26 */     Map localMap = this.noLock;
/*  27 */     AtomicLong localAtomicLong1 = (AtomicLong)localMap.get(paramString);
/*  28 */     if (null != localAtomicLong1) {
/*  29 */       return localAtomicLong1;
/*     */     }
/*     */ 
/*  32 */     this.lock.lock();
/*     */     try {
/*  34 */       localAtomicLong1 = (AtomicLong)this.underLock.get(paramString);
/*  35 */       if (null != localAtomicLong1) {
/*  36 */         return localAtomicLong1;
/*     */       }
/*     */ 
/*  40 */       localAtomicLong1 = new AtomicLong(0L);
/*  41 */       this.underLock.put(paramString, localAtomicLong1);
/*     */ 
/*  45 */       Object localObject1 = (Map)this.underLock.clone();
/*  46 */       this.noLock = ((Map)localObject1);
/*     */ 
/*  48 */       return localAtomicLong1;
/*     */     } finally {
/*  50 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void increment(String paramString) {
/*  55 */     open(paramString).incrementAndGet();
/*     */   }
/*     */ 
/*     */   public void increment(String paramString, int paramInt) {
/*  59 */     open(paramString).addAndGet(paramInt);
/*     */   }
/*     */ 
/*     */   public AtomicLong get(String paramString) {
/*  63 */     return (AtomicLong)this.noLock.get(paramString);
/*     */   }
/*     */ 
/*     */   public void set(String paramString, long paramLong) {
/*  67 */     open(paramString).set(paramLong);
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String paramString)
/*     */   {
/*  74 */     return this.noLock.get(paramString);
/*     */   }
/*     */ 
/*     */   public AttributeList getAttributes(String[] paramArrayOfString)
/*     */   {
/*  79 */     AttributeList localAttributeList = new AttributeList();
/*  80 */     for (int i = 0; i < paramArrayOfString.length; i++) {
/*  81 */       Object localObject = getAttribute(paramArrayOfString[i]);
/*  82 */       if (null != localObject)
/*  83 */         localAttributeList.add(new Attribute(paramArrayOfString[i], localObject));
/*     */     }
/*  85 */     return localAttributeList;
/*     */   }
/*     */ 
/*     */   public void setAttribute(Attribute paramAttribute)
/*     */   {
/*     */   }
/*     */ 
/*     */   public AttributeList setAttributes(AttributeList paramAttributeList)
/*     */   {
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */   public Object invoke(String paramString, Object[] paramArrayOfObject, String[] paramArrayOfString)
/*     */     throws MBeanException, ReflectionException
/*     */   {
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */   public MBeanInfo getMBeanInfo()
/*     */   {
/* 105 */     MBeanAttributeInfo[] arrayOfMBeanAttributeInfo = new MBeanAttributeInfo[this.noLock.size()];
/* 106 */     int i = 0;
/* 107 */     for (String str : this.noLock.keySet()) {
/* 108 */       arrayOfMBeanAttributeInfo[(i++)] = new MBeanAttributeInfo(str, "java.lang.Long", str, true, false, false);
/*     */     }
/*     */ 
/* 116 */     return new MBeanInfo(getClass().getName(), "Counter", arrayOfMBeanAttributeInfo, null, null, null);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Counter(String paramString1, String paramString2)
/*     */   {
/* 126 */     MBeans.register(this, paramString1 + ":type=" + paramString2);
/*     */   }
/*     */ 
/*     */   public Counter(MBeans.Manager paramManager, String paramString1, String paramString2)
/*     */   {
/* 136 */     paramManager.register(this, paramString1 + ":type=" + paramString2);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.util.Counter
 * JD-Core Version:    0.6.2
 */