package xdb;

public abstract interface TField<V, F>
{
  public abstract F get(V paramV);
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.TField
 * JD-Core Version:    0.6.2
 */