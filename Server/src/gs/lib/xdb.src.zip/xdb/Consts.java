/*    */ package xdb;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.NavigableMap;
/*    */ import java.util.Set;
/*    */ import xdb.consts.ConstList;
/*    */ import xdb.consts.ConstMap;
/*    */ import xdb.consts.ConstNavigableMap;
/*    */ import xdb.consts.ConstSet;
/*    */ 
/*    */ public final class Consts
/*    */ {
/*    */   public static <E> List<E> constList(List<E> paramList)
/*    */   {
/* 10 */     return new ConstList(paramList);
/*    */   }
/*    */ 
/*    */   public static <E> Set<E> constSet(Set<E> paramSet) {
/* 14 */     return new ConstSet(paramSet);
/*    */   }
/*    */ 
/*    */   public static <K, V> Map<K, V> constMap(Map<K, V> paramMap) {
/* 18 */     return new ConstMap(paramMap);
/*    */   }
/*    */ 
/*    */   public static <K, V> NavigableMap<K, V> constNavigableMap(NavigableMap<K, V> paramNavigableMap) {
/* 22 */     return new ConstNavigableMap(paramNavigableMap);
/*    */   }
/*    */ 
/*    */   public static <T> T[] toConst(T[] paramArrayOfT) {
/* 26 */     for (int i = 0; i < paramArrayOfT.length; i++) {
/* 27 */       paramArrayOfT[i] = toConst(paramArrayOfT[i]);
/*    */     }
/* 29 */     return paramArrayOfT;
/*    */   }
/*    */ 
/*    */   public static <T> T toConst(T paramT) {
/* 33 */     if ((null != paramT) && ((paramT instanceof Bean)))
/*    */     {
/* 35 */       Bean localBean = ((Bean)paramT).toConst();
/* 36 */       return localBean;
/*    */     }
/* 38 */     return paramT;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Consts
 * JD-Core Version:    0.6.2
 */