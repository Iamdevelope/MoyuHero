/*     */ package xdb;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*     */ import xdb.util.Dbx;
/*     */ 
/*     */ public class Tables
/*     */ {
/*  11 */   private final Map<String, Table> tables = new HashMap();
/*  12 */   private final ReentrantReadWriteLock flushLock = new ReentrantReadWriteLock();
/*  13 */   private final Lock checkpointLock = new ReentrantLock();
/*     */   private Logger logger;
/*  18 */   private List<Storage> storages = new ArrayList();
/*  19 */   private TableSys tableSys = new TableSys();
/*     */ 
/* 156 */   private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
/*     */ 
/*     */   public final TableSys getTableSys()
/*     */   {
/*  22 */     return this.tableSys;
/*     */   }
/*     */ 
/*     */   public final Table getTable(String paramString) {
/*  26 */     return (Table)this.tables.get(paramString);
/*     */   }
/*     */ 
/*     */   public final Collection<Table> getTables() {
/*  30 */     return this.tables.values();
/*     */   }
/*     */ 
/*     */   protected Tables()
/*     */   {
/*  35 */     add(this.tableSys);
/*     */   }
/*     */ 
/*     */   protected final void add(Table paramTable) {
/*  39 */     if (null != this.tables.put(paramTable.getName(), paramTable))
/*  40 */       throw new XError("duplicate table name " + paramTable.getName());
/*     */   }
/*     */ 
/*     */   final void open(XdbConf paramXdbConf) {
/*  44 */     if (null != this.logger) {
/*  45 */       throw new XError("tables opened");
/*     */     }
/*  47 */     Dbx.load(paramXdbConf.getLibdbPath(), paramXdbConf.getDbHome());
/*     */ 
/*  50 */     String str = paramXdbConf.getLogHome().toString() + File.separator;
/*     */ 
/*  52 */     for (int i = 0; i < 2; i++) {
/*  53 */       this.logger = new Logger(str, paramXdbConf.getLogPages());
/*  54 */       for (Table localTable2 : this.tables.values()) {
/*  55 */         Storage localStorage = localTable2.open(paramXdbConf, this.logger);
/*  56 */         if (null != localStorage)
/*  57 */           this.storages.add(localStorage);
/*     */       }
/*  59 */       int j = this.logger.verify();
/*  60 */       if (0 == j)
/*     */         break;
/*  62 */       if (1 == j)
/*     */       {
/*  64 */         close();
/*     */       }
/*     */       else {
/*  67 */         throw new XError("db corrupt @" + i);
/*     */       }
/*     */     }
/*     */ 
/*  71 */     Lockeys.getInstance().initializeLockIdMap(this.tables.values());
/*  72 */     for (Table localTable1 : this.tables.values())
/*  73 */       localTable1.initialize(this);
/*     */   }
/*     */ 
/*     */   final void close()
/*     */   {
/*  78 */     this.storages.clear();
/*     */ 
/*  80 */     for (Table localTable : this.tables.values()) {
/*  81 */       localTable.close();
/*     */     }
/*  83 */     if (null != this.logger) {
/*  84 */       this.logger.close();
/*  85 */       this.logger = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   final Lock flushReadLock() {
/*  90 */     return this.flushLock.readLock();
/*     */   }
/*     */ 
/*     */   final boolean isHeldFlushWriteLockByCurrentThread() {
/*  94 */     return this.flushLock.writeLock().isHeldByCurrentThread();
/*     */   }
/*     */ 
/*     */   final Lock flushWriteLock() {
/*  98 */     return this.flushLock.writeLock();
/*     */   }
/*     */ 
/*     */   final void logNotify() {
/* 102 */     for (Table localTable : this.tables.values())
/* 103 */       localTable.logNotify();
/*     */   }
/*     */ 
/*     */   final Lock checkpointLock()
/*     */   {
/* 108 */     return this.checkpointLock;
/*     */   }
/*     */ 
/*     */   final List<Storage> getStorages()
/*     */   {
/* 126 */     return this.storages;
/*     */   }
/*     */ 
/*     */   final Logger getLogger() {
/* 130 */     return this.logger;
/*     */   }
/*     */ 
/*     */   private void copy(File paramFile1, File paramFile2) throws Exception {
/* 134 */     if (Trace.isDebugEnabled()) {
/* 135 */       Trace.debug("copy " + paramFile1 + " " + paramFile2);
/*     */     }
/* 137 */     FileInputStream localFileInputStream = new FileInputStream(paramFile1);
/*     */     try {
/* 139 */       FileOutputStream localFileOutputStream = new FileOutputStream(new File(paramFile2, paramFile1.getName()));
/*     */       try {
/* 141 */         byte[] arrayOfByte = new byte[8192];
/* 142 */         int i = 0;
/* 143 */         while ((i = localFileInputStream.read(arrayOfByte)) > 0)
/* 144 */           localFileOutputStream.write(arrayOfByte, 0, i);
/*     */       }
/*     */       finally {
/*     */       }
/*     */     }
/*     */     finally {
/* 150 */       localFileInputStream.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final boolean isBackupDir(File paramFile)
/*     */   {
/*     */     try
/*     */     {
/* 162 */       sdf.parse(paramFile.getName());
/* 163 */       return true; } catch (ParseException localParseException) {
/*     */     }
/* 165 */     return false;
/*     */   }
/*     */ 
/*     */   final void backupFull()
/*     */     throws Throwable
/*     */   {
/* 171 */     XdbConf localXdbConf = Xdb.getInstance().getConf();
/*     */ 
/* 174 */     String str = sdf.format(Calendar.getInstance().getTime());
/* 175 */     File localFile1 = new File(localXdbConf.getBackupDir(), str);
/*     */ 
/* 177 */     Trace.warn("backup FULL begin");
/*     */ 
/* 180 */     File localFile2 = new File(localFile1, "dbdata");
/* 181 */     localFile2.mkdirs();
/* 182 */     for (Object localObject1 = this.storages.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Storage)((Iterator)localObject1).next();
/* 183 */       copy(((Storage)localObject2).getFile(), localFile2);
/*     */     }
/*     */ 
/* 186 */     localObject1 = new File(localFile1, "dblogs");
/* 187 */     ((File)localObject1).mkdirs();
/* 188 */     this.logger.removeOlder();
/* 189 */     for (Object localObject2 = Logger.listFiles().iterator(); ((Iterator)localObject2).hasNext(); ) { File localFile3 = (File)((Iterator)localObject2).next();
/* 190 */       copy(localFile3, (File)localObject1);
/*     */     }
/* 192 */     new FileOutputStream(new File(localFile1, "database.backup.done")).close();
/* 193 */     Trace.warn("backup FULL end");
/*     */   }
/*     */ 
/*     */   public static SortedMap<String, File> backups() {
/* 197 */     return backups(Xdb.getInstance().getConf().getBackupDir());
/*     */   }
/*     */ 
/*     */   public static SortedMap<String, File> backups(File paramFile) {
/* 201 */     TreeMap localTreeMap = new TreeMap();
/* 202 */     File[] arrayOfFile1 = paramFile.listFiles();
/* 203 */     if (null != arrayOfFile1) {
/* 204 */       for (File localFile : arrayOfFile1) {
/* 205 */         if ((localFile.isDirectory()) && (isBackupDir(localFile)))
/* 206 */           localTreeMap.put(localFile.getName(), localFile);
/*     */       }
/*     */     }
/* 209 */     return localTreeMap;
/*     */   }
/*     */ 
/*     */   final void backupInc() throws Throwable
/*     */   {
/* 214 */     Trace.warn("backup INCREMENT begin");
/*     */ 
/* 216 */     SortedMap localSortedMap1 = backups();
/* 217 */     if (localSortedMap1.isEmpty()) {
/* 218 */       Trace.warn("backup INCREMENT end. NO FULL BACKUP FOUND.");
/* 219 */       return;
/*     */     }
/* 221 */     File localFile1 = new File((File)localSortedMap1.get(localSortedMap1.lastKey()), "dblogs");
/* 222 */     SortedMap localSortedMap2 = Logger.sortedFiles(localFile1);
/* 223 */     if (Trace.isDebugEnabled())
/* 224 */       Trace.debug(localSortedMap2.values());
/* 225 */     for (File localFile2 : Logger.listFiles()) {
/* 226 */       if (false == localSortedMap2.containsKey(localFile2.getName())) {
/* 227 */         copy(localFile2, localFile1);
/*     */       }
/*     */     }
/*     */ 
/* 231 */     if (!localSortedMap2.isEmpty()) {
/* 232 */       copy((File)localSortedMap2.get(localSortedMap2.lastKey()), localFile1);
/*     */     }
/* 234 */     Trace.warn("backup INCREMENT end");
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 157 */     sdf.setLenient(false);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.Tables
 * JD-Core Version:    0.6.2
 */