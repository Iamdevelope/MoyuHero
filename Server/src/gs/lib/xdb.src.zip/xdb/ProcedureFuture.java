/*     */ package xdb;
/*     */ 
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.RunnableFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import xdb.util.ScheduledTimeoutExecutor;
/*     */ import xdb.util.TimeoutExecutor;
/*     */ 
/*     */ class ProcedureFuture<P extends Procedure>
/*     */   implements RunnableFuture<P>
/*     */ {
/*     */   private volatile Future<P> future;
/*     */   private final P p;
/*     */   private final Procedure.Done<P> done;
/*  26 */   private int ranTimes = 0;
/*     */ 
/*     */   public ProcedureFuture(P paramP) {
/*  29 */     this.p = paramP;
/*  30 */     this.future = Xdb.executor().getProcedureTimeoutExecutor().submit(this, paramP, paramP.getConf().getMaxExecutionTime());
/*  31 */     this.done = null;
/*     */   }
/*     */ 
/*     */   public ProcedureFuture(P paramP, Procedure.Done<P> paramDone) {
/*  35 */     this.p = paramP;
/*  36 */     this.done = paramDone;
/*  37 */     this.future = Xdb.executor().getProcedureTimeoutExecutor().submit(this, paramP, paramP.getConf().getMaxExecutionTime());
/*     */   }
/*     */ 
/*     */   private void done() {
/*  41 */     this.p.fetchTasks();
/*     */ 
/*  43 */     Xdb.executor().execute(new Runnable()
/*     */     {
/*     */       public void run() {
/*  46 */         ProcedureFuture.this.p.runLastTasks();
/*     */       }
/*     */     });
/*  50 */     if (null != this.done)
/*     */       try {
/*  52 */         this.done.doDone(this.p);
/*     */       }
/*     */       catch (Throwable localThrowable)
/*     */       {
/*  58 */         Trace.error("doDone", localThrowable);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  75 */     this.ranTimes += 1;
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  80 */         Transaction.create().perform(this.p);
/*     */       } finally {
/*  82 */         Transaction.destroy();
/*     */       }
/*  84 */       done();
/*     */     }
/*     */     catch (XLockDead localXLockDead) {
/*  87 */       if (this.ranTimes >= this.p.getConf().getRetryTimes()) {
/*  88 */         done();
/*  89 */         throw new XAngelError();
/*     */       }
/*  91 */       int i = Xdb.random().nextInt(this.p.getConf().getRetryDelay());
/*  92 */       this.future = Xdb.executor().getScheduledTimeoutExecutor().schedule(Executors.callable(this, this.p), i, TimeUnit.MILLISECONDS, this.p.getConf().getMaxExecutionTime());
/*     */ 
/*  95 */       throw localXLockDead;
/*     */     }
/*     */     catch (Error localError) {
/*  98 */       done();
/*  99 */       throw localError;
/*     */     }
/*     */     catch (Throwable localThrowable) {
/* 102 */       done();
/* 103 */       throw new XError(localThrowable);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean cancel(boolean paramBoolean)
/*     */   {
/* 111 */     return this.future.cancel(paramBoolean);
/*     */   }
/*     */ 
/*     */   public P get() throws InterruptedException, ExecutionException
/*     */   {
/*     */     while (true)
/*     */       try {
/* 118 */         this.future.get();
/* 119 */         return this.p;
/*     */       } catch (ExecutionException localExecutionException) {
/* 121 */         if (!(localExecutionException.getCause() instanceof XLockDead))
/* 122 */           throw localExecutionException;
/*     */       }
/*     */   }
/*     */ 
/*     */   public P get(long paramLong, TimeUnit paramTimeUnit)
/*     */     throws InterruptedException, ExecutionException, TimeoutException
/*     */   {
/*     */     while (true)
/*     */       try
/*     */       {
/* 133 */         this.future.get(paramLong, paramTimeUnit);
/* 134 */         return this.p;
/*     */       } catch (ExecutionException localExecutionException) {
/* 136 */         if (!(localExecutionException.getCause() instanceof XLockDead))
/* 137 */           throw localExecutionException;
/*     */       }
/*     */   }
/*     */ 
/*     */   public boolean isCancelled()
/*     */   {
/* 145 */     return this.future.isCancelled();
/*     */   }
/*     */ 
/*     */   public boolean isDone()
/*     */   {
/* 150 */     return this.future.isDone();
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xdb.ProcedureFuture
 * JD-Core Version:    0.6.2
 */