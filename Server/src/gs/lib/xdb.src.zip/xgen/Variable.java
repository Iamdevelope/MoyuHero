/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Set;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import xdb.util.DatabaseMetaData.Bean.Variable;
/*     */ 
/*     */ public class Variable
/*     */ {
/*     */   private String name;
/*     */   private String type;
/*     */   private String key;
/*     */   private String value;
/*     */   private String initial;
/*     */   private String comment;
/*     */   private String comparator;
/*     */   private String foreign;
/*     */   private String capacity;
/*     */   private String Name;
/*     */   private Type vartype;
/* 212 */   private MODIFY_TYPES modifytype = MODIFY_TYPES.NONE;
/*     */ 
/*     */   public String getComparator()
/*     */   {
/*  24 */     return this.comparator;
/*     */   }
/*     */ 
/*     */   public String getComment() {
/*  28 */     return this.comment;
/*     */   }
/*     */ 
/*     */   public String getInitial() {
/*  32 */     return this.initial;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  36 */     return this.Name;
/*     */   }
/*     */ 
/*     */   public String getname() {
/*  40 */     return this.name;
/*     */   }
/*     */ 
/*     */   Variable(String paramString)
/*     */   {
/*  45 */     this.name = paramString;
/*  46 */     this.Name = Main.toUpper1(paramString);
/*  47 */     this.comment = "";
/*  48 */     this.initial = "";
/*     */   }
/*     */ 
/*     */   public Variable(Element paramElement) {
/*  52 */     this.name = paramElement.getAttribute("name").trim().toLowerCase();
/*  53 */     Main.verifyName(this.name);
/*  54 */     this.type = paramElement.getAttribute("type").trim();
/*  55 */     this.key = paramElement.getAttribute("key").trim();
/*  56 */     this.value = paramElement.getAttribute("value").trim();
/*  57 */     this.initial = paramElement.getAttribute("default").trim();
/*  58 */     this.comparator = paramElement.getAttribute("comparator");
/*  59 */     this.foreign = paramElement.getAttribute("foreign").trim();
/*  60 */     this.capacity = paramElement.getAttribute("capacity");
/*     */ 
/*  62 */     Node localNode = paramElement.getNextSibling();
/*  63 */     if ((localNode != null) && (3 == localNode.getNodeType())) {
/*  64 */       this.comment = localNode.getTextContent().trim().replaceAll("[\r\n]", "");
/*     */     }
/*     */ 
/*  67 */     this.Name = Main.toUpper1(this.name);
/*     */   }
/*     */ 
/*     */   public Type getVartype()
/*     */   {
/*  74 */     return this.vartype;
/*     */   }
/*     */ 
/*     */   public void compile(Xdb paramXdb) {
/*  78 */     this.vartype = Type.compile(this.type, this.key, this.value);
/*     */   }
/*     */ 
/*     */   public void verify(Xdb paramXdb, Type paramType)
/*     */   {
/*  83 */     this.vartype.verifyCapacity(paramXdb, new Capacity(this.capacity, "bean." + paramType.getName() + "." + getname()));
/*     */ 
/*  85 */     if ((paramType.getName().equals("fxbean0")) && (this.name.equals("a"))) {
/*  86 */       System.out.println();
/*     */     }
/*     */ 
/*  89 */     if (!this.foreign.isEmpty())
/*     */     {
/*  91 */       this.vartype.verifyForeign(paramXdb, new Foreign(this.foreign, paramType.getName() + "." + getname()));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void collectForeigns(Set<String> paramSet) {
/*  96 */     Foreign localForeign = new Foreign(this.foreign, "");
/*  97 */     if (null != localForeign.getKey())
/*  98 */       paramSet.add(localForeign.getKey());
/*  99 */     if (null != localForeign.getValue())
/* 100 */       paramSet.add(localForeign.getValue());
/*     */   }
/*     */ 
/*     */   public void declare(PrintStream paramPrintStream, String paramString) {
/* 104 */     paramPrintStream.println(paramString + "private " + this.vartype.getTypeName() + " " + this.name + ";" + " // " + this.comment);
/*     */   }
/*     */ 
/*     */   public void construct(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 108 */     this.vartype.construct(paramXBean, this, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void deepCopy(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 112 */     this.vartype.deepCopy(paramXBean.isData(), this, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void marshal(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 116 */     this.vartype.marshal(paramXBean, this, paramPrintStream, paramString, getname());
/*     */   }
/*     */ 
/*     */   public void unmarshal(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 120 */     this.vartype.unmarshal(paramXBean, this, paramPrintStream, paramString, getname());
/*     */   }
/*     */ 
/*     */   public void setterInterface(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 124 */     this.vartype.setterInterface(paramXBean, this, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void setterConst(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 128 */     this.vartype.setterConst(paramXBean, this, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void setter(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 132 */     this.vartype.setter(paramXBean, this, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void setterData(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 136 */     this.vartype.setterData(paramXBean, this, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void getterInterface(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 140 */     this.vartype.getterInterface(paramXBean, this, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void getterConst(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 144 */     this.vartype.getterConst(paramXBean, this, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void getter(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 148 */     this.vartype.getter(paramXBean, this, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void getterData(XBean paramXBean, PrintStream paramPrintStream, String paramString) {
/* 152 */     this.vartype.getterData(paramXBean, this, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void equals(PrintStream paramPrintStream, String paramString) {
/* 156 */     paramPrintStream.println(paramString + "if (" + this.vartype.notEquals(this.name) + ") return false;");
/*     */   }
/*     */ 
/*     */   public void hashCode(PrintStream paramPrintStream, String paramString) {
/* 160 */     paramPrintStream.println(paramString + "_h_ += " + this.vartype.hashCode(this.name) + ";");
/*     */   }
/*     */ 
/*     */   public void toString(PrintStream paramPrintStream, String paramString) {
/* 164 */     this.vartype.toString(paramPrintStream, paramString, this.name);
/*     */   }
/*     */ 
/*     */   public String newListenable(XBean paramXBean) {
/* 168 */     return this.vartype.newListenable(paramXBean, this);
/*     */   }
/*     */ 
/*     */   public boolean isAny() {
/* 172 */     return this.vartype.isAny();
/*     */   }
/*     */ 
/*     */   public void printSelect(PrintStream paramPrintStream, String paramString1, String paramString2) {
/* 176 */     if (!this.vartype.isCloneable()) {
/* 177 */       return;
/*     */     }
/* 179 */     String str = this.vartype.getBoxingName();
/* 180 */     paramPrintStream.println("\tpublic static " + str + " select" + getName() + "(" + paramString1 + " key) {");
/* 181 */     paramPrintStream.println("\t\treturn getTable().select(key, new xdb.TField<" + paramString2 + ", " + str + ">() {");
/* 182 */     paramPrintStream.print("\t\t\t\tpublic " + str + " get(" + paramString2 + " v) { return v.get" + getName());
/* 183 */     if (((this.vartype instanceof TypeCollection)) || ((this.vartype instanceof TypeBaseMap))) paramPrintStream.print("AsData");
/* 184 */     if ((this.vartype instanceof TypeBinary)) paramPrintStream.print("Copy");
/* 185 */     paramPrintStream.println("(); }");
/* 186 */     paramPrintStream.println("\t\t\t});");
/* 187 */     paramPrintStream.println("\t}");
/* 188 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public String compareto()
/*     */   {
/* 193 */     return this.vartype.compareto(this.name, "_o_." + this.name);
/*     */   }
/*     */ 
/*     */   public void printMetaData(PrintStream paramPrintStream, String paramString)
/*     */   {
/* 198 */     paramPrintStream.println(paramString + ", " + Main.quote(this.name));
/* 199 */     paramPrintStream.println(paramString + ", " + Main.quote(this.type) + ", " + Main.quote(this.key) + ", " + Main.quote(this.value) + ", " + Main.quote(this.comparator));
/*     */ 
/* 201 */     paramPrintStream.println(paramString + ", " + Main.quote(this.initial) + ", " + Main.quote(this.foreign) + ", " + Main.quote(this.capacity));
/*     */   }
/*     */ 
/*     */   public void setModifyType(MODIFY_TYPES paramMODIFY_TYPES)
/*     */   {
/* 216 */     this.modifytype = paramMODIFY_TYPES;
/*     */   }
/*     */ 
/*     */   public MODIFY_TYPES getModifyType()
/*     */   {
/* 221 */     return this.modifytype;
/*     */   }
/*     */   Variable(DatabaseMetaData.Bean.Variable paramVariable) {
/* 224 */     this.name = paramVariable.getName();
/* 225 */     Main.verifyName(this.name);
/* 226 */     this.type = paramVariable.getTypeName();
/* 227 */     this.key = paramVariable.getKeyTypeName();
/* 228 */     this.value = paramVariable.getValueTypeName();
/* 229 */     if (this.value.isEmpty())
/* 230 */       this.value = "";
/* 231 */     this.foreign = "";
/* 232 */     this.initial = "";
/* 233 */     this.capacity = "1024";
/* 234 */     this.comparator = "";
/*     */ 
/* 236 */     this.Name = Main.toUpper1(this.name);
/*     */   }
/*     */ 
/*     */   public String getKeyTypeName()
/*     */   {
/* 243 */     return this.key;
/*     */   }
/*     */ 
/*     */   public String getValueTypeName()
/*     */   {
/* 248 */     return this.value;
/*     */   }
/*     */ 
/*     */   public static enum MODIFY_TYPES
/*     */   {
/* 207 */     ADD, 
/* 208 */     REMOVE, 
/* 209 */     NONE;
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.Variable
 * JD-Core Version:    0.6.2
 */