/*    */ package xgen;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class TypeList extends TypeCollection
/*    */ {
/*    */   public String getName()
/*    */   {
/* 10 */     return "list";
/*    */   }
/*    */ 
/*    */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*    */   {
/* 15 */     paramForeign.throwIf(null != paramForeign.getKey(), "[list] need value only.");
/* 16 */     if (null != paramForeign.getValue()) {
/* 17 */       Table localTable = paramXdb.getTable(paramForeign.getValue());
/* 18 */       paramForeign.throwIf(null == localTable, "[list.value] table not exist.");
/* 19 */       paramForeign.throwIf(localTable.isMemory(), "[list.value] foreign table is memory");
/* 20 */       paramForeign.throwIf(localTable.getKeyType() != getValueType(), "[list.value] type not match");
/*    */     }
/*    */   }
/*    */ 
/*    */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*    */   {
/* 26 */     paramCapacity.capacityNeed();
/* 27 */     paramCapacity.keyNotNeed();
/* 28 */     getValueType().verifyCapacity(paramXdb, paramCapacity.extractValue());
/*    */   }
/*    */ 
/*    */   public String getCollectionName()
/*    */   {
/* 33 */     return "java.util.LinkedList";
/*    */   }
/*    */ 
/*    */   protected String getGetterName()
/*    */   {
/* 38 */     return "java.util.List" + V();
/*    */   }
/*    */ 
/*    */   public boolean isConstant()
/*    */   {
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */   public String hashCode(String paramString)
/*    */   {
/* 48 */     return paramString + ".hashCode()";
/*    */   }
/*    */ 
/*    */   public String notEquals(String paramString)
/*    */   {
/* 53 */     return "!" + paramString + ".equals(_o_." + paramString + ")";
/*    */   }
/*    */ 
/*    */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*    */   {
/* 58 */     return defineNoParent(paramString);
/*    */   }
/*    */ 
/*    */   public String defineNoParent(String paramString)
/*    */   {
/* 63 */     return getTypeName() + " " + paramString + " = new " + getTypeName() + "();";
/*    */   }
/*    */ 
/*    */   public Type compile(String paramString1, String paramString2)
/*    */   {
/* 68 */     return new TypeList(paramString1, paramString2);
/*    */   }
/*    */ 
/*    */   private TypeList(String paramString1, String paramString2) {
/* 72 */     _compile(paramString1, paramString2);
/*    */   }
/*    */ 
/*    */   TypeList(Map<String, Type> paramMap)
/*    */   {
/* 80 */     paramMap.put(getName(), this);
/*    */   }
/*    */ 
/*    */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*    */   {
/* 85 */     paramPrintStream.println(paramString + paramVariable.getname() + " = new " + getTypeName() + "();");
/*    */   }
/*    */ 
/*    */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*    */   {
/* 90 */     return "new xdb.logs.ListenableChanged().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeList
 * JD-Core Version:    0.6.2
 */