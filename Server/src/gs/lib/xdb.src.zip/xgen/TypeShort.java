/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TypeShort extends Type
/*     */ {
/*     */   public void printTableSelectMethod(PrintStream paramPrintStream, String paramString)
/*     */   {
/*  10 */     String str = getBoxingName();
/*  11 */     paramPrintStream.println("\tpublic static " + str + " select(" + paramString + " key) {");
/*  12 */     paramPrintStream.println("\t\treturn getTable().select(key, new xdb.TField<" + str + ", " + str + ">() {");
/*  13 */     paramPrintStream.println("\t\t\tpublic " + str + " get(" + str + " v) { return v; }");
/*  14 */     paramPrintStream.println("\t\t});");
/*  15 */     paramPrintStream.println("\t}");
/*  16 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  21 */     return "short";
/*     */   }
/*     */ 
/*     */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*     */   {
/*  26 */     paramForeign.throwIf(null != paramForeign.getKey(), "[short] need value only.");
/*  27 */     if (null != paramForeign.getValue()) {
/*  28 */       Table localTable = paramXdb.getTable(paramForeign.getValue());
/*  29 */       paramForeign.throwIf(null == localTable, "[short] table not exist.");
/*  30 */       paramForeign.throwIf(localTable.isMemory(), "[short] foreign table is memory");
/*  31 */       paramForeign.throwIf(localTable.getKeyType() != this, "[short] type not match");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*     */   {
/*  37 */     paramCapacity.notNeed();
/*     */   }
/*     */ 
/*     */   public Type compile(String paramString1, String paramString2)
/*     */   {
/*  42 */     if ((paramString1 != null) && (!paramString1.isEmpty()))
/*  43 */       throw new RuntimeException(getName() + " DO NOT NEED A KEY!");
/*  44 */     if ((paramString2 != null) && (!paramString2.isEmpty()))
/*  45 */       throw new RuntimeException(getName() + " DO NOT NEED A VALUE!");
/*  46 */     return this;
/*     */   }
/*     */ 
/*     */   public String compareto(String paramString1, String paramString2)
/*     */   {
/*  51 */     return "Short.valueOf(" + paramString1 + ").compareTo(" + paramString2 + ")";
/*     */   }
/*     */ 
/*     */   public String getBoxingName()
/*     */   {
/*  56 */     return "Short";
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/*  61 */     return "short";
/*     */   }
/*     */ 
/*     */   public String defineNoParent(String paramString)
/*     */   {
/*  66 */     return getTypeName() + " " + paramString + " = 0;";
/*     */   }
/*     */ 
/*     */   public String notEquals(String paramString)
/*     */   {
/*  71 */     return paramString + " != _o_." + paramString;
/*     */   }
/*     */ 
/*     */   public String hashCode(String paramString)
/*     */   {
/*  76 */     return paramString;
/*     */   }
/*     */ 
/*     */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*     */   {
/*  81 */     return defineNoParent(paramString);
/*     */   }
/*     */ 
/*     */   public void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/*  86 */     paramPrintStream.println(paramString1 + "_os_.marshal(" + paramString2 + ");");
/*     */   }
/*     */ 
/*     */   public void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/*  91 */     paramPrintStream.println(paramString1 + paramString2 + " = _os_.unmarshal_short();");
/*     */   }
/*     */ 
/*     */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*  96 */     String str = paramVariable.getInitial();
/*  97 */     if (!str.isEmpty())
/*  98 */       paramPrintStream.println(paramString + paramVariable.getname() + " = " + str + ";");
/*     */   }
/*     */ 
/*     */   public boolean isConstant()
/*     */   {
/* 103 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isCloneable()
/*     */   {
/* 108 */     return true;
/*     */   }
/*     */ 
/*     */   public String deepCopy(boolean paramBoolean, Variable paramVariable, String paramString)
/*     */   {
/* 113 */     return paramString;
/*     */   }
/*     */ 
/*     */   public void deepCopy(boolean paramBoolean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 118 */     paramPrintStream.println(paramString + paramVariable.getname() + " = _o_." + paramVariable.getname() + ";");
/*     */   }
/*     */ 
/*     */   TypeShort(Map<String, Type> paramMap)
/*     */   {
/* 126 */     paramMap.put(getName(), this);
/*     */   }
/*     */ 
/*     */   public void getterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 131 */     paramPrintStream.println(paramString + "public short get" + paramVariable.getName() + "(); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 136 */     if (null != paramXBean)
/* 137 */       paramPrintStream.println(paramString + "@Override");
/* 138 */     paramPrintStream.println(paramString + "public short get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 139 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 140 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 141 */     paramPrintStream.println(paramString + "}");
/* 142 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 147 */     getter(paramXBean, paramVariable, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void getterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 152 */     if (null != paramXBean)
/* 153 */       paramPrintStream.println(paramString + "@Override");
/* 154 */     paramPrintStream.println(paramString + "public short get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 155 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 156 */     paramPrintStream.println(paramString + "}");
/* 157 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 162 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(short _v_); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void setterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 167 */     paramPrintStream.println(paramString + "@Override");
/* 168 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(short _v_) { // " + paramVariable.getComment());
/* 169 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 170 */     paramPrintStream.println(paramString + "\tthrow new UnsupportedOperationException();");
/* 171 */     paramPrintStream.println(paramString + "}");
/* 172 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 177 */     paramPrintStream.println(paramString + "@Override");
/* 178 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(short _v_) { // " + paramVariable.getComment());
/* 179 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 180 */     paramPrintStream.println(paramString + "\txdb.Logs.logIf(new xdb.LogKey(this, " + Main.quote(paramVariable.getname()) + ") {");
/* 181 */     paramPrintStream.println(paramString + "\t\tprotected xdb.Log create() {");
/* 182 */     paramPrintStream.println(paramString + "\t\t\treturn new xdb.logs.LogShort(this, " + paramVariable.getname() + ") {");
/* 183 */     paramPrintStream.println(paramString + "\t\t\t\tpublic void rollback() { " + paramVariable.getname() + " = _xdb_saved; }");
/* 184 */     paramPrintStream.println(paramString + "\t\t\t};}});");
/* 185 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_;");
/* 186 */     paramPrintStream.println(paramString + "}");
/* 187 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 192 */     paramPrintStream.println(paramString + "@Override");
/* 193 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(short _v_) { // " + paramVariable.getComment());
/* 194 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_;");
/* 195 */     paramPrintStream.println(paramString + "}");
/* 196 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*     */   {
/* 201 */     return "new xdb.logs.ListenableChanged().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*     */   }
/*     */ 
/*     */   public void depends(Set<Type> paramSet)
/*     */   {
/* 206 */     paramSet.add(this);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeShort
 * JD-Core Version:    0.6.2
 */