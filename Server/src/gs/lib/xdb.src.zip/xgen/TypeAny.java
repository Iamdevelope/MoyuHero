/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TypeAny extends Type
/*     */ {
/*     */   private String name;
/*     */ 
/*     */   TypeAny(String paramString)
/*     */   {
/*  11 */     this.name = paramString;
/*     */   }
/*     */ 
/*     */   public void printTableSelectMethod(PrintStream paramPrintStream, String paramString)
/*     */   {
/*  16 */     throw new UnsupportedOperationException("select for " + getName());
/*     */   }
/*     */ 
/*     */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*     */   {
/*  21 */     paramForeign.throwIf(true, "[any] unsupported.");
/*     */   }
/*     */ 
/*     */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*     */   {
/*  26 */     paramCapacity.capacityOnly();
/*     */   }
/*     */ 
/*     */   public Type compile(String paramString1, String paramString2)
/*     */   {
/*  31 */     if ((paramString1 != null) && (!paramString1.isEmpty()))
/*  32 */       throw new RuntimeException(getName() + " DO NOT NEED A KEY!");
/*  33 */     if ((paramString2 != null) && (!paramString2.isEmpty()))
/*  34 */       throw new RuntimeException(getName() + " DO NOT NEED A VALUE!");
/*  35 */     return this;
/*     */   }
/*     */ 
/*     */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*  41 */     paramPrintStream.println(paramString + paramVariable.getname() + " = null;");
/*     */   }
/*     */ 
/*     */   public void deepCopy(boolean paramBoolean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*  46 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public String deepCopy(boolean paramBoolean, Variable paramVariable, String paramString)
/*     */   {
/*  51 */     throw new UnsupportedOperationException(paramVariable.getname() + ":" + paramString);
/*     */   }
/*     */ 
/*     */   public String defineNoParent(String paramString)
/*     */   {
/*  56 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*     */   {
/*  62 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public String getBoxingName()
/*     */   {
/*  68 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  73 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/*  78 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*  83 */     paramPrintStream.println(paramString + "@Override");
/*  84 */     paramPrintStream.println(paramString + "public " + this.name + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/*  85 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/*  86 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/*  87 */     paramPrintStream.println(paramString + "}");
/*  88 */     paramPrintStream.println();
/*     */   }
/*     */ 
/*     */   public void getterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*  93 */     paramPrintStream.println(paramString + "@Override");
/*  94 */     paramPrintStream.println(paramString + "public " + this.name + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/*  95 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/*  96 */     paramPrintStream.println(paramString + "}");
/*  97 */     paramPrintStream.println();
/*     */   }
/*     */ 
/*     */   public void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 102 */     paramPrintStream.println(paramString + "@Override");
/* 103 */     paramPrintStream.println(paramString + "public " + this.name + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 104 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 105 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 106 */     paramPrintStream.println(paramString + "}");
/* 107 */     paramPrintStream.println();
/*     */   }
/*     */ 
/*     */   public void getterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 112 */     paramPrintStream.println(paramString + "public " + this.name + " get" + paramVariable.getName() + "(); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public String hashCode(String paramString)
/*     */   {
/* 117 */     return paramString + ".hashCode()";
/*     */   }
/*     */ 
/*     */   public boolean isConstant()
/*     */   {
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isCloneable()
/*     */   {
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isAny() {
/* 131 */     return true;
/*     */   }
/*     */ 
/*     */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*     */   {
/* 136 */     return "new xdb.logs.ListenableChanged().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*     */   }
/*     */ 
/*     */   public String notEquals(String paramString)
/*     */   {
/* 141 */     return "!" + paramString + ".equals(_o_." + paramString + ")";
/*     */   }
/*     */ 
/*     */   public void setter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 146 */     paramPrintStream.println(paramString + "@Override");
/* 147 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(" + getTypeName() + " _v_) { // " + paramVariable.getComment());
/* 148 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 149 */     paramPrintStream.println(paramString + "\txdb.Logs.logIf(new xdb.LogKey(this, " + Main.quote(paramVariable.getname()) + ") {");
/* 150 */     paramPrintStream.println(paramString + "\t\tprotected xdb.Log create() {");
/* 151 */     paramPrintStream.println(paramString + "\t\t\treturn new xdb.logs.LogObject<" + getTypeName() + ">(this, " + paramVariable.getname() + ") {");
/* 152 */     paramPrintStream.println(paramString + "\t\t\t\tpublic void rollback() { " + paramVariable.getname() + " = _xdb_saved; }");
/* 153 */     paramPrintStream.println(paramString + "\t\t}; }});");
/* 154 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_;");
/* 155 */     paramPrintStream.println(paramString + "}");
/* 156 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 161 */     paramPrintStream.println(paramString + "@Override");
/* 162 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(" + getTypeName() + " _v_) { // " + paramVariable.getComment());
/* 163 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 164 */     paramPrintStream.println(paramString + "\tthrow new UnsupportedOperationException();");
/* 165 */     paramPrintStream.println(paramString + "}");
/* 166 */     paramPrintStream.println();
/*     */   }
/*     */ 
/*     */   public void setterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 171 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(" + getTypeName() + " _v_); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void setterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 176 */     paramPrintStream.println(paramString + "@Override");
/* 177 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(" + getTypeName() + " _v_) { // " + paramVariable.getComment());
/* 178 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_;");
/* 179 */     paramPrintStream.println(paramString + "}");
/* 180 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 185 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 190 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void depends(Set<Type> paramSet)
/*     */   {
/* 195 */     paramSet.add(this);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeAny
 * JD-Core Version:    0.6.2
 */