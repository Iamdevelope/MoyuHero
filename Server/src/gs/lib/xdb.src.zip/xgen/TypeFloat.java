/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TypeFloat extends Type
/*     */ {
/*     */   public void printTableSelectMethod(PrintStream paramPrintStream, String paramString)
/*     */   {
/*  10 */     String str = getBoxingName();
/*  11 */     paramPrintStream.println("\tpublic static " + str + " select(" + paramString + " key) {");
/*  12 */     paramPrintStream.println("\t\treturn getTable().select(key, new xdb.TField<" + str + ", " + str + ">() {");
/*  13 */     paramPrintStream.println("\t\t\tpublic " + str + " get(" + str + " v) { return v; }");
/*  14 */     paramPrintStream.println("\t\t});");
/*  15 */     paramPrintStream.println("\t}");
/*  16 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  21 */     return "float";
/*     */   }
/*     */ 
/*     */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*     */   {
/*  26 */     paramForeign.throwIf(null != paramForeign.getKey(), "[float] need value only.");
/*  27 */     if (null != paramForeign.getValue()) {
/*  28 */       Table localTable = paramXdb.getTable(paramForeign.getValue());
/*  29 */       paramForeign.throwIf(null == localTable, "[float] table not exist.");
/*  30 */       paramForeign.throwIf(localTable.isMemory(), "[float] foreign table is memory");
/*  31 */       paramForeign.throwIf(localTable.getKeyType() != this, "[float] type not match");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*     */   {
/*  37 */     paramCapacity.notNeed();
/*     */   }
/*     */ 
/*     */   public Type compile(String paramString1, String paramString2)
/*     */   {
/*  42 */     if ((paramString1 != null) && (!paramString1.isEmpty()))
/*  43 */       throw new RuntimeException(getName() + " DO NOT NEED A KEY!");
/*  44 */     if ((paramString2 != null) && (!paramString2.isEmpty()))
/*  45 */       throw new RuntimeException(getName() + " DO NOT NEED A VALUE!");
/*  46 */     return this;
/*     */   }
/*     */ 
/*     */   public String compareto(String paramString1, String paramString2)
/*     */   {
/*  52 */     throw new UnsupportedOperationException("compareTo");
/*     */   }
/*     */ 
/*     */   public String getBoxingName()
/*     */   {
/*  57 */     return "Float";
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/*  62 */     return "float";
/*     */   }
/*     */ 
/*     */   public String notEquals(String paramString)
/*     */   {
/*  67 */     return paramString + " != _o_." + paramString;
/*     */   }
/*     */ 
/*     */   public String hashCode(String paramString)
/*     */   {
/*  72 */     return paramString;
/*     */   }
/*     */ 
/*     */   public boolean isConstant()
/*     */   {
/*  77 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isCloneable()
/*     */   {
/*  82 */     return true;
/*     */   }
/*     */ 
/*     */   public String defineNoParent(String paramString)
/*     */   {
/*  87 */     return getTypeName() + " " + paramString + " = 0.0f;";
/*     */   }
/*     */ 
/*     */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*     */   {
/*  92 */     return defineNoParent(paramString);
/*     */   }
/*     */ 
/*     */   public void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/*  97 */     paramPrintStream.println(paramString1 + "_os_.marshal(" + paramString2 + ");");
/*     */   }
/*     */ 
/*     */   public String deepCopy(boolean paramBoolean, Variable paramVariable, String paramString)
/*     */   {
/* 102 */     return paramString;
/*     */   }
/*     */ 
/*     */   public void deepCopy(boolean paramBoolean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 107 */     paramPrintStream.println(paramString + paramVariable.getname() + " = _o_." + paramVariable.getname() + ";");
/*     */   }
/*     */ 
/*     */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 112 */     String str = paramVariable.getInitial();
/* 113 */     if (!str.isEmpty())
/* 114 */       paramPrintStream.println(paramString + paramVariable.getname() + " = " + str + ";");
/*     */   }
/*     */ 
/*     */   public void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 119 */     paramPrintStream.println(paramString1 + paramString2 + " = _os_.unmarshal_float();");
/*     */   }
/*     */ 
/*     */   TypeFloat(Map<String, Type> paramMap)
/*     */   {
/* 127 */     paramMap.put(getName(), this);
/*     */   }
/*     */ 
/*     */   public void getterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 132 */     paramPrintStream.println(paramString + "public float get" + paramVariable.getName() + "(); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 137 */     if (null != paramXBean)
/* 138 */       paramPrintStream.println(paramString + "@Override");
/* 139 */     paramPrintStream.println(paramString + "public float get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 140 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 141 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 142 */     paramPrintStream.println(paramString + "}");
/* 143 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 148 */     getter(paramXBean, paramVariable, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void getterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 153 */     if (null != paramXBean)
/* 154 */       paramPrintStream.println(paramString + "@Override");
/* 155 */     paramPrintStream.println(paramString + "public float get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 156 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 157 */     paramPrintStream.println(paramString + "}");
/* 158 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 163 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(float _v_); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void setterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 168 */     paramPrintStream.println(paramString + "@Override");
/* 169 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(float _v_) { // " + paramVariable.getComment());
/* 170 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 171 */     paramPrintStream.println(paramString + "\tthrow new UnsupportedOperationException();");
/* 172 */     paramPrintStream.println(paramString + "}");
/* 173 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 178 */     paramPrintStream.println(paramString + "@Override");
/* 179 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(float _v_) { // " + paramVariable.getComment());
/* 180 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 181 */     paramPrintStream.println(paramString + "\txdb.Logs.logIf(new xdb.LogKey(this, " + Main.quote(paramVariable.getname()) + ") {");
/* 182 */     paramPrintStream.println(paramString + "\t\tprotected xdb.Log create() {");
/* 183 */     paramPrintStream.println(paramString + "\t\t\treturn new xdb.logs.LogFloat(this, " + paramVariable.getname() + ") {");
/* 184 */     paramPrintStream.println(paramString + "\t\t\t\tpublic void rollback() { " + paramVariable.getname() + " = _xdb_saved; }");
/* 185 */     paramPrintStream.println(paramString + "\t\t\t};}});");
/* 186 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_;");
/* 187 */     paramPrintStream.println(paramString + "}");
/* 188 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 193 */     paramPrintStream.println(paramString + "@Override");
/* 194 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(float _v_) { // " + paramVariable.getComment());
/* 195 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_;");
/* 196 */     paramPrintStream.println(paramString + "}");
/* 197 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*     */   {
/* 202 */     return "new xdb.logs.ListenableChanged().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*     */   }
/*     */ 
/*     */   public void depends(Set<Type> paramSet)
/*     */   {
/* 207 */     paramSet.add(this);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeFloat
 * JD-Core Version:    0.6.2
 */