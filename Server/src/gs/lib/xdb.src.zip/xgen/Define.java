/*    */ package xgen;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ public class Define
/*    */ {
/* 11 */   private static Define ms_define = new Define();
/* 12 */   private HashSet<String> m_locknameset = new HashSet();
/* 13 */   private HashMap<String, Integer> m_cachecapmap = new HashMap();
/* 14 */   private HashMap<String, Integer[]> m_cachepagemap = new HashMap();
/* 15 */   private boolean m_parsed = false;
/*    */ 
/*    */   public static Define getInstance()
/*    */   {
/* 19 */     return ms_define;
/*    */   }
/*    */ 
/*    */   public void parse(Element paramElement)
/*    */   {
/* 24 */     this.m_locknameset.clear();
/* 25 */     this.m_cachecapmap.clear();
/* 26 */     this.m_cachepagemap.clear();
/* 27 */     if (paramElement == null)
/*    */     {
/* 29 */       this.m_parsed = false;
/* 30 */       return;
/*    */     }
/* 32 */     this.m_parsed = true;
/*    */ 
/* 34 */     NodeList localNodeList = paramElement.getChildNodes();
/* 35 */     for (int i = 0; i < localNodeList.getLength(); i++)
/*    */     {
/*    */       try
/*    */       {
/* 39 */         Node localNode = localNodeList.item(i);
/* 40 */         if (localNode.getNodeType() == 1)
/*    */         {
/* 42 */           Element localElement = (Element)localNode;
/* 43 */           String str1 = localElement.getNodeName();
/*    */           String str2;
/* 44 */           if (str1.equals("lock"))
/*    */           {
/* 46 */             str2 = localElement.getAttribute("name");
/* 47 */             if ((str2 != null) && (str2.equals("")))
/*    */               continue;
/* 49 */             this.m_locknameset.add(str2);
/*    */           }
/*    */           else
/*    */           {
/*    */             String str3;
/* 51 */             if (str1.equals("cachecap"))
/*    */             {
/* 53 */               str2 = localElement.getAttribute("name");
/* 54 */               if ((str2 != null) && (str2.equals("")))
/*    */                 continue;
/* 56 */               str3 = localElement.getAttribute("value");
/* 57 */               if (str3 == null)
/*    */                 continue;
/* 59 */               this.m_cachecapmap.put(str2, Integer.valueOf(Integer.parseInt(str3)));
/*    */             }
/* 61 */             else if (str1.equals("cachepage"))
/*    */             {
/* 63 */               str2 = localElement.getAttribute("name");
/* 64 */               if ((str2 != null) && (str2.equals("")))
/*    */                 continue;
/* 66 */               str3 = localElement.getAttribute("low");
/* 67 */               if (str3 == null)
/*    */                 continue;
/* 69 */               String str4 = localElement.getAttribute("high");
/* 70 */               if (str4 == null)
/*    */                 continue;
/* 72 */               this.m_cachepagemap.put(str2, new Integer[] { Integer.valueOf(Integer.parseInt(str3)), Integer.valueOf(Integer.parseInt(str4)) });
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */       catch (NumberFormatException localNumberFormatException) {
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean isParsed() {
/* 83 */     return this.m_parsed;
/*    */   }
/*    */ 
/*    */   public boolean isLockname(String paramString)
/*    */   {
/* 88 */     return this.m_locknameset.contains(paramString);
/*    */   }
/*    */ 
/*    */   public Integer getCacheCap(String paramString)
/*    */   {
/* 93 */     return (Integer)this.m_cachecapmap.get(paramString);
/*    */   }
/*    */ 
/*    */   public Integer[] getCachePage(String paramString)
/*    */   {
/* 98 */     return (Integer[])this.m_cachepagemap.get(paramString);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.Define
 * JD-Core Version:    0.6.2
 */