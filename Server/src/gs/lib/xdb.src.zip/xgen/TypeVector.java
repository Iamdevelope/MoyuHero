/*    */ package xgen;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class TypeVector extends TypeCollection
/*    */ {
/*    */   public String getName()
/*    */   {
/* 10 */     return "vector";
/*    */   }
/*    */ 
/*    */   protected String getImplName()
/*    */   {
/* 15 */     return "list";
/*    */   }
/*    */ 
/*    */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*    */   {
/* 20 */     paramForeign.throwIf(null != paramForeign.getKey(), "[vector] need value only.");
/* 21 */     if (null != paramForeign.getValue()) {
/* 22 */       Table localTable = paramXdb.getTable(paramForeign.getValue());
/* 23 */       paramForeign.throwIf(null == localTable, "[vector] table not exist.");
/* 24 */       paramForeign.throwIf(localTable.isMemory(), "[vector] foreign table is memory");
/* 25 */       paramForeign.throwIf(localTable.getKeyType() != getValueType(), "[vector] type not match");
/*    */     }
/*    */   }
/*    */ 
/*    */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*    */   {
/* 31 */     paramCapacity.capacityNeed();
/* 32 */     paramCapacity.keyNotNeed();
/* 33 */     getValueType().verifyCapacity(paramXdb, paramCapacity.extractValue());
/*    */   }
/*    */ 
/*    */   public String getCollectionName()
/*    */   {
/* 38 */     return "java.util.ArrayList";
/*    */   }
/*    */ 
/*    */   protected String getGetterName()
/*    */   {
/* 43 */     return "java.util.List" + V();
/*    */   }
/*    */ 
/*    */   public boolean isConstant()
/*    */   {
/* 48 */     return false;
/*    */   }
/*    */ 
/*    */   public String hashCode(String paramString)
/*    */   {
/* 53 */     return paramString + ".hashCode()";
/*    */   }
/*    */ 
/*    */   public String notEquals(String paramString)
/*    */   {
/* 58 */     return "!" + paramString + ".equals(_o_." + paramString + ")";
/*    */   }
/*    */ 
/*    */   public String defineNoParent(String paramString)
/*    */   {
/* 63 */     return getTypeName() + " " + paramString + " = new " + getTypeName() + "();";
/*    */   }
/*    */ 
/*    */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*    */   {
/* 68 */     return defineNoParent(paramString);
/*    */   }
/*    */ 
/*    */   public Type compile(String paramString1, String paramString2)
/*    */   {
/* 73 */     return new TypeVector(paramString1, paramString2);
/*    */   }
/*    */ 
/*    */   private TypeVector(String paramString1, String paramString2) {
/* 77 */     _compile(paramString1, paramString2);
/*    */   }
/*    */ 
/*    */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*    */   {
/* 82 */     paramPrintStream.println(paramString + paramVariable.getname() + " = new " + getTypeName() + "();");
/*    */   }
/*    */ 
/*    */   TypeVector(Map<String, Type> paramMap)
/*    */   {
/* 90 */     paramMap.put(getName(), this);
/*    */   }
/*    */ 
/*    */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*    */   {
/* 95 */     return "new xdb.logs.ListenableChanged().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeVector
 * JD-Core Version:    0.6.2
 */