/*    */ package xgen;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ public class Lock
/*    */ {
/*    */   static void make(Collection<Table> paramCollection)
/*    */   {
/* 13 */     String str = "Locks";
/* 14 */     PrintStream localPrintStream = Main.openTableFile(str);
/*    */ 
/* 16 */     localPrintStream.println("package xtable;");
/* 17 */     localPrintStream.println();
/* 18 */     localPrintStream.println("import xdb.TTable;");
/* 19 */     localPrintStream.println();
/* 20 */     localPrintStream.println("public final class Locks {");
/* 21 */     localPrintStream.println();
/*    */ 
/* 23 */     TreeMap localTreeMap = new TreeMap();
/* 24 */     for (Iterator localIterator = paramCollection.iterator(); localIterator.hasNext(); ) { localObject1 = (Table)localIterator.next();
/* 25 */       localObject2 = ((Table)localObject1).getLock();
/* 26 */       localObject3 = (ArrayList)localTreeMap.get(localObject2);
/* 27 */       if (localObject3 == null) {
/* 28 */         localObject3 = new ArrayList();
/* 29 */         localTreeMap.put(localObject2, localObject3);
/*    */       }
/* 31 */       ((ArrayList)localObject3).add(((Table)localObject1).getName());
/*    */     }
/* 34 */     Object localObject1;
/*    */     Object localObject2;
/*    */     Object localObject3;
/* 34 */     for (localIterator = localTreeMap.entrySet().iterator(); localIterator.hasNext(); ) { localObject1 = (Map.Entry)localIterator.next();
/* 35 */       localObject2 = (ArrayList)((Map.Entry)localObject1).getValue();
/* 36 */       Collections.sort((List)localObject2);
/* 37 */       localObject3 = new StringBuilder();
/* 38 */       for (int i = 1; i < ((ArrayList)localObject2).size(); i++)
/* 39 */         ((StringBuilder)localObject3).append((String)((ArrayList)localObject2).get(i)).append("  ");
/* 40 */       localPrintStream.printf("\tpublic static final TTable<?,?> %s = _Tables_.getInstance().%s; // %s", new Object[] { ((String)((Map.Entry)localObject1).getKey()).toUpperCase(), ((ArrayList)localObject2).get(0), ((StringBuilder)localObject3).toString() }).println();
/*    */     }
/*    */ 
/* 44 */     localPrintStream.println();
/* 45 */     localPrintStream.println("}");
/*    */ 
/* 47 */     localPrintStream.close();
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.Lock
 * JD-Core Version:    0.6.2
 */