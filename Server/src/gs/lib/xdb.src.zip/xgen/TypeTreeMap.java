/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TypeTreeMap extends TypeBaseMap
/*     */ {
/*     */   public void addOwnerTable(Table paramTable)
/*     */   {
/*  10 */     super.addOwnerTable(paramTable);
/*  11 */     this.keytype.addOwnerTable(paramTable);
/*  12 */     this.valuetype.addOwnerTable(paramTable);
/*     */   }
/*     */ 
/*     */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*     */   {
/*     */     Table localTable;
/*  17 */     if (null != paramForeign.getKey()) {
/*  18 */       localTable = paramXdb.getTable(paramForeign.getKey());
/*  19 */       paramForeign.throwIf(null == localTable, "[treemap.key] table not exist");
/*  20 */       paramForeign.throwIf(localTable.isMemory(), "[treemap.key] foreign table is memory");
/*  21 */       paramForeign.throwIf(localTable.getKeyType() != this.keytype, "[treemap.key] type not match.");
/*     */     }
/*  23 */     if (null != paramForeign.getValue()) {
/*  24 */       localTable = paramXdb.getTable(paramForeign.getValue());
/*  25 */       paramForeign.throwIf(null == localTable, "[treemap.value] table not exist");
/*  26 */       paramForeign.throwIf(localTable.isMemory(), "[treemap.value] foreign table is memory");
/*  27 */       paramForeign.throwIf(localTable.getKeyType() != this.valuetype, "[treemap.value] type not match");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*     */   {
/*  33 */     paramCapacity.capacityNeed();
/*  34 */     this.keytype.verifyCapacity(paramXdb, paramCapacity.extractKey());
/*  35 */     this.valuetype.verifyCapacity(paramXdb, paramCapacity.extractValue());
/*     */   }
/*     */ 
/*     */   TypeTreeMap(Map<String, Type> paramMap) {
/*  39 */     paramMap.put(getName(), this);
/*     */   }
/*     */ 
/*     */   public Type compile(String paramString1, String paramString2)
/*     */   {
/*  44 */     return new TypeTreeMap(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   private TypeTreeMap(String paramString1, String paramString2) {
/*  48 */     this.keytype = Type.compile(paramString1, null, null);
/*  49 */     if (!this.keytype.isConstant())
/*  50 */       throw new RuntimeException("map.key need a constant valuetype");
/*  51 */     this.valuetype = Type.compile(paramString2, null, null);
/*     */   }
/*     */ 
/*     */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*  56 */     String str = "";
/*  57 */     if (!paramVariable.getComparator().isEmpty())
/*  58 */       str = "new " + paramVariable.getComparator() + "()";
/*  59 */     paramPrintStream.println(paramString + paramVariable.getname() + " = new " + getTypeName() + "(" + str + ");");
/*     */   }
/*     */ 
/*     */   public String defineNoParent(String paramString)
/*     */   {
/*  64 */     return getTypeName() + " " + paramString + " = new " + getTypeName() + "();";
/*     */   }
/*     */ 
/*     */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*     */   {
/*  69 */     return defineNoParent(paramString);
/*     */   }
/*     */ 
/*     */   public String getBoxingName()
/*     */   {
/*  74 */     return getGetterName();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  79 */     return "treemap";
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/*  84 */     return "java.util.TreeMap" + KV();
/*     */   }
/*     */ 
/*     */   public String getGetterName()
/*     */   {
/*  89 */     return "java.util.NavigableMap" + KV();
/*     */   }
/*     */ 
/*     */   public void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*  94 */     paramPrintStream.println(paramString + "@Override");
/*  95 */     paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/*  96 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/*  97 */     paramPrintStream.println(paramString + "\treturn xdb.Logs.logNavigableMap(new xdb.LogKey(this, " + Main.quote(paramVariable.getname()) + "), " + paramVariable.getname() + ");");
/*     */ 
/*  99 */     paramPrintStream.println(paramString + "}");
/* 100 */     paramPrintStream.println("");
/*     */ 
/* 102 */     if ((isCloneable()) && (!paramXBean.isData())) {
/* 103 */       paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "AsData() { // " + paramVariable.getComment());
/* 104 */       Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 105 */       paramPrintStream.println(paramString + "\t" + getGetterName() + " " + paramVariable.getname() + ";");
/* 106 */       paramPrintStream.println(paramString + "\t" + paramXBean.getName() + " _o_ = this;");
/* 107 */       deepCopy(true, paramVariable, paramPrintStream, paramString + "\t");
/* 108 */       paramPrintStream.println(paramString + "\t" + "return " + paramVariable.getname() + ";");
/* 109 */       paramPrintStream.println(paramString + "}");
/* 110 */       paramPrintStream.println();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 116 */     paramPrintStream.println(paramString + "@Override");
/* 117 */     paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 118 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 119 */     paramPrintStream.println(paramString + "\treturn xdb.Consts.constNavigableMap(" + paramVariable.getname() + ");");
/* 120 */     paramPrintStream.println(paramString + "}");
/* 121 */     paramPrintStream.println("");
/*     */ 
/* 123 */     if (isCloneable()) {
/* 124 */       paramPrintStream.println(paramString + "@Override");
/* 125 */       paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "AsData() { // " + paramVariable.getComment());
/* 126 */       Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 127 */       paramPrintStream.println(paramString + "\t" + getGetterName() + " " + paramVariable.getname() + ";");
/* 128 */       paramPrintStream.println(paramString + "\t" + paramXBean.getName() + " _o_ = " + paramXBean.getName() + ".this;");
/* 129 */       deepCopy(true, paramVariable, paramPrintStream, paramString + "\t");
/* 130 */       paramPrintStream.println(paramString + "\t" + "return " + paramVariable.getname() + ";");
/* 131 */       paramPrintStream.println(paramString + "}");
/* 132 */       paramPrintStream.println("");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String hashCode(String paramString)
/*     */   {
/* 138 */     return paramString + ".hashCode()";
/*     */   }
/*     */ 
/*     */   public void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 143 */     paramPrintStream.println(paramString1 + "_os_.compact_uint32(" + paramString2 + ".size());");
/* 144 */     paramPrintStream.println(paramString1 + "for (java.util.Map.Entry" + KV() + " _e_ : " + paramString2 + ".entrySet())");
/* 145 */     paramPrintStream.println(paramString1 + "{");
/* 146 */     this.keytype.marshal(paramXBean, paramVariable, paramPrintStream, paramString1 + "\t", "_e_.getKey()");
/* 147 */     this.valuetype.marshal(paramXBean, paramVariable, paramPrintStream, paramString1 + "\t", "_e_.getValue()");
/* 148 */     paramPrintStream.println(paramString1 + "}");
/*     */   }
/*     */ 
/*     */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*     */   {
/* 153 */     return "new xdb.logs.ListenableMap().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*     */   }
/*     */ 
/*     */   public String notEquals(String paramString)
/*     */   {
/* 158 */     return "!" + paramString + ".equals(_o_." + paramString + ")";
/*     */   }
/*     */ 
/*     */   public void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 164 */     paramPrintStream.println(paramString1 + "for (int size = _os_.uncompact_uint32(); size > 0; --size)");
/* 165 */     paramPrintStream.println(paramString1 + "{");
/* 166 */     paramPrintStream.println(paramString1 + "\t" + this.keytype.defineSetParent(paramXBean, paramVariable, "_k_"));
/* 167 */     this.keytype.unmarshal(paramXBean, paramVariable, paramPrintStream, paramString1 + "\t", "_k_");
/* 168 */     paramPrintStream.println(paramString1 + "\t" + this.valuetype.defineSetParent(paramXBean, paramVariable, "_v_"));
/* 169 */     this.valuetype.unmarshal(paramXBean, paramVariable, paramPrintStream, paramString1 + "\t", "_v_");
/* 170 */     paramPrintStream.println(paramString1 + "\t" + paramString2 + ".put(_k_, _v_);");
/* 171 */     paramPrintStream.println(paramString1 + "}");
/*     */   }
/*     */ 
/*     */   public void depends(Set<Type> paramSet)
/*     */   {
/* 176 */     if (paramSet.add(this)) {
/* 177 */       this.keytype.depends(paramSet);
/* 178 */       this.valuetype.depends(paramSet);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeTreeMap
 * JD-Core Version:    0.6.2
 */