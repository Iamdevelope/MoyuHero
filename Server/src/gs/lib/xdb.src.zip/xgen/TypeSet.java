/*    */ package xgen;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class TypeSet extends TypeCollection
/*    */ {
/*    */   public String getName()
/*    */   {
/* 10 */     return "set";
/*    */   }
/*    */ 
/*    */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*    */   {
/* 15 */     paramForeign.throwIf(null != paramForeign.getKey(), "[set] need value only.");
/* 16 */     if (null != paramForeign.getValue()) {
/* 17 */       Table localTable = paramXdb.getTable(paramForeign.getValue());
/* 18 */       paramForeign.throwIf(null == localTable, "[set.value] table not exist.");
/* 19 */       paramForeign.throwIf(localTable.isMemory(), "[set.value] foreign table is memory");
/* 20 */       paramForeign.throwIf(localTable.getKeyType() != getValueType(), "[set.value] type not match");
/*    */     }
/*    */   }
/*    */ 
/*    */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*    */   {
/* 26 */     paramCapacity.capacityNeed();
/* 27 */     paramCapacity.keyNotNeed();
/* 28 */     getValueType().verifyCapacity(paramXdb, paramCapacity.extractValue());
/*    */   }
/*    */ 
/*    */   public boolean isConstant()
/*    */   {
/* 33 */     return false;
/*    */   }
/*    */ 
/*    */   public String hashCode(String paramString)
/*    */   {
/* 38 */     return paramString + ".hashCode()";
/*    */   }
/*    */ 
/*    */   public String notEquals(String paramString)
/*    */   {
/* 43 */     return "!" + paramString + ".equals(_o_." + paramString + ")";
/*    */   }
/*    */ 
/*    */   public String defineNoParent(String paramString)
/*    */   {
/* 48 */     return getTypeName() + " " + paramString + " = new " + getTypeName() + "();";
/*    */   }
/*    */ 
/*    */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*    */   {
/* 53 */     return defineNoParent(paramString);
/*    */   }
/*    */ 
/*    */   public String getCollectionName()
/*    */   {
/* 58 */     return Type.getCurrentBean().isData() ? "java.util.HashSet" : "xdb.util.SetX";
/*    */   }
/*    */ 
/*    */   public String getGetterName()
/*    */   {
/* 63 */     return "java.util.Set" + V();
/*    */   }
/*    */ 
/*    */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*    */   {
/* 68 */     paramPrintStream.println(paramString + paramVariable.getname() + " = new " + getTypeName() + "();");
/*    */   }
/*    */ 
/*    */   public Type compile(String paramString1, String paramString2)
/*    */   {
/* 73 */     return new TypeSet(paramString1, paramString2);
/*    */   }
/*    */ 
/*    */   private TypeSet(String paramString1, String paramString2) {
/* 77 */     _compile(paramString1, paramString2);
/*    */   }
/*    */ 
/*    */   TypeSet(Map<String, Type> paramMap)
/*    */   {
/* 85 */     paramMap.put(getName(), this);
/*    */   }
/*    */ 
/*    */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*    */   {
/* 90 */     return "new xdb.logs.ListenableSet().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeSet
 * JD-Core Version:    0.6.2
 */