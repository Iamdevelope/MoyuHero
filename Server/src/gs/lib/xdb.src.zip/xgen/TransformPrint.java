/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class TransformPrint
/*     */ {
/*  15 */   private List<String> _transformtable = new ArrayList();
/*     */ 
/*     */   public void printMain()
/*     */   {
/*  20 */     PrintStream localPrintStream = Main.openTransformMainFile("Main");
/*     */ 
/*  22 */     localPrintStream.println("import java.io.File;");
/*     */ 
/*  24 */     localPrintStream.println("import java.io.FileInputStream;");
/*  25 */     localPrintStream.println("import java.io.FileNotFoundException;");
/*  26 */     localPrintStream.println("import java.io.FileOutputStream;");
/*  27 */     localPrintStream.println("import java.io.IOException;");
/*  28 */     localPrintStream.println("import java.io.InputStream;");
/*  29 */     localPrintStream.println("import java.io.OutputStream;");
/*  30 */     localPrintStream.println("import java.util.ArrayList;");
/*  31 */     localPrintStream.println("import java.util.List;");
/*     */ 
/*  33 */     localPrintStream.println("import com.goldhuman.Common.Octets;");
/*  34 */     localPrintStream.println("import com.goldhuman.Common.Marshal.OctetsStream;");
/*     */ 
/*  36 */     localPrintStream.println("import xdb.util.DatabaseMetaData;");
/*  37 */     localPrintStream.println("import xdb.util.Dbx;");
/*     */ 
/*  40 */     localPrintStream.println();
/*     */ 
/*  42 */     localPrintStream.println("public class Main {");
/*     */ 
/*  44 */     localPrintStream.println("\tpublic static void main(String[] args) {");
/*  45 */     localPrintStream.println("\tString libpath = \".\";");
/*  46 */     localPrintStream.println("\tString srcdir = \"" + Main.getTransformSrcDb() + "\";");
/*  47 */     localPrintStream.println("\tString destdir = \"" + Main.getTransformDestDb() + "\";");
/*     */ 
/*  49 */     localPrintStream.println("\t//这里不提供 usage()，各个步骤的关联性很强，增加灵活性就会增加出错的机率，用的人自己把握");
/*  50 */     localPrintStream.println("\tfor (int i = 0; i < args.length; ++i) ");
/*  51 */     localPrintStream.println("\t{");
/*  52 */     localPrintStream.println("\t\tif (args[i].equals(\"-srcdb\"))\t");
/*  53 */     localPrintStream.println("\t{");
/*  54 */     localPrintStream.println("\t\t\tsrcdir = args[++i];\t");
/*  55 */     localPrintStream.println("\t\t\tSystem.out.println(\"WARN: USE NEW SRCDB:\" + srcdir);\t");
/*  56 */     localPrintStream.println("\t}\t");
/*  57 */     localPrintStream.println("\t\telse if (args[i].equals(\"-destdb\"))\t");
/*  58 */     localPrintStream.println("\t{");
/*  59 */     localPrintStream.println("\t\t\tdestdir = args[++i];\t");
/*  60 */     localPrintStream.println("\t\t\tSystem.out.println(\"WARN: USE NEW DSTDB:\" + destdir);\t");
/*  61 */     localPrintStream.println("\t}\t");
/*  62 */     localPrintStream.println("\t\telse\t");
/*  63 */     localPrintStream.println("\t\t\tlibpath = args[i];\t");
/*  64 */     localPrintStream.println("\t}\t");
/*     */ 
/*  66 */     localPrintStream.println("\tList<String> dotable = new ArrayList<String>();");
/*     */ 
/*  68 */     localPrintStream.println("\t{");
/*  69 */     for (String str : this._transformtable)
/*     */     {
/*  71 */       localPrintStream.println("\t\tdotable.add(\"" + str + "\");");
/*     */     }
/*     */ 
/*  74 */     localPrintStream.println("\t}");
/*     */ 
/*  78 */     localPrintStream.println("\tFile src = new File(srcdir);");
/*  79 */     localPrintStream.println("\tFile dst = new File(destdir);");
/*  80 */     localPrintStream.println("\tdeleteDir(dst);");
/*     */ 
/*  82 */     localPrintStream.println("\txdb.util.Dbx.start(libpath);");
/*     */ 
/*  84 */     localPrintStream.println("\tDbx sdb = Dbx.open(src, DatabaseMetaData.getInstance());");
/*  85 */     localPrintStream.println("\tDbx ddb = Dbx.open(dst, DatabaseMetaData.getInstance());");
/*  86 */     localPrintStream.println("\ttry{");
/*  87 */     localPrintStream.println("\t\tfor (DatabaseMetaData.Table tableMetaData : sdb.getMetaData().getTables()) {");
/*     */ 
/*  89 */     localPrintStream.println("\t\t\tString tablename = tableMetaData.getName();");
/*  90 */     localPrintStream.println("\t\t\tDbx.Table stb = sdb.openTable(tablename);");
/*  91 */     localPrintStream.println("\t\t\tDbx.Table dtb = ddb.openTable(tablename);");
/*     */ 
/*  93 */     localPrintStream.println("\t\t\tif( dotable.contains(tablename) )");
/*     */ 
/*  95 */     localPrintStream.println("\t\t\t{");
/*  96 */     localPrintStream.println("\t\t\t\ttry{");
/*  97 */     localPrintStream.println("\t\t\t\t\tSystem.out.println(\"Begin to transform db: \" + tablename);");
/*  98 */     localPrintStream.println("\t\t\t\t\tWalker walker = new Walker(dtb);");
/*  99 */     localPrintStream.println("\t\t\t\t\tstb.walk(walker); ");
/* 100 */     localPrintStream.println("\t\t\t\t\twalker.finish();");
/* 101 */     localPrintStream.println("\t\t\t\t\twalker = null;");
/* 102 */     localPrintStream.println("\t\t\t\t}finally");
/* 103 */     localPrintStream.println("\t\t\t\t{");
/* 104 */     localPrintStream.println("\t\t\t\tstb.close();");
/* 105 */     localPrintStream.println("\t\t\t\tdtb.close();");
/* 106 */     localPrintStream.println("\t\t\t\t}");
/* 107 */     localPrintStream.println("\t\t\t}");
/* 108 */     localPrintStream.println("\t\t\telse");
/* 109 */     localPrintStream.println("\t\t\t{");
/* 110 */     localPrintStream.println("\t\t\t\ttry{");
/* 111 */     localPrintStream.println("\t\t\t\t\tSystem.out.println(\"Begin to copy db: \" + tablename);");
/* 112 */     localPrintStream.println("\t\t\t\t\tWalkerRaw walker = new WalkerRaw(dtb);");
/* 113 */     localPrintStream.println("\t\t\t\t\tstb._walk(walker);");
/* 114 */     localPrintStream.println("\t\t\t\t\twalker.finish();");
/* 115 */     localPrintStream.println("\t\t\t\t\twalker = null;");
/* 116 */     localPrintStream.println("\t\t\t\t\t}finally");
/* 117 */     localPrintStream.println("\t\t\t\t\t{");
/* 118 */     localPrintStream.println("\t\t\t\t\t\tstb.close();");
/* 119 */     localPrintStream.println("\t\t\t\t\t\tdtb.close();");
/* 120 */     localPrintStream.println("\t\t\t\t\t}");
/* 121 */     localPrintStream.println("\t\t\t\t//stb.close();");
/* 122 */     localPrintStream.println("\t\t\t\t//dtb.close();");
/*     */ 
/* 124 */     localPrintStream.println("\t\t\t\t//System.out.println(\"Begin to copy db: \" + tablename);");
/* 125 */     localPrintStream.println("\t\t\t\t//try {");
/* 126 */     localPrintStream.println("\t\t\t\t//\tMain.copyFile(new File ( srcdir + \"/dbdata/\" + tablename), new File (destdir + \"/dbdata/\") );");
/* 127 */     localPrintStream.println("\t\t\t\t//} catch (Exception e) {");
/* 128 */     localPrintStream.println("\t\t\t\t//e.printStackTrace();}");
/* 129 */     localPrintStream.println("\t\t\t\t}");
/* 130 */     localPrintStream.println("\t\t\t}");
/*     */ 
/* 139 */     localPrintStream.println("");
/* 140 */     localPrintStream.println("\t}finally");
/* 141 */     localPrintStream.println("\t{");
/* 142 */     localPrintStream.println("\t\tsdb.close();");
/* 143 */     localPrintStream.println("\t\tddb.close();");
/* 144 */     localPrintStream.println("\t}");
/*     */ 
/* 146 */     localPrintStream.println("\txdb.util.Dbx.stop();");
/*     */ 
/* 148 */     localPrintStream.println("}");
/*     */ 
/* 150 */     localPrintStream.println("\tstatic class Walker implements xdb.Storage.IWalk {");
/*     */ 
/* 152 */     localPrintStream.println("\t\tprivate Dbx.Table _dtb = null;");
/* 153 */     localPrintStream.println("\t\tprivate int _cnt = 0;");
/* 154 */     localPrintStream.println("\t\tfinal int _checkpoint = 2000;");
/*     */ 
/* 157 */     localPrintStream.println("\t\tpublic Walker(Dbx.Table dtb) {");
/* 158 */     localPrintStream.println("\t\t\t_dtb = dtb;");
/* 159 */     localPrintStream.println("\t\t}");
/*     */ 
/* 162 */     localPrintStream.println("\t\tpublic boolean onRecord(byte[] _key, byte[] _data) {");
/* 163 */     localPrintStream.println("\t\t\t_cnt++;");
/* 164 */     localPrintStream.println("\t\t\tif ( _cnt >= _checkpoint )//保存一下修改，释放一下内存");
/* 165 */     localPrintStream.println("\t\t\t{");
/* 166 */     localPrintStream.println("\t\t\t\t_cnt = 0;");
/* 167 */     localPrintStream.println("\t\t\t\t_dtb.save();");
/* 168 */     localPrintStream.println("\t\t\t}");
/*     */ 
/* 170 */     localPrintStream.println("\t\t\tOctetsStream key = _dtb.getMetaData().getKeyType().marshal(");
/* 171 */     localPrintStream.println("\t\t\t\t_dtb.getMetaData().getKeyType().unmarshal(_key));");
/*     */ 
/* 173 */     localPrintStream.println("\t\t\tOctetsStream value = _dtb.getMetaData().getValueType().marshal(");
/* 174 */     localPrintStream.println("\t\t\t\t_dtb.getMetaData().getValueType().unmarshal(_data));");
/*     */ 
/* 176 */     localPrintStream.println("\t\t\tif ( _dtb.insert(key, value ) == false )");
/* 177 */     localPrintStream.println("\t\t\t\tthrow new Error(\"onRecord : insert key to etb false???on panic……\");");
/* 178 */     localPrintStream.println("\t\t\treturn true;");
/* 179 */     localPrintStream.println("\t\t}");
/*     */ 
/* 181 */     localPrintStream.println("\t\tpublic void finish() {");
/*     */ 
/* 183 */     localPrintStream.println("\t\t\t_dtb = null;");
/*     */ 
/* 185 */     localPrintStream.println("\t\t}");
/* 186 */     localPrintStream.println("}");
/*     */ 
/* 189 */     localPrintStream.println("\tstatic class WalkerRaw implements xdb.Storage.IWalk {");
/*     */ 
/* 191 */     localPrintStream.println("\t\tprivate Dbx.Table _dtb = null;");
/* 192 */     localPrintStream.println("\t\tprivate int _cnt = 0;");
/* 193 */     localPrintStream.println("\t\tfinal int _checkpoint = 2000;");
/*     */ 
/* 196 */     localPrintStream.println("\t\tpublic WalkerRaw(Dbx.Table dtb) {");
/* 197 */     localPrintStream.println("\t\t\t_dtb = dtb;");
/* 198 */     localPrintStream.println("\t\t}");
/*     */ 
/* 201 */     localPrintStream.println("\t\tpublic boolean onRecord(byte[] _key, byte[] _data) {");
/* 202 */     localPrintStream.println("\t\t\t_cnt++;");
/* 203 */     localPrintStream.println("\t\t\tif ( _cnt >= _checkpoint )//保存一下修改，释放一下内存");
/* 204 */     localPrintStream.println("\t\t\t{");
/* 205 */     localPrintStream.println("\t\t\t\t_cnt = 0;");
/* 206 */     localPrintStream.println("\t\t\t\t_dtb.save();");
/* 207 */     localPrintStream.println("\t\t\t}");
/* 208 */     localPrintStream.println("\t\t\tOctetsStream key = OctetsStream.wrap(Octets.wrap(_key));");
/* 209 */     localPrintStream.println("\t\t\tOctetsStream value = OctetsStream.wrap(Octets.wrap(_data));");
/*     */ 
/* 211 */     localPrintStream.println("\t\t\tif ( _dtb._insert(key, value ) == false )");
/* 212 */     localPrintStream.println("\t\t\t\tthrow new Error(\"onRecord : insert key to etb false???on panic……\");");
/* 213 */     localPrintStream.println("\t\t\treturn true;");
/* 214 */     localPrintStream.println("\t\t}");
/*     */ 
/* 216 */     localPrintStream.println("\t\tpublic void finish() {");
/*     */ 
/* 218 */     localPrintStream.println("\t\t\t_dtb = null;");
/*     */ 
/* 220 */     localPrintStream.println("\t\t}");
/* 221 */     localPrintStream.println("}");
/*     */ 
/* 223 */     localPrintStream.println("\tprivate static void deleteDir(File dir) {");
/* 224 */     localPrintStream.println("\t\tif (dir == null || !dir.exists() || !dir.isDirectory())");
/* 225 */     localPrintStream.println("\t\t\treturn; // 检查参数");
/* 226 */     localPrintStream.println("\t\tfor (File file : dir.listFiles()) { ");
/* 227 */     localPrintStream.println("\t\t\tif (file.isFile()) ");
/* 228 */     localPrintStream.println("\t\t\t\tfile.delete(); // 删除所有文件 ");
/* 229 */     localPrintStream.println("\t\t\telse if (file.isDirectory()) ");
/* 230 */     localPrintStream.println("\t\t\t\tdeleteDir(file); // 递规的方式删除文件夹");
/* 231 */     localPrintStream.println("\t\t} ");
/* 232 */     localPrintStream.println("\t}");
/*     */ 
/* 234 */     localPrintStream.println("\tprivate static void copyFile(File src, File destDir) throws FileNotFoundException, IOException {");
/* 235 */     localPrintStream.println("\t\tInputStream is = new FileInputStream(src);");
/* 236 */     localPrintStream.println("\t\ttry {");
/* 237 */     localPrintStream.println("\t\t\tOutputStream os = new FileOutputStream(new File(destDir, src.getName()));");
/* 238 */     localPrintStream.println("\t\t\ttry {");
/* 239 */     localPrintStream.println("\t\t\t\tbyte [] buffer = new byte[4096];");
/* 240 */     localPrintStream.println("\t\t\t\tint rc = 0;");
/* 241 */     localPrintStream.println("\t\t\t\twhile ((rc = is.read(buffer)) > 0) {");
/* 242 */     localPrintStream.println("\t\t\t\t\tos.write(buffer, 0, rc);");
/* 243 */     localPrintStream.println("\t\t\t}");
/* 244 */     localPrintStream.println("\t\t\t} finally {");
/* 245 */     localPrintStream.println("\t\t\t\tos.close();");
/* 246 */     localPrintStream.println("\t\t\t}");
/* 247 */     localPrintStream.println("\t\t} finally {");
/* 248 */     localPrintStream.println("\t\t\tis.close();");
/* 249 */     localPrintStream.println("\t\t}");
/* 250 */     localPrintStream.println("\t\t}");
/*     */ 
/* 252 */     localPrintStream.println("}");
/*     */ 
/* 254 */     localPrintStream.close();
/*     */   }
/*     */ 
/*     */   public void addModifyTable(String paramString)
/*     */   {
/* 260 */     this._transformtable.add(paramString);
/*     */   }
/*     */ 
/*     */   public boolean isModifyTable(String paramString)
/*     */   {
/* 265 */     return this._transformtable.contains(paramString);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TransformPrint
 * JD-Core Version:    0.6.2
 */