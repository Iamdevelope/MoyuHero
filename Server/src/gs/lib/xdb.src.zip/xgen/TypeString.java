/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TypeString extends Type
/*     */ {
/*     */   public void printTableSelectMethod(PrintStream paramPrintStream, String paramString)
/*     */   {
/*  10 */     String str = getBoxingName();
/*  11 */     paramPrintStream.println("\tpublic static " + str + " select(" + paramString + " key) {");
/*  12 */     paramPrintStream.println("\t\treturn getTable().select(key, new xdb.TField<" + str + ", " + str + ">() {");
/*  13 */     paramPrintStream.println("\t\t\tpublic " + str + " get(" + str + " v) { return v; }");
/*  14 */     paramPrintStream.println("\t\t});");
/*  15 */     paramPrintStream.println("\t}");
/*  16 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  21 */     return "string";
/*     */   }
/*     */ 
/*     */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*     */   {
/*  26 */     paramForeign.throwIf(null != paramForeign.getKey(), "[string] need value only.");
/*  27 */     if (null != paramForeign.getValue()) {
/*  28 */       Table localTable = paramXdb.getTable(paramForeign.getValue());
/*  29 */       paramForeign.throwIf(null == localTable, "[string] table not exist.");
/*  30 */       paramForeign.throwIf(localTable.isMemory(), "[string] foreign table is memory");
/*  31 */       paramForeign.throwIf(localTable.getKeyType() != this, "[string] type not match");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*     */   {
/*  37 */     paramCapacity.capacityOnly();
/*     */   }
/*     */ 
/*     */   public Type compile(String paramString1, String paramString2)
/*     */   {
/*  42 */     if ((paramString1 != null) && (!paramString1.isEmpty()))
/*  43 */       throw new RuntimeException(getName() + " DO NOT NEED A KEY!");
/*  44 */     if ((paramString2 != null) && (!paramString2.isEmpty()))
/*  45 */       throw new RuntimeException(getName() + " DO NOT NEED A VALUE!");
/*  46 */     return this;
/*     */   }
/*     */ 
/*     */   public String compareto(String paramString1, String paramString2)
/*     */   {
/*  51 */     return paramString1 + ".compareTo(" + paramString2 + ")";
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/*  56 */     return "String";
/*     */   }
/*     */ 
/*     */   public String getBoxingName()
/*     */   {
/*  61 */     return getTypeName();
/*     */   }
/*     */ 
/*     */   public TypeString(Map<String, Type> paramMap) {
/*  65 */     paramMap.put(getName(), this);
/*     */   }
/*     */ 
/*     */   public String defineNoParent(String paramString)
/*     */   {
/*  70 */     return getTypeName() + " " + paramString + " = \"\";";
/*     */   }
/*     */ 
/*     */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*     */   {
/*  75 */     return defineNoParent(paramString);
/*     */   }
/*     */ 
/*     */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*  80 */     String str = paramVariable.getInitial();
/*  81 */     paramPrintStream.println(paramString + paramVariable.getname() + " = " + Main.quote(str) + ";");
/*     */   }
/*     */ 
/*     */   public boolean isConstant()
/*     */   {
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isCloneable()
/*     */   {
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   public String deepCopy(boolean paramBoolean, Variable paramVariable, String paramString)
/*     */   {
/*  96 */     return paramString;
/*     */   }
/*     */ 
/*     */   public void deepCopy(boolean paramBoolean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 101 */     paramPrintStream.println(paramString + paramVariable.getname() + " = _o_." + paramVariable.getname() + ";");
/*     */   }
/*     */ 
/*     */   public void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 106 */     paramPrintStream.println(paramString1 + paramString2 + " = _os_.unmarshal_String(xdb.Const.IO_CHARSET);");
/*     */   }
/*     */ 
/*     */   public void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 111 */     paramPrintStream.println(paramString1 + "_os_.marshal(" + paramString2 + ", xdb.Const.IO_CHARSET);");
/*     */   }
/*     */ 
/*     */   public void toString(PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 116 */     paramPrintStream.println(paramString1 + "_sb_.append(\"'\").append(" + paramString2 + ").append(\"'\");");
/*     */   }
/*     */ 
/*     */   public String notEquals(String paramString)
/*     */   {
/* 121 */     return "!" + paramString + ".equals(_o_." + paramString + ")";
/*     */   }
/*     */ 
/*     */   public String hashCode(String paramString)
/*     */   {
/* 126 */     return paramString + ".hashCode()";
/*     */   }
/*     */ 
/*     */   public void getterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 131 */     paramPrintStream.println(paramString + "public String get" + paramVariable.getName() + "(); // " + paramVariable.getComment());
/* 132 */     paramPrintStream.println(paramString + "public com.goldhuman.Common.Octets get" + paramVariable.getName() + "Octets(); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 137 */     if (null != paramXBean)
/* 138 */       paramPrintStream.println(paramString + "@Override");
/* 139 */     paramPrintStream.println(paramString + "public String get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 140 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 141 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 142 */     paramPrintStream.println(paramString + "}");
/* 143 */     paramPrintStream.println("");
/* 144 */     if (null != paramXBean)
/* 145 */       paramPrintStream.println(paramString + "@Override");
/* 146 */     paramPrintStream.println(paramString + "public com.goldhuman.Common.Octets get" + paramVariable.getName() + "Octets() { // " + paramVariable.getComment());
/* 147 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 148 */     paramPrintStream.println(paramString + "\treturn com.goldhuman.Common.Octets.wrap(get" + paramVariable.getName() + "(), xdb.Const.IO_CHARSET);");
/* 149 */     paramPrintStream.println(paramString + "}");
/* 150 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 155 */     paramPrintStream.println(paramString + "@Override");
/* 156 */     paramPrintStream.println(paramString + "public String get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 157 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 158 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 159 */     paramPrintStream.println(paramString + "}");
/* 160 */     paramPrintStream.println("");
/* 161 */     paramPrintStream.println(paramString + "@Override");
/* 162 */     paramPrintStream.println(paramString + "public com.goldhuman.Common.Octets get" + paramVariable.getName() + "Octets() { // " + paramVariable.getComment());
/* 163 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 164 */     paramPrintStream.println(paramString + "\treturn " + paramXBean.getName() + ".this.get" + paramVariable.getName() + "Octets();");
/* 165 */     paramPrintStream.println(paramString + "}");
/* 166 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void getterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 171 */     if (null != paramXBean)
/* 172 */       paramPrintStream.println(paramString + "@Override");
/* 173 */     paramPrintStream.println(paramString + "public String get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 174 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 175 */     paramPrintStream.println(paramString + "}");
/* 176 */     paramPrintStream.println("");
/* 177 */     if (null != paramXBean)
/* 178 */       paramPrintStream.println(paramString + "@Override");
/* 179 */     paramPrintStream.println(paramString + "public com.goldhuman.Common.Octets get" + paramVariable.getName() + "Octets() { // " + paramVariable.getComment());
/* 180 */     paramPrintStream.println(paramString + "\treturn com.goldhuman.Common.Octets.wrap(get" + paramVariable.getName() + "(), xdb.Const.IO_CHARSET);");
/* 181 */     paramPrintStream.println(paramString + "}");
/* 182 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 187 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(String _v_); // " + paramVariable.getComment());
/* 188 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "Octets(com.goldhuman.Common.Octets _v_); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void setterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 193 */     paramPrintStream.println(paramString + "@Override");
/* 194 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(String _v_) { // " + paramVariable.getComment());
/* 195 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 196 */     paramPrintStream.println(paramString + "\tthrow new UnsupportedOperationException();");
/* 197 */     paramPrintStream.println(paramString + "}");
/* 198 */     paramPrintStream.println();
/* 199 */     paramPrintStream.println(paramString + "@Override");
/* 200 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "Octets(com.goldhuman.Common.Octets _v_) { // " + paramVariable.getComment());
/* 201 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 202 */     paramPrintStream.println(paramString + "\tthrow new UnsupportedOperationException();");
/* 203 */     paramPrintStream.println(paramString + "}");
/* 204 */     paramPrintStream.println();
/*     */   }
/*     */ 
/*     */   public void setter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 209 */     paramPrintStream.println(paramString + "@Override");
/* 210 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(String _v_) { // " + paramVariable.getComment());
/* 211 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 212 */     paramPrintStream.println(paramString + "\tif (null == _v_)");
/* 213 */     paramPrintStream.println(paramString + "\t\tthrow new NullPointerException();");
/* 214 */     paramPrintStream.println(paramString + "\txdb.Logs.logIf(new xdb.LogKey(this, " + Main.quote(paramVariable.getname()) + ") {");
/* 215 */     paramPrintStream.println(paramString + "\t\tprotected xdb.Log create() {");
/* 216 */     paramPrintStream.println(paramString + "\t\t\treturn new xdb.logs.LogString(this, " + paramVariable.getname() + ") {");
/* 217 */     paramPrintStream.println(paramString + "\t\t\t\tpublic void rollback() { " + paramVariable.getname() + " = _xdb_saved; }");
/* 218 */     paramPrintStream.println(paramString + "\t\t\t};}});");
/* 219 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_;");
/* 220 */     paramPrintStream.println(paramString + "}");
/* 221 */     paramPrintStream.println("");
/* 222 */     paramPrintStream.println(paramString + "@Override");
/* 223 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "Octets(com.goldhuman.Common.Octets _v_) { // " + paramVariable.getComment());
/* 224 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 225 */     paramPrintStream.println(paramString + "\tthis.set" + paramVariable.getName() + "(_v_.getString(xdb.Const.IO_CHARSET));");
/* 226 */     paramPrintStream.println(paramString + "}");
/* 227 */     paramPrintStream.println();
/*     */   }
/*     */ 
/*     */   public void setterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 232 */     paramPrintStream.println(paramString + "@Override");
/* 233 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(String _v_) { // " + paramVariable.getComment());
/* 234 */     paramPrintStream.println(paramString + "\tif (null == _v_)");
/* 235 */     paramPrintStream.println(paramString + "\t\tthrow new NullPointerException();");
/* 236 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_;");
/* 237 */     paramPrintStream.println(paramString + "}");
/* 238 */     paramPrintStream.println("");
/* 239 */     paramPrintStream.println(paramString + "@Override");
/* 240 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "Octets(com.goldhuman.Common.Octets _v_) { // " + paramVariable.getComment());
/* 241 */     paramPrintStream.println(paramString + "\tthis.set" + paramVariable.getName() + "(_v_.getString(xdb.Const.IO_CHARSET));");
/* 242 */     paramPrintStream.println(paramString + "}");
/* 243 */     paramPrintStream.println();
/*     */   }
/*     */ 
/*     */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*     */   {
/* 248 */     return "new xdb.logs.ListenableChanged().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*     */   }
/*     */ 
/*     */   public void depends(Set<Type> paramSet)
/*     */   {
/* 253 */     paramSet.add(this);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeString
 * JD-Core Version:    0.6.2
 */