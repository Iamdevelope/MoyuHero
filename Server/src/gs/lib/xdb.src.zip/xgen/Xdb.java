/*     */ package xgen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import xdb.util.DatabaseMetaData;
/*     */ import xdb.util.DatabaseMetaData.Bean;
/*     */ import xdb.util.DatabaseMetaData.Bean.Variable;
/*     */ import xdb.util.DatabaseMetaData.Table;
/*     */ import xdb.util.DatabaseMetaData.Type;
/*     */ import xdb.util.DatabaseMetaData.Type.Depends;
/*     */ 
/*     */ public class Xdb
/*     */ {
/*  15 */   private Set<String> nameset = new HashSet();
/*  16 */   private List<XBean> xbeans = new ArrayList();
/*  17 */   private List<CBean> cbeans = new ArrayList();
/*  18 */   private Map<String, Table> tables = new HashMap();
/*     */   private File xgenOutput;
/*     */   private File xtabledir;
/*     */   private File xbeandir;
/*     */   private File xbeandir__;
/*     */ 
/*     */   Table getTable(String paramString)
/*     */   {
/*  25 */     return (Table)this.tables.get(paramString);
/*     */   }
/*     */ 
/*     */   void add(XBean paramXBean) {
/*  29 */     if (!this.nameset.add(paramXBean.getName()))
/*  30 */       throw new RuntimeException(new StringBuilder().append("duplicate bean name ").append(paramXBean.getName()).toString());
/*  31 */     this.xbeans.add(paramXBean);
/*     */   }
/*     */ 
/*     */   void add(CBean paramCBean) {
/*  35 */     if (!this.nameset.add(paramCBean.getName()))
/*  36 */       throw new RuntimeException(new StringBuilder().append("duplicate bean name ").append(paramCBean.getName()).toString());
/*  37 */     this.cbeans.add(paramCBean);
/*     */   }
/*     */ 
/*     */   void add(Table paramTable) {
/*  41 */     if (null != this.tables.put(paramTable.getName(), paramTable))
/*  42 */       throw new RuntimeException(new StringBuilder().append("duplicate table name ").append(paramTable.getName()).toString());
/*     */   }
/*     */ 
/*     */   File getXbeandir() {
/*  46 */     return this.xbeandir;
/*     */   }
/*     */ 
/*     */   File getXtabledir() {
/*  50 */     return this.xtabledir;
/*     */   }
/*     */ 
/*     */   public File getXbeandir__() {
/*  54 */     return this.xbeandir__;
/*     */   }
/*     */ 
/*     */   Xdb(Element paramElement) {
/*  58 */     this.xgenOutput = new File(paramElement.getAttribute("xgenOutput"));
/*  59 */     if ((!this.xgenOutput.isDirectory()) || (!this.xgenOutput.exists())) {
/*  60 */       throw new RuntimeException(new StringBuilder().append("'").append(this.xgenOutput).append("' (!isDirectory || !exists())").toString());
/*     */     }
/*  62 */     this.xtabledir = new File(this.xgenOutput, "xtable");
/*  63 */     this.xbeandir = new File(this.xgenOutput, "xbean");
/*  64 */     this.xbeandir__ = new File(this.xbeandir, "__");
/*     */ 
/*  66 */     NodeList localNodeList = paramElement.getChildNodes();
/*  67 */     for (int i = 0; i < localNodeList.getLength(); i++) {
/*  68 */       Node localNode = localNodeList.item(i);
/*  69 */       if (1 == localNode.getNodeType())
/*     */       {
/*  72 */         Element localElement = (Element)localNode;
/*  73 */         String str = localElement.getNodeName();
/*  74 */         if (str.equals("xbean"))
/*  75 */           add(new XBean(localElement));
/*  76 */         else if (str.equals("table"))
/*  77 */           add(new Table(localElement));
/*  78 */         else if (!str.endsWith("Conf"))
/*     */         {
/*  80 */           if (str.equals("cbean"))
/*  81 */             add(new CBean(localElement));
/*  82 */           else if (str.endsWith("define"))
/*  83 */             Define.getInstance().parse(localElement);
/*     */           else
/*  85 */             throw new RuntimeException(new StringBuilder().append("nodename=").append(str).toString()); 
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*  91 */   void compile() { for (Iterator localIterator = this.xbeans.iterator(); localIterator.hasNext(); ) { localObject = (XBean)localIterator.next();
/*  92 */       ((XBean)localObject).compile(this);
/*     */     }
/*  93 */     Object localObject;
/*  93 */     for (localIterator = this.cbeans.iterator(); localIterator.hasNext(); ) { localObject = (CBean)localIterator.next();
/*  94 */       ((CBean)localObject).compile(this); }
/*  95 */     for (localIterator = this.tables.values().iterator(); localIterator.hasNext(); ) { localObject = (Table)localIterator.next();
/*  96 */       ((Table)localObject).compile(this);
/*     */     }
/*     */ 
/*  99 */     for (localIterator = this.xbeans.iterator(); localIterator.hasNext(); ) { localObject = (XBean)localIterator.next();
/* 100 */       ((XBean)localObject).verify(this);
/* 101 */       ((XBean)localObject).depends();
/*     */     }
/* 103 */     for (localIterator = this.cbeans.iterator(); localIterator.hasNext(); ) { localObject = (CBean)localIterator.next();
/* 104 */       ((CBean)localObject).verify(this);
/* 105 */       ((CBean)localObject).depends();
/*     */     }
/* 107 */     for (localIterator = this.tables.values().iterator(); localIterator.hasNext(); ) { localObject = (Table)localIterator.next();
/* 108 */       ((Table)localObject).verify(this);
/*     */     }
/*     */ 
/* 111 */     for (localIterator = this.tables.values().iterator(); localIterator.hasNext(); ) { localObject = (Table)localIterator.next();
/*     */ 
/* 113 */       detectForeignCircle((Table)localObject, new Detected((Table)localObject));
/*     */     }
/*     */ 
/* 117 */     for (localIterator = this.xbeans.iterator(); localIterator.hasNext(); ) { localObject = (XBean)localIterator.next();
/* 118 */       if (((XBean)localObject).getOwnerTables().size() > 1) {
/* 119 */         Main.warn(new StringBuilder().append("OWNER xbean=").append(Main.quote(((XBean)localObject).getName())).append(" owners=").append(((XBean)localObject).getOwnerTables()).toString(), 'o');
/*     */       }
/*     */     }
/* 122 */     for (localIterator = this.cbeans.iterator(); localIterator.hasNext(); ) { localObject = (CBean)localIterator.next();
/* 123 */       if (((CBean)localObject).getOwnerTables().size() > 1)
/* 124 */         Main.warn(new StringBuilder().append("OWNER cbean=").append(Main.quote(((CBean)localObject).getName())).append(" owners=").append(((CBean)localObject).getOwnerTables()).toString(), 'o');
/*     */     }
/*     */   }
/*     */ 
/*     */   void detectForeignCircle(Table paramTable, Detected paramDetected)
/*     */   {
/* 157 */     if (null == paramTable) {
/* 158 */       return;
/*     */     }
/* 160 */     if (paramDetected.contains(paramTable)) {
/* 161 */       return;
/*     */     }
/* 163 */     Set localSet = paramDetected.foreigns(paramTable);
/* 164 */     if (localSet.contains(paramTable.getName())) {
/* 165 */       throw new IllegalStateException(new StringBuilder().append("foreign to self is not supported!NO null value in XDB. table=").append(paramTable.getName()).toString());
/*     */     }
/*     */ 
/* 168 */     for (String str : localSet)
/* 169 */       detectForeignCircle((Table)this.tables.get(str), paramDetected);
/*     */   }
/*     */ 
/*     */   void make() {
/* 173 */     this.xtabledir.mkdirs();
/* 174 */     this.xbeandir.mkdirs();
/* 175 */     this.xbeandir__.mkdirs();
/*     */ 
/* 177 */     for (Iterator localIterator = this.xbeans.iterator(); localIterator.hasNext(); ) { localObject = (XBean)localIterator.next();
/* 178 */       ((XBean)localObject).make();
/*     */     }
/* 180 */     Object localObject;
/* 179 */     XBean.make(this.xbeans);
/* 180 */     for (localIterator = this.cbeans.iterator(); localIterator.hasNext(); ) { localObject = (CBean)localIterator.next();
/* 181 */       ((CBean)localObject).make(); }
/* 182 */     for (localIterator = this.tables.values().iterator(); localIterator.hasNext(); ) { localObject = (Table)localIterator.next();
/* 183 */       ((Table)localObject).make(); }
/* 184 */     Table.make(this.tables.values());
/* 185 */     Lock.make(this.tables.values());
/* 186 */     makeMetaData();
/*     */   }
/*     */ 
/*     */   void makeMetaData() {
/* 190 */     PrintStream localPrintStream = Main.fopen(getXtabledir(), "_DatabaseMetaData_");
/*     */ 
/* 192 */     localPrintStream.println("package xtable;");
/* 193 */     localPrintStream.println("");
/* 194 */     localPrintStream.println("");
/* 195 */     localPrintStream.println("public class _DatabaseMetaData_ extends xdb.util.DatabaseMetaData {");
/*     */ 
/* 197 */     localPrintStream.println("\t@Override");
/* 198 */     localPrintStream.println("\tpublic boolean isVerifyXdb() {");
/* 199 */     localPrintStream.println(new StringBuilder().append("\t\treturn ").append(Main.noverify ? "false" : "true").append(";").toString());
/* 200 */     localPrintStream.println("\t}");
/*     */ 
/* 203 */     localPrintStream.println("\tpublic _DatabaseMetaData_() {");
/*     */ 
/* 205 */     localPrintStream.println("\t\t// xbeans");
/* 206 */     for (Iterator localIterator = this.xbeans.iterator(); localIterator.hasNext(); ) { localObject = (XBean)localIterator.next();
/* 207 */       localPrintStream.println("\t\t{");
/* 208 */       ((XBean)localObject).printMeta(localPrintStream, "\t\t\t");
/* 209 */       localPrintStream.println("\t\t}");
/*     */     }
/* 213 */     Object localObject;
/* 212 */     localPrintStream.println("\t\t// cbeans");
/* 213 */     for (localIterator = this.cbeans.iterator(); localIterator.hasNext(); ) { localObject = (CBean)localIterator.next();
/* 214 */       localPrintStream.println("\t\t{");
/* 215 */       ((CBean)localObject).printMeta(localPrintStream, "\t\t\t");
/* 216 */       localPrintStream.println("\t\t}");
/*     */     }
/*     */ 
/* 219 */     localPrintStream.println("\t\t// tables");
/* 220 */     for (localIterator = this.tables.values().iterator(); localIterator.hasNext(); ) { localObject = (Table)localIterator.next();
/* 221 */       ((Table)localObject).printMeta(localPrintStream, "\t\t");
/*     */     }
/* 223 */     localPrintStream.println("\t}");
/* 224 */     localPrintStream.println("}");
/* 225 */     localPrintStream.println("");
/* 226 */     localPrintStream.close();
/*     */   }
/*     */ 
/*     */   void clean() {
/* 230 */     remove(this.xbeandir);
/* 231 */     remove(this.xtabledir);
/*     */   }
/*     */ 
/*     */   void remove(File paramFile) {
/* 235 */     if (!paramFile.exists()) {
/* 236 */       return;
/*     */     }
/* 238 */     if (paramFile.isDirectory()) {
/* 239 */       for (File localFile : paramFile.listFiles()) {
/* 240 */         remove(localFile);
/*     */       }
/* 242 */       paramFile.delete();
/*     */     } else {
/* 244 */       paramFile.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean diffMetaData(List<XBean> paramList, List<CBean> paramList1)
/*     */   {
/* 257 */     DatabaseMetaData localDatabaseMetaData = DatabaseMetaData.getInstance();
/*     */ 
/* 259 */     boolean bool = false;
/*     */ 
/* 261 */     for (Iterator localIterator1 = localDatabaseMetaData.getBeans().iterator(); localIterator1.hasNext(); ) { localBean = (DatabaseMetaData.Bean)localIterator1.next();
/*     */ 
/* 263 */       for (localIterator2 = paramList.iterator(); localIterator2.hasNext(); ) { localObject1 = (XBean)localIterator2.next();
/* 264 */         if (localBean.getName().equals(((XBean)localObject1).getName()))
/*     */         {
/* 266 */           for (localIterator3 = localBean.getVariables().iterator(); localIterator3.hasNext(); ) { localObject2 = (DatabaseMetaData.Bean.Variable)localIterator3.next();
/* 267 */             Variable localVariable1 = ((XBean)localObject1).getVariable(((DatabaseMetaData.Bean.Variable)localObject2).getName());
/* 268 */             if (localVariable1 == null)
/*     */             {
/* 271 */               localVariable1 = new Variable((DatabaseMetaData.Bean.Variable)localObject2);
/* 272 */               localVariable1.compile(this);
/* 273 */               ((XBean)localObject1).getVariables().add(localVariable1);
/* 274 */               localVariable1.setModifyType(Variable.MODIFY_TYPES.REMOVE);
/* 275 */               ((XBean)localObject1).setHasModify();
/* 276 */               System.out.println(new StringBuilder().append("XBean: Var Is removed: ").append(localBean.getName()).append(".").append(localVariable1.getname()).toString());
/* 277 */               bool = true;
/*     */             }
/*     */           }
/*     */ 
/* 281 */           for (localIterator3 = ((XBean)localObject1).getVariables().iterator(); localIterator3.hasNext(); ) { localObject2 = (Variable)localIterator3.next();
/* 282 */             int i = 0;
/* 283 */             for (localIterator4 = localBean.getVariables().iterator(); localIterator4.hasNext(); ) { localVariable = (DatabaseMetaData.Bean.Variable)localIterator4.next();
/* 284 */               if ((localVariable.getName().equals(((Variable)localObject2).getname())) || (((Variable)localObject2).getModifyType() != Variable.MODIFY_TYPES.NONE))
/* 285 */                 i = 1;
/*     */             }
/* 287 */             if (i == 0)
/*     */             {
/* 289 */               System.out.println(new StringBuilder().append("XBean: Var Is added: ").append(localBean.getName()).append(".").append(((Variable)localObject2).getname()).toString());
/* 290 */               ((Variable)localObject2).setModifyType(Variable.MODIFY_TYPES.ADD);
/* 291 */               ((XBean)localObject1).setHasModify();
/* 292 */               bool = true;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 298 */       for (localIterator2 = paramList1.iterator(); localIterator2.hasNext(); ) { localObject1 = (CBean)localIterator2.next();
/*     */ 
/* 300 */         if (localBean.getName().equals(((CBean)localObject1).getName()))
/*     */         {
/* 302 */           for (localIterator3 = localBean.getVariables().iterator(); localIterator3.hasNext(); ) { localObject2 = (DatabaseMetaData.Bean.Variable)localIterator3.next();
/* 303 */             Variable localVariable2 = ((CBean)localObject1).getVariable(((DatabaseMetaData.Bean.Variable)localObject2).getName());
/* 304 */             if (localVariable2 == null)
/*     */             {
/* 306 */               System.out.println(new StringBuilder().append("CBean: Var is Removed: ").append(localBean.getName()).append(".").append(((DatabaseMetaData.Bean.Variable)localObject2).getName()).toString());
/* 307 */               throw new RuntimeException("It is Unsupportment for CBean Remove. it destroy the uniqment of key");
/*     */             }
/*     */           }
/*     */ 
/* 311 */           for (localIterator3 = ((CBean)localObject1).getVariables().iterator(); localIterator3.hasNext(); ) { localObject2 = (Variable)localIterator3.next();
/* 312 */             int j = 0;
/* 313 */             for (localIterator4 = localBean.getVariables().iterator(); localIterator4.hasNext(); ) { localVariable = (DatabaseMetaData.Bean.Variable)localIterator4.next();
/* 314 */               if ((localVariable.getName().equals(((Variable)localObject2).getname())) || (((Variable)localObject2).getModifyType() != Variable.MODIFY_TYPES.NONE))
/* 315 */                 j = 1;
/*     */             }
/* 317 */             if (j == 0)
/*     */             {
/* 319 */               System.out.println(new StringBuilder().append("CBean: Var Is added: ").append(localBean.getName()).append(".").append(((Variable)localObject2).getname()).toString());
/* 320 */               ((Variable)localObject2).setModifyType(Variable.MODIFY_TYPES.ADD);
/* 321 */               ((CBean)localObject1).setHasModify();
/* 322 */               bool = true;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     DatabaseMetaData.Bean localBean;
/*     */     Iterator localIterator2;
/*     */     Object localObject1;
/*     */     Iterator localIterator3;
/*     */     Object localObject2;
/*     */     Iterator localIterator4;
/*     */     DatabaseMetaData.Bean.Variable localVariable;
/* 330 */     return bool;
/*     */   }
/*     */ 
/*     */   private void transformVerify(List<XBean> paramList, Set<Table> paramSet, List<CBean> paramList1)
/*     */   {
/* 339 */     DatabaseMetaData localDatabaseMetaData = DatabaseMetaData.getInstance();
/*     */ 
/* 342 */     for (Iterator localIterator1 = paramSet.iterator(); localIterator1.hasNext(); ) { localObject1 = (Table)localIterator1.next();
/*     */ 
/* 344 */       localObject2 = localDatabaseMetaData.getTable(((Table)localObject1).getName());
/* 345 */       if (localObject2 != null)
/*     */       {
/* 347 */         if ((!((Table)localObject1).getKeyType().getName().equals(((DatabaseMetaData.Table)localObject2).getKeyName())) || (!((Table)localObject1).getValueType().getName().equals(((DatabaseMetaData.Table)localObject2).getValueName())))
/*     */         {
/* 350 */           throw new RuntimeException(new StringBuilder().append("\nthe Table is Modify??? \n").append(((Table)localObject1).getName()).append("\n\tkeytype: ").append(((Table)localObject1).getKeyType().getName()).append("\n\tvaluetype: ").append(((Table)localObject1).getValueType().getName()).append("\n\toldkeytype: ").append(((DatabaseMetaData.Table)localObject2).getKeyName()).append("\n\toldvaluetype: ").append(((DatabaseMetaData.Table)localObject2).getValueName()).toString());
/*     */         }
/*     */       }
/*     */     }
/* 361 */     Object localObject1;
/*     */     Object localObject2;
/* 361 */     for (localIterator1 = paramList.iterator(); localIterator1.hasNext(); ) { localObject1 = (XBean)localIterator1.next();
/*     */ 
/* 363 */       localObject2 = localDatabaseMetaData.getBean(((XBean)localObject1).getName());
/* 364 */       if (localObject2 != null)
/*     */       {
/* 366 */         for (localIterator2 = ((DatabaseMetaData.Bean)localObject2).getVariables().iterator(); localIterator2.hasNext(); ) { localVariable = (DatabaseMetaData.Bean.Variable)localIterator2.next();
/*     */ 
/* 368 */           localVariable1 = ((XBean)localObject1).getVariable(localVariable.getName());
/* 369 */           if (localVariable1 != null)
/*     */           {
/* 371 */             if ((!transformVerifySkip(localVariable1, localVariable, ((XBean)localObject1).getName())) || (!localVariable.getKeyTypeName().equals(localVariable1.getKeyTypeName())) || (!localVariable.getValueTypeName().equals(localVariable1.getValueTypeName())))
/*     */             {
/* 375 */               throw new RuntimeException(new StringBuilder().append("\nthe XBean is Modify??? \n").append(((XBean)localObject1).getName()).append(".").append(localVariable1.getName()).append("\n\tType: ").append(localVariable1.getVartype().getName()).append("\n \tkeytype: ").append(localVariable1.getKeyTypeName()).append("\n \tvaluetype: ").append(localVariable1.getValueTypeName()).append("\n\toldType: ").append(localVariable.getTypeName()).append("\n \toldkeytype: ").append(localVariable.getKeyTypeName()).append("\n \toldvaluetype: ").append(localVariable.getValueTypeName()).toString());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 391 */     Iterator localIterator2;
/*     */     DatabaseMetaData.Bean.Variable localVariable;
/*     */     Variable localVariable1;
/* 391 */     for (localIterator1 = paramList1.iterator(); localIterator1.hasNext(); ) { localObject1 = (CBean)localIterator1.next();
/*     */ 
/* 393 */       localObject2 = localDatabaseMetaData.getBean(((CBean)localObject1).getName());
/* 394 */       if (localObject2 != null)
/*     */       {
/* 396 */         for (localIterator2 = ((DatabaseMetaData.Bean)localObject2).getVariables().iterator(); localIterator2.hasNext(); ) { localVariable = (DatabaseMetaData.Bean.Variable)localIterator2.next();
/*     */ 
/* 398 */           localVariable1 = ((CBean)localObject1).getVariable(localVariable.getName());
/* 399 */           if (localVariable1 != null)
/*     */           {
/* 401 */             if ((!transformVerifySkip(localVariable1, localVariable, ((CBean)localObject1).getName())) || (!localVariable.getKeyTypeName().equals(localVariable1.getKeyTypeName())) || (!localVariable.getValueTypeName().equals(localVariable1.getValueTypeName())))
/*     */             {
/* 405 */               throw new RuntimeException(new StringBuilder().append("\nthe CBean is Modify??? \n").append(((CBean)localObject1).getName()).append(".").append(localVariable1.getName()).append("\n\tType: ").append(localVariable1.getVartype().getName()).append("\n \tkeytype: ").append(localVariable1.getKeyTypeName()).append("\n \tvaluetype: ").append(localVariable1.getValueTypeName()).append("\n\toldType: ").append(localVariable.getTypeName()).append("\n \toldkeytype: ").append(localVariable.getKeyTypeName()).append("\n \toldvaluetype: ").append(localVariable.getValueTypeName()).toString());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean transformVerifySkip(Variable paramVariable, DatabaseMetaData.Bean.Variable paramVariable1, String paramString)
/*     */   {
/* 429 */     if ((paramVariable1.getTypeName().equals("map")) && (paramVariable.getVartype().getName().equals("treemap")))
/*     */     {
/* 431 */       System.out.println(new StringBuilder().append("Skip Bean : ").append(paramString).append(" TYPE: map -> treemap").toString());
/* 432 */       return true;
/*     */     }
/*     */ 
/* 435 */     if ((paramVariable1.getTypeName().equals("treemap")) && (paramVariable.getVartype().getName().equals("map")))
/*     */     {
/* 437 */       System.out.println(new StringBuilder().append("Skip Bean : ").append(paramString).append(" TYPE: treemap -> map").toString());
/* 438 */       return true;
/*     */     }
/*     */ 
/* 442 */     if ((paramVariable1.getTypeName().equals("vector")) && (paramVariable.getVartype().getName().equals("list")))
/*     */     {
/* 444 */       System.out.println(new StringBuilder().append("Skip Bean : ").append(paramString).append(" TYPE: vector -> list").toString());
/* 445 */       return true;
/*     */     }
/*     */ 
/* 448 */     if ((paramVariable1.getTypeName().equals("list")) && (paramVariable.getVartype().getName().equals("vector")))
/*     */     {
/* 450 */       System.out.println(new StringBuilder().append("Skip Bean : ").append(paramString).append(" TYPE: list -> vector").toString());
/* 451 */       return true;
/*     */     }
/*     */ 
/* 455 */     if ((paramVariable1.getTypeName().equals("set")) && (paramVariable.getVartype().getName().equals("vector")))
/*     */     {
/* 457 */       System.out.println(new StringBuilder().append("Skip Bean : ").append(paramString).append(" TYPE: set -> vector").toString());
/* 458 */       return true;
/*     */     }
/*     */ 
/* 462 */     if ((paramVariable1.getTypeName().equals("set")) && (paramVariable.getVartype().getName().equals("list")))
/*     */     {
/* 464 */       System.out.println(new StringBuilder().append("Skip Bean : ").append(paramString).append(" TYPE: set -> list").toString());
/* 465 */       return true;
/*     */     }
/*     */ 
/* 468 */     return paramVariable1.getTypeName().equals(paramVariable.getVartype().getName());
/*     */   }
/*     */ 
/*     */   void transformMake()
/*     */   {
/* 473 */     this.xtabledir.mkdirs();
/* 474 */     this.xbeandir.mkdirs();
/* 475 */     this.xbeandir__.mkdirs();
/*     */ 
/* 477 */     HashSet localHashSet1 = new HashSet();
/*     */ 
/* 479 */     ArrayList localArrayList1 = new ArrayList();
/* 480 */     ArrayList localArrayList2 = new ArrayList();
/* 481 */     HashSet localHashSet2 = new HashSet();
/* 482 */     ArrayList localArrayList3 = new ArrayList();
/*     */ 
/* 486 */     for (Object localObject1 = this.tables.values().iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Table)((Iterator)localObject1).next();
/* 487 */       if (!((Table)localObject2).isMemory())
/*     */       {
/* 489 */         ((Table)localObject2).depends(localHashSet1);
/* 490 */         localHashSet2.add(localObject2);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 495 */     for (localObject1 = this.xbeans.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (XBean)((Iterator)localObject1).next();
/* 496 */       for (localObject3 = localHashSet1.iterator(); ((Iterator)localObject3).hasNext(); ) { localObject4 = (Type)((Iterator)localObject3).next();
/*     */ 
/* 498 */         if (((XBean)localObject2).getName().equals(((Type)localObject4).getName()))
/*     */         {
/* 500 */           localArrayList1.add(localObject2);
/*     */ 
/* 502 */           localObject5 = DatabaseMetaData.getInstance().getBean(((XBean)localObject2).getName());
/* 503 */           if (localObject5 != null)
/*     */           {
/* 506 */             for (localIterator1 = ((DatabaseMetaData.Bean)localObject5).getVariables().iterator(); localIterator1.hasNext(); ) { localObject6 = (DatabaseMetaData.Bean.Variable)localIterator1.next();
/*     */ 
/* 508 */               localObject7 = new DatabaseMetaData.Type.Depends();
/* 509 */               ((DatabaseMetaData.Bean.Variable)localObject6).depends((DatabaseMetaData.Type.Depends)localObject7);
/* 510 */               for (DatabaseMetaData.Type localType : ((DatabaseMetaData.Type.Depends)localObject7).getDepends())
/*     */               {
/* 512 */                 if (!Type.isExist(localType.getName()))
/*     */                 {
/* 514 */                   if (localType.isBean())
/*     */                   {
/* 516 */                     System.out.println(new StringBuilder().append("XBean: XBean(").append(localType.getName()).append(") is Removed. Rebuild from DatabaseMetaData ").toString());
/* 517 */                     DatabaseMetaData.Bean localBean = DatabaseMetaData.getInstance().getBean(localType.getName());
/*     */ 
/* 519 */                     if (localBean == null)
/*     */                     {
/* 521 */                       throw new RuntimeException(new StringBuilder().append("Can't find Info of Bean(").append(localType.getName()).append(") from DatabaseMetaData").toString());
/*     */                     }
/* 523 */                     XBean localXBean = new XBean(localBean);
/* 524 */                     localArrayList2.add(localXBean);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 534 */     Object localObject3;
/*     */     Object localObject4;
/*     */     Object localObject5;
/*     */     Iterator localIterator1;
/*     */     Object localObject6;
/*     */     Object localObject7;
/* 534 */     for (localObject1 = localArrayList2.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (XBean)((Iterator)localObject1).next();
/*     */ 
/* 536 */       this.xbeans.add(localObject2);
/* 537 */       localArrayList1.add(localObject2);
/* 538 */       ((XBean)localObject2).compile(this);
/* 539 */       ((XBean)localObject2).verify(this);
/*     */     }
/*     */ 
/* 542 */     for (localObject1 = localArrayList2.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (XBean)((Iterator)localObject1).next();
/*     */ 
/* 544 */       ((XBean)localObject2).depends();
/*     */     }
/*     */ 
/* 547 */     for (localObject1 = this.cbeans.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (CBean)((Iterator)localObject1).next();
/* 548 */       for (localObject3 = localHashSet1.iterator(); ((Iterator)localObject3).hasNext(); ) { localObject4 = (Type)((Iterator)localObject3).next();
/* 549 */         if (((CBean)localObject2).getName().equals(((Type)localObject4).getName())) {
/* 550 */           localArrayList3.add(localObject2);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 558 */     Main.doTransformCheck(diffMetaData(localArrayList1, localArrayList3));
/*     */ 
/* 561 */     transformVerify(localArrayList1, localHashSet2, localArrayList3);
/*     */ 
/* 563 */     for (localObject1 = localArrayList1.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (XBean)((Iterator)localObject1).next();
/* 564 */       ((XBean)localObject2).transformMake(); }
/* 565 */     XBean.make(localArrayList1);
/* 566 */     for (localObject1 = localArrayList3.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (CBean)((Iterator)localObject1).next();
/* 567 */       ((CBean)localObject2).transformMake(); }
/* 568 */     for (localObject1 = localHashSet2.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Table)((Iterator)localObject1).next();
/* 569 */       ((Table)localObject2).make(); }
/* 570 */     Table.make(localHashSet2);
/* 571 */     makeMetaDataTransform(localArrayList1, localArrayList3, localHashSet2);
/*     */ 
/* 573 */     localObject1 = new TransformPrint();
/*     */ 
/* 575 */     for (Object localObject2 = localHashSet2.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject3 = (Table)((Iterator)localObject2).next();
/* 576 */       localHashSet1.clear();
/* 577 */       ((Table)localObject3).depends(localHashSet1);
/* 578 */       for (localObject4 = localHashSet1.iterator(); ((Iterator)localObject4).hasNext(); ) { localObject5 = (Type)((Iterator)localObject4).next();
/*     */ 
/* 580 */         int i = 0;
/* 581 */         for (localObject6 = this.xbeans.iterator(); ((Iterator)localObject6).hasNext(); ) { localObject7 = (XBean)((Iterator)localObject6).next();
/*     */ 
/* 583 */           if ((((Type)localObject5).getName().equals(((XBean)localObject7).getName())) && (((XBean)localObject7).hasModify())) {
/* 584 */             System.out.println(new StringBuilder().append("Table ").append(((Table)localObject3).getName()).append(" is modify(").append(((XBean)localObject7).getName()).append(" modify)").toString());
/*     */ 
/* 586 */             if (!((TransformPrint)localObject1).isModifyTable(((Table)localObject3).getName()))
/* 587 */               ((TransformPrint)localObject1).addModifyTable(((Table)localObject3).getName());
/* 588 */             i = 1;
/*     */           }
/*     */         }
/* 591 */         if (i != 0)
/*     */           break;
/* 593 */         for (localObject6 = this.cbeans.iterator(); ((Iterator)localObject6).hasNext(); ) { localObject7 = (CBean)((Iterator)localObject6).next();
/*     */ 
/* 595 */           if ((((Type)localObject5).getName().equals(((CBean)localObject7).getName())) && (((CBean)localObject7).hasModify())) {
/* 596 */             System.out.println(new StringBuilder().append("Table ").append(((Table)localObject3).getName()).append(" is modify(").append(((CBean)localObject7).getName()).append(" modify)").toString());
/*     */ 
/* 598 */             if (!((TransformPrint)localObject1).isModifyTable(((Table)localObject3).getName())) {
/* 599 */               ((TransformPrint)localObject1).addModifyTable(((Table)localObject3).getName());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 606 */     ((TransformPrint)localObject1).printMain();
/*     */   }
/*     */ 
/*     */   void makeMetaDataTransform(List<XBean> paramList, List<CBean> paramList1, Set<Table> paramSet) {
/* 610 */     PrintStream localPrintStream = Main.fopen(getXtabledir(), "_DatabaseMetaData_");
/*     */ 
/* 612 */     localPrintStream.println("package xtable;");
/* 613 */     localPrintStream.println("");
/* 614 */     localPrintStream.println("");
/* 615 */     localPrintStream.println("public class _DatabaseMetaData_ extends xdb.util.DatabaseMetaData {");
/*     */ 
/* 618 */     localPrintStream.println("\tpublic _DatabaseMetaData_() {");
/*     */ 
/* 620 */     localPrintStream.println("\t\t// xbeans");
/* 621 */     for (Iterator localIterator = paramList.iterator(); localIterator.hasNext(); ) { localObject = (XBean)localIterator.next();
/* 622 */       localPrintStream.println("\t\t{");
/* 623 */       ((XBean)localObject).printMeta(localPrintStream, "\t\t\t");
/* 624 */       localPrintStream.println("\t\t}");
/*     */     }
/* 628 */     Object localObject;
/* 627 */     localPrintStream.println("\t\t// cbeans");
/* 628 */     for (localIterator = paramList1.iterator(); localIterator.hasNext(); ) { localObject = (CBean)localIterator.next();
/* 629 */       localPrintStream.println("\t\t{");
/* 630 */       ((CBean)localObject).printMeta(localPrintStream, "\t\t\t");
/* 631 */       localPrintStream.println("\t\t}");
/*     */     }
/*     */ 
/* 634 */     localPrintStream.println("\t\t// tables");
/* 635 */     for (localIterator = paramSet.iterator(); localIterator.hasNext(); ) { localObject = (Table)localIterator.next();
/* 636 */       ((Table)localObject).printMeta(localPrintStream, "\t\t");
/*     */     }
/*     */ 
/* 639 */     localPrintStream.println("\tsuper.addTable(\"_sys_\", \"DB\", \"int\", false, \"int\", \"\", \"\");");
/*     */ 
/* 641 */     localPrintStream.println("\t}");
/* 642 */     localPrintStream.println("}");
/* 643 */     localPrintStream.println("");
/* 644 */     localPrintStream.close();
/*     */   }
/*     */ 
/*     */   File getXgenOutputdir() {
/* 648 */     return this.xgenOutput;
/*     */   }
/*     */ 
/*     */   static class Detected
/*     */   {
/*     */     private Table origin;
/* 136 */     private Map<String, Set<String>> detected = new LinkedHashMap();
/*     */ 
/*     */     Detected(Table paramTable)
/*     */     {
/* 133 */       this.origin = paramTable;
/*     */     }
/*     */ 
/*     */     Set<String> foreigns(Table paramTable)
/*     */     {
/* 139 */       Set localSet = paramTable.getForeigns();
/* 140 */       this.detected.put(paramTable.getName(), localSet);
/* 141 */       if (localSet.contains(this.origin.getName())) {
/* 142 */         for (Map.Entry localEntry : this.detected.entrySet()) {
/* 143 */           if (false == ((Set)localEntry.getValue()).isEmpty())
/* 144 */             System.err.println(this.origin.getName() + " " + localEntry);
/*     */         }
/* 146 */         throw new IllegalStateException("foreign circle found.");
/*     */       }
/* 148 */       return localSet;
/*     */     }
/*     */ 
/*     */     boolean contains(Table paramTable) {
/* 152 */       return this.detected.containsKey(paramTable.getName());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.Xdb
 * JD-Core Version:    0.6.2
 */