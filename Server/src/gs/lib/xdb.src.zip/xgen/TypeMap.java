/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TypeMap extends TypeBaseMap
/*     */ {
/*     */   public void addOwnerTable(Table paramTable)
/*     */   {
/*  10 */     super.addOwnerTable(paramTable);
/*  11 */     this.keytype.addOwnerTable(paramTable);
/*  12 */     this.valuetype.addOwnerTable(paramTable);
/*     */   }
/*     */ 
/*     */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*     */   {
/*     */     Table localTable;
/*  17 */     if (null != paramForeign.getKey()) {
/*  18 */       localTable = paramXdb.getTable(paramForeign.getKey());
/*  19 */       paramForeign.throwIf(null == localTable, "[map.key] table not exist");
/*  20 */       paramForeign.throwIf(localTable.isMemory(), "[map.key] foreign table is memory");
/*  21 */       paramForeign.throwIf(localTable.getKeyType() != this.keytype, "[map.key] type not match.");
/*     */     }
/*  23 */     if (null != paramForeign.getValue()) {
/*  24 */       localTable = paramXdb.getTable(paramForeign.getValue());
/*  25 */       paramForeign.throwIf(null == localTable, "[map.value] table not exist");
/*  26 */       paramForeign.throwIf(localTable.isMemory(), "[map.value] foreign table is memory");
/*  27 */       paramForeign.throwIf(localTable.getKeyType() != this.valuetype, "[map.value] type not match");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*     */   {
/*  33 */     paramCapacity.capacityNeed();
/*  34 */     this.keytype.verifyCapacity(paramXdb, paramCapacity.extractKey());
/*  35 */     this.valuetype.verifyCapacity(paramXdb, paramCapacity.extractValue());
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  40 */     return "map";
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/*  45 */     return "java.util.HashMap" + KV();
/*     */   }
/*     */ 
/*     */   public String getGetterName()
/*     */   {
/*  50 */     return "java.util.Map" + KV();
/*     */   }
/*     */ 
/*     */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*  55 */     paramPrintStream.println(paramString + paramVariable.getname() + " = new " + getTypeName() + "();");
/*     */   }
/*     */ 
/*     */   public Type compile(String paramString1, String paramString2)
/*     */   {
/*  60 */     return new TypeMap(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   private TypeMap(String paramString1, String paramString2) {
/*  64 */     this.keytype = Type.compile(paramString1, null, null);
/*  65 */     if (!this.keytype.isConstant())
/*  66 */       throw new RuntimeException("map.key need a constant valuetype");
/*  67 */     this.valuetype = Type.compile(paramString2, null, null);
/*     */   }
/*     */ 
/*     */   TypeMap(Map<String, Type> paramMap)
/*     */   {
/*  75 */     paramMap.put(getName(), this);
/*     */   }
/*     */ 
/*     */   public void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/*  80 */     paramPrintStream.println(paramString1 + "_os_.compact_uint32(" + paramString2 + ".size());");
/*  81 */     paramPrintStream.println(paramString1 + "for (java.util.Map.Entry" + KV() + " _e_ : " + paramString2 + ".entrySet())");
/*  82 */     paramPrintStream.println(paramString1 + "{");
/*  83 */     this.keytype.marshal(paramXBean, paramVariable, paramPrintStream, paramString1 + "\t", "_e_.getKey()");
/*  84 */     this.valuetype.marshal(paramXBean, paramVariable, paramPrintStream, paramString1 + "\t", "_e_.getValue()");
/*  85 */     paramPrintStream.println(paramString1 + "}");
/*     */   }
/*     */ 
/*     */   public void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/*  90 */     paramPrintStream.println(paramString1 + "{");
/*  91 */     paramPrintStream.println(paramString1 + "\tint size = _os_.uncompact_uint32();");
/*  92 */     paramPrintStream.println(paramString1 + "\tif (size >= 12) { // {java.util.HashMap} 16 * 0.75 = 12");
/*  93 */     paramPrintStream.println(paramString1 + "\t\t" + paramVariable.getname() + " = new " + getTypeName() + "(size * 2);");
/*  94 */     paramPrintStream.println(paramString1 + "\t}");
/*  95 */     paramPrintStream.println(paramString1 + "\tfor (; size > 0; --size)");
/*  96 */     paramPrintStream.println(paramString1 + "\t{");
/*  97 */     paramPrintStream.println(paramString1 + "\t\t" + this.keytype.defineSetParent(paramXBean, paramVariable, "_k_"));
/*  98 */     this.keytype.unmarshal(paramXBean, paramVariable, paramPrintStream, paramString1 + "\t\t", "_k_");
/*  99 */     paramPrintStream.println(paramString1 + "\t\t" + this.valuetype.defineSetParent(paramXBean, paramVariable, "_v_"));
/* 100 */     this.valuetype.unmarshal(paramXBean, paramVariable, paramPrintStream, paramString1 + "\t\t", "_v_");
/* 101 */     paramPrintStream.println(paramString1 + "\t\t" + paramString2 + ".put(_k_, _v_);");
/* 102 */     paramPrintStream.println(paramString1 + "\t}");
/* 103 */     paramPrintStream.println(paramString1 + "}");
/*     */   }
/*     */ 
/*     */   public void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 108 */     paramPrintStream.println(paramString + "@Override");
/* 109 */     paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 110 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 111 */     paramPrintStream.println(paramString + "\treturn xdb.Logs.logMap(new xdb.LogKey(this, " + Main.quote(paramVariable.getname()) + "), " + paramVariable.getname() + ");");
/*     */ 
/* 113 */     paramPrintStream.println(paramString + "}");
/* 114 */     paramPrintStream.println();
/*     */ 
/* 116 */     if (isCloneable()) {
/* 117 */       paramPrintStream.println(paramString + "@Override");
/* 118 */       paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "AsData() { // " + paramVariable.getComment());
/* 119 */       Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 120 */       paramPrintStream.println(paramString + "\t" + getGetterName() + " " + paramVariable.getname() + ";");
/* 121 */       paramPrintStream.println(paramString + "\t" + paramXBean.getName() + " _o_ = this;");
/* 122 */       deepCopy(true, paramVariable, paramPrintStream, paramString + "\t");
/* 123 */       paramPrintStream.println(paramString + "\t" + "return " + paramVariable.getname() + ";");
/* 124 */       paramPrintStream.println(paramString + "}");
/* 125 */       paramPrintStream.println();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 131 */     paramPrintStream.println(paramString + "@Override");
/* 132 */     paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 133 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 134 */     paramPrintStream.println(paramString + "\treturn xdb.Consts.constMap(" + paramVariable.getname() + ");");
/* 135 */     paramPrintStream.println(paramString + "}");
/* 136 */     paramPrintStream.println("");
/*     */ 
/* 138 */     if (isCloneable()) {
/* 139 */       paramPrintStream.println(paramString + "@Override");
/* 140 */       paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "AsData() { // " + paramVariable.getComment());
/* 141 */       Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 142 */       paramPrintStream.println(paramString + "\t" + getGetterName() + " " + paramVariable.getname() + ";");
/* 143 */       paramPrintStream.println(paramString + "\t" + paramXBean.getName() + " _o_ = " + paramXBean.getName() + ".this;");
/* 144 */       deepCopy(true, paramVariable, paramPrintStream, paramString + "\t");
/* 145 */       paramPrintStream.println(paramString + "\t" + "return " + paramVariable.getname() + ";");
/* 146 */       paramPrintStream.println(paramString + "}");
/* 147 */       paramPrintStream.println("");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String hashCode(String paramString)
/*     */   {
/* 153 */     return paramString + ".hashCode()";
/*     */   }
/*     */ 
/*     */   public String notEquals(String paramString)
/*     */   {
/* 158 */     return "!" + paramString + ".equals(_o_." + paramString + ")";
/*     */   }
/*     */ 
/*     */   public String defineNoParent(String paramString)
/*     */   {
/* 163 */     return getTypeName() + " " + paramString + " = new " + getTypeName() + "();";
/*     */   }
/*     */ 
/*     */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*     */   {
/* 168 */     return defineNoParent(paramString);
/*     */   }
/*     */ 
/*     */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*     */   {
/* 173 */     return "new xdb.logs.ListenableMap().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*     */   }
/*     */ 
/*     */   public void depends(Set<Type> paramSet)
/*     */   {
/* 178 */     if (paramSet.add(this)) {
/* 179 */       this.keytype.depends(paramSet);
/* 180 */       this.valuetype.depends(paramSet);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeMap
 * JD-Core Version:    0.6.2
 */