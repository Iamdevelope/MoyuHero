/*    */ package xgen;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ public class Enum
/*    */ {
/*    */   private String name;
/*    */   private String value;
/*    */   private String comment;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 13 */     return this.name;
/*    */   }
/*    */ 
/*    */   public Enum(Element paramElement) {
/* 17 */     this.name = paramElement.getAttribute("name").trim();
/* 18 */     this.value = paramElement.getAttribute("value").trim();
/* 19 */     Node localNode = paramElement.getNextSibling();
/* 20 */     if ((localNode != null) && (3 == localNode.getNodeType()))
/* 21 */       this.comment = localNode.getTextContent().trim().replaceAll("[\r\n]", "");
/*    */   }
/*    */ 
/*    */   public void print(PrintStream paramPrintStream, String paramString)
/*    */   {
/* 26 */     paramPrintStream.println(paramString + "public final static int " + this.name + " = " + this.value + "; // " + this.comment);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.Enum
 * JD-Core Version:    0.6.2
 */