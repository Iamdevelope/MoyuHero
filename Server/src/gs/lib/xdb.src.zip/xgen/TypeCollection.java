/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Set;
/*     */ 
/*     */ public abstract class TypeCollection extends Type
/*     */ {
/*     */   private Type valuetype;
/*     */ 
/*     */   public void printTableSelectMethod(PrintStream paramPrintStream, String paramString)
/*     */   {
/*  12 */     throw new UnsupportedOperationException("select for " + getName());
/*     */   }
/*     */ 
/*     */   public boolean isCloneable()
/*     */   {
/*  17 */     return this.valuetype.isCloneable();
/*     */   }
/*     */ 
/*     */   public void addOwnerTable(Table paramTable)
/*     */   {
/*  22 */     super.addOwnerTable(paramTable);
/*  23 */     this.valuetype.addOwnerTable(paramTable);
/*     */   }
/*     */ 
/*     */   protected void _compile(String paramString1, String paramString2) {
/*  27 */     if ((paramString1 != null) && (!paramString1.isEmpty()))
/*  28 */       throw new RuntimeException(getName() + " DO NOT NEED A KEY!");
/*  29 */     this.valuetype = Type.compile(paramString2, null, null);
/*     */   }
/*     */ 
/*     */   protected String toUpper1(String paramString) {
/*  33 */     return paramString.substring(0, 1).toUpperCase() + paramString.substring(1);
/*     */   }
/*     */ 
/*     */   protected String V() {
/*  37 */     return "<" + this.valuetype.getBoxingName() + ">";
/*     */   }
/*     */ 
/*     */   Type getValueType() {
/*  41 */     return this.valuetype;
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/*  46 */     return getCollectionName() + V();
/*     */   }
/*     */ 
/*     */   protected abstract String getGetterName();
/*     */ 
/*     */   public String getBoxingName()
/*     */   {
/*  53 */     return getGetterName();
/*     */   }
/*     */ 
/*     */   protected String getImplName() {
/*  57 */     return getName();
/*     */   }
/*     */ 
/*     */   public abstract String getCollectionName();
/*     */ 
/*     */   public void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/*  68 */     paramPrintStream.println(paramString1 + "_os_.compact_uint32(" + paramString2 + ".size());");
/*  69 */     paramPrintStream.println(paramString1 + "for (" + this.valuetype.getBoxingName() + " _v_ : " + paramString2 + ") {");
/*  70 */     this.valuetype.marshal(paramXBean, paramVariable, paramPrintStream, paramString1 + "\t", "_v_");
/*  71 */     paramPrintStream.println(paramString1 + "}");
/*     */   }
/*     */ 
/*     */   public void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/*  76 */     paramPrintStream.println(paramString1 + "for (int size = _os_.uncompact_uint32(); size > 0; --size) {");
/*  77 */     paramPrintStream.println(paramString1 + "\t" + this.valuetype.defineSetParent(paramXBean, paramVariable, "_v_"));
/*  78 */     this.valuetype.unmarshal(paramXBean, paramVariable, paramPrintStream, paramString1 + "\t", "_v_");
/*  79 */     paramPrintStream.println(paramString1 + "\t" + paramString2 + ".add(_v_);");
/*  80 */     paramPrintStream.println(paramString1 + "}");
/*     */   }
/*     */ 
/*     */   public String deepCopy(boolean paramBoolean, Variable paramVariable, String paramString)
/*     */   {
/*  85 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void deepCopy(boolean paramBoolean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*  90 */     paramPrintStream.println(paramString + paramVariable.getname() + " = new " + getTypeName() + "();");
/*  91 */     if (this.valuetype.isConstant()) {
/*  92 */       paramPrintStream.println(paramString + paramVariable.getname() + ".addAll(_o_." + paramVariable.getname() + ");");
/*  93 */       return;
/*     */     }
/*  95 */     paramPrintStream.println(paramString + "for (" + this.valuetype.getBoxingName() + " _v_ : _o_." + paramVariable.getname() + ")");
/*  96 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + ".add(" + this.valuetype.deepCopy(paramBoolean, paramVariable, "_v_") + ");");
/*     */   }
/*     */ 
/*     */   public void depends(Set<Type> paramSet)
/*     */   {
/* 101 */     if (paramSet.add(this))
/* 102 */       this.valuetype.depends(paramSet);
/*     */   }
/*     */ 
/*     */   public void getterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 107 */     paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "(); // " + paramVariable.getComment());
/* 108 */     if (isCloneable())
/* 109 */       paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "AsData(); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void getterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 114 */     paramPrintStream.println(paramString + "@Override");
/* 115 */     paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 116 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 117 */     paramPrintStream.println(paramString + "}");
/* 118 */     paramPrintStream.println("");
/*     */ 
/* 120 */     if (isCloneable()) {
/* 121 */       paramPrintStream.println(paramString + "@Override");
/* 122 */       paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "AsData() { // " + paramVariable.getComment());
/* 123 */       paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 124 */       paramPrintStream.println(paramString + "}");
/* 125 */       paramPrintStream.println("");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 131 */     paramPrintStream.println(paramString + "@Override");
/* 132 */     paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 133 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 134 */     paramPrintStream.println(paramString + "\treturn xdb.Consts.const" + toUpper1(getImplName()) + "(" + paramVariable.getname() + ");");
/* 135 */     paramPrintStream.println(paramString + "}");
/* 136 */     paramPrintStream.println("");
/*     */ 
/* 138 */     if (isCloneable()) {
/* 139 */       paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "AsData() { // " + paramVariable.getComment());
/* 140 */       Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 141 */       paramPrintStream.println(paramString + "\t" + getGetterName() + " " + paramVariable.getname() + ";");
/* 142 */       paramPrintStream.println(paramString + "\t" + paramXBean.getName() + " _o_ = " + paramXBean.getName() + ".this;");
/* 143 */       deepCopy(true, paramVariable, paramPrintStream, "\t\t");
/* 144 */       paramPrintStream.println(paramString + "\t" + "return " + paramVariable.getname() + ";");
/* 145 */       paramPrintStream.println(paramString + "}");
/* 146 */       paramPrintStream.println("");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 153 */     paramPrintStream.println(paramString + "@Override");
/* 154 */     paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 155 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 156 */     paramPrintStream.println(paramString + "\treturn xdb.Logs.log" + toUpper1(getImplName()) + "(new xdb.LogKey(this, " + Main.quote(paramVariable.getname()) + "), " + paramVariable.getname() + ");");
/*     */ 
/* 158 */     paramPrintStream.println(paramString + "}");
/* 159 */     paramPrintStream.println("");
/*     */ 
/* 161 */     if ((isCloneable()) && (!paramXBean.isData())) {
/* 162 */       paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "AsData() { // " + paramVariable.getComment());
/* 163 */       Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 164 */       paramPrintStream.println(paramString + "\t" + getGetterName() + " " + paramVariable.getname() + ";");
/* 165 */       paramPrintStream.println(paramString + "\t" + paramXBean.getName() + " _o_ = this;");
/* 166 */       deepCopy(true, paramVariable, paramPrintStream, "\t\t");
/* 167 */       paramPrintStream.println(paramString + "\t" + "return " + paramVariable.getname() + ";");
/* 168 */       paramPrintStream.println(paramString + "}");
/* 169 */       paramPrintStream.println("");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeCollection
 * JD-Core Version:    0.6.2
 */