/*      */ package xgen;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import xdb.util.DatabaseMetaData;
/*      */ import xdb.util.DatabaseMetaData.Bean;
/*      */ import xdb.util.DatabaseMetaData.Bean.Variable;
/*      */ 
/*      */ public class XBean extends Type
/*      */ {
/*      */   private String name;
/*   13 */   private boolean anyMaybe = false;
/*   14 */   private List<Variable> variables = new ArrayList();
/*   15 */   private List<Enum> enums = new ArrayList();
/*   16 */   private boolean isData = false;
/*   17 */   private Set<String> varNames = new HashSet();
/*      */ 
/*  798 */   private boolean hasModify = false;
/*      */ 
/*      */   public void addOwnerTable(Table paramTable)
/*      */   {
/*   21 */     super.addOwnerTable(paramTable);
/*   22 */     for (Variable localVariable : this.variables)
/*   23 */       localVariable.getVartype().addOwnerTable(paramTable);
/*      */   }
/*      */ 
/*      */   private void add(Variable paramVariable) {
/*   27 */     if (false == this.varNames.add(paramVariable.getname()))
/*   28 */       throw new IllegalArgumentException("duplicate varname." + paramVariable.getname() + "@" + this.name);
/*   29 */     this.variables.add(paramVariable);
/*      */   }
/*      */ 
/*      */   public void collectForeigns(Set<String> paramSet) {
/*   33 */     for (Variable localVariable : this.variables)
/*   34 */       localVariable.collectForeigns(paramSet);
/*      */   }
/*      */ 
/*      */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*      */   {
/*   39 */     paramForeign.throwIf(true, "[xbean] unsupported.");
/*      */   }
/*      */ 
/*      */   public boolean isData() {
/*   43 */     return this.isData;
/*      */   }
/*      */ 
/*      */   public Type compile(String paramString1, String paramString2)
/*      */   {
/*   48 */     if ((paramString1 != null) && (!paramString1.isEmpty()))
/*   49 */       throw new RuntimeException(getName() + " DO NOT NEED A KEY!");
/*   50 */     if ((paramString2 != null) && (!paramString2.isEmpty()))
/*   51 */       throw new RuntimeException(getName() + " DO NOT NEED A VALUE!");
/*   52 */     return this;
/*      */   }
/*      */ 
/*      */   public XBean(Element paramElement) {
/*   56 */     this.name = paramElement.getAttribute("name").trim();
/*   57 */     Main.verifyName(this.name);
/*   58 */     if (this.name.equals("Pod"))
/*   59 */       throw new RuntimeException("name of 'Pod' has been used by xdb");
/*   60 */     Type.add(this);
/*   61 */     this.anyMaybe = "true".equalsIgnoreCase(paramElement.getAttribute("any"));
/*      */ 
/*   63 */     NodeList localNodeList = paramElement.getChildNodes();
/*   64 */     for (int i = 0; i < localNodeList.getLength(); i++) {
/*   65 */       Node localNode = localNodeList.item(i);
/*   66 */       if (1 == localNode.getNodeType())
/*      */       {
/*   69 */         Element localElement = (Element)localNode;
/*   70 */         String str = localElement.getNodeName();
/*      */ 
/*   72 */         if (str.equals("variable"))
/*   73 */           add(new Variable(localElement));
/*   74 */         else if (str.equals("enum"))
/*   75 */           this.enums.add(new Enum(localElement));
/*      */         else
/*   77 */           throw new RuntimeException("node=" + str);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isAny() {
/*   83 */     for (Type localType : depends())
/*   84 */       if ((localType != this) && (localType.isAny()))
/*   85 */         return true;
/*   86 */     return false;
/*      */   }
/*      */ 
/*      */   public void compile(Xdb paramXdb) {
/*   90 */     boolean bool = Type.setAny(this.anyMaybe);
/*      */     try {
/*   92 */       for (Variable localVariable : this.variables)
/*   93 */         localVariable.compile(paramXdb);
/*      */     } finally {
/*   95 */       Type.setAny(bool);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void verify(Xdb paramXdb) {
/*  100 */     for (Variable localVariable : this.variables)
/*  101 */       localVariable.verify(paramXdb, this);
/*      */   }
/*      */ 
/*      */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*      */   {
/*  106 */     paramCapacity.notNeed();
/*      */   }
/*      */ 
/*      */   private void generateImplementCopyConstruct(PrintStream paramPrintStream) {
/*  110 */     String str = getName();
/*  111 */     paramPrintStream.println("\tpublic " + str + "(" + str + " _o_) {");
/*  112 */     paramPrintStream.println("\t\tthis(_o_, null, null);");
/*  113 */     paramPrintStream.println("\t}");
/*  114 */     paramPrintStream.println("");
/*  115 */     paramPrintStream.println("\t" + str + "(xbean." + str + " _o1_, xdb.XBean _xp_, String _vn_) {");
/*  116 */     paramPrintStream.println("\t\tsuper(_xp_, _vn_);");
/*      */ 
/*  118 */     if (isAny()) {
/*  119 */       paramPrintStream.println("\t\tthrow new UnsupportedOperationException();");
/*  120 */       paramPrintStream.println("\t}");
/*  121 */       paramPrintStream.println("");
/*  122 */       return;
/*      */     }
/*      */ 
/*  125 */     paramPrintStream.println("\t\tif (_o1_ instanceof " + str + ") assign((" + str + ")_o1_);");
/*  126 */     paramPrintStream.println("\t\telse if (_o1_ instanceof " + str + ".Data) assign((" + str + ".Data)_o1_);");
/*  127 */     paramPrintStream.println("\t\telse if (_o1_ instanceof " + str + ".Const) assign(((" + str + ".Const)_o1_).nThis());");
/*  128 */     paramPrintStream.println("\t\telse throw new UnsupportedOperationException();");
/*  129 */     paramPrintStream.println("\t}");
/*  130 */     paramPrintStream.println("");
/*      */ 
/*  132 */     paramPrintStream.println("\tprivate void assign(" + str + " _o_) {");
/*  133 */     Main._xdb_verify_(paramPrintStream, "\t\t_o_.");
/*      */     Variable localVariable;
/*  134 */     for (Iterator localIterator = this.variables.iterator(); localIterator.hasNext(); localVariable.deepCopy(this, paramPrintStream, "\t\t")) localVariable = (Variable)localIterator.next();
/*  135 */     paramPrintStream.println("\t}");
/*  136 */     paramPrintStream.println("");
/*      */ 
/*  138 */     paramPrintStream.println("\tprivate void assign(" + str + ".Data _o_) {");
/*  139 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); localVariable.deepCopy(this, paramPrintStream, "\t\t")) localVariable = (Variable)localIterator.next();
/*  140 */     paramPrintStream.println("\t}");
/*  141 */     paramPrintStream.println("");
/*      */   }
/*      */ 
/*      */   private void generateImplement() {
/*  145 */     String str = getName();
/*  146 */     PrintStream localPrintStream = Main.openBean__File(str);
/*      */ 
/*  148 */     localPrintStream.println("");
/*  149 */     localPrintStream.println("package xbean.__;");
/*  150 */     localPrintStream.println("");
/*  151 */     localPrintStream.println("import com.goldhuman.Common.Marshal.OctetsStream;");
/*  152 */     localPrintStream.println("import com.goldhuman.Common.Marshal.MarshalException;");
/*  153 */     localPrintStream.println("");
/*  154 */     localPrintStream.println("public final class " + str + " extends xdb.XBean implements xbean." + str + " {");
/*      */ 
/*  157 */     for (Iterator localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).declare(localPrintStream, "\t")) localObject = (Variable)localIterator.next();
/*  158 */     localPrintStream.println("");
/*      */ 
/*  162 */     localPrintStream.println("\t" + str + "(int __, xdb.XBean _xp_, String _vn_) {");
/*  163 */     localPrintStream.println("\t\tsuper(_xp_, _vn_);");
/*  164 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).construct(this, localPrintStream, "\t\t")) localObject = (Variable)localIterator.next();
/*  165 */     localPrintStream.println("\t}");
/*  166 */     localPrintStream.println("");
/*  167 */     localPrintStream.println("\tpublic " + str + "() {");
/*  168 */     localPrintStream.println("\t\tthis(0, null, null);");
/*  169 */     localPrintStream.println("\t}");
/*  170 */     localPrintStream.println("");
/*      */ 
/*  172 */     generateImplementCopyConstruct(localPrintStream);
/*      */ 
/*  175 */     localPrintStream.println("\t@Override");
/*  176 */     localPrintStream.println("\tpublic final OctetsStream marshal(OctetsStream _os_) {");
/*  177 */     if (isAny()) {
/*  178 */       localPrintStream.println("\t\tthrow new UnsupportedOperationException();");
/*      */     } else {
/*  180 */       Main._xdb_verify_(localPrintStream, "\t\t");
/*  181 */       for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).marshal(this, localPrintStream, "\t\t")) localObject = (Variable)localIterator.next();
/*  182 */       localPrintStream.println("\t\treturn _os_;");
/*      */     }
/*  184 */     localPrintStream.println("\t}");
/*  185 */     localPrintStream.println("");
/*      */ 
/*  188 */     localPrintStream.println("\t@Override");
/*  189 */     localPrintStream.println("\tpublic final OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {");
/*  190 */     if (isAny()) {
/*  191 */       localPrintStream.println("\t\tthrow new UnsupportedOperationException();");
/*      */     } else {
/*  193 */       Main._xdb_verify_(localPrintStream, "\t\t");
/*  194 */       for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).unmarshal(this, localPrintStream, "\t\t")) localObject = (Variable)localIterator.next();
/*  195 */       localPrintStream.println("\t\treturn _os_;");
/*      */     }
/*  197 */     localPrintStream.println("\t}");
/*  198 */     localPrintStream.println("");
/*      */ 
/*  201 */     localPrintStream.println("\t@Override");
/*  202 */     localPrintStream.println("\tpublic xbean." + str + " copy() {");
/*  203 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  204 */     localPrintStream.println("\t\treturn new " + str + "(this);");
/*  205 */     localPrintStream.println("\t}");
/*  206 */     localPrintStream.println("");
/*  207 */     localPrintStream.println("\t@Override");
/*  208 */     localPrintStream.println("\tpublic xbean." + str + " toData() {");
/*  209 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  210 */     localPrintStream.println("\t\treturn new Data(this);");
/*  211 */     localPrintStream.println("\t}");
/*  212 */     localPrintStream.println("");
/*  213 */     localPrintStream.println("\tpublic xbean." + str + " toBean() {");
/*  214 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  215 */     localPrintStream.println("\t\treturn new " + str + "(this); // same as copy()");
/*  216 */     localPrintStream.println("\t}");
/*  217 */     localPrintStream.println("");
/*  218 */     localPrintStream.println("\t@Override");
/*  219 */     localPrintStream.println("\tpublic xbean." + str + " toDataIf() {");
/*  220 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  221 */     localPrintStream.println("\t\treturn new Data(this);");
/*  222 */     localPrintStream.println("\t}");
/*  223 */     localPrintStream.println("");
/*  224 */     localPrintStream.println("\tpublic xbean." + str + " toBeanIf() {");
/*  225 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  226 */     localPrintStream.println("\t\treturn this;");
/*  227 */     localPrintStream.println("\t}");
/*  228 */     localPrintStream.println("");
/*      */ 
/*  231 */     localPrintStream.println("\t@Override");
/*  232 */     localPrintStream.println("\tpublic xdb.Bean toConst() {");
/*  233 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  234 */     localPrintStream.println("\t\treturn new Const();");
/*  235 */     localPrintStream.println("\t}");
/*  236 */     localPrintStream.println("");
/*      */ 
/*  239 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).getter(this, localPrintStream, "\t")) localObject = (Variable)localIterator.next();
/*  240 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).setter(this, localPrintStream, "\t")) localObject = (Variable)localIterator.next();
/*      */ 
/*  243 */     localPrintStream.println("\t@Override");
/*  244 */     localPrintStream.println("\tpublic final boolean equals(Object _o1_) {");
/*  245 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  246 */     localPrintStream.println("\t\t" + str + " _o_ = null;");
/*  247 */     localPrintStream.println("\t\tif ( _o1_ instanceof " + str + " ) _o_ = (" + str + ")_o1_;");
/*  248 */     localPrintStream.println("\t\telse if ( _o1_ instanceof " + str + ".Const ) _o_ = ((" + str + ".Const)_o1_).nThis();");
/*  249 */     localPrintStream.println("\t\telse return false;");
/*      */ 
/*  251 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).equals(localPrintStream, "\t\t")) localObject = (Variable)localIterator.next();
/*  252 */     localPrintStream.println("\t\treturn true;");
/*  253 */     localPrintStream.println("\t}");
/*  254 */     localPrintStream.println("");
/*      */ 
/*  257 */     localPrintStream.println("\t@Override");
/*  258 */     localPrintStream.println("\tpublic final int hashCode() {");
/*  259 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  260 */     localPrintStream.println("\t\tint _h_ = 0;");
/*  261 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).hashCode(localPrintStream, "\t\t")) localObject = (Variable)localIterator.next();
/*  262 */     localPrintStream.println("\t\treturn _h_;");
/*  263 */     localPrintStream.println("\t}");
/*  264 */     localPrintStream.println("");
/*      */ 
/*  267 */     localPrintStream.println("\t@Override");
/*  268 */     localPrintStream.println("\tpublic String toString() {");
/*  269 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  270 */     localPrintStream.println("\t\tStringBuilder _sb_ = new StringBuilder();");
/*  271 */     localPrintStream.println("\t\t_sb_.append(\"(\");");
/*  272 */     int i = 1;
/*  273 */     for (Object localObject = this.variables.iterator(); ((Iterator)localObject).hasNext(); ) { localVariable = (Variable)((Iterator)localObject).next();
/*  274 */       if (0 == i) localPrintStream.println("\t\t_sb_.append(\",\");");
/*  275 */       localVariable.toString(localPrintStream, "\t\t");
/*  276 */       i = 0;
/*      */     }
/*  287 */     Variable localVariable;
/*  278 */     localPrintStream.println("\t\t_sb_.append(\")\");");
/*  279 */     localPrintStream.println("\t\treturn _sb_.toString();");
/*  280 */     localPrintStream.println("\t}");
/*  281 */     localPrintStream.println("");
/*      */ 
/*  284 */     localPrintStream.println("\t@Override");
/*  285 */     localPrintStream.println("\tpublic xdb.logs.Listenable newListenable() {");
/*  286 */     localPrintStream.println("\t\txdb.logs.ListenableBean lb = new xdb.logs.ListenableBean();");
/*  287 */     for (localObject = this.variables.iterator(); ((Iterator)localObject).hasNext(); ) { localVariable = (Variable)((Iterator)localObject).next();
/*  288 */       localPrintStream.println("\t\tlb.add(" + localVariable.newListenable(this) + ");");
/*      */     }
/*  290 */     localPrintStream.println("\t\treturn lb;");
/*  291 */     localPrintStream.println("\t}");
/*  292 */     localPrintStream.println("");
/*      */ 
/*  296 */     generateNestConstImeplement(localPrintStream, "\t");
/*  297 */     localPrintStream.println("");
/*  298 */     this.isData = true;
/*  299 */     generateNestDataImeplement(localPrintStream, "\t");
/*  300 */     this.isData = false;
/*  301 */     localPrintStream.println("}");
/*      */ 
/*  303 */     localPrintStream.close();
/*      */   }
/*      */ 
/*      */   private void generateNestDataImplementCopyConstruct(PrintStream paramPrintStream) {
/*  307 */     String str = getName();
/*  308 */     paramPrintStream.println("\t\tData(xbean." + str + " _o1_) {");
/*  309 */     if (isAny()) {
/*  310 */       paramPrintStream.println("\t\t\tthrow new UnsupportedOperationException();");
/*  311 */       paramPrintStream.println("\t\t}");
/*  312 */       paramPrintStream.println("");
/*  313 */       return;
/*      */     }
/*      */ 
/*  316 */     paramPrintStream.println("\t\t\tif (_o1_ instanceof " + str + ") assign((" + str + ")_o1_);");
/*  317 */     paramPrintStream.println("\t\t\telse if (_o1_ instanceof " + str + ".Data) assign((" + str + ".Data)_o1_);");
/*  318 */     paramPrintStream.println("\t\t\telse if (_o1_ instanceof " + str + ".Const) assign(((" + str + ".Const)_o1_).nThis());");
/*  319 */     paramPrintStream.println("\t\t\telse throw new UnsupportedOperationException();");
/*  320 */     paramPrintStream.println("\t\t}");
/*  321 */     paramPrintStream.println("");
/*      */ 
/*  323 */     paramPrintStream.println("\t\tprivate void assign(" + str + " _o_) {");
/*      */     Variable localVariable;
/*  324 */     for (Iterator localIterator = this.variables.iterator(); localIterator.hasNext(); localVariable.deepCopy(this, paramPrintStream, "\t\t\t")) localVariable = (Variable)localIterator.next();
/*  325 */     paramPrintStream.println("\t\t}");
/*  326 */     paramPrintStream.println("");
/*      */ 
/*  328 */     paramPrintStream.println("\t\tprivate void assign(" + str + ".Data _o_) {");
/*  329 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); localVariable.deepCopy(this, paramPrintStream, "\t\t\t")) localVariable = (Variable)localIterator.next();
/*  330 */     paramPrintStream.println("\t\t}");
/*  331 */     paramPrintStream.println("");
/*      */   }
/*      */ 
/*      */   private void generateNestDataImeplement(PrintStream paramPrintStream, String paramString) {
/*  335 */     String str = getName();
/*      */ 
/*  337 */     paramPrintStream.println(paramString + "public static final class Data implements xbean." + str + " {");
/*      */ 
/*  339 */     for (Iterator localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).declare(paramPrintStream, paramString + "\t")) localObject = (Variable)localIterator.next();
/*  340 */     paramPrintStream.println("");
/*      */ 
/*  342 */     paramPrintStream.println(paramString + "\tpublic Data() {");
/*  343 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).construct(this, paramPrintStream, paramString + "\t\t")) localObject = (Variable)localIterator.next();
/*  344 */     paramPrintStream.println(paramString + "\t}");
/*  345 */     paramPrintStream.println("");
/*  346 */     generateNestDataImplementCopyConstruct(paramPrintStream);
/*      */ 
/*  349 */     paramPrintStream.println(paramString + "\t@Override");
/*  350 */     paramPrintStream.println(paramString + "\tpublic final OctetsStream marshal(OctetsStream _os_) {");
/*  351 */     if (isAny()) {
/*  352 */       paramPrintStream.println(paramString + "\t\tthrow new UnsupportedOperationException();");
/*      */     } else {
/*  354 */       for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).marshal(this, paramPrintStream, paramString + "\t\t")) localObject = (Variable)localIterator.next();
/*  355 */       paramPrintStream.println(paramString + "\t\treturn _os_;");
/*      */     }
/*  357 */     paramPrintStream.println(paramString + "\t}");
/*  358 */     paramPrintStream.println("");
/*      */ 
/*  361 */     paramPrintStream.println(paramString + "\t@Override");
/*  362 */     paramPrintStream.println(paramString + "\tpublic final OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {");
/*  363 */     if (isAny()) {
/*  364 */       paramPrintStream.println(paramString + "\t\tthrow new UnsupportedOperationException();");
/*      */     } else {
/*  366 */       for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).unmarshal(this, paramPrintStream, paramString + "\t\t")) localObject = (Variable)localIterator.next();
/*  367 */       paramPrintStream.println(paramString + "\t\treturn _os_;");
/*      */     }
/*  369 */     paramPrintStream.println(paramString + "\t}");
/*  370 */     paramPrintStream.println("");
/*      */ 
/*  373 */     paramPrintStream.println(paramString + "\t@Override");
/*  374 */     paramPrintStream.println(paramString + "\tpublic xbean." + str + " copy() {");
/*  375 */     paramPrintStream.println(paramString + "\t\treturn new Data(this);");
/*  376 */     paramPrintStream.println(paramString + "\t}");
/*  377 */     paramPrintStream.println("");
/*  378 */     paramPrintStream.println(paramString + "\t@Override");
/*  379 */     paramPrintStream.println(paramString + "\tpublic xbean." + str + " toData() {");
/*  380 */     paramPrintStream.println(paramString + "\t\treturn new Data(this);");
/*  381 */     paramPrintStream.println(paramString + "\t}");
/*  382 */     paramPrintStream.println("");
/*  383 */     paramPrintStream.println(paramString + "\tpublic xbean." + str + " toBean() {");
/*  384 */     paramPrintStream.println(paramString + "\t\treturn new " + str + "(this, null, null);");
/*  385 */     paramPrintStream.println(paramString + "\t}");
/*  386 */     paramPrintStream.println("");
/*  387 */     paramPrintStream.println(paramString + "\t@Override");
/*  388 */     paramPrintStream.println(paramString + "\tpublic xbean." + str + " toDataIf() {");
/*  389 */     paramPrintStream.println(paramString + "\t\treturn this;");
/*  390 */     paramPrintStream.println(paramString + "\t}");
/*  391 */     paramPrintStream.println("");
/*  392 */     paramPrintStream.println(paramString + "\tpublic xbean." + str + " toBeanIf() {");
/*  393 */     paramPrintStream.println(paramString + "\t\treturn new " + str + "(this, null, null);");
/*  394 */     paramPrintStream.println(paramString + "\t}");
/*  395 */     paramPrintStream.println("");
/*      */ 
/*  397 */     paramPrintStream.println(paramString + "\t// xdb.Bean interface. Data Unsupported");
/*  398 */     paramPrintStream.println(paramString + "\tpublic boolean xdbManaged() { throw new UnsupportedOperationException(); }");
/*  399 */     paramPrintStream.println(paramString + "\tpublic xdb.Bean xdbParent() { throw new UnsupportedOperationException(); }");
/*  400 */     paramPrintStream.println(paramString + "\tpublic String xdbVarname()  { throw new UnsupportedOperationException(); }");
/*  401 */     paramPrintStream.println(paramString + "\tpublic Long    xdbObjId()   { throw new UnsupportedOperationException(); }");
/*  402 */     paramPrintStream.println(paramString + "\tpublic xdb.Bean toConst()   { throw new UnsupportedOperationException(); }");
/*  403 */     paramPrintStream.println(paramString + "\tpublic boolean isConst()    { return false; }");
/*  404 */     paramPrintStream.println(paramString + "\tpublic boolean isData()     { return true; }");
/*  405 */     paramPrintStream.println("");
/*      */ 
/*  408 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).getterData(this, paramPrintStream, paramString + "\t")) localObject = (Variable)localIterator.next();
/*  409 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).setterData(this, paramPrintStream, paramString + "\t")) localObject = (Variable)localIterator.next();
/*      */ 
/*  412 */     paramPrintStream.println(paramString + "\t@Override");
/*  413 */     paramPrintStream.println(paramString + "\tpublic final boolean equals(Object _o1_) {");
/*  414 */     paramPrintStream.println(paramString + "\t\tif (!(_o1_ instanceof " + str + ".Data)) return false;");
/*  415 */     paramPrintStream.println(paramString + "\t\t" + str + ".Data _o_ = (" + str + ".Data) _o1_;");
/*  416 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).equals(paramPrintStream, "\t\t\t")) localObject = (Variable)localIterator.next();
/*  417 */     paramPrintStream.println(paramString + "\t\treturn true;");
/*  418 */     paramPrintStream.println(paramString + "\t}");
/*  419 */     paramPrintStream.println("");
/*      */ 
/*  422 */     paramPrintStream.println(paramString + "\t@Override");
/*  423 */     paramPrintStream.println(paramString + "\tpublic final int hashCode() {");
/*  424 */     paramPrintStream.println(paramString + "\t\tint _h_ = 0;");
/*  425 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).hashCode(paramPrintStream, paramString + "\t\t")) localObject = (Variable)localIterator.next();
/*  426 */     paramPrintStream.println(paramString + "\t\treturn _h_;");
/*  427 */     paramPrintStream.println(paramString + "\t}");
/*  428 */     paramPrintStream.println("");
/*      */ 
/*  431 */     paramPrintStream.println(paramString + "\t@Override");
/*  432 */     paramPrintStream.println(paramString + "\tpublic String toString() {");
/*  433 */     paramPrintStream.println(paramString + "\t\tStringBuilder _sb_ = new StringBuilder();");
/*  434 */     paramPrintStream.println(paramString + "\t\t_sb_.append(\"(\");");
/*  435 */     int i = 1;
/*  436 */     for (Object localObject = this.variables.iterator(); ((Iterator)localObject).hasNext(); ) { Variable localVariable = (Variable)((Iterator)localObject).next();
/*  437 */       if (0 == i) paramPrintStream.println(paramString + "\t\t_sb_.append(\",\");");
/*  438 */       localVariable.toString(paramPrintStream, paramString + "\t\t");
/*  439 */       i = 0;
/*      */     }
/*  441 */     paramPrintStream.println(paramString + "\t\t_sb_.append(\")\");");
/*  442 */     paramPrintStream.println(paramString + "\t\treturn _sb_.toString();");
/*  443 */     paramPrintStream.println(paramString + "\t}");
/*  444 */     paramPrintStream.println("");
/*  445 */     paramPrintStream.println(paramString + "}");
/*      */   }
/*      */ 
/*      */   private void generateNestConstImeplement(PrintStream paramPrintStream, String paramString) {
/*  449 */     String str1 = getName();
/*  450 */     String str2 = str1 + ".this";
/*      */ 
/*  452 */     paramPrintStream.println(paramString + "private class Const implements xbean." + str1 + " {");
/*      */ 
/*  454 */     paramPrintStream.println(paramString + "\t" + str1 + " nThis() {");
/*  455 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ";");
/*  456 */     paramPrintStream.println(paramString + "\t}");
/*  457 */     paramPrintStream.println("");
/*  458 */     paramPrintStream.println(paramString + "\t@Override");
/*  459 */     paramPrintStream.println(paramString + "\tpublic xbean." + str1 + " copy() {");
/*  460 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".copy();");
/*  461 */     paramPrintStream.println(paramString + "\t}");
/*  462 */     paramPrintStream.println("");
/*  463 */     paramPrintStream.println(paramString + "\t@Override");
/*  464 */     paramPrintStream.println(paramString + "\tpublic xbean." + str1 + " toData() {");
/*  465 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".toData();");
/*  466 */     paramPrintStream.println(paramString + "\t}");
/*  467 */     paramPrintStream.println("");
/*  468 */     paramPrintStream.println(paramString + "\tpublic xbean." + str1 + " toBean() {");
/*  469 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".toBean();");
/*  470 */     paramPrintStream.println(paramString + "\t}");
/*  471 */     paramPrintStream.println("");
/*  472 */     paramPrintStream.println(paramString + "\t@Override");
/*  473 */     paramPrintStream.println(paramString + "\tpublic xbean." + str1 + " toDataIf() {");
/*  474 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".toDataIf();");
/*  475 */     paramPrintStream.println(paramString + "\t}");
/*  476 */     paramPrintStream.println("");
/*  477 */     paramPrintStream.println(paramString + "\tpublic xbean." + str1 + " toBeanIf() {");
/*  478 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".toBeanIf();");
/*  479 */     paramPrintStream.println(paramString + "\t}");
/*  480 */     paramPrintStream.println("");
/*      */     Variable localVariable;
/*  483 */     for (Iterator localIterator = this.variables.iterator(); localIterator.hasNext(); localVariable.getterConst(this, paramPrintStream, paramString + "\t")) localVariable = (Variable)localIterator.next();
/*  484 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); localVariable.setterConst(this, paramPrintStream, paramString + "\t")) localVariable = (Variable)localIterator.next();
/*      */ 
/*  486 */     paramPrintStream.println(paramString + "\t@Override");
/*  487 */     paramPrintStream.println(paramString + "\tpublic xdb.Bean toConst() {");
/*  488 */     Main._xdb_verify_(paramPrintStream, paramString + "\t\t");
/*  489 */     paramPrintStream.println(paramString + "\t\treturn this;");
/*  490 */     paramPrintStream.println(paramString + "\t}");
/*  491 */     paramPrintStream.println("");
/*      */ 
/*  493 */     paramPrintStream.println(paramString + "\t@Override");
/*  494 */     paramPrintStream.println(paramString + "\tpublic boolean isConst() {");
/*  495 */     Main._xdb_verify_(paramPrintStream, paramString + "\t\t");
/*  496 */     paramPrintStream.println(paramString + "\t\treturn true;");
/*  497 */     paramPrintStream.println(paramString + "\t}");
/*  498 */     paramPrintStream.println("");
/*  499 */     paramPrintStream.println(paramString + "\t@Override");
/*  500 */     paramPrintStream.println(paramString + "\tpublic boolean isData() {");
/*  501 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".isData();");
/*  502 */     paramPrintStream.println(paramString + "\t}");
/*  503 */     paramPrintStream.println("");
/*  504 */     paramPrintStream.println(paramString + "\t@Override");
/*  505 */     paramPrintStream.println(paramString + "\tpublic OctetsStream marshal(OctetsStream _os_) {");
/*  506 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".marshal(_os_);");
/*  507 */     paramPrintStream.println(paramString + "\t}");
/*  508 */     paramPrintStream.println("");
/*  509 */     paramPrintStream.println(paramString + "\t@Override");
/*  510 */     paramPrintStream.println(paramString + "\tpublic OctetsStream unmarshal(OctetsStream arg0) throws MarshalException {");
/*  511 */     Main._xdb_verify_(paramPrintStream, paramString + "\t\t");
/*  512 */     paramPrintStream.println(paramString + "\t\tthrow new UnsupportedOperationException();");
/*  513 */     paramPrintStream.println(paramString + "\t}");
/*  514 */     paramPrintStream.println("");
/*  515 */     paramPrintStream.println(paramString + "\t@Override");
/*  516 */     paramPrintStream.println(paramString + "\tpublic xdb.Bean xdbParent() {");
/*  517 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".xdbParent();");
/*  518 */     paramPrintStream.println(paramString + "\t}");
/*  519 */     paramPrintStream.println("");
/*  520 */     paramPrintStream.println(paramString + "\t@Override");
/*  521 */     paramPrintStream.println(paramString + "\tpublic boolean xdbManaged() {");
/*  522 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".xdbManaged();");
/*  523 */     paramPrintStream.println(paramString + "\t}");
/*  524 */     paramPrintStream.println("");
/*  525 */     paramPrintStream.println(paramString + "\t@Override");
/*  526 */     paramPrintStream.println(paramString + "\tpublic String xdbVarname() {");
/*  527 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".xdbVarname();");
/*  528 */     paramPrintStream.println(paramString + "\t}");
/*  529 */     paramPrintStream.println("");
/*  530 */     paramPrintStream.println(paramString + "\t@Override");
/*  531 */     paramPrintStream.println(paramString + "\tpublic Long xdbObjId() {");
/*  532 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".xdbObjId();");
/*  533 */     paramPrintStream.println(paramString + "\t}");
/*  534 */     paramPrintStream.println("");
/*  535 */     paramPrintStream.println(paramString + "\t@Override");
/*  536 */     paramPrintStream.println(paramString + "\tpublic boolean equals(Object obj) {");
/*  537 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".equals(obj);");
/*  538 */     paramPrintStream.println(paramString + "\t}");
/*  539 */     paramPrintStream.println("");
/*  540 */     paramPrintStream.println(paramString + "\t@Override");
/*  541 */     paramPrintStream.println(paramString + "\tpublic int hashCode() {");
/*  542 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".hashCode();");
/*  543 */     paramPrintStream.println(paramString + "\t}");
/*  544 */     paramPrintStream.println("");
/*  545 */     paramPrintStream.println(paramString + "\t@Override");
/*  546 */     paramPrintStream.println(paramString + "\tpublic String toString() {");
/*  547 */     paramPrintStream.println(paramString + "\t\treturn " + str2 + ".toString();");
/*  548 */     paramPrintStream.println(paramString + "\t}");
/*  549 */     paramPrintStream.println("");
/*  550 */     paramPrintStream.println(paramString + "}");
/*      */   }
/*      */ 
/*      */   private void generateInterface() {
/*  554 */     String str = getName();
/*  555 */     PrintStream localPrintStream = Main.openBeanFile(str);
/*      */ 
/*  557 */     localPrintStream.println("");
/*  558 */     localPrintStream.println("package xbean;");
/*  559 */     localPrintStream.println("");
/*  560 */     localPrintStream.println("public interface " + str + " extends xdb.Bean {");
/*      */ 
/*  562 */     localPrintStream.println("\tpublic " + str + " copy(); // deep clone");
/*  563 */     localPrintStream.println("\tpublic " + str + " toData(); // a Data instance");
/*  564 */     localPrintStream.println("\tpublic " + str + " toBean(); // a Bean instance");
/*  565 */     localPrintStream.println("\tpublic " + str + " toDataIf(); // a Data instance If need. else return this");
/*  566 */     localPrintStream.println("\tpublic " + str + " toBeanIf(); // a Bean instance If need. else return this");
/*  567 */     localPrintStream.println("");
/*      */ 
/*  570 */     for (Iterator localIterator = this.enums.iterator(); localIterator.hasNext(); ) { localObject = (Enum)localIterator.next();
/*  571 */       ((Enum)localObject).print(localPrintStream, "\t");
/*      */     }
/*      */     Object localObject;
/*  572 */     if (!this.enums.isEmpty()) {
/*  573 */       localPrintStream.println("");
/*      */     }
/*      */ 
/*  576 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).getterInterface(this, localPrintStream, "\t")) localObject = (Variable)localIterator.next();
/*  577 */     localPrintStream.println("");
/*      */ 
/*  580 */     for (localIterator = this.variables.iterator(); localIterator.hasNext(); ((Variable)localObject).setterInterface(this, localPrintStream, "\t")) localObject = (Variable)localIterator.next();
/*      */ 
/*  582 */     localPrintStream.println("}");
/*      */ 
/*  584 */     localPrintStream.close();
/*      */   }
/*      */ 
/*      */   void make() {
/*  588 */     Type.setCurrentBean(this);
/*  589 */     generateInterface();
/*  590 */     generateImplement();
/*  591 */     Type.setCurrentBean(null);
/*      */   }
/*      */ 
/*      */   static void make(Collection<XBean> paramCollection)
/*      */   {
/*  596 */     String str = "Pod";
/*  597 */     PrintStream localPrintStream = Main.openBeanFile(str);
/*  598 */     localPrintStream.println("");
/*  599 */     localPrintStream.println("package xbean;");
/*  600 */     localPrintStream.println("");
/*  601 */     localPrintStream.println("/**");
/*  602 */     localPrintStream.println(" * bean factory");
/*  603 */     localPrintStream.println(" */");
/*  604 */     localPrintStream.println("public final class " + str + " {");
/*      */ 
/*  606 */     for (XBean localXBean : paramCollection) {
/*  607 */       localPrintStream.println("\tpublic static " + localXBean.getName() + " new" + localXBean.getName() + "() {");
/*  608 */       localPrintStream.println("\t\treturn new xbean.__." + localXBean.getName() + "();");
/*  609 */       localPrintStream.println("\t}");
/*  610 */       localPrintStream.println("");
/*  611 */       localPrintStream.println("\tpublic static " + localXBean.getName() + " new" + localXBean.getName() + "Data() {");
/*  612 */       localPrintStream.println("\t\treturn new xbean.__." + localXBean.getName() + ".Data();");
/*  613 */       localPrintStream.println("\t}");
/*  614 */       localPrintStream.println("");
/*      */     }
/*      */ 
/*  617 */     localPrintStream.println("}");
/*  618 */     localPrintStream.close();
/*      */   }
/*      */ 
/*      */   public String getName()
/*      */   {
/*  623 */     return this.name;
/*      */   }
/*      */ 
/*      */   public String getTypeName()
/*      */   {
/*  628 */     return "xbean." + getName();
/*      */   }
/*      */ 
/*      */   public String getBoxingName()
/*      */   {
/*  633 */     return getTypeName();
/*      */   }
/*      */ 
/*      */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*      */   {
/*  638 */     String str = paramVariable.getname();
/*  639 */     if (paramXBean.isData())
/*  640 */       paramPrintStream.println(paramString + str + " = new " + getName() + ".Data();");
/*      */     else
/*  642 */       paramPrintStream.println(paramString + str + " = new " + getName() + "(0, this, " + Main.quote(str) + ");");
/*      */   }
/*      */ 
/*      */   public String deepCopy(boolean paramBoolean, Variable paramVariable, String paramString)
/*      */   {
/*  648 */     if (paramBoolean)
/*  649 */       return "new " + getName() + ".Data(" + paramString + ")";
/*  650 */     return "new " + getName() + "(" + paramString + ", this, " + Main.quote(paramVariable.getname()) + ")";
/*      */   }
/*      */ 
/*      */   public void deepCopy(boolean paramBoolean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*      */   {
/*  655 */     if (paramBoolean) {
/*  656 */       paramPrintStream.println(paramString + paramVariable.getname() + " = new " + getName() + ".Data(_o_." + paramVariable.getname() + ");");
/*      */     }
/*      */     else
/*  659 */       paramPrintStream.println(paramString + paramVariable.getname() + " = new " + getName() + "(_o_." + paramVariable.getname() + ", this, " + Main.quote(paramVariable.getname()) + ");");
/*      */   }
/*      */ 
/*      */   public boolean isConstant()
/*      */   {
/*  665 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isCloneable()
/*      */   {
/*  670 */     return true;
/*      */   }
/*      */ 
/*      */   public void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*      */   {
/*  675 */     paramPrintStream.println(paramString1 + paramString2 + ".marshal(_os_);");
/*      */   }
/*      */ 
/*      */   public void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*      */   {
/*  680 */     paramPrintStream.println(paramString1 + paramString2 + ".unmarshal(_os_);");
/*      */   }
/*      */ 
/*      */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*      */   {
/*  685 */     if (paramXBean.isData()) {
/*  686 */       return defineNoParent(paramString);
/*      */     }
/*  688 */     return getTypeName() + " " + paramString + " = new " + getName() + "(0, this, " + Main.quote(paramVariable.getname()) + ");";
/*      */   }
/*      */ 
/*      */   public String defineNoParent(String paramString)
/*      */   {
/*  694 */     if ((Type.getCurrentBean() != null) && (Type.getCurrentBean().isData()))
/*  695 */       return getTypeName() + " " + paramString + " = xbean.Pod.new" + getName() + "Data();";
/*  696 */     return getTypeName() + " " + paramString + " = xbean.Pod.new" + getName() + "();";
/*      */   }
/*      */ 
/*      */   public String hashCode(String paramString)
/*      */   {
/*  701 */     return paramString + ".hashCode()";
/*      */   }
/*      */ 
/*      */   public String notEquals(String paramString)
/*      */   {
/*  706 */     return "!" + paramString + ".equals(_o_." + paramString + ")";
/*      */   }
/*      */ 
/*      */   public void getterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*      */   {
/*  711 */     paramPrintStream.println(paramString + "public xbean." + this.name + " get" + paramVariable.getName() + "(); // " + paramVariable.getComment());
/*      */   }
/*      */ 
/*      */   public void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*      */   {
/*  716 */     paramPrintStream.println(paramString + "@Override");
/*  717 */     paramPrintStream.println(paramString + "public xbean." + this.name + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/*  718 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/*  719 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/*  720 */     paramPrintStream.println(paramString + "}");
/*  721 */     paramPrintStream.println();
/*      */   }
/*      */ 
/*      */   public void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*      */   {
/*  726 */     paramPrintStream.println(paramString + "@Override");
/*  727 */     paramPrintStream.println(paramString + "public xbean." + this.name + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/*  728 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/*  729 */     paramPrintStream.println(paramString + "\treturn xdb.Consts.toConst(" + paramVariable.getname() + ");");
/*  730 */     paramPrintStream.println(paramString + "}");
/*  731 */     paramPrintStream.println();
/*      */   }
/*      */ 
/*      */   public void getterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*      */   {
/*  736 */     paramPrintStream.println(paramString + "@Override");
/*  737 */     paramPrintStream.println(paramString + "public xbean." + this.name + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/*  738 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/*  739 */     paramPrintStream.println(paramString + "}");
/*  740 */     paramPrintStream.println();
/*      */   }
/*      */ 
/*      */   public void setter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void setterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void setterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void setterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*      */   {
/*      */   }
/*      */ 
/*      */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*      */   {
/*  765 */     return "new xdb.logs.ListenableChanged().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*      */   }
/*      */ 
/*      */   public void printTableSelectMethod(PrintStream paramPrintStream, String paramString)
/*      */   {
/*  771 */     String str = getBoxingName();
/*  772 */     if (false == isAny())
/*      */     {
/*  774 */       paramPrintStream.println("\tpublic static " + str + " select(" + paramString + " key) {");
/*  775 */       paramPrintStream.println("\t\treturn getTable().select(key, new xdb.TField<" + str + ", " + str + ">() {");
/*  776 */       paramPrintStream.println("\t\t\tpublic " + str + " get(" + str + " v) { return v.toData(); }");
/*  777 */       paramPrintStream.println("\t\t});");
/*  778 */       paramPrintStream.println("\t}");
/*  779 */       paramPrintStream.println("");
/*      */     }
/*      */ 
/*  782 */     for (Variable localVariable : this.variables)
/*  783 */       localVariable.printSelect(paramPrintStream, paramString, str);
/*      */   }
/*      */ 
/*      */   public void printMeta(PrintStream paramPrintStream, String paramString) {
/*  787 */     paramPrintStream.println(paramString + "Bean bean = new Bean(" + Main.quote(getName()) + ", " + isAny() + ", " + isConstant() + ");");
/*      */ 
/*  789 */     for (Variable localVariable : this.variables) {
/*  790 */       paramPrintStream.println(paramString + "super.addVariableFor(bean");
/*  791 */       localVariable.printMetaData(paramPrintStream, paramString + "\t");
/*  792 */       paramPrintStream.println(paramString + "\t);");
/*      */     }
/*  794 */     paramPrintStream.println(paramString + "super.addBean(bean);");
/*      */   }
/*      */ 
/*      */   public void setHasModify()
/*      */   {
/*  799 */     this.hasModify = true; } 
/*  800 */   public boolean hasModify() { return this.hasModify; }
/*      */ 
/*      */   public Variable getVariable(String paramString)
/*      */   {
/*  804 */     for (Variable localVariable : this.variables)
/*      */     {
/*  806 */       if (localVariable.getname().equals(paramString))
/*  807 */         return localVariable;
/*      */     }
/*  809 */     return null;
/*      */   }
/*      */ 
/*      */   public List<Variable> getVariables()
/*      */   {
/*  814 */     return this.variables;
/*      */   }
/*      */ 
/*      */   public void skipVarMarshal(Variable paramVariable)
/*      */   {
/*      */   }
/*      */ 
/*      */   void transformMake()
/*      */   {
/*  825 */     Type.setCurrentBean(this);
/*  826 */     generateInterface();
/*  827 */     generateTransformImplement();
/*  828 */     Type.setCurrentBean(null);
/*      */   }
/*      */ 
/*      */   private void generateTransformImplement()
/*      */   {
/*  833 */     String str = getName();
/*  834 */     PrintStream localPrintStream = Main.openBean__File(str);
/*      */ 
/*  836 */     localPrintStream.println("");
/*  837 */     localPrintStream.println("package xbean.__;");
/*  838 */     localPrintStream.println("");
/*  839 */     localPrintStream.println("import com.goldhuman.Common.Marshal.OctetsStream;");
/*  840 */     localPrintStream.println("import com.goldhuman.Common.Marshal.MarshalException;");
/*  841 */     localPrintStream.println("");
/*  842 */     localPrintStream.println("public final class " + str + " extends xdb.XBean implements xbean." + str + " {");
/*      */ 
/*  845 */     for (Object localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Variable)((Iterator)localObject1).next();
/*      */ 
/*  847 */       ((Variable)localObject2).declare(localPrintStream, "\t");
/*      */     }
/*  849 */     localPrintStream.println("");
/*      */ 
/*  853 */     localPrintStream.println("\t" + str + "(int __, xdb.XBean _xp_, String _vn_) {");
/*  854 */     localPrintStream.println("\t\tsuper(_xp_, _vn_);");
/*  855 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Variable)((Iterator)localObject1).next();
/*      */ 
/*  857 */       ((Variable)localObject2).construct(this, localPrintStream, "\t\t");
/*      */     }
/*      */ 
/*  860 */     localPrintStream.println("\t}");
/*  861 */     localPrintStream.println("");
/*  862 */     localPrintStream.println("\tpublic " + str + "() {");
/*  863 */     localPrintStream.println("\t\tthis(0, null, null);");
/*  864 */     localPrintStream.println("\t}");
/*  865 */     localPrintStream.println("");
/*      */ 
/*  867 */     generateImplementCopyConstruct(localPrintStream);
/*      */ 
/*  870 */     localPrintStream.println("\t@Override");
/*  871 */     localPrintStream.println("\tpublic final OctetsStream marshal(OctetsStream _os_) {");
/*  872 */     if (isAny()) {
/*  873 */       localPrintStream.println("\t\tthrow new UnsupportedOperationException();");
/*      */     } else {
/*  875 */       Main._xdb_verify_(localPrintStream, "\t\t");
/*  876 */       for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Variable)((Iterator)localObject1).next();
/*      */ 
/*  878 */         if (((Variable)localObject2).getModifyType() == Variable.MODIFY_TYPES.REMOVE)
/*  879 */           skipVarMarshal((Variable)localObject2);
/*      */         else
/*  881 */           ((Variable)localObject2).marshal(this, localPrintStream, "\t\t");
/*      */       }
/*  883 */       localPrintStream.println("\t\treturn _os_;");
/*      */     }
/*  885 */     localPrintStream.println("\t}");
/*  886 */     localPrintStream.println("");
/*      */ 
/*  889 */     localPrintStream.println("\t@Override");
/*  890 */     localPrintStream.println("\tpublic final OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {");
/*      */     Object localObject3;
/*  891 */     if (isAny()) {
/*  892 */       localPrintStream.println("\t\tthrow new UnsupportedOperationException();");
/*      */     } else {
/*  894 */       Main._xdb_verify_(localPrintStream, "\t\t");
/*      */ 
/*  896 */       localObject1 = DatabaseMetaData.getInstance().getBean(getName());
/*      */ 
/*  898 */       if (localObject1 == null)
/*      */       {
/*  900 */         for (localObject2 = this.variables.iterator(); ((Iterator)localObject2).hasNext(); ((Variable)localObject3).unmarshal(this, localPrintStream, "\t\t")) localObject3 = (Variable)((Iterator)localObject2).next();
/*      */       }
/*      */       else
/*      */       {
/*  904 */         for (localObject2 = ((DatabaseMetaData.Bean)localObject1).getVariables().iterator(); ((Iterator)localObject2).hasNext(); ) { localObject3 = (DatabaseMetaData.Bean.Variable)((Iterator)localObject2).next();
/*      */ 
/*  906 */           Variable localVariable = getVariable(((DatabaseMetaData.Bean.Variable)localObject3).getName());
/*  907 */           assert (localVariable != null);
/*  908 */           localVariable.unmarshal(this, localPrintStream, "\t\t");
/*      */         }
/*      */       }
/*  911 */       localPrintStream.println("\t\treturn _os_;");
/*      */     }
/*  913 */     localPrintStream.println("\t}");
/*  914 */     localPrintStream.println("");
/*      */ 
/*  917 */     localPrintStream.println("\t@Override");
/*  918 */     localPrintStream.println("\tpublic xbean." + str + " copy() {");
/*  919 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  920 */     localPrintStream.println("\t\treturn new " + str + "(this);");
/*  921 */     localPrintStream.println("\t}");
/*  922 */     localPrintStream.println("");
/*  923 */     localPrintStream.println("\t@Override");
/*  924 */     localPrintStream.println("\tpublic xbean." + str + " toData() {");
/*  925 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  926 */     localPrintStream.println("\t\treturn new Data(this);");
/*  927 */     localPrintStream.println("\t}");
/*  928 */     localPrintStream.println("");
/*  929 */     localPrintStream.println("\tpublic xbean." + str + " toBean() {");
/*  930 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  931 */     localPrintStream.println("\t\treturn new " + str + "(this); // same as copy()");
/*  932 */     localPrintStream.println("\t}");
/*  933 */     localPrintStream.println("");
/*  934 */     localPrintStream.println("\t@Override");
/*  935 */     localPrintStream.println("\tpublic xbean." + str + " toDataIf() {");
/*  936 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  937 */     localPrintStream.println("\t\treturn new Data(this);");
/*  938 */     localPrintStream.println("\t}");
/*  939 */     localPrintStream.println("");
/*  940 */     localPrintStream.println("\tpublic xbean." + str + " toBeanIf() {");
/*  941 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  942 */     localPrintStream.println("\t\treturn this;");
/*  943 */     localPrintStream.println("\t}");
/*  944 */     localPrintStream.println("");
/*      */ 
/*  947 */     localPrintStream.println("\t@Override");
/*  948 */     localPrintStream.println("\tpublic xdb.Bean toConst() {");
/*  949 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  950 */     localPrintStream.println("\t\treturn new Const();");
/*  951 */     localPrintStream.println("\t}");
/*  952 */     localPrintStream.println("");
/*      */ 
/*  955 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Variable)((Iterator)localObject1).next();
/*      */ 
/*  957 */       ((Variable)localObject2).getter(this, localPrintStream, "\t");
/*      */     }
/*  959 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Variable)((Iterator)localObject1).next();
/*      */ 
/*  961 */       ((Variable)localObject2).setter(this, localPrintStream, "\t");
/*      */     }
/*      */ 
/*  964 */     localPrintStream.println("\t@Override");
/*  965 */     localPrintStream.println("\tpublic final boolean equals(Object _o1_) {");
/*  966 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  967 */     localPrintStream.println("\t\t" + str + " _o_ = null;");
/*  968 */     localPrintStream.println("\t\tif ( _o1_ instanceof " + str + " ) _o_ = (" + str + ")_o1_;");
/*  969 */     localPrintStream.println("\t\telse if ( _o1_ instanceof " + str + ".Const ) _o_ = ((" + str + ".Const)_o1_).nThis();");
/*  970 */     localPrintStream.println("\t\telse return false;");
/*      */ 
/*  972 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ((Variable)localObject2).equals(localPrintStream, "\t\t")) localObject2 = (Variable)((Iterator)localObject1).next();
/*  973 */     localPrintStream.println("\t\treturn true;");
/*  974 */     localPrintStream.println("\t}");
/*  975 */     localPrintStream.println("");
/*      */ 
/*  978 */     localPrintStream.println("\t@Override");
/*  979 */     localPrintStream.println("\tpublic final int hashCode() {");
/*  980 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  981 */     localPrintStream.println("\t\tint _h_ = 0;");
/*  982 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ((Variable)localObject2).hashCode(localPrintStream, "\t\t")) localObject2 = (Variable)((Iterator)localObject1).next();
/*  983 */     localPrintStream.println("\t\treturn _h_;");
/*  984 */     localPrintStream.println("\t}");
/*  985 */     localPrintStream.println("");
/*      */ 
/*  988 */     localPrintStream.println("\t@Override");
/*  989 */     localPrintStream.println("\tpublic String toString() {");
/*  990 */     Main._xdb_verify_(localPrintStream, "\t\t");
/*  991 */     localPrintStream.println("\t\tStringBuilder _sb_ = new StringBuilder();");
/*  992 */     localPrintStream.println("\t\t_sb_.append(\"(\");");
/*  993 */     int i = 1;
/*  994 */     for (Object localObject2 = this.variables.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject3 = (Variable)((Iterator)localObject2).next();
/*  995 */       if (0 == i) localPrintStream.println("\t\t_sb_.append(\",\");");
/*  996 */       ((Variable)localObject3).toString(localPrintStream, "\t\t");
/*  997 */       i = 0;
/*      */     }
/*  999 */     localPrintStream.println("\t\t_sb_.append(\")\");");
/* 1000 */     localPrintStream.println("\t\treturn _sb_.toString();");
/* 1001 */     localPrintStream.println("\t}");
/* 1002 */     localPrintStream.println("");
/*      */ 
/* 1005 */     localPrintStream.println("\t@Override");
/* 1006 */     localPrintStream.println("\tpublic xdb.logs.Listenable newListenable() {");
/* 1007 */     localPrintStream.println("\t\txdb.logs.ListenableBean lb = new xdb.logs.ListenableBean();");
/* 1008 */     for (localObject2 = this.variables.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject3 = (Variable)((Iterator)localObject2).next();
/* 1009 */       localPrintStream.println("\t\tlb.add(" + ((Variable)localObject3).newListenable(this) + ");");
/*      */     }
/* 1011 */     localPrintStream.println("\t\treturn lb;");
/* 1012 */     localPrintStream.println("\t}");
/* 1013 */     localPrintStream.println("");
/*      */ 
/* 1017 */     generateNestConstImeplement(localPrintStream, "\t");
/* 1018 */     localPrintStream.println("");
/* 1019 */     this.isData = true;
/* 1020 */     generateTransformNestDataImeplement(localPrintStream, "\t");
/* 1021 */     this.isData = false;
/* 1022 */     localPrintStream.println("}");
/*      */ 
/* 1024 */     localPrintStream.close();
/*      */   }
/*      */ 
/*      */   private void generateTransformNestDataImeplement(PrintStream paramPrintStream, String paramString) {
/* 1028 */     String str = getName();
/*      */ 
/* 1030 */     paramPrintStream.println(paramString + "public static final class Data implements xbean." + str + " {");
/*      */ 
/* 1032 */     for (Object localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ((Variable)localObject2).declare(paramPrintStream, paramString + "\t")) localObject2 = (Variable)((Iterator)localObject1).next();
/* 1033 */     paramPrintStream.println("");
/*      */ 
/* 1035 */     paramPrintStream.println(paramString + "\tpublic Data() {");
/* 1036 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ((Variable)localObject2).construct(this, paramPrintStream, paramString + "\t\t")) localObject2 = (Variable)((Iterator)localObject1).next();
/* 1037 */     paramPrintStream.println(paramString + "\t}");
/* 1038 */     paramPrintStream.println("");
/* 1039 */     generateNestDataImplementCopyConstruct(paramPrintStream);
/*      */ 
/* 1042 */     paramPrintStream.println(paramString + "\t@Override");
/* 1043 */     paramPrintStream.println(paramString + "\tpublic final OctetsStream marshal(OctetsStream _os_) {");
/* 1044 */     if (isAny()) {
/* 1045 */       paramPrintStream.println(paramString + "\t\tthrow new UnsupportedOperationException();");
/*      */     }
/*      */     else {
/* 1048 */       for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Variable)((Iterator)localObject1).next();
/*      */ 
/* 1050 */         if (((Variable)localObject2).getModifyType() == Variable.MODIFY_TYPES.REMOVE)
/* 1051 */           skipVarMarshal((Variable)localObject2);
/*      */         else
/* 1053 */           ((Variable)localObject2).marshal(this, paramPrintStream, "\t\t");
/*      */       }
/* 1055 */       paramPrintStream.println(paramString + "\t\treturn _os_;");
/*      */     }
/* 1057 */     paramPrintStream.println(paramString + "\t}");
/* 1058 */     paramPrintStream.println("");
/*      */ 
/* 1061 */     paramPrintStream.println(paramString + "\t@Override");
/* 1062 */     paramPrintStream.println(paramString + "\tpublic final OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {");
/*      */     Object localObject3;
/* 1063 */     if (isAny()) {
/* 1064 */       paramPrintStream.println(paramString + "\t\tthrow new UnsupportedOperationException();");
/*      */     }
/*      */     else {
/* 1067 */       localObject1 = DatabaseMetaData.getInstance().getBean(getName());
/*      */ 
/* 1069 */       if (localObject1 == null)
/*      */       {
/* 1071 */         for (localObject2 = this.variables.iterator(); ((Iterator)localObject2).hasNext(); ((Variable)localObject3).unmarshal(this, paramPrintStream, "\t\t")) localObject3 = (Variable)((Iterator)localObject2).next();
/*      */       }
/*      */       else
/*      */       {
/* 1075 */         for (localObject2 = ((DatabaseMetaData.Bean)localObject1).getVariables().iterator(); ((Iterator)localObject2).hasNext(); ) { localObject3 = (DatabaseMetaData.Bean.Variable)((Iterator)localObject2).next();
/*      */ 
/* 1077 */           Variable localVariable = getVariable(((DatabaseMetaData.Bean.Variable)localObject3).getName());
/* 1078 */           assert (localVariable != null);
/* 1079 */           localVariable.unmarshal(this, paramPrintStream, "\t\t");
/*      */         }
/*      */       }
/*      */ 
/* 1083 */       paramPrintStream.println(paramString + "\t\treturn _os_;");
/*      */     }
/* 1085 */     paramPrintStream.println(paramString + "\t}");
/* 1086 */     paramPrintStream.println("");
/*      */ 
/* 1089 */     paramPrintStream.println(paramString + "\t@Override");
/* 1090 */     paramPrintStream.println(paramString + "\tpublic xbean." + str + " copy() {");
/* 1091 */     paramPrintStream.println(paramString + "\t\treturn new Data(this);");
/* 1092 */     paramPrintStream.println(paramString + "\t}");
/* 1093 */     paramPrintStream.println("");
/* 1094 */     paramPrintStream.println(paramString + "\t@Override");
/* 1095 */     paramPrintStream.println(paramString + "\tpublic xbean." + str + " toData() {");
/* 1096 */     paramPrintStream.println(paramString + "\t\treturn new Data(this);");
/* 1097 */     paramPrintStream.println(paramString + "\t}");
/* 1098 */     paramPrintStream.println("");
/* 1099 */     paramPrintStream.println(paramString + "\tpublic xbean." + str + " toBean() {");
/* 1100 */     paramPrintStream.println(paramString + "\t\treturn new " + str + "(this, null, null);");
/* 1101 */     paramPrintStream.println(paramString + "\t}");
/* 1102 */     paramPrintStream.println("");
/* 1103 */     paramPrintStream.println(paramString + "\t@Override");
/* 1104 */     paramPrintStream.println(paramString + "\tpublic xbean." + str + " toDataIf() {");
/* 1105 */     paramPrintStream.println(paramString + "\t\treturn this;");
/* 1106 */     paramPrintStream.println(paramString + "\t}");
/* 1107 */     paramPrintStream.println("");
/* 1108 */     paramPrintStream.println(paramString + "\tpublic xbean." + str + " toBeanIf() {");
/* 1109 */     paramPrintStream.println(paramString + "\t\treturn new " + str + "(this, null, null);");
/* 1110 */     paramPrintStream.println(paramString + "\t}");
/* 1111 */     paramPrintStream.println("");
/*      */ 
/* 1113 */     paramPrintStream.println(paramString + "\t// xdb.Bean interface. Data Unsupported");
/* 1114 */     paramPrintStream.println(paramString + "\tpublic boolean xdbManaged() { throw new UnsupportedOperationException(); }");
/* 1115 */     paramPrintStream.println(paramString + "\tpublic xdb.Bean xdbParent() { throw new UnsupportedOperationException(); }");
/* 1116 */     paramPrintStream.println(paramString + "\tpublic String xdbVarname()  { throw new UnsupportedOperationException(); }");
/* 1117 */     paramPrintStream.println(paramString + "\tpublic Long    xdbObjId()   { throw new UnsupportedOperationException(); }");
/* 1118 */     paramPrintStream.println(paramString + "\tpublic xdb.Bean toConst()   { throw new UnsupportedOperationException(); }");
/* 1119 */     paramPrintStream.println(paramString + "\tpublic boolean isConst()    { return false; }");
/* 1120 */     paramPrintStream.println(paramString + "\tpublic boolean isData()     { return true; }");
/* 1121 */     paramPrintStream.println("");
/*      */ 
/* 1124 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ((Variable)localObject2).getterData(this, paramPrintStream, paramString + "\t")) localObject2 = (Variable)((Iterator)localObject1).next();
/* 1125 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ((Variable)localObject2).setterData(this, paramPrintStream, paramString + "\t")) localObject2 = (Variable)((Iterator)localObject1).next();
/*      */ 
/* 1128 */     paramPrintStream.println(paramString + "\t@Override");
/* 1129 */     paramPrintStream.println(paramString + "\tpublic final boolean equals(Object _o1_) {");
/* 1130 */     paramPrintStream.println(paramString + "\t\tif (!(_o1_ instanceof " + str + ".Data)) return false;");
/* 1131 */     paramPrintStream.println(paramString + "\t\t" + str + ".Data _o_ = (" + str + ".Data) _o1_;");
/* 1132 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ((Variable)localObject2).equals(paramPrintStream, "\t\t\t")) localObject2 = (Variable)((Iterator)localObject1).next();
/* 1133 */     paramPrintStream.println(paramString + "\t\treturn true;");
/* 1134 */     paramPrintStream.println(paramString + "\t}");
/* 1135 */     paramPrintStream.println("");
/*      */ 
/* 1138 */     paramPrintStream.println(paramString + "\t@Override");
/* 1139 */     paramPrintStream.println(paramString + "\tpublic final int hashCode() {");
/* 1140 */     paramPrintStream.println(paramString + "\t\tint _h_ = 0;");
/* 1141 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ((Variable)localObject2).hashCode(paramPrintStream, paramString + "\t\t")) localObject2 = (Variable)((Iterator)localObject1).next();
/* 1142 */     paramPrintStream.println(paramString + "\t\treturn _h_;");
/* 1143 */     paramPrintStream.println(paramString + "\t}");
/* 1144 */     paramPrintStream.println("");
/*      */ 
/* 1147 */     paramPrintStream.println(paramString + "\t@Override");
/* 1148 */     paramPrintStream.println(paramString + "\tpublic String toString() {");
/* 1149 */     paramPrintStream.println(paramString + "\t\tStringBuilder _sb_ = new StringBuilder();");
/* 1150 */     paramPrintStream.println(paramString + "\t\t_sb_.append(\"(\");");
/* 1151 */     int i = 1;
/* 1152 */     for (Object localObject2 = this.variables.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject3 = (Variable)((Iterator)localObject2).next();
/* 1153 */       if (0 == i) paramPrintStream.println(paramString + "\t\t_sb_.append(\",\");");
/* 1154 */       ((Variable)localObject3).toString(paramPrintStream, paramString + "\t\t");
/* 1155 */       i = 0;
/*      */     }
/* 1157 */     paramPrintStream.println(paramString + "\t\t_sb_.append(\")\");");
/* 1158 */     paramPrintStream.println(paramString + "\t\treturn _sb_.toString();");
/* 1159 */     paramPrintStream.println(paramString + "\t}");
/* 1160 */     paramPrintStream.println("");
/* 1161 */     paramPrintStream.println(paramString + "}");
/*      */   }
/*      */ 
/*      */   public void depends(Set<Type> paramSet)
/*      */   {
/* 1166 */     if (Type.addDepend(paramSet, this))
/* 1167 */       for (Variable localVariable : this.variables)
/* 1168 */         localVariable.getVartype().depends(paramSet);
/*      */   }
/*      */ 
/*      */   public XBean(DatabaseMetaData.Bean paramBean)
/*      */   {
/* 1179 */     this.name = paramBean.getName();
/* 1180 */     Main.verifyName(this.name);
/* 1181 */     if (this.name.equals("Pod"))
/* 1182 */       throw new RuntimeException("name of 'Pod' has been used by xdb");
/* 1183 */     Type.add(this);
/*      */ 
/* 1186 */     DatabaseMetaData.Bean localBean = DatabaseMetaData.getInstance().getBean(this.name);
/* 1187 */     assert (localBean != null);
/* 1188 */     this.anyMaybe = localBean.isAny();
/* 1189 */     for (DatabaseMetaData.Bean.Variable localVariable : localBean.getVariables())
/*      */     {
/* 1198 */       add(new Variable(localVariable));
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.XBean
 * JD-Core Version:    0.6.2
 */