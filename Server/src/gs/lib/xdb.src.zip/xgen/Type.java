/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public abstract class Type
/*     */ {
/*     */   private static XBean currentBean;
/*  24 */   private Set<Table> owners = new HashSet();
/*     */ 
/* 179 */   private static Map<String, Type> types = new HashMap();
/*     */ 
/* 210 */   private static boolean any = false;
/*     */ 
/* 235 */   private static Type dependFrom = null;
/*     */ 
/*     */   static void setCurrentBean(XBean paramXBean)
/*     */   {
/*  16 */     currentBean = paramXBean; } 
/*  17 */   static XBean getCurrentBean() { return currentBean; }
/*     */ 
/*     */ 
/*     */   public abstract String getName();
/*     */ 
/*     */   public void addOwnerTable(Table paramTable)
/*     */   {
/*  35 */     this.owners.add(paramTable);
/*     */   }
/*     */ 
/*     */   public Set<Table> getOwnerTables()
/*     */   {
/*  43 */     return this.owners;
/*     */   }
/*     */ 
/*     */   public abstract void verifyForeign(Xdb paramXdb, Foreign paramForeign);
/*     */ 
/*     */   public abstract void verifyCapacity(Xdb paramXdb, Capacity paramCapacity);
/*     */ 
/*     */   public abstract void printTableSelectMethod(PrintStream paramPrintStream, String paramString);
/*     */ 
/*     */   public abstract Type compile(String paramString1, String paramString2);
/*     */ 
/*     */   public abstract String getTypeName();
/*     */ 
/*     */   public boolean supportAutoIncrement()
/*     */   {
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */   public abstract String getBoxingName();
/*     */ 
/*     */   public abstract boolean isConstant();
/*     */ 
/*     */   public abstract boolean isCloneable();
/*     */ 
/*     */   public abstract void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString);
/*     */ 
/*     */   public abstract void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString);
/*     */ 
/*     */   public abstract void getterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString);
/*     */ 
/*     */   public abstract void getterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString);
/*     */ 
/*     */   public abstract void setter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString);
/*     */ 
/*     */   public abstract void setterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString);
/*     */ 
/*     */   public abstract void setterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString);
/*     */ 
/*     */   public abstract void setterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString);
/*     */ 
/*     */   public abstract void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString);
/*     */ 
/*     */   public String compareto(String paramString1, String paramString2)
/*     */   {
/*  95 */     throw new UnsupportedOperationException("compareTo");
/*     */   }
/*     */ 
/*     */   public abstract void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2);
/*     */ 
/*     */   public abstract void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2);
/*     */ 
/*     */   public abstract void deepCopy(boolean paramBoolean, Variable paramVariable, PrintStream paramPrintStream, String paramString);
/*     */ 
/*     */   public abstract String deepCopy(boolean paramBoolean, Variable paramVariable, String paramString);
/*     */ 
/*     */   public void toString(PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 130 */     paramPrintStream.println(paramString1 + "_sb_.append(" + paramString2 + ");");
/*     */   }
/*     */ 
/*     */   public boolean isAny()
/*     */   {
/* 139 */     return false;
/*     */   }
/*     */ 
/*     */   public abstract String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString);
/*     */ 
/*     */   public abstract String defineNoParent(String paramString);
/*     */ 
/*     */   public abstract String notEquals(String paramString);
/*     */ 
/*     */   public abstract String hashCode(String paramString);
/*     */ 
/*     */   public abstract String newListenable(XBean paramXBean, Variable paramVariable);
/*     */ 
/*     */   public static void add(Type paramType)
/*     */   {
/* 205 */     if (types.put(paramType.getName(), paramType) != null)
/* 206 */       throw new RuntimeException("duplicate type " + paramType.getName());
/*     */   }
/*     */ 
/*     */   public static boolean setAny(boolean paramBoolean)
/*     */   {
/* 218 */     boolean bool = any;
/* 219 */     any = paramBoolean;
/* 220 */     return bool;
/*     */   }
/*     */ 
/*     */   public static Type compile(String paramString1, String paramString2, String paramString3) {
/* 224 */     Type localType = (Type)types.get(paramString1);
/* 225 */     if (null != localType) {
/* 226 */       return localType.compile(paramString2, paramString3);
/*     */     }
/* 228 */     if (any)
/* 229 */       return new TypeAny(paramString1);
/* 230 */     throw new RuntimeException("'" + paramString1 + "' TYPE NOT FOUND!");
/*     */   }
/*     */ 
/*     */   public abstract void depends(Set<Type> paramSet);
/*     */ 
/*     */   public static boolean addDepend(Set<Type> paramSet, Type paramType)
/*     */   {
/* 247 */     if (paramSet.add(paramType))
/* 248 */       return true;
/* 249 */     if (dependFrom == paramType)
/* 250 */       throw new RuntimeException("unsupport self-depend. type=" + Main.quote(paramType.getName()));
/* 251 */     return false;
/*     */   }
/*     */ 
/*     */   public Set<Type> depends() {
/* 255 */     HashSet localHashSet = new HashSet();
/* 256 */     dependFrom = this;
/*     */     try {
/* 258 */       depends(localHashSet);
/*     */     } finally {
/* 260 */       dependFrom = null;
/*     */     }
/* 262 */     return localHashSet;
/*     */   }
/*     */ 
/*     */   public static boolean isExist(String paramString)
/*     */   {
/* 268 */     return types.containsKey(paramString);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 183 */     new TypeBoolean(types);
/* 184 */     new TypeShort(types);
/* 185 */     new TypeInt(types);
/* 186 */     new TypeLong(types);
/* 187 */     new TypeString(types);
/* 188 */     new TypeFloat(types);
/*     */ 
/* 191 */     new TypeList(types);
/* 192 */     new TypeVector(types);
/* 193 */     new TypeSet(types);
/*     */ 
/* 196 */     new TypeMap(types);
/* 197 */     new TypeTreeMap(types);
/*     */ 
/* 199 */     new TypeBinary(types);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.Type
 * JD-Core Version:    0.6.2
 */