/*    */ package xgen;
/*    */ 
/*    */ import xdb.util.ForeignConf;
/*    */ 
/*    */ public class Foreign extends ForeignConf
/*    */ {
/*    */   private final String message;
/*    */ 
/*    */   public void throwIf(boolean paramBoolean, String paramString)
/*    */   {
/* 12 */     if (paramBoolean)
/* 13 */       throw new IllegalArgumentException("invalid foreign! " + this.message + " " + paramString);
/*    */   }
/*    */ 
/*    */   public void warn(String paramString) {
/* 17 */     Main.warn(this.message + " " + paramString, 'f');
/*    */   }
/*    */ 
/*    */   public Foreign(Foreign paramForeign, String paramString) {
/* 21 */     super(null, paramString);
/* 22 */     this.message = paramForeign.message;
/*    */   }
/*    */ 
/*    */   public Foreign(String paramString1, String paramString2) {
/* 26 */     super(paramString1);
/* 27 */     this.message = ("FOREIGN conf=" + Main.quote(paramString1) + " name=" + paramString2);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.Foreign
 * JD-Core Version:    0.6.2
 */