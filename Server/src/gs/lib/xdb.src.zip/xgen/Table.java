/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ public class Table
/*     */ {
/*     */   private String name;
/*     */   private String lock;
/*     */   private String key;
/*     */   private String value;
/*     */   private boolean autoIncrement;
/*     */   private boolean isMemory;
/*     */   private String foreign;
/*     */   private String capacity;
/*     */   private Type keytype;
/*     */   private Type valuetype;
/*     */ 
/*     */   public String getName()
/*     */   {
/*  18 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getLock() {
/*  22 */     return this.lock;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  27 */     return getName();
/*     */   }
/*     */ 
/*     */   Table(Element paramElement) {
/*  31 */     this.name = paramElement.getAttribute("name").trim();
/*  32 */     if (!this.name.toLowerCase().equals(this.name))
/*  33 */       throw new RuntimeException("tablename MUSTBE lowercase");
/*  34 */     Main.verifyName(this.name);
/*     */ 
/*  36 */     Define localDefine = Define.getInstance();
/*     */ 
/*  38 */     this.lock = paramElement.getAttribute("lock");
/*  39 */     if (this.lock == null)
/*  40 */       throw new RuntimeException(new StringBuilder().append("not found lock in table '").append(this.name).append("'").toString());
/*  41 */     if (this.lock.equals(""))
/*  42 */       this.lock = this.name;
/*  43 */     else if ((localDefine.isParsed()) && (!Define.getInstance().isLockname(this.lock))) {
/*  44 */       throw new RuntimeException(new StringBuilder().append("undefined lockname '").append(this.lock).append("' in table '").append(this.name).append("'").toString());
/*     */     }
/*  46 */     if (localDefine.isParsed())
/*     */     {
/*  48 */       if (paramElement.hasAttribute("cachelow"))
/*  49 */         throw new RuntimeException(new StringBuilder().append("cachelow is not allowed for defined xdb in table '").append(this.name).append("'").toString());
/*  50 */       if (paramElement.hasAttribute("cachehigh"))
/*  51 */         throw new RuntimeException(new StringBuilder().append("cachehigh is not allowed for defined xdb in table '").append(this.name).append("'").toString());
/*  52 */       String str1 = paramElement.getAttribute("cacheCapacity");
/*  53 */       if ((str1 != null) && (localDefine.getCacheCap(str1) == null))
/*  54 */         throw new RuntimeException(new StringBuilder().append("undefined cacheCapacity '").append(str1).append("' in table '").append(this.name).append("'").toString());
/*  55 */       String str2 = paramElement.getAttribute("cachePage");
/*  56 */       if ((str2 != null) && (localDefine.getCachePage(str2) == null)) {
/*  57 */         throw new RuntimeException(new StringBuilder().append("undefined cachePage '").append(str2).append("' in table '").append(this.name).append("'").toString());
/*     */       }
/*     */     }
/*  60 */     this.key = paramElement.getAttribute("key").trim();
/*  61 */     this.value = paramElement.getAttribute("value").trim();
/*  62 */     this.isMemory = paramElement.getAttribute("persistence").equalsIgnoreCase("MEMORY");
/*     */ 
/*  64 */     this.autoIncrement = paramElement.getAttribute("autoIncrement").equals("true");
/*  65 */     this.foreign = paramElement.getAttribute("foreign").trim();
/*  66 */     this.capacity = paramElement.getAttribute("capacity").trim();
/*     */   }
/*     */ 
/*     */   public Type getKeyType()
/*     */   {
/*  73 */     return this.keytype;
/*     */   }
/*     */ 
/*     */   public Type getValueType() {
/*  77 */     return this.valuetype;
/*     */   }
/*     */ 
/*     */   void compile(Xdb paramXdb) {
/*  81 */     this.keytype = Type.compile(this.key, null, null);
/*  82 */     if (!this.keytype.isConstant())
/*  83 */       throw new RuntimeException("table.key need a constant valuetype");
/*  84 */     if ((this.autoIncrement) && (!this.keytype.supportAutoIncrement()))
/*  85 */       throw new RuntimeException(new StringBuilder().append("type of '").append(this.key).append("' unsupport autoIncrement").toString());
/*  86 */     this.valuetype = Type.compile(this.value, null, null);
/*     */   }
/*     */ 
/*     */   void verify(Xdb paramXdb)
/*     */   {
/*  91 */     if (!this.foreign.isEmpty())
/*     */     {
/*  93 */       localObject = new Foreign(this.foreign, new StringBuilder().append("table=").append(getName()).toString());
/*  94 */       if (((Foreign)localObject).getKey() != null)
/*  95 */         this.keytype.verifyForeign(paramXdb, new Foreign((Foreign)localObject, ((Foreign)localObject).getKey()));
/*  96 */       if (((Foreign)localObject).getValue() != null) {
/*  97 */         this.valuetype.verifyForeign(paramXdb, new Foreign((Foreign)localObject, ((Foreign)localObject).getValue()));
/*     */       }
/*     */     }
/* 100 */     Object localObject = new Capacity(this.capacity, new StringBuilder().append("table.").append(getName()).toString());
/* 101 */     this.keytype.verifyCapacity(paramXdb, ((Capacity)localObject).extractKey());
/* 102 */     this.valuetype.verifyCapacity(paramXdb, ((Capacity)localObject).extractValue());
/* 103 */     ((Capacity)localObject).warnIf(null != ((Capacity)localObject).getCapacity(), "capacity is not required.");
/*     */ 
/* 106 */     this.keytype.addOwnerTable(this);
/* 107 */     this.valuetype.addOwnerTable(this);
/*     */   }
/*     */ 
/*     */   Set<String> getForeigns()
/*     */   {
/* 115 */     HashSet localHashSet1 = new HashSet();
/* 116 */     Foreign localForeign = new Foreign(this.foreign, "");
/* 117 */     if (localForeign.getKey() != null)
/* 118 */       localHashSet1.add(localForeign.getKey());
/* 119 */     if (localForeign.getValue() != null) {
/* 120 */       localHashSet1.add(localForeign.getValue());
/*     */     }
/* 122 */     HashSet localHashSet2 = new HashSet();
/* 123 */     this.keytype.depends(localHashSet2);
/* 124 */     this.valuetype.depends(localHashSet2);
/* 125 */     for (Type localType : localHashSet2) {
/* 126 */       if ((localType instanceof CBean))
/* 127 */         ((CBean)localType).collectForeigns(localHashSet1);
/* 128 */       else if ((localType instanceof XBean)) {
/* 129 */         ((XBean)localType).collectForeigns(localHashSet1);
/*     */       }
/*     */     }
/* 132 */     return localHashSet1;
/*     */   }
/*     */ 
/*     */   boolean isNeedExplicitCheck() {
/* 136 */     return (Main.explicitLockCheck) && (!Main.explicitLockIgnoreTables.contains(this.name));
/*     */   }
/*     */ 
/*     */   void make() {
/* 140 */     if ((this.valuetype.isAny()) && (!this.isMemory)) {
/* 141 */       throw new RuntimeException(new StringBuilder().append("'").append(this.value).append("@").append(this.name).append("(isAny() && !isMemory)").toString());
/*     */     }
/* 143 */     String str1 = Main.toUpper1(this.name);
/* 144 */     PrintStream localPrintStream = Main.openTableFile(str1);
/*     */ 
/* 146 */     String str2 = this.keytype.getBoxingName();
/* 147 */     String str3 = this.valuetype.getBoxingName();
/* 148 */     String str4 = new StringBuilder().append("<").append(str2).append(", ").append(str3).append(">").toString();
/*     */ 
/* 151 */     localPrintStream.println("package xtable;");
/* 152 */     localPrintStream.println("");
/* 153 */     localPrintStream.println("// typed table access point");
/* 154 */     localPrintStream.println(new StringBuilder().append("public class ").append(str1).append(" {").toString());
/* 155 */     localPrintStream.println(new StringBuilder().append("\t").append(str1).append("() {").toString());
/* 156 */     localPrintStream.println("\t}");
/* 157 */     localPrintStream.println("");
/*     */ 
/* 160 */     if (isNeedExplicitCheck()) {
/* 161 */       localPrintStream.println(new StringBuilder().append("\tprivate static void _explicitLockCheck(").append(str2).append(" key) {").toString());
/* 162 */       localPrintStream.println("\t\tif (!_Tables_.isExplicitLockCheck) return;");
/* 163 */       localPrintStream.println(new StringBuilder().append("\t\txdb.Lockey lockey = xdb.Lockeys.get(_Tables_.getInstance().").append(this.name).append(", key);").toString());
/* 164 */       localPrintStream.println("\t\tif (!lockey.isHeldByCurrentThread()) {");
/* 165 */       localPrintStream.println("\t\t\tthrow new IllegalStateException(\"check ExplicitLock Exception\");");
/* 166 */       localPrintStream.println("\t\t}");
/* 167 */       localPrintStream.println("\t}");
/* 168 */       localPrintStream.println("");
/*     */     }
/*     */ 
/* 171 */     if (this.autoIncrement) {
/* 172 */       localPrintStream.println(new StringBuilder().append("\tpublic static xdb.util.AutoKey<").append(str2).append("> getAutoKey() {").toString());
/* 173 */       localPrintStream.println(new StringBuilder().append("\t\treturn _Tables_.getInstance().").append(this.name).append(".getAutoKey();").toString());
/* 174 */       localPrintStream.println("\t}");
/* 175 */       localPrintStream.println("");
/* 176 */       localPrintStream.println(new StringBuilder().append("\tpublic static ").append(str2).append(" nextKey() {").toString());
/* 177 */       localPrintStream.println("\t\treturn getAutoKey().next();");
/* 178 */       localPrintStream.println("\t}");
/* 179 */       localPrintStream.println("");
/* 180 */       localPrintStream.println(new StringBuilder().append("\tpublic static ").append(str2).append(" insert(").append(str3).append(" value) {").toString());
/* 181 */       localPrintStream.println("\t\tLong next = nextKey();");
/* 182 */       localPrintStream.println("\t\tinsert(next, value);");
/* 183 */       localPrintStream.println("\t\treturn next;");
/* 184 */       localPrintStream.println("\t}");
/* 185 */       localPrintStream.println("");
/*     */     }
/*     */ 
/* 188 */     localPrintStream.println(new StringBuilder().append("\tpublic static ").append(str3).append(" get(").append(str2).append(" key) {").toString());
/* 189 */     if (isNeedExplicitCheck()) {
/* 190 */       localPrintStream.println("\t\t_explicitLockCheck(key);");
/*     */     }
/* 192 */     localPrintStream.println(new StringBuilder().append("\t\treturn _Tables_.getInstance().").append(this.name).append(".get(key);").toString());
/* 193 */     localPrintStream.println("\t}");
/* 194 */     localPrintStream.println("");
/* 195 */     localPrintStream.println(new StringBuilder().append("\tpublic static ").append(str3).append(" get(").append(str2).append(" key, ").append(str3).append(" value) {").toString());
/* 196 */     if (isNeedExplicitCheck()) {
/* 197 */       localPrintStream.println("\t\t_explicitLockCheck(key);");
/*     */     }
/* 199 */     localPrintStream.println(new StringBuilder().append("\t\treturn _Tables_.getInstance().").append(this.name).append(".get(key, value);").toString());
/* 200 */     localPrintStream.println("\t}");
/* 201 */     localPrintStream.println("");
/*     */ 
/* 203 */     localPrintStream.println(new StringBuilder().append("\tpublic static void insert(").append(str2).append(" key, ").append(str3).append(" value) {").toString());
/* 204 */     localPrintStream.println(new StringBuilder().append("\t\t_Tables_.getInstance().").append(this.name).append(".insert(key, value);").toString());
/* 205 */     localPrintStream.println("\t}");
/* 206 */     localPrintStream.println("");
/* 207 */     localPrintStream.println(new StringBuilder().append("\tpublic static void delete(").append(str2).append(" key) {").toString());
/* 208 */     if (isNeedExplicitCheck()) {
/* 209 */       localPrintStream.println("\t\t_explicitLockCheck(key);");
/*     */     }
/* 211 */     localPrintStream.println(new StringBuilder().append("\t\t_Tables_.getInstance().").append(this.name).append(".delete(key);").toString());
/* 212 */     localPrintStream.println("\t}");
/* 213 */     localPrintStream.println("");
/*     */ 
/* 226 */     localPrintStream.println(new StringBuilder().append("\tpublic static boolean add(").append(str2).append(" key, ").append(str3).append(" value) {").toString());
/* 227 */     if (isNeedExplicitCheck()) {
/* 228 */       localPrintStream.println(new StringBuilder().append("\t\tboolean ret = _Tables_.getInstance().").append(this.name).append(".add(key, value);").toString());
/* 229 */       localPrintStream.println("\t\tif (!ret) {");
/* 230 */       localPrintStream.println("\t\t\t_explicitLockCheck(key);");
/* 231 */       localPrintStream.println("\t\t}");
/* 232 */       localPrintStream.println("\t\treturn ret;");
/*     */     } else {
/* 234 */       localPrintStream.println(new StringBuilder().append("\t\treturn _Tables_.getInstance().").append(this.name).append(".add(key, value);").toString());
/*     */     }
/* 236 */     localPrintStream.println("\t}");
/* 237 */     localPrintStream.println("");
/*     */ 
/* 239 */     localPrintStream.println(new StringBuilder().append("\tpublic static boolean remove(").append(str2).append(" key) {").toString());
/* 240 */     if (isNeedExplicitCheck()) {
/* 241 */       localPrintStream.println("\t\t_explicitLockCheck(key);");
/*     */     }
/* 243 */     localPrintStream.println(new StringBuilder().append("\t\treturn _Tables_.getInstance().").append(this.name).append(".remove(key);").toString());
/* 244 */     localPrintStream.println("\t}");
/* 245 */     localPrintStream.println("");
/*     */ 
/* 247 */     localPrintStream.println(new StringBuilder().append("\tpublic static xdb.TTableCache").append(str4).append(" getCache() {").toString());
/* 248 */     localPrintStream.println(new StringBuilder().append("\t\treturn _Tables_.getInstance().").append(this.name).append(".getCache();").toString());
/* 249 */     localPrintStream.println("\t}");
/* 250 */     localPrintStream.println("");
/* 251 */     localPrintStream.println(new StringBuilder().append("\tpublic static xdb.TTable").append(str4).append(" getTable() {").toString());
/* 252 */     localPrintStream.println(new StringBuilder().append("\t\treturn _Tables_.getInstance().").append(this.name).append(";").toString());
/* 253 */     localPrintStream.println("\t}");
/* 254 */     localPrintStream.println("");
/* 255 */     this.valuetype.printTableSelectMethod(localPrintStream, str2);
/* 256 */     localPrintStream.println("}");
/*     */ 
/* 258 */     localPrintStream.close();
/*     */   }
/*     */ 
/*     */   void define(PrintStream paramPrintStream) {
/* 262 */     String str1 = this.keytype.getBoxingName();
/* 263 */     String str2 = this.valuetype.getBoxingName();
/* 264 */     String str3 = new StringBuilder().append("xdb.TTable<").append(str1).append(", ").append(str2).append(">").toString();
/*     */ 
/* 266 */     paramPrintStream.println(new StringBuilder().append("\t").append(str3).append(" ").append(this.name).append(" = new ").append(str3).append("() {").toString());
/* 267 */     paramPrintStream.println("\t\tpublic String getName() {");
/* 268 */     paramPrintStream.println(new StringBuilder().append("\t\t\treturn ").append(Main.quote(this.name)).append(";").toString());
/* 269 */     paramPrintStream.println("\t\t}");
/* 270 */     paramPrintStream.println("");
/*     */ 
/* 272 */     if (this.autoIncrement) {
/* 273 */       paramPrintStream.println(new StringBuilder().append("\t\tprotected xdb.util.AutoKey<").append(str1).append("> bindAutoKey() {").toString());
/* 274 */       paramPrintStream.println(new StringBuilder().append("\t\t\treturn getInstance().getTableSys().getAutoKeys().getAutoKey").append(str1).append("(getName());").toString());
/* 275 */       paramPrintStream.println("\t\t}");
/* 276 */       paramPrintStream.println("");
/*     */     }
/*     */ 
/* 279 */     paramPrintStream.println(new StringBuilder().append("\t\tpublic OctetsStream marshalKey(").append(str1).append(" key) {").toString());
/* 280 */     paramPrintStream.println("\t\t\tOctetsStream _os_ = new OctetsStream();");
/* 281 */     this.keytype.marshal(null, null, paramPrintStream, "\t\t\t", "key");
/* 282 */     paramPrintStream.println("\t\t\treturn _os_;");
/* 283 */     paramPrintStream.println("\t\t}");
/* 284 */     paramPrintStream.println("");
/* 285 */     paramPrintStream.println(new StringBuilder().append("\t\tpublic OctetsStream marshalValue(").append(str2).append(" value) {").toString());
/* 286 */     paramPrintStream.println("\t\t\tOctetsStream _os_ = new OctetsStream();");
/* 287 */     this.valuetype.marshal(null, null, paramPrintStream, "\t\t\t", "value");
/* 288 */     paramPrintStream.println("\t\t\treturn _os_;");
/* 289 */     paramPrintStream.println("\t\t}");
/* 290 */     paramPrintStream.println("");
/*     */ 
/* 292 */     paramPrintStream.println(new StringBuilder().append("\t\tpublic ").append(str1).append(" unmarshalKey(OctetsStream _os_) throws MarshalException {").toString());
/* 293 */     paramPrintStream.println(new StringBuilder().append("\t\t\t").append(this.keytype.defineNoParent("key")).toString());
/* 294 */     this.keytype.unmarshal(null, null, paramPrintStream, "\t\t\t", "key");
/* 295 */     paramPrintStream.println("\t\t\treturn key;");
/* 296 */     paramPrintStream.println("\t\t}");
/* 297 */     paramPrintStream.println("");
/*     */ 
/* 299 */     paramPrintStream.println(new StringBuilder().append("\t\tpublic ").append(str2).append(" unmarshalValue(OctetsStream _os_) throws MarshalException {").toString());
/* 300 */     paramPrintStream.println(new StringBuilder().append("\t\t\t").append(this.valuetype.defineNoParent("value")).toString());
/* 301 */     this.valuetype.unmarshal(null, null, paramPrintStream, "\t\t\t", "value");
/* 302 */     paramPrintStream.println("\t\t\treturn value;");
/* 303 */     paramPrintStream.println("\t\t}");
/* 304 */     paramPrintStream.println("");
/* 305 */     paramPrintStream.println(new StringBuilder().append("\t\tpublic ").append(str2).append(" newValue() {").toString());
/* 306 */     paramPrintStream.println(new StringBuilder().append("\t\t\t").append(this.valuetype.defineNoParent("value")).toString());
/* 307 */     paramPrintStream.println("\t\t\treturn value;");
/* 308 */     paramPrintStream.println("\t\t}");
/* 309 */     paramPrintStream.println("");
/* 310 */     paramPrintStream.println("\t};");
/* 311 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   static void make(Collection<Table> paramCollection) {
/* 315 */     String str = "_Tables_";
/* 316 */     PrintStream localPrintStream = Main.openTableFile(str);
/*     */ 
/* 318 */     localPrintStream.println("package xtable;");
/* 319 */     localPrintStream.println("");
/* 320 */     if (!paramCollection.isEmpty()) {
/* 321 */       localPrintStream.println("import com.goldhuman.Common.Marshal.OctetsStream;");
/* 322 */       localPrintStream.println("import com.goldhuman.Common.Marshal.MarshalException;");
/*     */     }
/* 324 */     localPrintStream.println("");
/* 325 */     localPrintStream.println("public class _Tables_ extends xdb.Tables {");
/* 326 */     localPrintStream.println("\tstatic volatile boolean isExplicitLockCheck = false;");
/* 327 */     localPrintStream.println("");
/* 328 */     localPrintStream.println("\tpublic static void startExplicitLockCheck() {");
/* 329 */     localPrintStream.println("\t\tisExplicitLockCheck = true;");
/* 330 */     localPrintStream.println("\t}");
/* 331 */     localPrintStream.println("");
/* 332 */     localPrintStream.println("\tpublic static _Tables_ getInstance() {");
/* 333 */     localPrintStream.println("\t\treturn (_Tables_)xdb.Xdb.getInstance().getTables();");
/* 334 */     localPrintStream.println("\t}");
/* 335 */     localPrintStream.println("");
/* 336 */     localPrintStream.println("\tpublic _Tables_() {");
/* 337 */     for (Iterator localIterator = paramCollection.iterator(); localIterator.hasNext(); ) { localTable = (Table)localIterator.next();
/* 338 */       localPrintStream.println(new StringBuilder().append("\t\tadd(").append(localTable.getName()).append(");").toString());
/*     */     }
/* 342 */     Table localTable;
/* 339 */     localPrintStream.println("\t}");
/* 340 */     localPrintStream.println("");
/* 341 */     localPrintStream.println("\t// visible in package");
/* 342 */     for (localIterator = paramCollection.iterator(); localIterator.hasNext(); localTable.define(localPrintStream)) localTable = (Table)localIterator.next();
/* 343 */     localPrintStream.println("");
/* 344 */     localPrintStream.println("}");
/*     */ 
/* 346 */     localPrintStream.close();
/*     */   }
/*     */ 
/*     */   public void printMeta(PrintStream paramPrintStream, String paramString) {
/* 350 */     paramPrintStream.println(new StringBuilder().append(paramString).append("super.addTable(").append(Main.quote(getName())).append(", ").append(Main.quote(this.isMemory ? "MEMORY" : "DB")).append(", ").append(Main.quote(this.key)).append(", ").append(this.autoIncrement).append(", ").append(Main.quote(this.value)).append(", ").append(Main.quote(this.foreign)).append(", ").append(Main.quote(this.capacity)).append(");").toString());
/*     */   }
/*     */ 
/*     */   public void depends(Set<Type> paramSet)
/*     */   {
/* 361 */     getValueType().depends(paramSet);
/*     */ 
/* 363 */     getKeyType().depends(paramSet);
/*     */   }
/*     */ 
/*     */   public boolean isMemory()
/*     */   {
/* 368 */     return this.isMemory;
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.Table
 * JD-Core Version:    0.6.2
 */