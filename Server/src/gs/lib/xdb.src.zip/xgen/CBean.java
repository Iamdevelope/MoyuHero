/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import xdb.util.DatabaseMetaData;
/*     */ import xdb.util.DatabaseMetaData.Bean;
/*     */ import xdb.util.DatabaseMetaData.Bean.Variable;
/*     */ 
/*     */ public class CBean extends Type
/*     */ {
/*     */   private String name;
/*  13 */   private List<Variable> variables = new ArrayList();
/*  14 */   private List<Enum> enums = new ArrayList();
/*  15 */   private Set<String> varNames = new HashSet();
/*     */ 
/* 386 */   private boolean hasModify = false;
/*     */ 
/*     */   public void addOwnerTable(Table paramTable)
/*     */   {
/*  19 */     super.addOwnerTable(paramTable);
/*  20 */     for (Variable localVariable : this.variables)
/*  21 */       localVariable.getVartype().addOwnerTable(paramTable);
/*     */   }
/*     */ 
/*     */   private void add(Variable paramVariable) {
/*  25 */     if (false == this.varNames.add(paramVariable.getname()))
/*  26 */       throw new IllegalArgumentException(new StringBuilder().append("duplicate varname.").append(paramVariable.getname()).append("@").append(this.name).toString());
/*  27 */     this.variables.add(paramVariable);
/*     */   }
/*     */ 
/*     */   public void collectForeigns(Set<String> paramSet) {
/*  31 */     for (Variable localVariable : this.variables)
/*  32 */       localVariable.collectForeigns(paramSet);
/*     */   }
/*     */ 
/*     */   public void printTableSelectMethod(PrintStream paramPrintStream, String paramString)
/*     */   {
/*  37 */     String str = getBoxingName();
/*  38 */     paramPrintStream.println(new StringBuilder().append("\tpublic static ").append(str).append(" select(").append(paramString).append(" key) {").toString());
/*  39 */     paramPrintStream.println(new StringBuilder().append("\t\treturn getTable().select(key, new xdb.TField<").append(str).append(", ").append(str).append(">() {").toString());
/*  40 */     paramPrintStream.println(new StringBuilder().append("\t\t\tpublic ").append(str).append(" get(").append(str).append(" v) { return v; }").toString());
/*  41 */     paramPrintStream.println("\t\t});");
/*  42 */     paramPrintStream.println("\t}");
/*  43 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*     */   {
/*  49 */     paramForeign.throwIf(null != paramForeign.getKey(), "[cbean] need value only.");
/*  50 */     if (null != paramForeign.getValue()) {
/*  51 */       Table localTable = paramXdb.getTable(paramForeign.getValue());
/*  52 */       paramForeign.throwIf(null == localTable, "[cbean] table not exist.");
/*  53 */       paramForeign.throwIf(localTable.isMemory(), "[cbean] foreign table is memory");
/*  54 */       paramForeign.throwIf(localTable.getKeyType() != this, "[cbean] type not match");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*     */   {
/*  60 */     paramCapacity.notNeed();
/*     */   }
/*     */ 
/*     */   public Type compile(String paramString1, String paramString2)
/*     */   {
/*  65 */     if ((paramString1 != null) && (!paramString1.isEmpty()))
/*  66 */       throw new RuntimeException(new StringBuilder().append(getName()).append(" DO NOT NEED A KEY!").toString());
/*  67 */     if ((paramString2 != null) && (!paramString2.isEmpty()))
/*  68 */       throw new RuntimeException(new StringBuilder().append(getName()).append(" DO NOT NEED A VALUE!").toString());
/*  69 */     return this;
/*     */   }
/*     */ 
/*     */   public CBean(Element paramElement) {
/*  73 */     this.name = paramElement.getAttribute("name").trim();
/*  74 */     Main.verifyName(this.name);
/*  75 */     if (this.name.equals("Pod"))
/*  76 */       throw new RuntimeException("name of 'Pod' has been used by xdb");
/*  77 */     Type.add(this);
/*     */ 
/*  79 */     NodeList localNodeList = paramElement.getChildNodes();
/*  80 */     for (int i = 0; i < localNodeList.getLength(); i++) {
/*  81 */       Node localNode = localNodeList.item(i);
/*  82 */       if (1 == localNode.getNodeType())
/*     */       {
/*  85 */         Element localElement = (Element)localNode;
/*  86 */         String str = localElement.getNodeName();
/*     */ 
/*  88 */         if (str.equals("variable"))
/*  89 */           add(new Variable(localElement));
/*  90 */         else if (str.equals("enum"))
/*  91 */           this.enums.add(new Enum(localElement));
/*     */         else
/*  93 */           throw new RuntimeException(new StringBuilder().append("node=").append(str).toString()); 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*  98 */   public void compile(Xdb paramXdb) { for (Variable localVariable : this.variables) {
/*  99 */       localVariable.compile(paramXdb);
/* 100 */       if (!localVariable.getVartype().isConstant())
/* 101 */         throw new RuntimeException(new StringBuilder().append(getName()).append(" is constant bean. only immutable variable is available").toString());
/*     */     } }
/*     */ 
/*     */   public void verify(Xdb paramXdb)
/*     */   {
/* 106 */     for (Variable localVariable : this.variables)
/* 107 */       localVariable.verify(paramXdb, this);
/*     */   }
/*     */ 
/*     */   void make() {
/* 111 */     boolean bool = Main.noverify;
/* 112 */     Main.noverify = true;
/* 113 */     _make();
/* 114 */     Main.noverify = bool;
/*     */   }
/*     */   private void _make() {
/* 117 */     String str = getName();
/* 118 */     PrintStream localPrintStream = Main.openBeanFile(str);
/* 119 */     localPrintStream.println("");
/* 120 */     localPrintStream.println("package xbean;");
/* 121 */     localPrintStream.println("");
/* 122 */     localPrintStream.println("import com.goldhuman.Common.Marshal.Marshal;");
/* 123 */     localPrintStream.println("import com.goldhuman.Common.Marshal.MarshalException;");
/* 124 */     localPrintStream.println("import com.goldhuman.Common.Marshal.OctetsStream;");
/* 125 */     localPrintStream.println("");
/* 126 */     localPrintStream.println(new StringBuilder().append("public class ").append(str).append(" implements Marshal, Comparable<").append(str).append("> {").toString());
/* 127 */     localPrintStream.println("");
/*     */     Object localObject2;
/* 128 */     for (Object localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ((Variable)localObject2).declare(localPrintStream, "\t")) localObject2 = (Variable)((Iterator)localObject1).next();
/* 129 */     localPrintStream.println("");
/*     */ 
/* 132 */     for (localObject1 = this.enums.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Enum)((Iterator)localObject1).next();
/* 133 */       ((Enum)localObject2).print(localPrintStream, "\t"); }
/* 134 */     if (!this.enums.isEmpty()) {
/* 135 */       localPrintStream.println("");
/*     */     }
/*     */ 
/* 138 */     localPrintStream.println(new StringBuilder().append("\tpublic ").append(str).append("() {").toString());
/* 139 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ((Variable)localObject2).construct(null, localPrintStream, "\t\t")) localObject2 = (Variable)((Iterator)localObject1).next();
/* 140 */     localPrintStream.println("\t}");
/* 141 */     localPrintStream.println("");
/*     */ 
/* 143 */     if (!this.variables.isEmpty())
/*     */     {
/* 146 */       localObject1 = new StringBuilder();
/* 147 */       int i = 1;
/* 148 */       for (Iterator localIterator = this.variables.iterator(); localIterator.hasNext(); ) { localVariable2 = (Variable)localIterator.next();
/* 149 */         if (i != 0) i = 0; else ((StringBuilder)localObject1).append(", ");
/* 150 */         ((StringBuilder)localObject1).append(localVariable2.getVartype().getTypeName()).append(" ").append(localVariable2.getname());
/*     */       }
/* 153 */       Variable localVariable2;
/* 152 */       localPrintStream.println(new StringBuilder().append("\tpublic ").append(str).append("(").append(((StringBuilder)localObject1).toString()).append(") {").toString());
/* 153 */       for (localIterator = this.variables.iterator(); localIterator.hasNext(); ) { localVariable2 = (Variable)localIterator.next();
/* 154 */         localPrintStream.println(new StringBuilder().append("\t\tthis.").append(localVariable2.getname()).append(" = ").append(localVariable2.getname()).append(";").toString()); }
/* 155 */       localPrintStream.println("\t}");
/* 156 */       localPrintStream.println("");
/*     */     }
/* 159 */     Variable localVariable1;
/* 159 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); localVariable1.getter(null, localPrintStream, "\t")) localVariable1 = (Variable)((Iterator)localObject1).next();
/*     */ 
/* 162 */     localPrintStream.println("\t@Override");
/* 163 */     localPrintStream.println("\tpublic final OctetsStream marshal(OctetsStream _os_) {");
/* 164 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); localVariable1.marshal(null, localPrintStream, "\t\t")) localVariable1 = (Variable)((Iterator)localObject1).next();
/* 165 */     localPrintStream.println("\t\treturn _os_;");
/* 166 */     localPrintStream.println("\t}");
/* 167 */     localPrintStream.println("");
/*     */ 
/* 170 */     localPrintStream.println("\t@Override");
/* 171 */     localPrintStream.println("\tpublic final OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {");
/* 172 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); localVariable1.unmarshal(null, localPrintStream, "\t\t")) localVariable1 = (Variable)((Iterator)localObject1).next();
/* 173 */     localPrintStream.println("\t\treturn _os_;");
/* 174 */     localPrintStream.println("\t}");
/* 175 */     localPrintStream.println("");
/*     */ 
/* 178 */     localPrintStream.println("\t@Override");
/* 179 */     localPrintStream.println(new StringBuilder().append("\tpublic int compareTo(").append(getName()).append(" _o_) {").toString());
/* 180 */     localPrintStream.println("\t\tif (_o_ == this)");
/* 181 */     localPrintStream.println("\t\t\treturn 0;");
/* 182 */     localPrintStream.println("\t\tint _c_ = 0;");
/* 183 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ) { localVariable1 = (Variable)((Iterator)localObject1).next();
/* 184 */       localPrintStream.println(new StringBuilder().append("\t\t_c_ = ").append(localVariable1.compareto()).append(";").toString());
/* 185 */       localPrintStream.println("\t\tif (0 != _c_) return _c_;");
/*     */     }
/* 187 */     localPrintStream.println("\t\treturn _c_;");
/* 188 */     localPrintStream.println("\t}");
/* 189 */     localPrintStream.println("");
/* 190 */     localPrintStream.println("\t@Override");
/* 191 */     localPrintStream.println("\tpublic boolean equals(Object _o_) {");
/* 192 */     localPrintStream.println(new StringBuilder().append("\t\tif (_o_ instanceof ").append(getName()).append(")").toString());
/* 193 */     localPrintStream.println(new StringBuilder().append("\t\t\treturn 0 == this.compareTo((").append(getName()).append(")_o_);").toString());
/* 194 */     localPrintStream.println("\t\treturn false;");
/* 195 */     localPrintStream.println("\t}");
/* 196 */     localPrintStream.println("");
/* 197 */     localPrintStream.println("\t@Override");
/* 198 */     localPrintStream.println("\tpublic int hashCode() {");
/* 199 */     localPrintStream.println("\t\tint _h_ = 0;");
/* 200 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); localVariable1.hashCode(localPrintStream, "\t\t")) localVariable1 = (Variable)((Iterator)localObject1).next();
/* 201 */     localPrintStream.println("\t\treturn _h_;");
/* 202 */     localPrintStream.println("\t}");
/* 203 */     localPrintStream.println("");
/* 204 */     localPrintStream.println("}");
/* 205 */     localPrintStream.close();
/*     */   }
/*     */ 
/*     */   public String compareto(String paramString1, String paramString2)
/*     */   {
/* 210 */     return new StringBuilder().append(paramString1).append(".compareTo(").append(paramString2).append(")").toString();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 215 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/* 220 */     return new StringBuilder().append("xbean.").append(getName()).toString();
/*     */   }
/*     */ 
/*     */   public String getBoxingName()
/*     */   {
/* 225 */     return getTypeName();
/*     */   }
/*     */ 
/*     */   public String notEquals(String paramString)
/*     */   {
/* 230 */     return new StringBuilder().append("!").append(paramString).append(".equals(_o_.").append(paramString).append(")").toString();
/*     */   }
/*     */ 
/*     */   public String hashCode(String paramString)
/*     */   {
/* 235 */     return new StringBuilder().append(paramString).append(".hashCode()").toString();
/*     */   }
/*     */ 
/*     */   public boolean isConstant()
/*     */   {
/* 240 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isCloneable()
/*     */   {
/* 245 */     return true;
/*     */   }
/*     */ 
/*     */   public String defineNoParent(String paramString)
/*     */   {
/* 250 */     return new StringBuilder().append(getTypeName()).append(" ").append(paramString).append(" = new ").append(getTypeName()).append("();").toString();
/*     */   }
/*     */ 
/*     */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*     */   {
/* 255 */     return defineNoParent(paramString);
/*     */   }
/*     */ 
/*     */   public void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 260 */     paramPrintStream.println(new StringBuilder().append(paramString1).append(paramString2).append(".marshal(_os_);").toString());
/*     */   }
/*     */ 
/*     */   public String deepCopy(boolean paramBoolean, Variable paramVariable, String paramString)
/*     */   {
/* 265 */     return paramString;
/*     */   }
/*     */ 
/*     */   public void deepCopy(boolean paramBoolean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 270 */     paramPrintStream.println(new StringBuilder().append(paramString).append(paramVariable.getname()).append(" = _o_.").append(paramVariable.getname()).append(";").toString());
/*     */   }
/*     */ 
/*     */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 275 */     paramPrintStream.println(new StringBuilder().append(paramString).append(paramVariable.getname()).append(" = new ").append(getTypeName()).append("(").append(paramVariable.getInitial()).append(");").toString());
/*     */   }
/*     */ 
/*     */   public void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 280 */     paramPrintStream.println(new StringBuilder().append(paramString1).append(paramString2).append(".unmarshal(_os_);").toString());
/*     */   }
/*     */ 
/*     */   public void getterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 285 */     paramPrintStream.println(new StringBuilder().append(paramString).append("public xbean.").append(this.name).append(" get").append(paramVariable.getName()).append("(); // ").append(paramVariable.getComment()).toString());
/*     */   }
/*     */ 
/*     */   public void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 290 */     if (null != paramXBean)
/* 291 */       paramPrintStream.println(new StringBuilder().append(paramString).append("@Override").toString());
/* 292 */     paramPrintStream.println(new StringBuilder().append(paramString).append("public xbean.").append(this.name).append(" get").append(paramVariable.getName()).append("() { // ").append(paramVariable.getComment()).toString());
/* 293 */     Main._xdb_verify_(paramPrintStream, new StringBuilder().append(paramString).append("\t").toString());
/* 294 */     paramPrintStream.println(new StringBuilder().append(paramString).append("\treturn ").append(paramVariable.getname()).append(";").toString());
/* 295 */     paramPrintStream.println(new StringBuilder().append(paramString).append("}").toString());
/* 296 */     paramPrintStream.println();
/*     */   }
/*     */ 
/*     */   public void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 301 */     if (null != paramXBean)
/* 302 */       paramPrintStream.println(new StringBuilder().append(paramString).append("@Override").toString());
/* 303 */     paramPrintStream.println(new StringBuilder().append(paramString).append("public xbean.").append(this.name).append(" get").append(paramVariable.getName()).append("() { // ").append(paramVariable.getComment()).toString());
/* 304 */     Main._xdb_verify_(paramPrintStream, new StringBuilder().append(paramString).append("\t").toString());
/* 305 */     paramPrintStream.println(new StringBuilder().append(paramString).append("\treturn ").append(paramVariable.getname()).append(";").toString());
/* 306 */     paramPrintStream.println(new StringBuilder().append(paramString).append("}").toString());
/* 307 */     paramPrintStream.println();
/*     */   }
/*     */ 
/*     */   public void getterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 312 */     if (null != paramXBean)
/* 313 */       paramPrintStream.println(new StringBuilder().append(paramString).append("@Override").toString());
/* 314 */     paramPrintStream.println(new StringBuilder().append(paramString).append("public xbean.").append(this.name).append(" get").append(paramVariable.getName()).append("() { // ").append(paramVariable.getComment()).toString());
/* 315 */     paramPrintStream.println(new StringBuilder().append(paramString).append("\treturn ").append(paramVariable.getname()).append(";").toString());
/* 316 */     paramPrintStream.println(new StringBuilder().append(paramString).append("}").toString());
/* 317 */     paramPrintStream.println();
/*     */   }
/*     */ 
/*     */   public void setterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 322 */     paramPrintStream.println(new StringBuilder().append(paramString).append("public void set").append(paramVariable.getName()).append("(").append(getTypeName()).append(" _v_); // ").append(paramVariable.getComment()).toString());
/*     */   }
/*     */ 
/*     */   public void setterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 327 */     paramPrintStream.println(new StringBuilder().append(paramString).append("@Override").toString());
/* 328 */     paramPrintStream.println(new StringBuilder().append(paramString).append("public void set").append(paramVariable.getName()).append("(").append(getTypeName()).append(" _v_) { // ").append(paramVariable.getComment()).toString());
/* 329 */     Main._xdb_verify_(paramPrintStream, new StringBuilder().append(paramString).append("\t").toString());
/* 330 */     paramPrintStream.println(new StringBuilder().append(paramString).append("\tthrow new UnsupportedOperationException();").toString());
/* 331 */     paramPrintStream.println(new StringBuilder().append(paramString).append("}").toString());
/* 332 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 337 */     paramPrintStream.println(new StringBuilder().append(paramString).append("@Override").toString());
/* 338 */     paramPrintStream.println(new StringBuilder().append(paramString).append("public void set").append(paramVariable.getName()).append("(").append(getTypeName()).append(" _v_) { // ").append(paramVariable.getComment()).toString());
/* 339 */     Main._xdb_verify_(paramPrintStream, new StringBuilder().append(paramString).append("\t").toString());
/* 340 */     paramPrintStream.println(new StringBuilder().append(paramString).append("\txdb.Logs.logIf(new xdb.LogKey(this, ").append(Main.quote(paramVariable.getname())).append(") {").toString());
/* 341 */     paramPrintStream.println(new StringBuilder().append(paramString).append("\t\tprotected xdb.Log create() {").toString());
/* 342 */     paramPrintStream.println(new StringBuilder().append(paramString).append("\t\t\treturn new xdb.logs.LogObject<").append(getTypeName()).append(">(this, ").append(paramVariable.getname()).append(") {").toString());
/* 343 */     paramPrintStream.println(new StringBuilder().append(paramString).append("\t\t\t\tpublic void rollback() { ").append(paramVariable.getname()).append(" = _xdb_saved; }").toString());
/* 344 */     paramPrintStream.println(new StringBuilder().append(paramString).append("\t\t}; }});").toString());
/* 345 */     paramPrintStream.println(new StringBuilder().append(paramString).append("\t").append(paramVariable.getname()).append(" = _v_;").toString());
/* 346 */     paramPrintStream.println(new StringBuilder().append(paramString).append("}").toString());
/* 347 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 352 */     paramPrintStream.println(new StringBuilder().append(paramString).append("@Override").toString());
/* 353 */     paramPrintStream.println(new StringBuilder().append(paramString).append("public void set").append(paramVariable.getName()).append("(").append(getTypeName()).append(" _v_) { // ").append(paramVariable.getComment()).toString());
/* 354 */     paramPrintStream.println(new StringBuilder().append(paramString).append("\t").append(paramVariable.getname()).append(" = _v_;").toString());
/* 355 */     paramPrintStream.println(new StringBuilder().append(paramString).append("}").toString());
/* 356 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*     */   {
/* 361 */     return new StringBuilder().append("new xdb.logs.ListenableChanged().setVarName(").append(Main.quote(paramVariable.getname())).append(")").toString();
/*     */   }
/*     */ 
/*     */   public void printMeta(PrintStream paramPrintStream, String paramString) {
/* 365 */     paramPrintStream.println(new StringBuilder().append(paramString).append("Bean bean = new Bean(").append(Main.quote(getName())).append(", ").append(isAny()).append(", ").append(isConstant()).append(");").toString());
/*     */ 
/* 367 */     for (Variable localVariable : this.variables) {
/* 368 */       paramPrintStream.println(new StringBuilder().append(paramString).append("super.addVariableFor(bean").toString());
/* 369 */       localVariable.printMetaData(paramPrintStream, new StringBuilder().append(paramString).append("\t").toString());
/* 370 */       paramPrintStream.println(new StringBuilder().append(paramString).append("\t);").toString());
/*     */     }
/* 372 */     paramPrintStream.println(new StringBuilder().append(paramString).append("super.addBean(bean);").toString());
/*     */   }
/*     */ 
/*     */   public void depends(Set<Type> paramSet)
/*     */   {
/* 378 */     if (Type.addDepend(paramSet, this))
/* 379 */       for (Variable localVariable : this.variables)
/* 380 */         localVariable.getVartype().depends(paramSet);
/*     */   }
/*     */ 
/*     */   public void setHasModify()
/*     */   {
/* 387 */     this.hasModify = true; } 
/* 388 */   public boolean hasModify() { return this.hasModify; }
/*     */ 
/*     */   public Variable getVariable(String paramString)
/*     */   {
/* 392 */     for (Variable localVariable : this.variables)
/*     */     {
/* 394 */       if (localVariable.getname().equals(paramString))
/* 395 */         return localVariable;
/*     */     }
/* 397 */     return null;
/*     */   }
/*     */ 
/*     */   public List<Variable> getVariables()
/*     */   {
/* 402 */     return this.variables;
/*     */   }
/*     */ 
/*     */   public void skipVarMarshal(Variable paramVariable)
/*     */   {
/*     */   }
/*     */ 
/*     */   void transformMake()
/*     */   {
/* 413 */     boolean bool = Main.noverify;
/* 414 */     Main.noverify = true;
/* 415 */     _transformMake();
/* 416 */     Main.noverify = bool;
/*     */   }
/*     */   private void _transformMake() {
/* 419 */     String str = getName();
/* 420 */     PrintStream localPrintStream = Main.openBeanFile(str);
/* 421 */     localPrintStream.println("");
/* 422 */     localPrintStream.println("package xbean;");
/* 423 */     localPrintStream.println("");
/* 424 */     localPrintStream.println("import com.goldhuman.Common.Marshal.Marshal;");
/* 425 */     localPrintStream.println("import com.goldhuman.Common.Marshal.MarshalException;");
/* 426 */     localPrintStream.println("import com.goldhuman.Common.Marshal.OctetsStream;");
/* 427 */     localPrintStream.println("");
/* 428 */     localPrintStream.println(new StringBuilder().append("public class ").append(str).append(" implements Marshal, Comparable<").append(str).append("> {").toString());
/* 429 */     localPrintStream.println("");
/*     */     Variable localVariable1;
/* 430 */     for (Object localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); localVariable1.declare(localPrintStream, "\t")) localVariable1 = (Variable)((Iterator)localObject1).next();
/* 431 */     localPrintStream.println("");
/*     */ 
/* 434 */     localPrintStream.println(new StringBuilder().append("\tpublic ").append(str).append("() {").toString());
/* 435 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); localVariable1.construct(null, localPrintStream, "\t\t")) localVariable1 = (Variable)((Iterator)localObject1).next();
/* 436 */     localPrintStream.println("\t}");
/* 437 */     localPrintStream.println("");
/*     */     Object localObject3;
/*     */     Variable localVariable2;
/* 439 */     if (!this.variables.isEmpty())
/*     */     {
/* 442 */       localObject1 = new StringBuilder();
/* 443 */       int i = 1;
/* 444 */       for (localObject3 = this.variables.iterator(); ((Iterator)localObject3).hasNext(); ) { localVariable2 = (Variable)((Iterator)localObject3).next();
/* 445 */         if (i != 0) i = 0; else ((StringBuilder)localObject1).append(", ");
/* 446 */         ((StringBuilder)localObject1).append(localVariable2.getVartype().getTypeName()).append(" ").append(localVariable2.getname());
/*     */       }
/* 448 */       localPrintStream.println(new StringBuilder().append("\tpublic ").append(str).append("(").append(((StringBuilder)localObject1).toString()).append(") {").toString());
/* 449 */       for (localObject3 = this.variables.iterator(); ((Iterator)localObject3).hasNext(); ) { localVariable2 = (Variable)((Iterator)localObject3).next();
/* 450 */         localPrintStream.println(new StringBuilder().append("\t\tthis.").append(localVariable2.getname()).append(" = ").append(localVariable2.getname()).append(";").toString()); }
/* 451 */       localPrintStream.println("\t}");
/* 452 */       localPrintStream.println("");
/*     */     }
/*     */ 
/* 455 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ((Variable)localObject2).getter(null, localPrintStream, "\t")) localObject2 = (Variable)((Iterator)localObject1).next();
/*     */ 
/* 458 */     localPrintStream.println("\t@Override");
/* 459 */     localPrintStream.println("\tpublic final OctetsStream marshal(OctetsStream _os_) {");
/*     */ 
/* 461 */     for (localObject1 = this.variables.iterator(); ((Iterator)localObject1).hasNext(); ) { localObject2 = (Variable)((Iterator)localObject1).next();
/* 462 */       if (((Variable)localObject2).getModifyType() == Variable.MODIFY_TYPES.REMOVE)
/* 463 */         skipVarMarshal((Variable)localObject2);
/*     */       else
/* 465 */         ((Variable)localObject2).marshal(null, localPrintStream, "\t\t");
/*     */     }
/* 467 */     localPrintStream.println("\t\treturn _os_;");
/* 468 */     localPrintStream.println("\t}");
/* 469 */     localPrintStream.println("");
/*     */ 
/* 472 */     localPrintStream.println("\t@Override");
/* 473 */     localPrintStream.println("\tpublic final OctetsStream unmarshal(OctetsStream _os_) throws MarshalException {");
/*     */ 
/* 476 */     localObject1 = DatabaseMetaData.getInstance().getBean(getName());
/* 477 */     if (localObject1 == null)
/*     */     {
/* 479 */       for (localObject2 = this.variables.iterator(); ((Iterator)localObject2).hasNext(); ((Variable)localObject3).unmarshal(null, localPrintStream, "\t\t")) localObject3 = (Variable)((Iterator)localObject2).next();
/*     */     }
/*     */     else
/*     */     {
/* 483 */       for (localObject2 = ((DatabaseMetaData.Bean)localObject1).getVariables().iterator(); ((Iterator)localObject2).hasNext(); ) { localObject3 = (DatabaseMetaData.Bean.Variable)((Iterator)localObject2).next();
/*     */ 
/* 485 */         localVariable2 = getVariable(((DatabaseMetaData.Bean.Variable)localObject3).getName());
/* 486 */         assert (localVariable2 != null);
/* 487 */         localVariable2.unmarshal(null, localPrintStream, "\t\t");
/*     */       }
/*     */     }
/*     */ 
/* 491 */     localPrintStream.println("\t\treturn _os_;");
/* 492 */     localPrintStream.println("\t}");
/* 493 */     localPrintStream.println("");
/*     */ 
/* 496 */     localPrintStream.println("\t@Override");
/* 497 */     localPrintStream.println(new StringBuilder().append("\tpublic int compareTo(").append(getName()).append(" _o_) {").toString());
/* 498 */     localPrintStream.println("\t\tif (_o_ == this)");
/* 499 */     localPrintStream.println("\t\t\treturn 0;");
/* 500 */     localPrintStream.println("\t\tint _c_ = 0;");
/* 501 */     for (Object localObject2 = this.variables.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject3 = (Variable)((Iterator)localObject2).next();
/* 502 */       localPrintStream.println(new StringBuilder().append("\t\t_c_ = ").append(((Variable)localObject3).compareto()).append(";").toString());
/* 503 */       localPrintStream.println("\t\tif (0 != _c_) return _c_;");
/*     */     }
/* 505 */     localPrintStream.println("\t\treturn _c_;");
/* 506 */     localPrintStream.println("\t}");
/* 507 */     localPrintStream.println("");
/* 508 */     localPrintStream.println("\t@Override");
/* 509 */     localPrintStream.println("\tpublic boolean equals(Object _o_) {");
/* 510 */     localPrintStream.println(new StringBuilder().append("\t\tif (_o_ instanceof ").append(getName()).append(")").toString());
/* 511 */     localPrintStream.println(new StringBuilder().append("\t\t\treturn 0 == this.compareTo((").append(getName()).append(")_o_);").toString());
/* 512 */     localPrintStream.println("\t\treturn false;");
/* 513 */     localPrintStream.println("\t}");
/* 514 */     localPrintStream.println("");
/* 515 */     localPrintStream.println("\t@Override");
/* 516 */     localPrintStream.println("\tpublic int hashCode() {");
/* 517 */     localPrintStream.println("\t\tint _h_ = 0;");
/* 518 */     for (localObject2 = this.variables.iterator(); ((Iterator)localObject2).hasNext(); ((Variable)localObject3).hashCode(localPrintStream, "\t\t")) localObject3 = (Variable)((Iterator)localObject2).next();
/* 519 */     localPrintStream.println("\t\treturn _h_;");
/* 520 */     localPrintStream.println("\t}");
/* 521 */     localPrintStream.println("");
/* 522 */     localPrintStream.println("}");
/* 523 */     localPrintStream.close();
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.CBean
 * JD-Core Version:    0.6.2
 */