/*    */ package xgen;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public abstract class TypeBaseMap extends Type
/*    */ {
/*    */   protected Type keytype;
/*    */   protected Type valuetype;
/*    */ 
/*    */   public abstract String getName();
/*    */ 
/*    */   public abstract String getTypeName();
/*    */ 
/*    */   public abstract String getGetterName();
/*    */ 
/*    */   protected String KV()
/*    */   {
/* 15 */     return "<" + this.keytype.getBoxingName() + ", " + this.valuetype.getBoxingName() + ">";
/*    */   }
/*    */ 
/*    */   public String getBoxingName()
/*    */   {
/* 20 */     return getGetterName();
/*    */   }
/*    */ 
/*    */   public boolean isConstant()
/*    */   {
/* 25 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean isCloneable()
/*    */   {
/* 30 */     return this.valuetype.isCloneable();
/*    */   }
/*    */ 
/*    */   public void printTableSelectMethod(PrintStream paramPrintStream, String paramString)
/*    */   {
/* 35 */     throw new UnsupportedOperationException("select for " + getName());
/*    */   }
/*    */ 
/*    */   public String deepCopy(boolean paramBoolean, Variable paramVariable, String paramString)
/*    */   {
/* 40 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void deepCopy(boolean paramBoolean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*    */   {
/* 45 */     paramPrintStream.println(paramString + paramVariable.getname() + " = new " + getTypeName() + "();");
/* 46 */     String str1 = this.keytype.isConstant() ? "_e_.getKey()" : this.keytype.deepCopy(paramBoolean, paramVariable, "_e_.getKey()");
/* 47 */     String str2 = this.valuetype.isConstant() ? "_e_.getValue()" : this.valuetype.deepCopy(paramBoolean, paramVariable, "_e_.getValue()");
/* 48 */     paramPrintStream.println(paramString + "for (java.util.Map.Entry" + KV() + " _e_ : _o_." + paramVariable.getname() + ".entrySet())");
/* 49 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + ".put(" + str1 + ", " + str2 + ");");
/*    */   }
/*    */ 
/*    */   public void getterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*    */   {
/* 54 */     paramPrintStream.println(paramString + "@Override");
/* 55 */     paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 56 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 57 */     paramPrintStream.println(paramString + "}");
/* 58 */     paramPrintStream.println("");
/*    */ 
/* 60 */     if (isCloneable()) {
/* 61 */       paramPrintStream.println(paramString + "@Override");
/* 62 */       paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "AsData() { // " + paramVariable.getComment());
/* 63 */       paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 64 */       paramPrintStream.println(paramString + "}");
/* 65 */       paramPrintStream.println("");
/*    */     }
/*    */   }
/*    */ 
/*    */   public void getterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*    */   {
/* 71 */     paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "(); // " + paramVariable.getComment());
/* 72 */     if (isCloneable())
/* 73 */       paramPrintStream.println(paramString + "public " + getGetterName() + " get" + paramVariable.getName() + "AsData(); // " + paramVariable.getComment());
/*    */   }
/*    */ 
/*    */   public void setter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void setterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void setterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void setterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*    */   {
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeBaseMap
 * JD-Core Version:    0.6.2
 */