/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TypeBinary extends Type
/*     */ {
/*     */   public void printTableSelectMethod(PrintStream paramPrintStream, String paramString)
/*     */   {
/*  11 */     throw new UnsupportedOperationException("select for " + getName());
/*     */   }
/*     */ 
/*     */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*     */   {
/*  16 */     paramForeign.warn("[binary] this foreign is unverifiable.");
/*     */   }
/*     */ 
/*     */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*     */   {
/*  21 */     paramCapacity.capacityOnly();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  26 */     return "binary";
/*     */   }
/*     */ 
/*     */   public Type compile(String paramString1, String paramString2)
/*     */   {
/*  31 */     if ((paramString1 != null) && (!paramString1.isEmpty()))
/*  32 */       throw new RuntimeException(getName() + " DO NOT NEED A KEY!");
/*  33 */     if ((paramString2 != null) && (!paramString2.isEmpty()))
/*  34 */       throw new RuntimeException(getName() + " DO NOT NEED A VALUE!");
/*  35 */     return this;
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/*  40 */     return "byte []";
/*     */   }
/*     */ 
/*     */   public String getBoxingName()
/*     */   {
/*  45 */     return getTypeName();
/*     */   }
/*     */ 
/*     */   public boolean isConstant()
/*     */   {
/*  50 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isCloneable()
/*     */   {
/*  55 */     return true;
/*     */   }
/*     */ 
/*     */   public String notEquals(String paramString)
/*     */   {
/*  60 */     return "!java.util.Arrays.equals(" + paramString + ", _o_." + paramString + ")";
/*     */   }
/*     */ 
/*     */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*     */   {
/*  65 */     return defineNoParent(paramString);
/*     */   }
/*     */ 
/*     */   public String defineNoParent(String paramString)
/*     */   {
/*  70 */     return "byte [] " + paramString + " = new byte [0];";
/*     */   }
/*     */ 
/*     */   public String hashCode(String paramString)
/*     */   {
/*  75 */     return "java.util.Arrays.hashCode(" + paramString + ")";
/*     */   }
/*     */ 
/*     */   public void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/*  80 */     paramPrintStream.println(paramString1 + "_os_.marshal(" + paramString2 + ");");
/*     */   }
/*     */ 
/*     */   public void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/*  85 */     paramPrintStream.println(paramString1 + paramString2 + " = _os_.unmarshal_bytes();");
/*     */   }
/*     */ 
/*     */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/*  90 */     paramPrintStream.println(paramString + paramVariable.getname() + " = new byte[0];");
/*     */   }
/*     */ 
/*     */   public String deepCopy(boolean paramBoolean, Variable paramVariable, String paramString)
/*     */   {
/*  95 */     return "java.util.Arrays.copyOf(" + paramString + ", " + paramString + ".length)";
/*     */   }
/*     */ 
/*     */   public void deepCopy(boolean paramBoolean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 100 */     paramPrintStream.println(paramString + paramVariable.getname() + " = " + deepCopy(paramBoolean, paramVariable, new StringBuilder().append("_o_.").append(paramVariable.getname()).toString()) + ";");
/*     */   }
/*     */ 
/*     */   public void getterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 105 */     paramPrintStream.println(paramString + "public <T extends com.goldhuman.Common.Marshal.Marshal> T get" + paramVariable.getName() + "(T _v_); // " + paramVariable.getComment());
/*     */ 
/* 107 */     paramPrintStream.println(paramString + "public boolean is" + paramVariable.getName() + "Empty(); // " + paramVariable.getComment());
/* 108 */     paramPrintStream.println(paramString + "public byte[] get" + paramVariable.getName() + "Copy(); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 113 */     paramPrintStream.println(paramString + "@Override");
/* 114 */     paramPrintStream.println(paramString + "public <T extends com.goldhuman.Common.Marshal.Marshal> T get" + paramVariable.getName() + "(T _v_) { // " + paramVariable.getComment());
/*     */ 
/* 116 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 117 */     paramPrintStream.println(paramString + "\treturn " + paramXBean.getName() + ".this.get" + paramVariable.getName() + "(_v_);");
/* 118 */     paramPrintStream.println(paramString + "}");
/* 119 */     paramPrintStream.println("");
/*     */ 
/* 121 */     paramPrintStream.println(paramString + "@Override");
/* 122 */     paramPrintStream.println(paramString + "public boolean is" + paramVariable.getName() + "Empty() { // " + paramVariable.getComment());
/* 123 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 124 */     paramPrintStream.println(paramString + "\treturn " + paramXBean.getName() + ".this.is" + paramVariable.getName() + "Empty();");
/* 125 */     paramPrintStream.println(paramString + "}");
/* 126 */     paramPrintStream.println("");
/*     */ 
/* 128 */     paramPrintStream.println(paramString + "@Override");
/* 129 */     paramPrintStream.println(paramString + "public byte[] get" + paramVariable.getName() + "Copy() { // " + paramVariable.getComment());
/* 130 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 131 */     paramPrintStream.println(paramString + "\treturn " + paramXBean.getName() + ".this.get" + paramVariable.getName() + "Copy();");
/* 132 */     paramPrintStream.println(paramString + "}");
/* 133 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 138 */     paramPrintStream.println(paramString + "@Override");
/* 139 */     paramPrintStream.println(paramString + "public <T extends com.goldhuman.Common.Marshal.Marshal> T get" + paramVariable.getName() + "(T _v_) { // " + paramVariable.getComment());
/*     */ 
/* 141 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 142 */     paramPrintStream.println(paramString + "\ttry {");
/* 143 */     paramPrintStream.println(paramString + "\t\t_v_.unmarshal(OctetsStream.wrap(com.goldhuman.Common.Octets.wrap(" + paramVariable.getname() + ")));");
/* 144 */     paramPrintStream.println(paramString + "\t\treturn _v_;");
/* 145 */     paramPrintStream.println(paramString + "\t} catch (MarshalException _e_) {");
/* 146 */     paramPrintStream.println(paramString + "\t\tthrow new xio.MarshalError();");
/* 147 */     paramPrintStream.println(paramString + "\t}");
/* 148 */     paramPrintStream.println(paramString + "}");
/* 149 */     paramPrintStream.println("");
/*     */ 
/* 151 */     paramPrintStream.println(paramString + "@Override");
/* 152 */     paramPrintStream.println(paramString + "public boolean is" + paramVariable.getName() + "Empty() { // " + paramVariable.getComment());
/* 153 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 154 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ".length == 0;");
/* 155 */     paramPrintStream.println(paramString + "}");
/* 156 */     paramPrintStream.println("");
/*     */ 
/* 158 */     paramPrintStream.println(paramString + "@Override");
/* 159 */     paramPrintStream.println(paramString + "public byte[] get" + paramVariable.getName() + "Copy() { // " + paramVariable.getComment());
/* 160 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 161 */     paramPrintStream.println(paramString + "\treturn java.util.Arrays.copyOf(" + paramVariable.getname() + ", " + paramVariable.getname() + ".length);");
/* 162 */     paramPrintStream.println(paramString + "}");
/* 163 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void getterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 168 */     paramPrintStream.println(paramString + "@Override");
/* 169 */     paramPrintStream.println(paramString + "public <T extends com.goldhuman.Common.Marshal.Marshal> T get" + paramVariable.getName() + "(T _v_) { // " + paramVariable.getComment());
/*     */ 
/* 171 */     paramPrintStream.println(paramString + "\ttry {");
/* 172 */     paramPrintStream.println(paramString + "\t\t_v_.unmarshal(OctetsStream.wrap(com.goldhuman.Common.Octets.wrap(" + paramVariable.getname() + ")));");
/* 173 */     paramPrintStream.println(paramString + "\t\treturn _v_;");
/* 174 */     paramPrintStream.println(paramString + "\t} catch (MarshalException _e_) {");
/* 175 */     paramPrintStream.println(paramString + "\t\tthrow new xio.MarshalError();");
/* 176 */     paramPrintStream.println(paramString + "\t}");
/* 177 */     paramPrintStream.println(paramString + "}");
/* 178 */     paramPrintStream.println("");
/*     */ 
/* 180 */     paramPrintStream.println(paramString + "@Override");
/* 181 */     paramPrintStream.println(paramString + "public boolean is" + paramVariable.getName() + "Empty() { // " + paramVariable.getComment());
/* 182 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ".length == 0;");
/* 183 */     paramPrintStream.println(paramString + "}");
/* 184 */     paramPrintStream.println("");
/*     */ 
/* 186 */     paramPrintStream.println(paramString + "@Override");
/* 187 */     paramPrintStream.println(paramString + "public byte[] get" + paramVariable.getName() + "Copy() { // " + paramVariable.getComment());
/* 188 */     paramPrintStream.println(paramString + "\treturn java.util.Arrays.copyOf(" + paramVariable.getname() + ", " + paramVariable.getname() + ".length);");
/* 189 */     paramPrintStream.println(paramString + "}");
/* 190 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 195 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(com.goldhuman.Common.Marshal.Marshal _v_); // " + paramVariable.getComment());
/* 196 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "Copy(byte[] _v_); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void setterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 201 */     paramPrintStream.println(paramString + "@Override");
/* 202 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(com.goldhuman.Common.Marshal.Marshal _v_) { // " + paramVariable.getComment());
/* 203 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 204 */     paramPrintStream.println(paramString + "\tthrow new UnsupportedOperationException();");
/* 205 */     paramPrintStream.println(paramString + "}");
/* 206 */     paramPrintStream.println("");
/*     */ 
/* 208 */     paramPrintStream.println(paramString + "@Override");
/* 209 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "Copy(byte[] _v_) { // " + paramVariable.getComment());
/* 210 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 211 */     paramPrintStream.println(paramString + "\tthrow new UnsupportedOperationException();");
/* 212 */     paramPrintStream.println(paramString + "}");
/* 213 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 218 */     paramPrintStream.println(paramString + "@Override");
/* 219 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(com.goldhuman.Common.Marshal.Marshal _v_) { // " + paramVariable.getComment());
/* 220 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 221 */     paramPrintStream.println(paramString + "\txdb.Logs.logIf(new xdb.LogKey(this, " + Main.quote(paramVariable.getname()) + ") {");
/* 222 */     paramPrintStream.println(paramString + "\t\tprotected xdb.Log create() {");
/* 223 */     paramPrintStream.println(paramString + "\t\t\treturn new xdb.logs.LogObject<" + getTypeName() + ">(this, " + paramVariable.getname() + ") {");
/* 224 */     paramPrintStream.println(paramString + "\t\t\t\tpublic void rollback() { " + paramVariable.getname() + " = _xdb_saved; }");
/* 225 */     paramPrintStream.println(paramString + "\t\t}; }});");
/* 226 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_.marshal(new OctetsStream()).getBytes();");
/* 227 */     paramPrintStream.println(paramString + "}");
/* 228 */     paramPrintStream.println("");
/*     */ 
/* 230 */     paramPrintStream.println(paramString + "@Override");
/* 231 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "Copy(byte[] _v_) { // " + paramVariable.getComment());
/* 232 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 233 */     paramPrintStream.println(paramString + "\txdb.Logs.logIf(new xdb.LogKey(this, " + Main.quote(paramVariable.getname()) + ") {");
/* 234 */     paramPrintStream.println(paramString + "\t\tprotected xdb.Log create() {");
/* 235 */     paramPrintStream.println(paramString + "\t\t\treturn new xdb.logs.LogObject<" + getTypeName() + ">(this, " + paramVariable.getname() + ") {");
/* 236 */     paramPrintStream.println(paramString + "\t\t\t\tpublic void rollback() { " + paramVariable.getname() + " = _xdb_saved; }");
/* 237 */     paramPrintStream.println(paramString + "\t\t}; }});");
/* 238 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = java.util.Arrays.copyOf(_v_, _v_.length);");
/* 239 */     paramPrintStream.println(paramString + "}");
/* 240 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 245 */     paramPrintStream.println(paramString + "@Override");
/* 246 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(com.goldhuman.Common.Marshal.Marshal _v_) { // " + paramVariable.getComment());
/* 247 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_.marshal(new OctetsStream()).getBytes();");
/* 248 */     paramPrintStream.println(paramString + "}");
/* 249 */     paramPrintStream.println("");
/*     */ 
/* 251 */     paramPrintStream.println(paramString + "@Override");
/* 252 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "Copy(byte[] _v_) { // " + paramVariable.getComment());
/* 253 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = java.util.Arrays.copyOf(_v_, _v_.length);");
/* 254 */     paramPrintStream.println(paramString + "}");
/* 255 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*     */   {
/* 260 */     return "new xdb.logs.ListenableChanged().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*     */   }
/*     */ 
/*     */   public void toString(PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 265 */     paramPrintStream.println(paramString1 + "_sb_.append('B').append(" + paramString2 + ".length);");
/*     */   }
/*     */ 
/*     */   TypeBinary(Map<String, Type> paramMap)
/*     */   {
/* 273 */     paramMap.put(getName(), this);
/*     */   }
/*     */ 
/*     */   public void depends(Set<Type> paramSet)
/*     */   {
/* 278 */     paramSet.add(this);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeBinary
 * JD-Core Version:    0.6.2
 */