/*     */ package xgen;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TypeInt extends Type
/*     */ {
/*     */   public void printTableSelectMethod(PrintStream paramPrintStream, String paramString)
/*     */   {
/*  10 */     String str = getBoxingName();
/*  11 */     paramPrintStream.println("\tpublic static " + str + " select(" + paramString + " key) {");
/*  12 */     paramPrintStream.println("\t\treturn getTable().select(key, new xdb.TField<" + str + ", " + str + ">() {");
/*  13 */     paramPrintStream.println("\t\t\tpublic " + str + " get(" + str + " v) { return v; }");
/*  14 */     paramPrintStream.println("\t\t});");
/*  15 */     paramPrintStream.println("\t}");
/*  16 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  21 */     return "int";
/*     */   }
/*     */ 
/*     */   public void verifyForeign(Xdb paramXdb, Foreign paramForeign)
/*     */   {
/*  26 */     paramForeign.throwIf(null != paramForeign.getKey(), "[int] need value only.");
/*  27 */     if (null != paramForeign.getValue()) {
/*  28 */       Table localTable = paramXdb.getTable(paramForeign.getValue());
/*  29 */       paramForeign.throwIf(null == localTable, "[int] table not exist.");
/*  30 */       paramForeign.throwIf(localTable.isMemory(), "[int] foreign table is memory");
/*  31 */       paramForeign.throwIf(localTable.getKeyType() != this, "[int] type not match");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void verifyCapacity(Xdb paramXdb, Capacity paramCapacity)
/*     */   {
/*  37 */     paramCapacity.notNeed();
/*     */   }
/*     */ 
/*     */   public Type compile(String paramString1, String paramString2)
/*     */   {
/*  42 */     if ((paramString1 != null) && (!paramString1.isEmpty()))
/*  43 */       throw new RuntimeException(getName() + " DO NOT NEED A KEY!");
/*  44 */     if ((paramString2 != null) && (!paramString2.isEmpty()))
/*  45 */       throw new RuntimeException(getName() + " DO NOT NEED A VALUE!");
/*  46 */     return this;
/*     */   }
/*     */ 
/*     */   public String compareto(String paramString1, String paramString2)
/*     */   {
/*  51 */     return "Integer.signum(" + paramString1 + " - " + paramString2 + ")";
/*     */   }
/*     */ 
/*     */   public String getBoxingName() {
/*  55 */     return "Integer";
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/*  60 */     return "int";
/*     */   }
/*     */ 
/*     */   public String notEquals(String paramString)
/*     */   {
/*  65 */     return paramString + " != _o_." + paramString;
/*     */   }
/*     */ 
/*     */   public String hashCode(String paramString)
/*     */   {
/*  70 */     return paramString;
/*     */   }
/*     */ 
/*     */   public boolean isConstant()
/*     */   {
/*  75 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isCloneable()
/*     */   {
/*  80 */     return true;
/*     */   }
/*     */ 
/*     */   public String defineNoParent(String paramString)
/*     */   {
/*  85 */     return getTypeName() + " " + paramString + " = 0;";
/*     */   }
/*     */ 
/*     */   public String defineSetParent(XBean paramXBean, Variable paramVariable, String paramString)
/*     */   {
/*  90 */     return defineNoParent(paramString);
/*     */   }
/*     */ 
/*     */   public void marshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/*  95 */     paramPrintStream.println(paramString1 + "_os_.marshal(" + paramString2 + ");");
/*     */   }
/*     */ 
/*     */   public String deepCopy(boolean paramBoolean, Variable paramVariable, String paramString)
/*     */   {
/* 100 */     return paramString;
/*     */   }
/*     */ 
/*     */   public void deepCopy(boolean paramBoolean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 105 */     paramPrintStream.println(paramString + paramVariable.getname() + " = _o_." + paramVariable.getname() + ";");
/*     */   }
/*     */ 
/*     */   public void construct(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 110 */     String str = paramVariable.getInitial();
/* 111 */     if (!str.isEmpty())
/* 112 */       paramPrintStream.println(paramString + paramVariable.getname() + " = " + str + ";");
/*     */   }
/*     */ 
/*     */   public void unmarshal(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString1, String paramString2)
/*     */   {
/* 117 */     paramPrintStream.println(paramString1 + paramString2 + " = _os_.unmarshal_int();");
/*     */   }
/*     */ 
/*     */   TypeInt(Map<String, Type> paramMap)
/*     */   {
/* 125 */     paramMap.put(getName(), this);
/*     */   }
/*     */ 
/*     */   public void getterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 130 */     paramPrintStream.println(paramString + "public int get" + paramVariable.getName() + "(); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void getter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 135 */     if (null != paramXBean)
/* 136 */       paramPrintStream.println(paramString + "@Override");
/* 137 */     paramPrintStream.println(paramString + "public int get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 138 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 139 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 140 */     paramPrintStream.println(paramString + "}");
/* 141 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void getterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 146 */     getter(paramXBean, paramVariable, paramPrintStream, paramString);
/*     */   }
/*     */ 
/*     */   public void getterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 151 */     if (null != paramXBean)
/* 152 */       paramPrintStream.println(paramString + "@Override");
/* 153 */     paramPrintStream.println(paramString + "public int get" + paramVariable.getName() + "() { // " + paramVariable.getComment());
/* 154 */     paramPrintStream.println(paramString + "\treturn " + paramVariable.getname() + ";");
/* 155 */     paramPrintStream.println(paramString + "}");
/* 156 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setterInterface(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 161 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(int _v_); // " + paramVariable.getComment());
/*     */   }
/*     */ 
/*     */   public void setterConst(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 166 */     paramPrintStream.println(paramString + "@Override");
/* 167 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(int _v_) { // " + paramVariable.getComment());
/* 168 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 169 */     paramPrintStream.println(paramString + "\tthrow new UnsupportedOperationException();");
/* 170 */     paramPrintStream.println(paramString + "}");
/* 171 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setter(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 176 */     paramPrintStream.println(paramString + "@Override");
/* 177 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(int _v_) { // " + paramVariable.getComment());
/* 178 */     Main._xdb_verify_(paramPrintStream, paramString + "\t");
/* 179 */     paramPrintStream.println(paramString + "\txdb.Logs.logIf(new xdb.LogKey(this, " + Main.quote(paramVariable.getname()) + ") {");
/* 180 */     paramPrintStream.println(paramString + "\t\tprotected xdb.Log create() {");
/* 181 */     paramPrintStream.println(paramString + "\t\t\treturn new xdb.logs.LogInt(this, " + paramVariable.getname() + ") {");
/* 182 */     paramPrintStream.println(paramString + "\t\t\t\tpublic void rollback() { " + paramVariable.getname() + " = _xdb_saved; }");
/* 183 */     paramPrintStream.println(paramString + "\t\t\t};}});");
/* 184 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_;");
/* 185 */     paramPrintStream.println(paramString + "}");
/* 186 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public void setterData(XBean paramXBean, Variable paramVariable, PrintStream paramPrintStream, String paramString)
/*     */   {
/* 191 */     paramPrintStream.println(paramString + "@Override");
/* 192 */     paramPrintStream.println(paramString + "public void set" + paramVariable.getName() + "(int _v_) { // " + paramVariable.getComment());
/* 193 */     paramPrintStream.println(paramString + "\t" + paramVariable.getname() + " = _v_;");
/* 194 */     paramPrintStream.println(paramString + "}");
/* 195 */     paramPrintStream.println("");
/*     */   }
/*     */ 
/*     */   public String newListenable(XBean paramXBean, Variable paramVariable)
/*     */   {
/* 200 */     return "new xdb.logs.ListenableChanged().setVarName(" + Main.quote(paramVariable.getname()) + ")";
/*     */   }
/*     */ 
/*     */   public void depends(Set<Type> paramSet)
/*     */   {
/* 205 */     paramSet.add(this);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.TypeInt
 * JD-Core Version:    0.6.2
 */