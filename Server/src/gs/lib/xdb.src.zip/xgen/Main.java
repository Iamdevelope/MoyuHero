/*     */ package xgen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ public class Main
/*     */ {
/*     */   private static Xdb xdb;
/*  16 */   public static String outputEncoding = "GBK";
/*  17 */   private static boolean nowarn = false;
/*  18 */   private static String warn = "cfo";
/*  19 */   static boolean noverify = false;
/*     */ 
/*  22 */   static boolean explicitLockCheck = false;
/*  23 */   static Set<String> explicitLockIgnoreTables = new TreeSet();
/*     */ 
/*  26 */   private static boolean transform = false;
/*  27 */   private static String srcdb = null;
/*  28 */   private static String destdb = null;
/*     */ 
/*  30 */   private static boolean transformCheck = false;
/*     */ 
/*     */   private static void usage() {
/*  33 */     System.out.println("Usage: java -jar xgen.jar [options] xdb.xml");
/*  34 */     System.out.println("\t-outputEncoding  encoding.");
/*  35 */     System.out.println("\t-output          output dir.");
/*  36 */     System.out.println("\t-nowarn          do not print warning message.");
/*  37 */     System.out.println("\t-warn [cfo]      select warning message. c=capacity, f=foreign, o=owner.");
/*  38 */     System.out.println("\t-noverify        do not generate xbean verify code.");
/*  39 */     System.out.println("\t-transform       for Tranform db");
/*  40 */     System.out.println("\t-srcdb           tranform src db Dir. ");
/*  41 */     System.out.println("\t-destdb          tranform dest db Dir. ");
/*  42 */     System.out.println("\t-transformCheck  for check tranform is need to transform or not");
/*  43 */     System.out.println("\t-explicitLockCheck [tale1:table2]  生成检查显示获得锁的代码, ");
/*  44 */     System.out.println("\t                 其中：[]中冒号分隔的是忽略explicitLockCheck的表");
/*  45 */     System.out.println("\t                       检查包括{add(fail),get,delete,remove} 不包括{add(success),insert,select}");
/*  46 */     Runtime.getRuntime().exit(1);
/*     */   }
/*     */ 
/*     */   public static void _xdb_verify_(PrintStream paramPrintStream, String paramString) {
/*  50 */     if (!noverify)
/*  51 */       paramPrintStream.println(paramString + "_xdb_verify_unsafe_();");
/*     */   }
/*     */ 
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/*  55 */     System.setProperty("line.separator", "\n");
/*  56 */     String str1 = null;
/*  57 */     String str2 = null;
/*     */ 
/*  59 */     for (int i = 0; i < paramArrayOfString.length; i++) {
/*  60 */       if (paramArrayOfString[i].equals("-outputEncoding")) { outputEncoding = paramArrayOfString[(++i)];
/*  61 */       } else if (paramArrayOfString[i].equals("-output")) { str2 = paramArrayOfString[(++i)];
/*  62 */       } else if (paramArrayOfString[i].equals("-nowarn")) { nowarn = true;
/*  63 */       } else if (paramArrayOfString[i].equals("-warn")) {
/*  64 */         if ((i + 1 < paramArrayOfString.length) && (!paramArrayOfString[(i + 1)].startsWith("-")))
/*  65 */           warn = paramArrayOfString[(++i)].toLowerCase();
/*     */         else
/*  67 */           warn = "";
/*     */       }
/*  69 */       else if (paramArrayOfString[i].equals("-noverify")) { noverify = true;
/*  70 */       } else if (paramArrayOfString[i].equals("-transform")) { transform = true;
/*  71 */       } else if (paramArrayOfString[i].equals("-transformCheck")) { transformCheck = true;
/*  72 */       } else if (paramArrayOfString[i].equals("-srcdb")) { srcdb = paramArrayOfString[(++i)];
/*  73 */       } else if (paramArrayOfString[i].equals("-destdb")) { destdb = paramArrayOfString[(++i)];
/*  74 */       } else if (paramArrayOfString[i].equals("-explicitLockCheck")) {
/*  75 */         explicitLockCheck = true;
/*  76 */         if ((i + 1 < paramArrayOfString.length) && (paramArrayOfString[(i + 1)].startsWith("["))) {
/*  77 */           i++;
/*  78 */           if ((!paramArrayOfString[i].startsWith("[")) || (!paramArrayOfString[i].endsWith("]")))
/*  79 */             usage();
/*  80 */           localObject1 = paramArrayOfString[i].substring(1, paramArrayOfString[i].length() - 1).split(":");
/*  81 */           for (Object localObject3 : localObject1) {
/*  82 */             if (!localObject3.equals(""))
/*  83 */               explicitLockIgnoreTables.add(localObject3);
/*     */           }
/*     */         }
/*     */       }
/*  87 */       else if (str1 == null) {
/*  88 */         str1 = paramArrayOfString[i];
/*     */       } else {
/*  90 */         usage();
/*     */       }
/*     */     }
/*  93 */     if (null == str1) {
/*  94 */       usage();
/*     */     }
/*  96 */     if (transform == true)
/*     */     {
/*  98 */       if (srcdb == null)
/*     */       {
/* 100 */         System.out.println("-srcdb need to been set!");
/* 101 */         usage();
/*     */       }
/* 103 */       if (destdb == null)
/*     */       {
/* 105 */         System.out.println("-destdb need to been set!");
/* 106 */         usage();
/*     */       }
/*     */     }
/*     */ 
/* 110 */     Document localDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(str1);
/* 111 */     Object localObject1 = localDocument.getDocumentElement();
/* 112 */     if (null != str2)
/* 113 */       ((Element)localObject1).setAttribute("xgenOutput", str2);
/* 114 */     xdb = new Xdb((Element)localObject1);
/* 115 */     xdb.compile();
/* 116 */     xdb.clean();
/* 117 */     if ((!transform) && (!transformCheck))
/*     */     {
/* 119 */       xdb.make();
/*     */     }
/*     */     else
/*     */     {
/* 124 */       xdb.transformMake();
/*     */     }
/*     */   }
/*     */ 
/*     */   static void warn(String paramString, char paramChar) {
/* 129 */     if ((!nowarn) && (warn.indexOf(paramChar) > -1))
/* 130 */       System.err.println("WARN " + paramString);
/*     */   }
/*     */ 
/*     */   static PrintStream openBeanFile(String paramString) {
/* 134 */     File localFile = xdb.getXbeandir();
/* 135 */     return fopen(localFile, paramString);
/*     */   }
/*     */ 
/*     */   static PrintStream openBean__File(String paramString) {
/* 139 */     File localFile = xdb.getXbeandir__();
/* 140 */     return fopen(localFile, paramString);
/*     */   }
/*     */ 
/*     */   static PrintStream openTableFile(String paramString) {
/* 144 */     File localFile = xdb.getXtabledir();
/* 145 */     return fopen(localFile, paramString);
/*     */   }
/*     */ 
/*     */   static PrintStream fopen(File paramFile, String paramString) {
/*     */     try {
/* 150 */       File localFile = new File(paramFile, paramString + ".java");
/*     */ 
/* 152 */       return new PrintStream(new FileOutputStream(localFile), false, outputEncoding);
/*     */     } catch (Exception localException) {
/* 154 */       throw new RuntimeException(localException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String toUpper1(String paramString) {
/* 159 */     return paramString.substring(0, 1).toUpperCase() + paramString.substring(1);
/*     */   }
/*     */ 
/*     */   public static String quote(String paramString) {
/* 163 */     return "\"" + paramString + "\"";
/*     */   }
/*     */ 
/*     */   public static void verifyName(String paramString) {
/* 167 */     if ((paramString.startsWith("_")) && (paramString.endsWith("_")))
/* 168 */       throw new RuntimeException("Invalid Name of '" + paramString + "'. the name like '_*_' is reserved");
/*     */   }
/*     */ 
/*     */   static PrintStream openTransformMainFile(String paramString) {
/* 172 */     File localFile = xdb.getXgenOutputdir();
/* 173 */     return fopen(localFile, paramString);
/*     */   }
/*     */ 
/*     */   static String getTransformSrcDb()
/*     */   {
/* 178 */     return srcdb;
/*     */   }
/*     */ 
/*     */   static String getTransformDestDb()
/*     */   {
/* 183 */     return destdb;
/*     */   }
/*     */ 
/*     */   static void doTransformCheck(boolean paramBoolean)
/*     */   {
/* 190 */     if (transformCheck)
/*     */     {
/* 192 */       if (paramBoolean)
/*     */       {
/* 194 */         System.exit(100);
/*     */       }
/*     */       else
/*     */       {
/* 198 */         System.exit(101);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.Main
 * JD-Core Version:    0.6.2
 */