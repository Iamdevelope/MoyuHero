/*    */ package xgen;
/*    */ 
/*    */ import xdb.util.CapacityConf;
/*    */ 
/*    */ public class Capacity extends CapacityConf
/*    */ {
/*    */   private final String message;
/*    */ 
/*    */   public void throwIf(boolean paramBoolean, String paramString)
/*    */   {
/* 11 */     if (paramBoolean)
/* 12 */       throw new IllegalArgumentException("invalid capacity! " + this.message + " info=" + paramString);
/*    */   }
/*    */ 
/*    */   public void warnIf(boolean paramBoolean, String paramString) {
/* 16 */     if (paramBoolean)
/* 17 */       Main.warn(this.message + " info=" + paramString, 'c');
/*    */   }
/*    */ 
/*    */   public void notNeed()
/*    */   {
/* 24 */     warnIf((super.getCapacity() != null) || (super.getKey() != null) || (super.getValue() != null), "capacity is not required.");
/*    */   }
/*    */ 
/*    */   public void capacityNeed()
/*    */   {
/* 35 */     warnIf(super.getCapacity() == null, "capacity is required.");
/*    */   }
/*    */ 
/*    */   public void keyNotNeed()
/*    */   {
/* 42 */     warnIf(super.getKey() != null, "capacity.key is not required.");
/*    */   }
/*    */ 
/*    */   public void valueNotNeed()
/*    */   {
/* 49 */     warnIf(super.getValue() != null, "capacity.value is not required.");
/*    */   }
/*    */ 
/*    */   public void capacityOnly()
/*    */   {
/* 56 */     capacityNeed();
/* 57 */     keyNotNeed();
/* 58 */     valueNotNeed();
/*    */   }
/*    */ 
/*    */   public Capacity extractKey() {
/* 62 */     return new Capacity(super.getKey(), null, null, this.message + "<key>");
/*    */   }
/*    */ 
/*    */   public Capacity extractValue() {
/* 66 */     return new Capacity(super.getValue(), null, null, this.message + "<value>");
/*    */   }
/*    */ 
/*    */   public Capacity(Integer paramInteger1, Integer paramInteger2, Integer paramInteger3, String paramString) {
/* 70 */     super(paramInteger1, paramInteger2, paramInteger3);
/* 71 */     this.message = paramString;
/*    */   }
/*    */ 
/*    */   public Capacity(String paramString1, String paramString2) {
/* 75 */     super(paramString1);
/* 76 */     this.message = ("CAPACITY conf=" + Main.quote(paramString1) + " name=" + paramString2);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xgen.Capacity
 * JD-Core Version:    0.6.2
 */