/*    */ package xio;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Filter
/*    */ {
/*    */   private final String name;
/*    */ 
/*    */   public Filter(String paramString)
/*    */   {
/*  9 */     this.name = paramString;
/*    */   }
/*    */ 
/*    */   public final String getName() {
/* 13 */     return this.name;
/*    */   }
/*    */ 
/*    */   protected void doFilter(Iterator paramIterator, ByteBuffer paramByteBuffer, Xio paramXio)
/*    */   {
/* 25 */     paramIterator.doFilterNextOf(this, paramByteBuffer, paramXio);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 30 */     return this.name;
/*    */   }
/*    */ 
/*    */   public static abstract interface Iterator
/*    */   {
/*    */     public abstract void doFilterNextOf(Filter paramFilter, ByteBuffer paramByteBuffer, Xio paramXio);
/*    */   }
/*    */ 
/*    */   public static class List
/*    */   {
/* 42 */     private final ArrayList<Filter> filters = new ArrayList();
/*    */ 
/*    */     private final int indexOf(String paramString) {
/* 45 */       for (int i = 0; i < this.filters.size(); i++)
/* 46 */         if (((Filter)this.filters.get(i)).getName().equals(paramString))
/* 47 */           return i;
/* 48 */       return -2;
/*    */     }
/*    */ 
/*    */     private final void add(int paramInt, Filter paramFilter) {
/* 52 */       if (paramInt < 0)
/* 53 */         throw new ArrayIndexOutOfBoundsException();
/* 54 */       if (indexOf(paramFilter.getName()) >= 0)
/* 55 */         throw new IllegalStateException();
/* 56 */       this.filters.add(paramInt, paramFilter);
/*    */     }
/*    */ 
/*    */     public void addAfter(String paramString, Filter paramFilter) {
/* 60 */       synchronized (this) { add(indexOf(paramString) + 1, paramFilter); }
/*    */     }
/*    */ 
/*    */     public void addBefore(String paramString, Filter paramFilter) {
/* 64 */       synchronized (this) { add(indexOf(paramString), paramFilter); }
/*    */     }
/*    */ 
/*    */     public void addFirst(Filter paramFilter) {
/* 68 */       synchronized (this) { add(0, paramFilter); }
/*    */     }
/*    */ 
/*    */     public void addLast(Filter paramFilter) {
/* 72 */       synchronized (this) { add(this.filters.size(), paramFilter); }
/*    */     }
/*    */ 
/*    */     public void clear() {
/* 76 */       synchronized (this) { this.filters.clear(); }
/*    */     }
/*    */ 
/*    */     public Filter get(String paramString) {
/* 80 */       synchronized (this) {
/* 81 */         int i = indexOf(paramString);
/* 82 */         if (i < 0)
/* 83 */           return null;
/* 84 */         return (Filter)this.filters.get(i);
/*    */       }
/*    */     }
/*    */ 
/*    */     public Filter remove(String paramString) {
/* 89 */       synchronized (this) { return (Filter)this.filters.remove(indexOf(paramString)); }
/*    */     }
/*    */ 
/*    */     public String toString() {
/* 93 */       synchronized (this) { return this.filters.toString(); }
/*    */     }
/*    */ 
/*    */     final List<Filter> raw()
/*    */     {
/* 98 */       return this.filters;
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.Filter
 * JD-Core Version:    0.6.2
 */