/*    */ package xio;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.UnknownHostException;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public final class Helper
/*    */ {
/*    */   public static final int MAX_BUFFER_SIZE = 1073741824;
/*    */ 
/*    */   public static int roudup(int paramInt)
/*    */   {
/* 14 */     if ((paramInt < 0) || (paramInt > 1073741824))
/* 15 */       throw new IllegalArgumentException("xio.Helper.roundup size=" + paramInt);
/* 16 */     int i = 16;
/* 17 */     while (paramInt > i) i <<= 1;
/* 18 */     return i;
/*    */   }
/*    */ 
/*    */   public static ByteBuffer realloc(ByteBuffer paramByteBuffer, int paramInt)
/*    */   {
/* 31 */     if (null == paramByteBuffer) {
/* 32 */       return ByteBuffer.allocate(roudup(paramInt));
/*    */     }
/*    */ 
/* 35 */     if (paramByteBuffer.remaining() < paramInt) {
/* 36 */       paramByteBuffer.flip();
/* 37 */       return ByteBuffer.allocate(roudup(paramByteBuffer.limit() + paramInt)).put(paramByteBuffer);
/*    */     }
/*    */ 
/* 40 */     return paramByteBuffer;
/*    */   }
/*    */ 
/*    */   static void checkBounds(int paramInt1, int paramInt2, int paramInt3)
/*    */   {
/* 58 */     if ((paramInt1 | paramInt2 | paramInt1 + paramInt2 | paramInt3 - (paramInt1 + paramInt2)) < 0)
/* 59 */       throw new IndexOutOfBoundsException();
/*    */   }
/*    */ 
/*    */   public static InetSocketAddress inetSocketAddress(int paramInt1, int paramInt2)
/*    */   {
/* 66 */     return new InetSocketAddress(inetAddress(paramInt1), paramInt2);
/*    */   }
/*    */ 
/*    */   public static int ip4(InetAddress paramInetAddress)
/*    */   {
/* 75 */     int i = 0;
/* 76 */     byte[] arrayOfByte = paramInetAddress.getAddress();
/* 77 */     if (arrayOfByte.length != 4)
/* 78 */       throw new IOError(paramInetAddress + " is not a ip4 address");
/* 79 */     i |= arrayOfByte[3] << 24 & 0xFF000000;
/* 80 */     i |= arrayOfByte[2] << 16 & 0xFF0000;
/* 81 */     i |= arrayOfByte[1] << 8 & 0xFF00;
/* 82 */     i |= arrayOfByte[0] & 0xFF;
/* 83 */     return i;
/*    */   }
/*    */ 
/*    */   public static InetAddress inetAddress(int paramInt)
/*    */   {
/*    */     try
/*    */     {
/* 91 */       byte[] arrayOfByte = new byte[4];
/* 92 */       arrayOfByte[0] = ((byte)(paramInt >>> 24 & 0xFF));
/* 93 */       arrayOfByte[1] = ((byte)(paramInt >>> 16 & 0xFF));
/* 94 */       arrayOfByte[2] = ((byte)(paramInt >>> 8 & 0xFF));
/* 95 */       arrayOfByte[3] = ((byte)(paramInt & 0xFF));
/* 96 */       return InetAddress.getByAddress(arrayOfByte);
/*    */     } catch (UnknownHostException localUnknownHostException) {
/* 98 */       throw new IOError(localUnknownHostException);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.Helper
 * JD-Core Version:    0.6.2
 */