/*     */ package xio;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.Marshal;
/*     */ import com.goldhuman.Common.Marshal.MarshalException;
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import com.goldhuman.Common.Octets;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import xdb.Trace;
/*     */ import xdb.util.Counter;
/*     */ 
/*     */ public abstract class Protocol
/*     */   implements Marshal, Runnable
/*     */ {
/*     */   private Xio connection;
/*     */   private Object context;
/*     */   private Object sender;
/*     */   private Object receiver;
/* 115 */   private static Counter counterSend = new Counter(Engine.mbeans(), "xdb", "Protocols.send");
/*     */ 
/* 239 */   private static Counter counterRecv = new Counter(Engine.mbeans(), "xdb", "Protocols.recv");
/*     */ 
/*     */   public Protocol()
/*     */   {
/*  20 */     this.sender = null;
/*  21 */     this.receiver = null;
/*     */   }
/*     */ 
/*     */   public final void setSender(Object paramObject) {
/*  25 */     this.sender = paramObject;
/*     */   }
/*     */ 
/*     */   public final Object getSender()
/*     */   {
/*  30 */     return this.sender;
/*     */   }
/*     */ 
/*     */   public final void setReceiver(Object paramObject)
/*     */   {
/*  35 */     this.receiver = paramObject;
/*     */   }
/*     */ 
/*     */   public final Object getReceiver()
/*     */   {
/*  40 */     return this.receiver;
/*     */   }
/*     */ 
/*     */   public final Object getContext() {
/*  44 */     return this.context;
/*     */   }
/*     */ 
/*     */   public final void setContext(Object paramObject) {
/*  48 */     this.context = paramObject;
/*     */   }
/*     */ 
/*     */   public final void setConnection(Xio paramXio) {
/*  52 */     this.connection = paramXio;
/*     */   }
/*     */ 
/*     */   public final Xio getConnection() {
/*  56 */     return this.connection;
/*     */   }
/*     */ 
/*     */   public final Manager getManager() {
/*  60 */     return this.connection.getCreator().getManager();
/*     */   }
/*     */ 
/*     */   public abstract int getType();
/*     */ 
/*     */   public String str()
/*     */   {
/*  67 */     StringBuilder localStringBuilder = new StringBuilder();
/*  68 */     if (this.sender != null)
/*     */     {
/*  70 */       localStringBuilder.append(new StringBuilder().append("sender=").append(this.sender.toString()).append(" ").toString());
/*     */     }
/*  72 */     if (this.receiver != null)
/*     */     {
/*  74 */       localStringBuilder.append(new StringBuilder().append("receiver=").append(this.receiver.toString()).append(" ").toString());
/*     */     }
/*  76 */     localStringBuilder.append(new StringBuilder().append("type=").append(getType()).append(" class=").append(getClass().getName()).append(" this=").append(this).toString());
/*  77 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   public final void run()
/*     */   {
/*     */     try
/*     */     {
/*  84 */       process();
/*     */     }
/*     */     catch (Throwable localThrowable)
/*     */     {
/*  88 */       Trace.error("Protocol.run ", localThrowable);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void dispatch(Stub paramStub) throws Exception
/*     */   {
/*  94 */     if (Trace.isDebugEnabled())
/*  95 */       Trace.debug(new StringBuilder().append("xio.Protocol execute ").append(str()).toString());
/*  96 */     getManager().execute(this);
/*     */   }
/*     */ 
/*     */   protected void process() {
/* 100 */     throw new UnsupportedOperationException(new StringBuilder().append("process of ").append(getClass().getName()).toString());
/*     */   }
/*     */ 
/*     */   public boolean send(Xio paramXio)
/*     */   {
/* 106 */     if (null != paramXio)
/* 107 */       return checkSend(paramXio, new OctetsStream().marshal(this));
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   public final boolean send(Manager paramManager) {
/* 112 */     return send(paramManager.get());
/*     */   }
/*     */ 
/*     */   protected final boolean checkSend(Xio paramXio, Octets paramOctets)
/*     */   {
/* 126 */     Coder localCoder = (Coder)paramXio.getCreator().getManager().getCoder();
/* 127 */     localCoder.getStub(getType()).checkSend(this, paramOctets.size());
/* 128 */     if (paramXio.write(new OctetsStream().compact_uint32(getType()).marshal(paramOctets).getByteBuffer())) {
/* 129 */       counterSend.increment(getClass().getName());
/* 130 */       return true;
/*     */     }
/* 132 */     return false;
/*     */   }
/*     */ 
/*     */   public static class Decoder extends Filter
/*     */   {
/*     */     private ByteBuffer buffer;
/*     */     private Protocol.Coder coder;
/*     */ 
/*     */     public Decoder(Protocol.Coder paramCoder)
/*     */     {
/* 248 */       super();
/* 249 */       this.coder = paramCoder;
/*     */     }
/*     */ 
/*     */     public void doFilter(Filter.Iterator paramIterator, ByteBuffer paramByteBuffer, Xio paramXio)
/*     */     {
/* 254 */       this.buffer = Helper.realloc(this.buffer, paramByteBuffer.remaining());
/* 255 */       this.buffer.put(paramByteBuffer).flip();
/* 256 */       this.buffer.position(decode(this.buffer.array(), this.buffer.limit(), paramXio));
/* 257 */       this.buffer.compact();
/* 258 */       if (0 == this.buffer.position())
/* 259 */         this.buffer = null;
/*     */     }
/*     */ 
/*     */     private int decode(byte[] paramArrayOfByte, int paramInt, Xio paramXio) {
/* 263 */       OctetsStream localOctetsStream = OctetsStream.wrap(Octets.wrap(paramArrayOfByte, paramInt));
/* 264 */       int i = 0;
/*     */       try
/*     */       {
/* 267 */         while (localOctetsStream.size() > i)
/*     */         {
/* 269 */           int j = localOctetsStream.uncompact_uint32();
/* 270 */           int k = localOctetsStream.uncompact_uint32();
/* 271 */           Protocol.Stub localStub = this.coder.getStub(j);
/* 272 */           localStub.checkSize(k);
/* 273 */           if (k > localOctetsStream.remain())
/*     */             break;
/* 275 */           i = localOctetsStream.position() + k;
/*     */           try {
/* 277 */             Protocol.counterRecv.increment(localStub.getCls().getName());
/*     */ 
/* 301 */             localStub.dispatch(localOctetsStream, paramXio, null);
/*     */           } catch (Throwable localThrowable) {
/* 303 */             throw new MarshalError("(" + j + ", " + k + ")", localThrowable);
/*     */           }
/*     */ 
/* 306 */           if (localOctetsStream.position() != i)
/* 307 */             throw new MarshalError("(" + j + ", " + k + ")=" + (i - localOctetsStream.position()));
/*     */         }
/*     */       }
/*     */       catch (MarshalException localMarshalException)
/*     */       {
/*     */       }
/* 313 */       return i;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Coder extends Manager.Coder
/*     */   {
/* 193 */     private Map<Integer, Protocol.Stub> stubs = new HashMap();
/*     */ 
/*     */     public Protocol.Stub getStub(int paramInt) {
/* 196 */       Protocol.Stub localStub = (Protocol.Stub)this.stubs.get(Integer.valueOf(paramInt));
/* 197 */       if (null == localStub)
/* 198 */         throw new MarshalError("Protocol.Stub NOT found type=" + paramInt);
/* 199 */       return localStub;
/*     */     }
/*     */ 
/*     */     public void checkSend(Protocol paramProtocol, int paramInt)
/*     */     {
/* 204 */       getStub(paramProtocol.getType()).checkSend(paramProtocol, paramInt);
/*     */     }
/*     */ 
/*     */     public void dispatch(int paramInt, OctetsStream paramOctetsStream, Xio paramXio, Object paramObject) throws Exception
/*     */     {
/* 209 */       getStub(paramInt).dispatch(paramOctetsStream, paramXio, paramObject);
/*     */     }
/*     */ 
/*     */     public void initFilterList(Filter.List paramList1, Filter.List paramList2)
/*     */     {
/* 214 */       paramList1.addLast(new Protocol.Decoder(this));
/*     */     }
/*     */ 
/*     */     public void parse(Manager paramManager, Element paramElement) throws Exception
/*     */     {
/* 219 */       NodeList localNodeList = paramElement.getChildNodes();
/* 220 */       for (int i = 0; i < localNodeList.getLength(); i++) {
/* 221 */         Node localNode = localNodeList.item(i);
/* 222 */         if (1 == localNode.getNodeType())
/*     */         {
/* 224 */           Element localElement = (Element)localNode;
/* 225 */           String str = localElement.getNodeName();
/* 226 */           if (str.equals("Protocol")) add(new Protocol.Stub(localElement));
/* 227 */           if (str.equals("Rpc")) add(new Rpc.Stub(localElement));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     void add(Protocol.Stub paramStub)
/*     */     {
/* 235 */       if (null != this.stubs.put(Integer.valueOf(paramStub.getType()), paramStub))
/* 236 */         throw new RuntimeException("duplicate type of " + paramStub);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Stub
/*     */   {
/*     */     private int type;
/*     */     private Class<Protocol> cls;
/*     */     private int maxSize;
/*     */ 
/*     */     public int getType()
/*     */     {
/* 141 */       return this.type;
/*     */     }
/*     */ 
/*     */     public Class<Protocol> getCls() {
/* 145 */       return this.cls;
/*     */     }
/*     */ 
/*     */     public Protocol newInstance() throws Exception {
/* 149 */       return (Protocol)this.cls.newInstance();
/*     */     }
/*     */ 
/*     */     public Stub(Element paramElement)
/*     */       throws Exception
/*     */     {
/* 156 */       this.cls = Class.forName(paramElement.getAttribute("class"));
/* 157 */       Protocol localProtocol = (Protocol)this.cls.newInstance();
/* 158 */       this.type = localProtocol.getType();
/*     */ 
/* 160 */       String str = paramElement.getAttribute("maxSize");
/* 161 */       this.maxSize = (str.isEmpty() ? 0 : Integer.parseInt(str));
/*     */     }
/*     */ 
/*     */     public void dispatch(OctetsStream paramOctetsStream, Xio paramXio, Object paramObject) throws Exception {
/* 165 */       Protocol localProtocol = newInstance();
/* 166 */       localProtocol.unmarshal(paramOctetsStream);
/* 167 */       localProtocol.setConnection(paramXio);
/* 168 */       localProtocol.setContext(paramObject);
/* 169 */       localProtocol.dispatch(this);
/*     */     }
/*     */ 
/*     */     public void checkSend(Protocol paramProtocol, int paramInt) {
/* 173 */       if (paramProtocol.getClass() != this.cls)
/* 174 */         throw new MarshalError("checkSend of " + this + " class mismatch!");
/* 175 */       if (Trace.isDebugEnabled())
/* 176 */         Trace.debug("xio.send " + paramProtocol.str());
/* 177 */       checkSize(paramInt);
/*     */     }
/*     */ 
/*     */     public void checkSize(int paramInt) {
/* 181 */       if ((paramInt < 0) || ((this.maxSize > 0) && (paramInt > this.maxSize)))
/* 182 */         throw new MarshalError("checkSize of " + this + " size=" + paramInt);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 187 */       return "Stub(" + this.type + ", " + this.cls.getName() + ")";
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.Protocol
 * JD-Core Version:    0.6.2
 */