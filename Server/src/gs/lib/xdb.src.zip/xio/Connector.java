/*     */ package xio;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.w3c.dom.Element;
/*     */ import xdb.Executor;
/*     */ 
/*     */ public class Connector extends Creator
/*     */ {
/*     */   private boolean reconnect;
/*     */   private int connectDelay;
/*     */   private boolean open;
/*     */ 
/*     */   public Connector()
/*     */   {
/*  24 */     this.open = false;
/*     */   }
/*     */ 
/*     */   public void onClose(Xio paramXio, Throwable paramThrowable) {
/*  28 */     super.getManager().removeXio(paramXio, paramThrowable);
/*  29 */     if ((this.reconnect) && (Engine.isOpen()))
/*  30 */       _connect(true);
/*     */   }
/*     */ 
/*     */   public synchronized int getConnectDelay() {
/*  34 */     return this.connectDelay;
/*     */   }
/*     */ 
/*     */   private synchronized void _connect(boolean paramBoolean) {
/*  38 */     if ((paramBoolean) || (!this.open)) {
/*  39 */       this.open = true;
/*  40 */       Engine.verify();
/*     */ 
/*  42 */       Executor.getInstance().schedule(new Connect(), getConnectDelay(), TimeUnit.SECONDS);
/*     */     }
/*     */   }
/*     */ 
/*     */   void open()
/*     */   {
/*  48 */     _connect(false);
/*     */   }
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/*  56 */     this.open = false;
/*     */   }
/*     */ 
/*     */   private final void doConnectSuccess(Xio paramXio, Connect paramConnect)
/*     */   {
/*  63 */     synchronized (this) {
/*  64 */       this.connectDelay = 0;
/*     */     }
/*  66 */     super.getManager().addXio(paramXio);
/*     */   }
/*     */ 
/*     */   private final void doConnectAbort(Throwable paramThrowable, Connect paramConnect) {
/*  70 */     synchronized (this)
/*     */     {
/*  72 */       if (this.connectDelay == 0) {
/*  73 */         this.connectDelay = 1;
/*     */       } else {
/*  75 */         this.connectDelay *= 2;
/*  76 */         if (this.connectDelay > 60)
/*  77 */           this.connectDelay = 60; 
/*     */       }
/*     */     }
/*     */     try { super.getManager().onConnectAbort(this, paramThrowable); } catch (Throwable localThrowable) {
/*  81 */     }_connect(true);
/*     */   }
/*     */ 
/*     */   protected void parse(Manager paramManager, Element paramElement)
/*     */   {
/* 130 */     super.parse(paramManager, paramElement);
/*     */ 
/* 132 */     String str = paramElement.getAttribute("remoteIp");
/* 133 */     int i = Integer.parseInt(paramElement.getAttribute("remotePort"));
/* 134 */     super.initNameAndAddress(paramElement.getAttribute("name"), new InetSocketAddress(str, i));
/*     */ 
/* 136 */     this.reconnect = (!paramElement.getAttribute("reconnect").equals("false"));
/*     */   }
/*     */ 
/*     */   public static Connector create(Manager paramManager, Element paramElement) throws Exception {
/* 140 */     String str = paramElement.getAttribute("class");
/* 141 */     Connector localConnector = str.isEmpty() ? new Connector() : (Connector)Class.forName(str).newInstance();
/*     */ 
/* 143 */     localConnector.parse(paramManager, paramElement);
/* 144 */     return localConnector;
/*     */   }
/*     */ 
/*     */   class Connect
/*     */     implements Handle, Runnable
/*     */   {
/*     */     Connect()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void doHandle(SelectionKey paramSelectionKey)
/*     */       throws Exception
/*     */     {
/*  87 */       if (paramSelectionKey.isConnectable()) {
/*  88 */         SocketChannel localSocketChannel = (SocketChannel)paramSelectionKey.channel();
/*  89 */         if (localSocketChannel.finishConnect()) {
/*  90 */           Connector.this.doConnectSuccess(Connector.this.newXio(localSocketChannel), this);
/*  91 */           return;
/*     */         }
/*     */       }
/*     */ 
/*  95 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */     public void doException(SelectionKey paramSelectionKey, Throwable paramThrowable) throws Throwable
/*     */     {
/* 100 */       Connector.this.doConnectAbort(paramThrowable, this);
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 105 */       if (!Engine.isOpen())
/* 106 */         return;
/* 107 */       SocketChannel localSocketChannel = null;
/*     */       try {
/* 109 */         localSocketChannel = SocketChannel.open();
/*     */ 
/* 111 */         localSocketChannel.socket().setTcpNoDelay(Connector.this.isTcpNoDelay());
/* 112 */         localSocketChannel.socket().setReceiveBufferSize(Connector.this.getReceiveBufferSize());
/* 113 */         localSocketChannel.socket().setSendBufferSize(Connector.this.getSendBufferSize());
/*     */ 
/* 115 */         localSocketChannel.configureBlocking(false);
/* 116 */         if (localSocketChannel.connect(Connector.this.getAddress()))
/* 117 */           Connector.this.doConnectSuccess(Connector.this.newXio(localSocketChannel), this);
/*     */         else
/* 119 */           Engine.register(localSocketChannel, 8, this);
/*     */       }
/*     */       catch (Throwable localThrowable1) {
/* 122 */         if (null != localSocketChannel) try { localSocketChannel.close(); } catch (Throwable localThrowable2) {
/*     */           } Connector.this.doConnectAbort(localThrowable1, this);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.Connector
 * JD-Core Version:    0.6.2
 */