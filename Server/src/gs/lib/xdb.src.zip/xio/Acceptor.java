/*     */ package xio;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.nio.channels.SelectableChannel;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.ServerSocketChannel;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import org.w3c.dom.Element;
/*     */ import xdb.Trace;
/*     */ 
/*     */ public class Acceptor extends Creator
/*     */   implements Handle
/*     */ {
/*     */   private int backlog;
/*     */   private volatile SelectionKey server;
/*     */ 
/*     */   public void onClose(Xio paramXio, Throwable paramThrowable)
/*     */   {
/*  24 */     super.getManager().removeXio(paramXio, paramThrowable);
/*     */   }
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/*     */     try {
/*  30 */       if (null != this.server) {
/*  31 */         this.server.channel().close();
/*  32 */         this.server = null;
/*     */       }
/*     */     }
/*     */     catch (Throwable localThrowable)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void open() {
/*  41 */     Engine.verify();
/*     */     try {
/*  43 */       if (null == this.server) {
/*  44 */         ServerSocketChannel localServerSocketChannel = ServerSocketChannel.open();
/*  45 */         ServerSocket localServerSocket = localServerSocketChannel.socket();
/*  46 */         localServerSocket.setReuseAddress(true);
/*     */ 
/*  48 */         localServerSocket.setReceiveBufferSize(super.getReceiveBufferSize());
/*  49 */         localServerSocket.bind(super.getAddress(), this.backlog);
/*  50 */         this.server = Engine.register(localServerSocketChannel, 16, this);
/*     */       }
/*     */     } catch (Exception localException) {
/*  53 */       throw new IllegalStateException(localException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doHandle(SelectionKey paramSelectionKey)
/*     */     throws Throwable
/*     */   {
/*  61 */     SocketChannel localSocketChannel = null;
/*     */     try {
/*  63 */       ServerSocketChannel localServerSocketChannel = (ServerSocketChannel)paramSelectionKey.channel();
/*  64 */       localSocketChannel = localServerSocketChannel.accept();
/*  65 */       if (null != localSocketChannel) {
/*  66 */         Socket localSocket = localSocketChannel.socket();
/*  67 */         localSocket.setSendBufferSize(super.getSendBufferSize());
/*  68 */         localSocket.setTcpNoDelay(super.isTcpNoDelay());
/*  69 */         localSocketChannel.configureBlocking(false);
/*  70 */         super.getManager().addXio(newXio(localSocketChannel));
/*     */       }
/*     */     } catch (Throwable localThrowable) {
/*  73 */       if (null != localSocketChannel)
/*  74 */         localSocketChannel.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doException(SelectionKey paramSelectionKey, Throwable paramThrowable)
/*     */     throws Throwable
/*     */   {
/*  82 */     Trace.error(toString() + " " + paramSelectionKey, paramThrowable);
/*     */   }
/*     */ 
/*     */   protected void parse(Manager paramManager, Element paramElement)
/*     */   {
/*  87 */     super.parse(paramManager, paramElement);
/*     */ 
/*  89 */     String str = paramElement.getAttribute("localIp");
/*  90 */     int i = Integer.parseInt(paramElement.getAttribute("localPort"));
/*  91 */     super.initNameAndAddress(paramElement.getAttribute("name"), new InetSocketAddress(str, i));
/*     */ 
/*  93 */     this.backlog = Integer.parseInt(paramElement.getAttribute("backlog"));
/*     */   }
/*     */ 
/*     */   public static Acceptor create(Manager paramManager, Element paramElement) throws Exception {
/*  97 */     String str = paramElement.getAttribute("class");
/*  98 */     Acceptor localAcceptor = str.isEmpty() ? new Acceptor() : (Acceptor)Class.forName(str).newInstance();
/*     */ 
/* 100 */     localAcceptor.parse(paramManager, paramElement);
/* 101 */     return localAcceptor;
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.Acceptor
 * JD-Core Version:    0.6.2
 */