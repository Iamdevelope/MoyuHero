/*    */ package xio;
/*    */ 
/*    */ public class ManagerNone extends Manager
/*    */ {
/*    */   protected void addXio(Xio paramXio)
/*    */   {
/*    */   }
/*    */ 
/*    */   public Xio get()
/*    */   {
/* 15 */     return null;
/*    */   }
/*    */ 
/*    */   protected void removeXio(Xio paramXio, Throwable paramThrowable)
/*    */   {
/*    */   }
/*    */ 
/*    */   public int size()
/*    */   {
/* 24 */     return 0;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.ManagerNone
 * JD-Core Version:    0.6.2
 */