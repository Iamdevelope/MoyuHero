/*    */ package xio.rpc;
/*    */ 
/*    */ import com.goldhuman.Common.Marshal.Marshal;
/*    */ import com.goldhuman.Common.Marshal.MarshalException;
/*    */ import com.goldhuman.Common.Marshal.OctetsStream;
/*    */ 
/*    */ public final class Void
/*    */   implements Marshal
/*    */ {
/*    */   public OctetsStream marshal(OctetsStream paramOctetsStream)
/*    */   {
/* 11 */     return paramOctetsStream;
/*    */   }
/*    */ 
/*    */   public OctetsStream unmarshal(OctetsStream paramOctetsStream) throws MarshalException
/*    */   {
/* 16 */     return paramOctetsStream;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.rpc.Void
 * JD-Core Version:    0.6.2
 */