/*    */ package xio.rpc;
/*    */ 
/*    */ import com.goldhuman.Common.Marshal.Marshal;
/*    */ import com.goldhuman.Common.Marshal.MarshalException;
/*    */ import com.goldhuman.Common.Marshal.OctetsStream;
/*    */ 
/*    */ public final class LongInt
/*    */   implements Marshal
/*    */ {
/*    */   private long value;
/*    */   private int code;
/*    */ 
/*    */   public OctetsStream marshal(OctetsStream paramOctetsStream)
/*    */   {
/* 13 */     return paramOctetsStream.marshal(this.value).marshal(this.code);
/*    */   }
/*    */ 
/*    */   public OctetsStream unmarshal(OctetsStream paramOctetsStream) throws MarshalException
/*    */   {
/* 18 */     this.value = paramOctetsStream.unmarshal_long();
/* 19 */     this.code = paramOctetsStream.unmarshal_int();
/* 20 */     return paramOctetsStream;
/*    */   }
/*    */ 
/*    */   public LongInt()
/*    */   {
/*    */   }
/*    */ 
/*    */   public LongInt(long paramLong, int paramInt) {
/* 28 */     this.value = paramLong;
/* 29 */     this.code = paramInt;
/*    */   }
/*    */ 
/*    */   public long getValue() {
/* 33 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(long paramLong) {
/* 37 */     this.value = paramLong;
/*    */   }
/*    */ 
/*    */   public int getCode() {
/* 41 */     return this.code;
/*    */   }
/*    */ 
/*    */   public void setCode(int paramInt) {
/* 45 */     this.code = paramInt;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 50 */     return String.valueOf(this.value) + "," + String.valueOf(this.code);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.rpc.LongInt
 * JD-Core Version:    0.6.2
 */