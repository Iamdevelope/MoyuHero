/*    */ package xio.rpc;
/*    */ 
/*    */ import com.goldhuman.Common.Marshal.Marshal;
/*    */ import com.goldhuman.Common.Marshal.MarshalException;
/*    */ import com.goldhuman.Common.Marshal.OctetsStream;
/*    */ 
/*    */ public final class Long
/*    */   implements Marshal
/*    */ {
/*    */   private long value;
/*    */ 
/*    */   public OctetsStream marshal(OctetsStream paramOctetsStream)
/*    */   {
/* 17 */     return paramOctetsStream.marshal(this.value);
/*    */   }
/*    */ 
/*    */   public OctetsStream unmarshal(OctetsStream paramOctetsStream) throws MarshalException
/*    */   {
/* 22 */     this.value = paramOctetsStream.unmarshal_long();
/* 23 */     return paramOctetsStream;
/*    */   }
/*    */ 
/*    */   public Long()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Long(long paramLong) {
/* 31 */     this.value = paramLong;
/*    */   }
/*    */ 
/*    */   public long getValue() {
/* 35 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(long paramLong) {
/* 39 */     this.value = paramLong;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 44 */     return String.valueOf(this.value);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.rpc.Long
 * JD-Core Version:    0.6.2
 */