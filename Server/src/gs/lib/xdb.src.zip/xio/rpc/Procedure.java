package xio.rpc;

import com.goldhuman.Common.Marshal.Marshal;
import xio.Xio;

public abstract interface Procedure<A extends Marshal, R extends Marshal>
{
  public abstract void setArgument(A paramA);

  public abstract void setResult(R paramR);

  public abstract void setConnection(Xio paramXio);

  public abstract A getArgument();

  public abstract R getResult();

  public abstract Xio getConnection();
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.rpc.Procedure
 * JD-Core Version:    0.6.2
 */