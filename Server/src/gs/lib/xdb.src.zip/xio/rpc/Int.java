/*    */ package xio.rpc;
/*    */ 
/*    */ import com.goldhuman.Common.Marshal.Marshal;
/*    */ import com.goldhuman.Common.Marshal.MarshalException;
/*    */ import com.goldhuman.Common.Marshal.OctetsStream;
/*    */ 
/*    */ public final class Int
/*    */   implements Marshal
/*    */ {
/*    */   private int value;
/*    */ 
/*    */   public OctetsStream marshal(OctetsStream paramOctetsStream)
/*    */   {
/* 12 */     return paramOctetsStream.marshal(this.value);
/*    */   }
/*    */ 
/*    */   public OctetsStream unmarshal(OctetsStream paramOctetsStream) throws MarshalException
/*    */   {
/* 17 */     this.value = paramOctetsStream.unmarshal_int();
/* 18 */     return paramOctetsStream;
/*    */   }
/*    */ 
/*    */   public Int()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Int(int paramInt) {
/* 26 */     this.value = paramInt;
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 30 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(int paramInt) {
/* 34 */     this.value = paramInt;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 39 */     return String.valueOf(this.value);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.rpc.Int
 * JD-Core Version:    0.6.2
 */