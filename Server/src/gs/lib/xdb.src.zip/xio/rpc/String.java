/*    */ package xio.rpc;
/*    */ 
/*    */ import com.goldhuman.Common.Marshal.Marshal;
/*    */ import com.goldhuman.Common.Marshal.MarshalException;
/*    */ import com.goldhuman.Common.Marshal.OctetsStream;
/*    */ 
/*    */ public final class String
/*    */   implements Marshal
/*    */ {
/*    */   private java.lang.String value;
/*    */ 
/*    */   public OctetsStream marshal(OctetsStream paramOctetsStream)
/*    */   {
/* 12 */     return paramOctetsStream.marshal(this.value, "UTF-16LE");
/*    */   }
/*    */ 
/*    */   public OctetsStream unmarshal(OctetsStream paramOctetsStream) throws MarshalException
/*    */   {
/* 17 */     this.value = paramOctetsStream.unmarshal_String("UTF-16LE");
/* 18 */     return paramOctetsStream;
/*    */   }
/*    */ 
/*    */   public String() {
/*    */   }
/*    */ 
/*    */   public String(java.lang.String paramString) {
/* 25 */     this.value = paramString;
/*    */   }
/*    */ 
/*    */   public java.lang.String getValue() {
/* 29 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(java.lang.String paramString) {
/* 33 */     this.value = paramString;
/*    */   }
/*    */ 
/*    */   public java.lang.String toString()
/*    */   {
/* 38 */     return this.value;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.rpc.String
 * JD-Core Version:    0.6.2
 */