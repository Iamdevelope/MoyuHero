/*    */ package xio;
/*    */ 
/*    */ public class MarshalError extends Error
/*    */ {
/*    */   static final long serialVersionUID = -5940715854092786215L;
/*    */ 
/*    */   public MarshalError()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MarshalError(String paramString, Throwable paramThrowable)
/*    */   {
/* 10 */     super(paramString, paramThrowable);
/*    */   }
/*    */ 
/*    */   public MarshalError(String paramString) {
/* 14 */     super(paramString);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.MarshalError
 * JD-Core Version:    0.6.2
 */