/*     */ package xio;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ public abstract class Creator
/*     */ {
/*     */   private Manager manager;
/*     */   private int inputBufferSize;
/*     */   private int outputBufferSize;
/*     */   private boolean keepOutputBuffer;
/*     */   private boolean keepInputBuffer;
/*     */   private boolean tcpNoDelay;
/*     */   private int receiveBufferSize;
/*     */   private int sendBufferSize;
/*  21 */   private String name = "";
/*     */   private InetSocketAddress address;
/*     */ 
/*     */   protected void parse(Manager paramManager, Element paramElement)
/*     */   {
/*  31 */     this.manager = paramManager;
/*     */ 
/*  33 */     this.inputBufferSize = Helper.roudup(Integer.parseInt(paramElement.getAttribute("inputBufferSize")));
/*  34 */     this.keepInputBuffer = (!paramElement.getAttribute("keepInputBuffer").equals("false"));
/*  35 */     this.outputBufferSize = Helper.roudup(Integer.parseInt(paramElement.getAttribute("outputBufferSize")));
/*  36 */     this.keepOutputBuffer = (!paramElement.getAttribute("keepOutputBuffer").equals("false"));
/*     */ 
/*  38 */     this.sendBufferSize = Integer.parseInt(paramElement.getAttribute("sendBufferSize"));
/*  39 */     this.receiveBufferSize = Integer.parseInt(paramElement.getAttribute("receiveBufferSize"));
/*  40 */     this.tcpNoDelay = paramElement.getAttribute("tcpNoDelay").equals("true");
/*     */   }
/*     */ 
/*     */   public final int getReceiveBufferSize() {
/*  44 */     return this.receiveBufferSize;
/*     */   }
/*     */ 
/*     */   public final int getSendBufferSize() {
/*  48 */     return this.sendBufferSize;
/*     */   }
/*     */ 
/*     */   public final boolean isTcpNoDelay() {
/*  52 */     return this.tcpNoDelay;
/*     */   }
/*     */ 
/*     */   public final int getOutputBufferSize() {
/*  56 */     return this.outputBufferSize;
/*     */   }
/*     */ 
/*     */   public final int getInputBufferSize()
/*     */   {
/*  61 */     return this.inputBufferSize;
/*     */   }
/*     */ 
/*     */   public final boolean isKeepInputBuffer()
/*     */   {
/*  69 */     return this.keepInputBuffer;
/*     */   }
/*     */ 
/*     */   public final boolean isKeepOutputBuffer()
/*     */   {
/*  77 */     return this.keepOutputBuffer;
/*     */   }
/*     */ 
/*     */   public final Manager getManager() {
/*  81 */     return this.manager;
/*     */   }
/*     */ 
/*     */   Xio newXio(SocketChannel paramSocketChannel)
/*     */   {
/*  91 */     return this.manager.newXio(this, paramSocketChannel);
/*     */   }
/*     */ 
/*     */   abstract void onClose(Xio paramXio, Throwable paramThrowable);
/*     */ 
/*     */   abstract void open();
/*     */ 
/*     */   abstract void close();
/*     */ 
/*     */   public final String getName()
/*     */   {
/* 109 */     return this.name;
/*     */   }
/*     */ 
/*     */   public final InetSocketAddress getAddress()
/*     */   {
/* 116 */     return this.address;
/*     */   }
/*     */ 
/*     */   protected final void initNameAndAddress(String paramString, InetSocketAddress paramInetSocketAddress)
/*     */   {
/* 124 */     this.name = paramString;
/* 125 */     this.address = paramInetSocketAddress;
/* 126 */     if (this.name.isEmpty())
/* 127 */       this.name = this.address.toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 132 */     return getAddress() + "@" + getManager().getName();
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.Creator
 * JD-Core Version:    0.6.2
 */