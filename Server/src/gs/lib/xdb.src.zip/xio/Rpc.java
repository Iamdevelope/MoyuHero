/*     */ package xio;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.Marshal;
/*     */ import com.goldhuman.Common.Marshal.MarshalException;
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import java.io.Closeable;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.w3c.dom.Element;
/*     */ import xdb.Executor;
/*     */ import xdb.Procedure.Done;
/*     */ import xdb.Trace;
/*     */ 
/*     */ public abstract class Rpc<A extends Marshal, R extends Marshal> extends Protocol
/*     */   implements Closeable, Procedure.Done<xdb.Procedure>
/*     */ {
/*     */   private boolean isRequest;
/*     */   private int sid;
/*     */   private A argument;
/*     */   private R result;
/*     */   private IOnClient<A, R> iOnClient;
/*     */   private FutureX<R> future;
/*     */ 
/*     */   public final int getSid()
/*     */   {
/*  41 */     return this.sid;
/*     */   }
/*     */ 
/*     */   public final A getArgument() {
/*  45 */     return this.argument;
/*     */   }
/*     */ 
/*     */   public final R getResult() {
/*  49 */     return this.result;
/*     */   }
/*     */ 
/*     */   public IOnClient<A, R> getIOnClient() {
/*  53 */     return this.iOnClient;
/*     */   }
/*     */ 
/*     */   public final Rpc<A, R> setIOnClient(IOnClient<A, R> paramIOnClient) {
/*  57 */     this.iOnClient = paramIOnClient;
/*  58 */     return this;
/*     */   }
/*     */ 
/*     */   public final Rpc<A, R> setArgument(A paramA) {
/*  62 */     this.argument = paramA;
/*  63 */     return this;
/*     */   }
/*     */ 
/*     */   public final Rpc<A, R> setResult(R paramR) {
/*  67 */     this.result = paramR;
/*  68 */     return this;
/*     */   }
/*     */ 
/*     */   public final boolean isRequest() {
/*  72 */     return this.isRequest;
/*     */   }
/*     */ 
/*     */   public final Rpc<A, R> setRequest(boolean paramBoolean) {
/*  76 */     this.isRequest = paramBoolean;
/*  77 */     return this;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*  82 */     if (null != this.future)
/*  83 */       this.future.setException(new IOError("AsynchronousClose"));
/*     */     else
/*  85 */       _onTimeout(-1);
/*     */   }
/*     */ 
/*     */   private final void _onTimeout(int paramInt) {
/*  89 */     if (null != this.iOnClient)
/*  90 */       this.iOnClient.onTimeout(this, paramInt);
/*     */     else
/*  92 */       onTimeout(paramInt);
/*     */   }
/*     */ 
/*     */   private final void _onClient() {
/*  96 */     if (null != this.iOnClient)
/*  97 */       this.iOnClient.onClient(this);
/*     */     else
/*  99 */       onClient();
/*     */   }
/*     */ 
/*     */   protected void onTimeout(int paramInt)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void onServer()
/*     */   {
/* 114 */     throw new UnsupportedOperationException("onServer of " + getClass().getName());
/*     */   }
/*     */ 
/*     */   protected void onClient() {
/* 118 */     throw new UnsupportedOperationException("onClient of " + getClass().getName());
/*     */   }
/*     */ 
/*     */   public int getTimeout()
/*     */   {
/* 129 */     return 2000;
/*     */   }
/*     */ 
/*     */   public boolean send(Xio paramXio)
/*     */   {
/* 155 */     if (null == paramXio)
/* 156 */       return false;
/* 157 */     this.isRequest = true;
/* 158 */     Manager localManager = paramXio.getCreator().getManager();
/* 159 */     this.sid = localManager.addContext(this);
/* 160 */     boolean bool = super.checkSend(paramXio, new OctetsStream().marshal(this));
/* 161 */     if ((bool) && (null == this.future))
/* 162 */       Executor.getInstance().schedule(new Timeout(localManager, this.sid), getTimeout(), TimeUnit.MILLISECONDS);
/* 163 */     return bool;
/*     */   }
/*     */ 
/*     */   public final FutureX<R> submit(Xio paramXio) {
/* 167 */     if (null != paramXio) {
/* 168 */       this.future = new FutureX(getTimeout());
/* 169 */       if (send(paramXio))
/* 170 */         return this.future;
/* 171 */       this.future = null;
/*     */     }
/* 173 */     throw new IOError(toString() + paramXio);
/*     */   }
/*     */ 
/*     */   public final FutureX<R> submit(Manager paramManager) {
/* 177 */     return submit(paramManager.get());
/*     */   }
/*     */ 
/*     */   public void checkProcedure(xdb.Procedure paramProcedure)
/*     */   {
/* 233 */     xio.rpc.Procedure localProcedure = (xio.rpc.Procedure)paramProcedure;
/* 234 */     localProcedure.setArgument(this.argument);
/* 235 */     localProcedure.setResult(this.result);
/*     */   }
/*     */ 
/*     */   public final OctetsStream marshal(OctetsStream paramOctetsStream)
/*     */   {
/* 260 */     if (this.isRequest)
/* 261 */       return paramOctetsStream.marshal(this.sid | 0x80000000).marshal(this.argument);
/* 262 */     return paramOctetsStream.marshal(this.sid).marshal(this.result);
/*     */   }
/*     */ 
/*     */   public final OctetsStream unmarshal(OctetsStream paramOctetsStream) throws MarshalException
/*     */   {
/* 267 */     this.sid = paramOctetsStream.unmarshal_int();
/* 268 */     this.isRequest = ((this.sid & 0x80000000) != 0);
/* 269 */     if (this.isRequest) {
/* 270 */       this.sid &= 2147483647;
/* 271 */       return this.argument.unmarshal(paramOctetsStream);
/*     */     }
/* 273 */     return this.result.unmarshal(paramOctetsStream);
/*     */   }
/*     */ 
/*     */   public void dispatch(Protocol.Stub paramStub) throws Exception
/*     */   {
/* 278 */     Stub localStub = (Stub)paramStub;
/* 279 */     if (this.isRequest) {
/* 280 */       localObject = localStub.newProcedure();
/* 281 */       if (null != localObject)
/*     */       {
/* 283 */         xio.rpc.Procedure localProcedure = (xio.rpc.Procedure)localObject;
/*     */ 
/* 285 */         localProcedure.setArgument(this.argument);
/* 286 */         localProcedure.setResult(this.result);
/* 287 */         localProcedure.setConnection(getConnection());
/* 288 */         if (Trace.isDebugEnabled())
/* 289 */           Trace.debug("xio.Rpc.request " + str() + " Procedure=" + localObject.getClass().getName());
/* 290 */         xdb.Procedure.execute((xdb.Procedure)localObject, this);
/* 291 */         return;
/*     */       }
/* 293 */       if (Trace.isDebugEnabled())
/* 294 */         Trace.debug("xio.Rpc.request execute " + str());
/* 295 */       getManager().execute(this);
/* 296 */       return;
/*     */     }
/*     */ 
/* 299 */     Object localObject = (Rpc)getConnection().getCreator().getManager().removeContext(this.sid, this);
/* 300 */     if (null == localObject) {
/* 301 */       Trace.info("xio.Rpc.response context lost! " + str());
/* 302 */       return;
/*     */     }
/* 304 */     ((Rpc)localObject).setRequest(false).setResult(this.result);
/* 305 */     if (null != ((Rpc)localObject).future) {
/* 306 */       if (Trace.isDebugEnabled())
/* 307 */         Trace.debug("xio.Rpc.response with submit " + ((Rpc)localObject).str());
/* 308 */       ((Rpc)localObject).future.set(((Rpc)localObject).result);
/* 309 */       return;
/*     */     }
/*     */ 
/* 312 */     if (Trace.isDebugEnabled())
/* 313 */       Trace.debug("xio.Rpc.response execute " + str());
/* 314 */     getManager().execute((Protocol)localObject);
/*     */   }
/*     */ 
/*     */   public final void doDone(xdb.Procedure paramProcedure)
/*     */   {
/* 319 */     this.isRequest = false;
/* 320 */     checkSend(getConnection(), new OctetsStream().marshal(this));
/*     */   }
/*     */ 
/*     */   protected final void process()
/*     */   {
/* 325 */     if (this.isRequest) {
/* 326 */       onServer();
/* 327 */       this.isRequest = false;
/* 328 */       checkSend(getConnection(), new OctetsStream().marshal(this));
/*     */     } else {
/* 330 */       _onClient();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 336 */     return "(" + this.argument + ", " + this.result + ")";
/*     */   }
/*     */ 
/*     */   public static class Stub extends Protocol.Stub
/*     */   {
/*     */     private Class<xdb.Procedure> onServerProcedure;
/*     */ 
/*     */     public xdb.Procedure newProcedure()
/*     */       throws Exception
/*     */     {
/* 242 */       if (null != this.onServerProcedure)
/* 243 */         return (xdb.Procedure)this.onServerProcedure.newInstance();
/* 244 */       return null;
/*     */     }
/*     */ 
/*     */     public Stub(Element paramElement) throws Exception
/*     */     {
/* 249 */       super();
/* 250 */       String str = paramElement.getAttribute("onServer");
/* 251 */       if (!str.isEmpty()) {
/* 252 */         this.onServerProcedure = Class.forName(str);
/* 253 */         ((Rpc)newInstance()).checkProcedure((xdb.Procedure)this.onServerProcedure.newInstance());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class FutureX<R> extends FutureTask<R>
/*     */   {
/* 190 */     private static Runnable dummy = new Runnable() { public void run() {  }  } ;
/*     */     private int defaulttimeout;
/*     */ 
/* 194 */     public FutureX(int paramInt) { super(null);
/* 195 */       this.defaulttimeout = paramInt;
/*     */     }
/*     */ 
/*     */     public R get()
/*     */     {
/* 200 */       return get(this.defaulttimeout, TimeUnit.MILLISECONDS);
/*     */     }
/*     */ 
/*     */     public R get(long paramLong, TimeUnit paramTimeUnit)
/*     */     {
/*     */       try {
/* 206 */         return super.get(paramLong, paramTimeUnit);
/*     */       } catch (Exception localException) {
/* 208 */         throw new IOError(localException);
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean cancel(boolean paramBoolean)
/*     */     {
/* 214 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     protected void set(R paramR)
/*     */     {
/* 219 */       super.set(paramR);
/*     */     }
/*     */ 
/*     */     protected void setException(Throwable paramThrowable)
/*     */     {
/* 224 */       super.setException(paramThrowable);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Timeout
/*     */     implements Runnable
/*     */   {
/*     */     private Manager manager;
/*     */     private int sid;
/*     */ 
/*     */     Timeout(Manager paramManager, int paramInt)
/*     */     {
/* 139 */       this.manager = paramManager;
/* 140 */       this.sid = paramInt;
/*     */     }
/*     */ 
/*     */     public void run() {
/* 144 */       Closeable localCloseable = this.manager.removeContext(this.sid);
/* 145 */       if ((null != localCloseable) && ((localCloseable instanceof Rpc)))
/*     */       {
/* 147 */         Rpc localRpc = (Rpc)localCloseable;
/* 148 */         localRpc._onTimeout(-2);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface IOnClient<A extends Marshal, R extends Marshal>
/*     */   {
/*     */     public abstract void onTimeout(Rpc<A, R> paramRpc, int paramInt);
/*     */ 
/*     */     public abstract void onClient(Rpc<A, R> paramRpc);
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.Rpc
 * JD-Core Version:    0.6.2
 */