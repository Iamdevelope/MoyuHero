package xio;

import java.nio.channels.SelectionKey;

public abstract interface Handle
{
  public abstract void doHandle(SelectionKey paramSelectionKey)
    throws Throwable;

  public abstract void doException(SelectionKey paramSelectionKey, Throwable paramThrowable)
    throws Throwable;
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.Handle
 * JD-Core Version:    0.6.2
 */