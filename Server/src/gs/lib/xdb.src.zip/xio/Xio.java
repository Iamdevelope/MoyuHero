/*     */ package xio;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SelectableChannel;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.List;
/*     */ import javax.management.ObjectName;
/*     */ import xdb.Trace;
/*     */ import xdb.util.MBeans.Manager;
/*     */ 
/*     */ public class Xio
/*     */   implements Handle, Closeable, XioMBean
/*     */ {
/*     */   public static final int OP_READ = 1;
/*     */   public static final int OP_WRITE = 4;
/*  21 */   private boolean open = true;
/*     */   private final SelectionKey key;
/*     */   private final Creator creator;
/*     */   private final SocketAddress peer;
/*     */   private final Input input;
/*     */   private final Output output;
/*     */   private final ObjectName objname;
/*     */ 
/*     */   public Xio(Creator paramCreator, SocketChannel paramSocketChannel, int paramInt, Input paramInput, Output paramOutput)
/*     */   {
/*  32 */     this.key = Engine.register(paramSocketChannel, paramInt, this);
/*  33 */     this.creator = paramCreator;
/*  34 */     Socket localSocket = paramSocketChannel.socket();
/*  35 */     this.peer = localSocket.getRemoteSocketAddress();
/*  36 */     this.input = paramInput;
/*  37 */     this.output = paramOutput;
/*     */ 
/*  39 */     ObjectName localObjectName = null;
/*     */     try {
/*  41 */       localObjectName = Engine.mbeans().register(this, new StringBuilder().append("xio:type=").append(paramCreator.getManager().getMBeanName()).append(",name=").append(localSocket.getInetAddress()).append("-").append(localSocket.getPort()).append("@").append(paramCreator.getManager().incrementAndGetNewXioCount()).toString());
/*     */     }
/*     */     catch (Throwable localThrowable)
/*     */     {
/*  46 */       Trace.warn(new StringBuilder().append("MBean.register xio. creator=").append(getCreatorInfo()).toString(), localThrowable);
/*     */     }
/*  48 */     this.objname = localObjectName;
/*     */   }
/*     */ 
/*     */   public final Creator getCreator() {
/*  52 */     return this.creator;
/*     */   }
/*     */ 
/*     */   public InetSocketAddress getPeer() {
/*  56 */     return (InetSocketAddress)this.peer;
/*     */   }
/*     */ 
/*     */   public final Input getInput() {
/*  60 */     return this.input;
/*     */   }
/*     */ 
/*     */   public final Output getOutput() {
/*  64 */     return this.output;
/*     */   }
/*     */ 
/*     */   private final SocketChannel getSocketChannel()
/*     */   {
/*  69 */     return (SocketChannel)this.key.channel();
/*     */   }
/*     */ 
/*     */   private synchronized boolean getAndClearOpen()
/*     */   {
/*  75 */     boolean bool = this.open;
/*  76 */     this.open = false;
/*  77 */     return bool;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*  82 */     close(null);
/*     */   }
/*     */ 
/*     */   public void close(Throwable paramThrowable)
/*     */   {
/*     */     try {
/*  88 */       if (getAndClearOpen()) {
/*  89 */         this.key.channel().close();
/*  90 */         this.creator.onClose(this, paramThrowable);
/*  91 */         Engine.mbeans().unregister(this.objname);
/*     */       }
/*     */     }
/*     */     catch (Throwable localThrowable)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 100 */     return new StringBuilder().append("Xio").append(this.peer).append('-').append(this.creator).toString();
/*     */   }
/*     */ 
/*     */   public final void interestOps(int paramInt)
/*     */   {
/* 105 */     this.key.interestOps(paramInt);
/* 106 */     Engine.wakeup();
/*     */   }
/*     */ 
/*     */   public final void interestOps(int paramInt1, int paramInt2) {
/* 110 */     int i = this.key.interestOps();
/* 111 */     int j = i & (paramInt1 ^ 0xFFFFFFFF) | paramInt2;
/* 112 */     if (i != j)
/* 113 */       interestOps(j);
/*     */   }
/*     */ 
/*     */   public boolean write(ByteBuffer paramByteBuffer)
/*     */   {
/*     */     try {
/* 119 */       if (!this.key.isValid())
/* 120 */         return false;
/* 121 */       return this.output.doOutput(paramByteBuffer, this);
/*     */     } catch (IOError localIOError) {
/* 123 */       if (Trace.isDebugEnabled())
/* 124 */         Trace.debug(this, localIOError);
/*     */     } catch (Throwable localThrowable) {
/* 126 */       Trace.error(this, localThrowable);
/*     */     }
/* 128 */     close();
/* 129 */     return false;
/*     */   }
/*     */ 
/*     */   public void doHandle(SelectionKey paramSelectionKey)
/*     */     throws Throwable
/*     */   {
/* 136 */     if ((paramSelectionKey.isReadable()) && 
/* 137 */       (-1 == this.input.doRead(this))) {
/* 138 */       close();
/* 139 */       return;
/*     */     }
/*     */ 
/* 142 */     if (paramSelectionKey.isWritable())
/* 143 */       this.output.doWrite(this);
/*     */   }
/*     */ 
/*     */   public void doException(SelectionKey paramSelectionKey, Throwable paramThrowable)
/*     */     throws Throwable
/*     */   {
/* 149 */     close(paramThrowable);
/*     */   }
/*     */ 
/*     */   public String getInterestOps()
/*     */   {
/* 306 */     StringBuilder localStringBuilder = new StringBuilder();
/* 307 */     int i = this.key.interestOps();
/* 308 */     if (0 != (i & 0x10)) localStringBuilder.append("+Accept");
/* 309 */     if (0 != (i & 0x8)) localStringBuilder.append("+Connect");
/* 310 */     if (0 != (i & 0x1)) localStringBuilder.append("+Read");
/* 311 */     if (0 != (i & 0x4)) localStringBuilder.append("+Write");
/* 312 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   public String getCreatorInfo()
/*     */   {
/* 317 */     StringBuilder localStringBuilder = new StringBuilder();
/* 318 */     Manager localManager = this.creator.getManager();
/* 319 */     XioConf localXioConf = localManager.getConf();
/* 320 */     localStringBuilder.append("XioConf.").append(localXioConf.getName());
/* 321 */     localStringBuilder.append("/");
/* 322 */     localStringBuilder.append(localManager.getClass().getName()).append(".").append(localManager.getName());
/* 323 */     localStringBuilder.append("/");
/* 324 */     localStringBuilder.append(this.creator.getClass().getName()).append(".").append(this.creator.getName());
/* 325 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   public String getPeerInfo()
/*     */   {
/* 330 */     return this.peer.toString();
/*     */   }
/*     */ 
/*     */   public int getInputBufferSize()
/*     */   {
/* 335 */     return this.input.getBufferSize();
/*     */   }
/*     */ 
/*     */   public int getInputBufferCapacity()
/*     */   {
/* 340 */     return this.input.getBufferCapacity();
/*     */   }
/*     */ 
/*     */   public int getOutputBufferSize()
/*     */   {
/* 345 */     return this.output.getBufferSize();
/*     */   }
/*     */ 
/*     */   public int getOutputBufferCapacity()
/*     */   {
/* 350 */     return this.output.getBufferCapacity();
/*     */   }
/*     */ 
/*     */   public int getOutputBufferAllocation()
/*     */   {
/* 355 */     return this.output.getBufferAllocation();
/*     */   }
/*     */ 
/*     */   public static final class Output extends Filter.List
/*     */     implements Filter.Iterator
/*     */   {
/*     */     private int index;
/*     */     private OutputBuffer buffer;
/*     */     private final int maxSize;
/*     */ 
/*     */     public int getBufferSize()
/*     */     {
/* 214 */       synchronized (this) {
/* 215 */         return null == this.buffer ? 0 : this.buffer.position();
/*     */       }
/*     */     }
/*     */ 
/*     */     public int getBufferCapacity() {
/* 220 */       return this.maxSize;
/*     */     }
/*     */ 
/*     */     public int getBufferAllocation() {
/* 224 */       synchronized (this) {
/* 225 */         return null == this.buffer ? 0 : this.buffer.allocation();
/*     */       }
/*     */     }
/*     */ 
/*     */     public Output() {
/* 230 */       this.maxSize = 1073741824;
/*     */     }
/*     */ 
/*     */     public Output(Creator paramCreator) {
/* 234 */       this.maxSize = paramCreator.getOutputBufferSize();
/*     */     }
/*     */ 
/*     */     public boolean doOutput(ByteBuffer paramByteBuffer, Xio paramXio)
/*     */     {
/* 239 */       synchronized (this) {
/* 240 */         int i = null == this.buffer ? 0 : this.buffer.position();
/* 241 */         if (i + paramByteBuffer.remaining() > this.maxSize) {
/* 242 */           return false;
/*     */         }
/* 244 */         this.index = raw().size();
/* 245 */         doNextFilter(--this.index, paramByteBuffer, paramXio);
/* 246 */         return true;
/*     */       }
/*     */     }
/*     */ 
/*     */     public void doFilterNextOf(Filter paramFilter, ByteBuffer paramByteBuffer, Xio paramXio)
/*     */     {
/* 253 */       if (raw().get(this.index) != paramFilter)
/* 254 */         throw new IllegalStateException();
/* 255 */       doNextFilter(--this.index, paramByteBuffer, paramXio);
/*     */     }
/*     */ 
/*     */     private void doNextFilter(int paramInt, ByteBuffer paramByteBuffer, Xio paramXio)
/*     */     {
/* 260 */       if (paramInt >= 0) {
/* 261 */         ((Filter)raw().get(paramInt)).doFilter(this, paramByteBuffer, paramXio);
/* 262 */         return;
/*     */       }
/*     */ 
/* 276 */       if (paramByteBuffer.remaining() > 0)
/*     */       {
/* 278 */         if (null == this.buffer) this.buffer = new OutputBuffer();
/* 279 */         this.buffer.put(paramByteBuffer);
/* 280 */         paramXio.interestOps(0, 4);
/*     */       }
/*     */     }
/*     */ 
/*     */     private final void doWrite(Xio paramXio) throws IOException {
/* 285 */       synchronized (this) {
/* 286 */         this.buffer.output(paramXio.getSocketChannel());
/*     */ 
/* 292 */         if (0 == this.buffer.position()) {
/* 293 */           if (!paramXio.creator.isKeepOutputBuffer())
/* 294 */             this.buffer = null;
/* 295 */           paramXio.interestOps(4, 0);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Input extends Filter.List
/*     */     implements Filter.Iterator
/*     */   {
/*     */     private int index;
/*     */     private ByteBuffer buffer;
/*     */ 
/*     */     public void doFilterNextOf(Filter paramFilter, ByteBuffer paramByteBuffer, Xio paramXio)
/*     */     {
/* 161 */       if (raw().get(this.index) != paramFilter)
/* 162 */         throw new IllegalStateException();
/* 163 */       ((Filter)raw().get(++this.index)).doFilter(this, paramByteBuffer, paramXio);
/*     */     }
/*     */ 
/*     */     public void doInput(ByteBuffer paramByteBuffer, Xio paramXio)
/*     */     {
/* 168 */       this.index = 0;
/* 169 */       ((Filter)raw().get(this.index)).doFilter(this, paramByteBuffer, paramXio);
/*     */     }
/*     */ 
/*     */     public int getBufferSize() {
/* 173 */       synchronized (this) {
/* 174 */         return null == this.buffer ? 0 : this.buffer.position();
/*     */       }
/*     */     }
/*     */ 
/*     */     public int getBufferCapacity() {
/* 179 */       synchronized (this) {
/* 180 */         return null == this.buffer ? 0 : this.buffer.limit();
/*     */       }
/*     */     }
/*     */ 
/*     */     private int doRead(Xio paramXio) throws IOException {
/* 185 */       synchronized (this) {
/* 186 */         if (null == this.buffer)
/* 187 */           this.buffer = ByteBuffer.allocate(paramXio.creator.getInputBufferSize());
/* 188 */         int i = paramXio.getSocketChannel().read(this.buffer);
/* 189 */         if (i > 0) {
/* 190 */           this.buffer.flip();
/* 191 */           doInput(this.buffer, paramXio);
/* 192 */           this.buffer.compact();
/*     */         }
/*     */ 
/* 198 */         if ((null != this.buffer) && (this.buffer.remaining() == 0))
/* 199 */           throw new IOError("OutofInputBuffer " + paramXio.creator);
/* 200 */         return i;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.Xio
 * JD-Core Version:    0.6.2
 */