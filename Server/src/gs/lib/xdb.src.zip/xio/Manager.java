/*     */ package xio;
/*     */ 
/*     */ import com.goldhuman.Common.Marshal.OctetsStream;
/*     */ import java.io.Closeable;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.ReflectionException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import xdb.Executor;
/*     */ import xdb.Trace;
/*     */ 
/*     */ public abstract class Manager
/*     */   implements DynamicMBean
/*     */ {
/*     */   String name;
/*     */   int maxSize;
/*  26 */   private Map<String, Creator> creators = new HashMap();
/*     */   Coder coder;
/*     */   private XioConf conf;
/*  29 */   private AtomicLong newXioCount = new AtomicLong();
/*     */ 
/* 139 */   private int serialId = 0;
/* 140 */   private Map<Integer, Closeable> contexts = new HashMap();
/*     */ 
/*     */   public void execute(Protocol paramProtocol)
/*     */   {
/*  42 */     Executor.getInstance().execute(paramProtocol);
/*     */   }
/*     */ 
/*     */   protected abstract void removeXio(Xio paramXio, Throwable paramThrowable);
/*     */ 
/*     */   protected abstract void addXio(Xio paramXio);
/*     */ 
/*     */   public abstract int size();
/*     */ 
/*     */   public abstract Xio get();
/*     */ 
/*     */   protected void close()
/*     */   {
/*  71 */     for (Creator localCreator : this.creators.values())
/*  72 */       localCreator.close();
/*  73 */     closeAllContexts();
/*     */   }
/*     */ 
/*     */   protected Xio newXio(Creator paramCreator, SocketChannel paramSocketChannel)
/*     */   {
/*  87 */     Xio.Input localInput = new Xio.Input();
/*  88 */     Xio.Output localOutput = new Xio.Output(paramCreator);
/*  89 */     this.coder.initFilterList(localInput, localOutput);
/*  90 */     return new Xio(paramCreator, paramSocketChannel, 1, localInput, localOutput);
/*     */   }
/*     */ 
/*     */   final long incrementAndGetNewXioCount() {
/*  94 */     return this.newXioCount.incrementAndGet();
/*     */   }
/*     */ 
/*     */   final String getMBeanName() {
/*  98 */     return new StringBuilder().append("XioConf.").append(this.conf.getName()).append("/").append(getClass().getName()).append(".").append(getName()).toString();
/*     */   }
/*     */ 
/*     */   protected void onConnectAbort(Connector paramConnector, Throwable paramThrowable) {
/* 102 */     Trace.warn(new StringBuilder().append("Connect Abort: ").append(paramConnector).toString(), paramThrowable);
/*     */   }
/*     */ 
/*     */   public Coder getCoder() {
/* 106 */     return this.coder;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 110 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 115 */     return this.name;
/*     */   }
/*     */ 
/*     */   public int getMaxSize() {
/* 119 */     return this.maxSize;
/*     */   }
/*     */ 
/*     */   public Creator getCreator(InetSocketAddress paramInetSocketAddress) {
/* 123 */     for (Creator localCreator : this.creators.values())
/* 124 */       if (paramInetSocketAddress.equals(localCreator.getAddress()))
/* 125 */         return localCreator;
/* 126 */     return null;
/*     */   }
/*     */ 
/*     */   public Creator getCreator(String paramString) {
/* 130 */     return (Creator)this.creators.get(paramString);
/*     */   }
/*     */ 
/*     */   void open()
/*     */   {
/* 134 */     Creator localCreator;
/* 134 */     for (Iterator localIterator = this.creators.values().iterator(); localIterator.hasNext(); localCreator.open()) localCreator = (Creator)localIterator.next();
/*     */   }
/*     */ 
/*     */   private final void closeAllContexts()
/*     */   {
/* 143 */     synchronized (this.contexts) {
/* 144 */       for (Closeable localCloseable : this.contexts.values()) try {
/* 145 */           localCloseable.close(); } catch (Throwable localThrowable) {
/*     */         } this.contexts.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final Closeable getContext(int paramInt) {
/* 151 */     synchronized (this.contexts) {
/* 152 */       return (Closeable)this.contexts.get(Integer.valueOf(paramInt));
/*     */     }
/*     */   }
/*     */ 
/*     */   public final <T> T getContext(int paramInt, T paramT) {
/* 157 */     synchronized (this.contexts)
/*     */     {
/* 159 */       Object localObject1 = this.contexts.get(Integer.valueOf(paramInt));
/* 160 */       return localObject1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final Closeable removeContext(int paramInt) {
/* 165 */     synchronized (this.contexts) {
/* 166 */       return (Closeable)this.contexts.remove(Integer.valueOf(paramInt));
/*     */     }
/*     */   }
/*     */ 
/*     */   public final <T> T removeContext(int paramInt, T paramT) {
/* 171 */     synchronized (this.contexts)
/*     */     {
/* 173 */       Object localObject1 = this.contexts.remove(Integer.valueOf(paramInt));
/* 174 */       return localObject1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final int addContext(Closeable paramCloseable) {
/* 179 */     synchronized (this.contexts) {
/*     */       do {
/* 181 */         this.serialId += 1;
/* 182 */         if (this.serialId <= 0)
/* 183 */           this.serialId = 1; 
/*     */       }
/* 184 */       while (false != this.contexts.containsKey(Integer.valueOf(this.serialId)));
/* 185 */       this.contexts.put(Integer.valueOf(this.serialId), paramCloseable);
/* 186 */       return this.serialId;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void add(Creator paramCreator)
/*     */   {
/* 208 */     if (null != this.creators.put(paramCreator.getName(), paramCreator))
/* 209 */       throw new RuntimeException(new StringBuilder().append("Creator duplicate! ").append(paramCreator).toString());
/*     */   }
/*     */ 
/*     */   void add(Coder paramCoder) {
/* 213 */     if (null != this.coder)
/* 214 */       throw new RuntimeException("too many Coder");
/* 215 */     this.coder = paramCoder;
/*     */   }
/*     */ 
/*     */   protected void parse(Element paramElement)
/*     */     throws Exception
/*     */   {
/* 225 */     this.name = paramElement.getAttribute("name");
/* 226 */     if (this.name.isEmpty())
/* 227 */       throw new RuntimeException("Manager need a name");
/*     */     String str1;
/* 230 */     this.maxSize = ((str1 = paramElement.getAttribute("maxSize")).isEmpty() ? 0 : Integer.parseInt(str1));
/*     */ 
/* 232 */     NodeList localNodeList = paramElement.getChildNodes();
/* 233 */     for (int i = 0; i < localNodeList.getLength(); i++) {
/* 234 */       Node localNode = localNodeList.item(i);
/* 235 */       if (1 == localNode.getNodeType())
/*     */       {
/* 238 */         Element localElement = (Element)localNode;
/* 239 */         String str2 = localElement.getNodeName();
/* 240 */         if (str2.equals("Connector")) add(Connector.create(this, localElement));
/* 241 */         else if (str2.equals("Acceptor")) add(Acceptor.create(this, localElement));
/* 242 */         else if (str2.equals("Coder")) add(Coder.create(this, localElement));
/*     */         else
/* 244 */           throw new RuntimeException(new StringBuilder().append("Unkown! node=").append(str2).append(" parent=").append(paramElement.getNodeName()).append(",").append(this.name).toString()); 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/* 249 */   public final XioConf getConf() { return this.conf; }
/*     */ 
/*     */   public static Manager create(XioConf paramXioConf, Element paramElement) throws Exception
/*     */   {
/* 253 */     String str = paramElement.getAttribute("class");
/* 254 */     Manager localManager = str.isEmpty() ? new ManagerSimple() : (Manager)Class.forName(str).newInstance();
/*     */ 
/* 256 */     localManager.parse(paramElement);
/* 257 */     localManager.conf = paramXioConf;
/* 258 */     return localManager;
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String paramString)
/*     */   {
/* 268 */     if (paramString.startsWith("count."))
/* 269 */       return Long.valueOf(this.newXioCount.get());
/* 270 */     return "<- see this";
/*     */   }
/*     */ 
/*     */   public AttributeList getAttributes(String[] paramArrayOfString)
/*     */   {
/* 275 */     AttributeList localAttributeList = new AttributeList();
/* 276 */     for (int i = 0; i < paramArrayOfString.length; i++) {
/* 277 */       Object localObject = getAttribute(paramArrayOfString[i]);
/* 278 */       if (null != localObject)
/* 279 */         localAttributeList.add(new Attribute(paramArrayOfString[i], localObject));
/*     */     }
/* 281 */     return localAttributeList;
/*     */   }
/*     */ 
/*     */   public MBeanInfo getMBeanInfo()
/*     */   {
/* 286 */     MBeanAttributeInfoBuilder localMBeanAttributeInfoBuilder = new MBeanAttributeInfoBuilder();
/* 287 */     buildMBeanInfo(localMBeanAttributeInfoBuilder);
/* 288 */     return new MBeanInfo(getClass().getName(), "Manager", localMBeanAttributeInfoBuilder.toArray(), null, null, null);
/*     */   }
/*     */ 
/*     */   protected void buildMBeanInfo(MBeanAttributeInfoBuilder paramMBeanAttributeInfoBuilder)
/*     */   {
/* 312 */     for (Creator localCreator : this.creators.values()) {
/* 313 */       StringBuilder localStringBuilder = new StringBuilder();
/* 314 */       if ((localCreator instanceof Acceptor))
/* 315 */         localStringBuilder.append("acceptor.");
/* 316 */       else if ((localCreator instanceof Connector))
/* 317 */         localStringBuilder.append("connector.");
/*     */       else
/* 319 */         localStringBuilder.append("creator.");
/* 320 */       localStringBuilder.append(localCreator.getName());
/* 321 */       paramMBeanAttributeInfoBuilder.add(new MBeanAttributeInfo(localStringBuilder.toString(), "java.lang.String", "creator", true, false, false));
/*     */     }
/*     */ 
/* 324 */     paramMBeanAttributeInfoBuilder.add(new MBeanAttributeInfo("count.newXioCount", "java.lang.Long", "count of xio created", true, false, false));
/*     */   }
/*     */ 
/*     */   public Object invoke(String paramString, Object[] paramArrayOfObject, String[] paramArrayOfString)
/*     */     throws MBeanException, ReflectionException
/*     */   {
/* 331 */     return null;
/*     */   }
/*     */ 
/*     */   public void setAttribute(Attribute paramAttribute)
/*     */     throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException
/*     */   {
/*     */   }
/*     */ 
/*     */   public AttributeList setAttributes(AttributeList paramAttributeList)
/*     */   {
/* 342 */     return null;
/*     */   }
/*     */ 
/*     */   public static final class MBeanAttributeInfoBuilder
/*     */   {
/* 293 */     private Map<String, MBeanAttributeInfo> attrs = new HashMap();
/*     */ 
/*     */     public void add(MBeanAttributeInfo paramMBeanAttributeInfo) {
/* 296 */       if (this.attrs.put(paramMBeanAttributeInfo.getName(), paramMBeanAttributeInfo) != null)
/* 297 */         throw new RuntimeException("duplicate MBeanAttributeInfo. name=" + paramMBeanAttributeInfo.getName());
/*     */     }
/*     */ 
/*     */     public MBeanAttributeInfo[] toArray() {
/* 301 */       return (MBeanAttributeInfo[])this.attrs.values().toArray(new MBeanAttributeInfo[this.attrs.size()]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract class Coder
/*     */   {
/*     */     public abstract void parse(Manager paramManager, Element paramElement)
/*     */       throws Exception;
/*     */ 
/*     */     public abstract void initFilterList(Filter.List paramList1, Filter.List paramList2);
/*     */ 
/*     */     public abstract void dispatch(int paramInt, OctetsStream paramOctetsStream, Xio paramXio, Object paramObject)
/*     */       throws Exception;
/*     */ 
/*     */     public abstract void checkSend(Protocol paramProtocol, int paramInt);
/*     */ 
/*     */     static Coder create(Manager paramManager, Element paramElement)
/*     */       throws Exception
/*     */     {
/* 199 */       String str = paramElement.getAttribute("class");
/* 200 */       Coder localCoder = str.isEmpty() ? new Protocol.Coder() : (Coder)Class.forName(str).newInstance();
/*     */ 
/* 202 */       localCoder.parse(paramManager, paramElement);
/* 203 */       return localCoder;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.Manager
 * JD-Core Version:    0.6.2
 */