/*     */ package xio;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.SelectableChannel;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import xdb.ThreadHelper;
/*     */ import xdb.Trace;
/*     */ import xdb.util.MBeans.Manager;
/*     */ import xdb.util.Misc;
/*     */ 
/*     */ public final class Engine
/*     */ {
/*  16 */   private static Engine engine = new Engine();
/*     */ 
/*  18 */   private MBeans.Manager xiombeans = new MBeans.Manager();
/*     */   private volatile Impl impl;
/*  33 */   private ConcurrentMap<String, XioConf> confs = Misc.newConcurrentMap();
/*     */ 
/*     */   public static MBeans.Manager mbeans()
/*     */   {
/*  21 */     return engine.xiombeans;
/*     */   }
/*     */ 
/*     */   public static Engine getInstance() {
/*  25 */     return engine;
/*     */   }
/*     */ 
/*     */   public void register(XioConf paramXioConf)
/*     */   {
/*  41 */     if (null != this.confs.putIfAbsent(paramXioConf.getName(), paramXioConf))
/*  42 */       throw new RuntimeException("duplicate XioConf name=" + paramXioConf.getName());
/*     */   }
/*     */ 
/*     */   public static Manager getManager(String paramString1, String paramString2)
/*     */   {
/*  50 */     XioConf localXioConf = (XioConf)engine.confs.get(paramString1);
/*  51 */     if (null == localXioConf)
/*  52 */       return null;
/*  53 */     return localXioConf.getManager(paramString2);
/*     */   }
/*     */ 
/*     */   public synchronized void open()
/*     */   {
/*  62 */     if (null == this.impl) {
/*  63 */       this.impl = new Impl();
/*  64 */       this.impl.start();
/*  65 */       for (XioConf localXioConf : this.confs.values())
/*  66 */         localXioConf.open();
/*  67 */       Trace.info("xio.Engine started");
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void close() {
/*  72 */     if (null != this.impl) {
/*  73 */       for (XioConf localXioConf : this.confs.values())
/*  74 */         localXioConf.close();
/*  75 */       this.confs.clear();
/*  76 */       this.impl.close();
/*  77 */       this.impl = null;
/*  78 */       this.xiombeans.unregisterAll();
/*  79 */       Trace.info("xio.Engine stopped");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isOpen()
/*     */   {
/*  87 */     return null != engine.impl;
/*     */   }
/*     */ 
/*     */   public static void verify()
/*     */   {
/*  92 */     if (false == isOpen())
/*  93 */       throw new IllegalStateException("xio.Engine is closed.");
/*     */   }
/*     */ 
/*     */   public static void wakeup()
/*     */   {
/* 103 */     engine.impl.selector.wakeup();
/*     */   }
/*     */ 
/*     */   public static SelectionKey register(SelectableChannel paramSelectableChannel, int paramInt, Handle paramHandle)
/*     */   {
/*     */     try
/*     */     {
/* 117 */       paramSelectableChannel.configureBlocking(false);
/* 118 */       synchronized (engine.impl.registerGuard) {
/* 119 */         engine.impl.selector.wakeup();
/* 120 */         return paramSelectableChannel.register(engine.impl.selector, paramInt, paramHandle);
/*     */       }
/*     */     } catch (IOException localIOException) {
/* 123 */       throw new IllegalStateException(localIOException);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class Impl extends ThreadHelper
/*     */   {
/*     */     private Selector selector;
/* 131 */     private Object registerGuard = new Object();
/*     */ 
/*     */     Impl() {
/* 134 */       super();
/*     */       try {
/* 136 */         this.selector = Selector.open();
/*     */       } catch (IOException localIOException) {
/* 138 */         throw new IOError(localIOException);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 144 */       while (isRunning())
/*     */         try
/*     */         {
/* 147 */           synchronized (this.registerGuard) {
/*     */           }
/* 149 */           if (this.selector.select() > 0)
/*     */           {
/* 152 */             ??? = this.selector.selectedKeys();
/* 153 */             for (SelectionKey localSelectionKey : (Set)???)
/* 154 */               if (localSelectionKey.isValid())
/*     */               {
/* 156 */                 Handle localHandle = null;
/*     */                 try {
/* 158 */                   localHandle = (Handle)localSelectionKey.attachment();
/* 159 */                   localHandle.doHandle(localSelectionKey);
/*     */                 } catch (Throwable localThrowable2) {
/*     */                   try {
/* 162 */                     localSelectionKey.channel().close();
/*     */                   }
/*     */                   catch (Throwable localThrowable3) {
/*     */                   }
/*     */                   try {
/* 167 */                     if (null != localHandle)
/* 168 */                       localHandle.doException(localSelectionKey, localThrowable2);
/*     */                   }
/*     */                   catch (Throwable localThrowable4) {
/* 171 */                     Trace.error("doException " + localThrowable4, localThrowable2);
/*     */                   }
/*     */                 }
/*     */               }
/* 175 */             ((Set)???).clear();
/*     */           }
/*     */         } catch (Throwable localThrowable1) {
/* 178 */           Trace.error("xio.Engine.run", localThrowable1);
/*     */         }
/*     */     }
/*     */ 
/*     */     public synchronized void wakeup()
/*     */     {
/* 185 */       this.selector.wakeup();
/* 186 */       super.wakeup();
/*     */     }
/*     */ 
/*     */     void close() {
/* 190 */       shutdown();
/*     */       try {
/* 192 */         this.selector.close();
/*     */       } catch (Throwable localThrowable) {
/* 194 */         localThrowable.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.Engine
 * JD-Core Version:    0.6.2
 */