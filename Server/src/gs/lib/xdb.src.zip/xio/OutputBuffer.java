/*     */ package xio;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.BufferUnderflowException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.ArrayDeque;
/*     */ 
/*     */ public final class OutputBuffer
/*     */ {
/*  23 */   private int size = 0;
/*     */   private final int piece;
/*  26 */   private ArrayDeque<ByteBuffer> outputs = new ArrayDeque();
/*  27 */   private ByteBuffer tail = null;
/*  28 */   private ArrayDeque<ByteBuffer> buffers = new ArrayDeque();
/*     */ 
/*     */   public OutputBuffer() {
/*  31 */     this(1048576);
/*     */   }
/*     */ 
/*     */   public OutputBuffer(int paramInt) {
/*  35 */     this.piece = Helper.roudup(paramInt);
/*     */   }
/*     */ 
/*     */   public final OutputBuffer put(ByteBuffer paramByteBuffer)
/*     */   {
/*  46 */     this.size += paramByteBuffer.remaining();
/*  47 */     while (paramByteBuffer.remaining() > 0)
/*     */     {
/*  49 */       if (null == this.tail) {
/*  50 */         this.tail = ((ByteBuffer)this.buffers.pollFirst());
/*  51 */         if (null == this.tail) {
/*  52 */           this.tail = ByteBuffer.allocateDirect(this.piece);
/*     */         }
/*     */       }
/*  55 */       int i = this.tail.remaining() > paramByteBuffer.remaining() ? paramByteBuffer.remaining() : this.tail.remaining();
/*  56 */       if (this.tail.put((ByteBuffer)paramByteBuffer.slice().limit(i)).remaining() == 0) {
/*  57 */         this.tail.flip();
/*  58 */         this.outputs.addLast(this.tail);
/*  59 */         this.tail = null;
/*     */       }
/*  61 */       paramByteBuffer.position(paramByteBuffer.position() + i);
/*     */     }
/*  63 */     return this;
/*     */   }
/*     */ 
/*     */   public final OutputBuffer put(byte[] paramArrayOfByte) {
/*  67 */     return put(ByteBuffer.wrap(paramArrayOfByte, 0, paramArrayOfByte.length));
/*     */   }
/*     */ 
/*     */   public final OutputBuffer put(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {
/*  71 */     return put(ByteBuffer.wrap(paramArrayOfByte, paramInt1, paramInt2));
/*     */   }
/*     */ 
/*     */   public final OutputBuffer output(SocketChannel paramSocketChannel)
/*     */     throws IOException
/*     */   {
/*  81 */     if (null != this.tail)
/*     */     {
/*  96 */       this.tail.flip();
/*  97 */       this.outputs.addLast(this.tail);
/*  98 */       this.tail = null;
/*     */     }
/* 100 */     this.size = ((int)(this.size - paramSocketChannel.write((ByteBuffer[])this.outputs.toArray(new ByteBuffer[this.outputs.size()]))));
/*     */ 
/* 102 */     while ((!this.outputs.isEmpty()) && 
/* 103 */       (((ByteBuffer)this.outputs.peekFirst()).remaining() <= 0))
/*     */     {
/* 105 */       this.buffers.addLast((ByteBuffer)((ByteBuffer)this.outputs.pollFirst()).clear());
/*     */     }
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */   public final OutputBuffer get(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*     */   {
/* 118 */     Helper.checkBounds(paramInt1, paramInt2, paramArrayOfByte.length);
/* 119 */     if (this.size < paramInt2) {
/* 120 */       throw new BufferUnderflowException();
/*     */     }
/* 122 */     this.size -= paramInt2;
/* 123 */     while (paramInt2 > 0) {
/* 124 */       ByteBuffer localByteBuffer = (ByteBuffer)this.outputs.peekFirst();
/* 125 */       if (null == localByteBuffer)
/*     */         break;
/* 127 */       int i = localByteBuffer.remaining();
/* 128 */       if (i > paramInt2)
/* 129 */         i = paramInt2;
/* 130 */       if (localByteBuffer.get(paramArrayOfByte, paramInt1, i).remaining() == 0)
/*     */       {
/* 132 */         this.buffers.add((ByteBuffer)((ByteBuffer)this.outputs.pollFirst()).flip());
/* 133 */       }paramInt1 += i;
/* 134 */       paramInt2 -= i;
/*     */     }
/* 136 */     if (paramInt2 > 0)
/*     */     {
/* 138 */       this.tail.flip();
/* 139 */       this.tail.get(paramArrayOfByte, paramInt1, paramInt2);
/* 140 */       this.tail.compact();
/*     */     }
/* 142 */     return this;
/*     */   }
/*     */ 
/*     */   public final OutputBuffer get(byte[] paramArrayOfByte) {
/* 146 */     return get(paramArrayOfByte, 0, paramArrayOfByte.length);
/*     */   }
/*     */ 
/*     */   public final int size()
/*     */   {
/* 153 */     return this.size;
/*     */   }
/*     */ 
/*     */   public final int position()
/*     */   {
/* 161 */     return this.size;
/*     */   }
/*     */ 
/*     */   public final int piece()
/*     */   {
/* 168 */     return this.piece;
/*     */   }
/*     */ 
/*     */   public final int allocation()
/*     */   {
/* 175 */     int i = this.outputs.size() + this.buffers.size();
/* 176 */     if (null != this.tail)
/* 177 */       i++;
/* 178 */     return i * this.piece;
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.OutputBuffer
 * JD-Core Version:    0.6.2
 */