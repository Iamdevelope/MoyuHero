/*    */ package xio;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import xdb.Trace;
/*    */ 
/*    */ public class ManagerByCreator extends Manager
/*    */ {
/* 10 */   private Map<Creator, Xio> xios = new HashMap();
/* 11 */   private Object mutex = new Object();
/*    */ 
/*    */   protected void onXioRemoved(Xio paramXio, Throwable paramThrowable) {
/* 14 */     Trace.warn("onXioRemoved=" + paramXio, paramThrowable);
/*    */   }
/*    */ 
/*    */   protected void onXioAdded(Xio paramXio) {
/* 18 */     if (Trace.isWarnEnabled())
/* 19 */       Trace.warn("onXioAdded=" + paramXio);
/*    */   }
/*    */ 
/*    */   protected void addXio(Xio paramXio)
/*    */   {
/* 24 */     int i = 0;
/* 25 */     synchronized (this.mutex) {
/* 26 */       if (this.xios.containsKey(paramXio.getCreator())) {
/* 27 */         Trace.warn("Close(duplicate creator) in addXio " + paramXio);
/* 28 */         paramXio.close();
/*    */       } else {
/* 30 */         this.xios.put(paramXio.getCreator(), paramXio);
/* 31 */         i = 1;
/*    */       }
/*    */     }
/* 34 */     if (i != 0) try {
/* 35 */         onXioAdded(paramXio);
/*    */       } catch (Throwable localThrowable) {
/*    */       } 
/*    */   }
/*    */ 
/* 40 */   public Xio get() { synchronized (this.mutex) {
/* 41 */       return (Xio)this.xios.values().iterator().next();
/*    */     }
/*    */   }
/*    */ 
/*    */   protected void removeXio(Xio paramXio, Throwable paramThrowable)
/*    */   {
/* 47 */     int i = 0;
/* 48 */     synchronized (this.mutex) {
/* 49 */       if (this.xios.get(paramXio.getCreator()) == paramXio) {
/* 50 */         this.xios.remove(paramXio.getCreator());
/* 51 */         i = 1;
/*    */       }
/*    */     }
/* 54 */     if (i != 0) try {
/* 55 */         onXioRemoved(paramXio, paramThrowable);
/*    */       } catch (Throwable localThrowable) {
/*    */       } 
/*    */   }
/*    */ 
/* 60 */   public int size() { synchronized (this.mutex) {
/* 61 */       return this.xios.size();
/*    */     }
/*    */   }
/*    */ 
/*    */   protected void close()
/*    */   {
/* 67 */     super.close();
/*    */     Map localMap;
/* 69 */     synchronized (this.mutex) {
/* 70 */       localMap = this.xios;
/* 71 */       this.xios = new HashMap();
/*    */     }
/* 73 */     for (??? = localMap.values().iterator(); ((Iterator)???).hasNext(); ) { Xio localXio = (Xio)((Iterator)???).next();
/* 74 */       localXio.close(); }
/*    */   }
/*    */ 
/*    */   public Xio get(Creator paramCreator) {
/* 78 */     synchronized (this.mutex) {
/* 79 */       return (Xio)this.xios.get(paramCreator);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.ManagerByCreator
 * JD-Core Version:    0.6.2
 */