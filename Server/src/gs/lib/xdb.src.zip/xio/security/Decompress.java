/*    */ package xio.security;
/*    */ 
/*    */ import com.goldhuman.Common.Octets;
/*    */ 
/*    */ public class Decompress extends Security
/*    */ {
/*    */   private long handle;
/*    */ 
/*    */   public Decompress()
/*    */   {
/* 13 */     this.handle = open_decompress();
/*    */   }
/*    */ 
/*    */   public Octets doUpdate(Octets paramOctets)
/*    */   {
/* 18 */     byte[] arrayOfByte = decompress_update(this.handle, paramOctets.getBytes(), paramOctets.size());
/* 19 */     paramOctets.replace(arrayOfByte);
/* 20 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   protected void finalize()
/*    */     throws Throwable
/*    */   {
/* 26 */     super.finalize();
/* 27 */     close_decompress(this.handle);
/*    */   }
/*    */ 
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 35 */       return new Decompress();
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/* 39 */       localException.printStackTrace();
/*    */     }
/* 41 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.security.Decompress
 * JD-Core Version:    0.6.2
 */