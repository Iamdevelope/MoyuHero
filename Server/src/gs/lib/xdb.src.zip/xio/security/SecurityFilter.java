/*     */ package xio.security;
/*     */ 
/*     */ import com.goldhuman.Common.Octets;
/*     */ import java.nio.ByteBuffer;
/*     */ import xio.Filter;
/*     */ import xio.Filter.Iterator;
/*     */ import xio.Xio;
/*     */ import xio.Xio.Input;
/*     */ import xio.Xio.Output;
/*     */ 
/*     */ public class SecurityFilter extends Filter
/*     */ {
/*     */   private Security _sec;
/*     */ 
/*     */   public static void setXioOutputSecurity(Xio paramXio, Security paramSecurity, Octets paramOctets)
/*     */   {
/*  27 */     if (paramXio.getOutput().get("OutputSecurity") != null)
/*     */     {
/*  29 */       paramXio.getOutput().remove("OutputSecurity");
/*     */     }
/*     */ 
/*  32 */     paramXio.getOutput().addLast(new SecurityFilter("OutputSecurity", paramSecurity, paramOctets));
/*     */   }
/*     */ 
/*     */   public static void setXioInputSecurity(Xio paramXio, Security paramSecurity, Octets paramOctets)
/*     */   {
/*  47 */     if (paramXio.getInput().get("InputSecurity") != null)
/*     */     {
/*  49 */       paramXio.getInput().remove("InputSecurity");
/*     */     }
/*     */ 
/*  52 */     paramXio.getInput().addFirst(new SecurityFilter("InputSecurity", paramSecurity, paramOctets));
/*     */   }
/*     */ 
/*     */   public SecurityFilter(String paramString, Security paramSecurity, Octets paramOctets)
/*     */   {
/*  61 */     super(paramString);
/*  62 */     this._sec = paramSecurity;
/*  63 */     this._sec.setParameter(paramOctets);
/*     */   }
/*     */ 
/*     */   public synchronized void setSecurity(Security paramSecurity, Octets paramOctets)
/*     */   {
/*  68 */     this._sec = paramSecurity;
/*  69 */     this._sec.setParameter(paramOctets);
/*     */   }
/*     */ 
/*     */   protected void doFilter(Filter.Iterator paramIterator, ByteBuffer paramByteBuffer, Xio paramXio)
/*     */   {
/* 101 */     Octets localOctets = new Octets(paramByteBuffer.array(), paramByteBuffer.position(), paramByteBuffer.remaining());
/* 102 */     this._sec.doUpdate(localOctets);
/*     */ 
/* 108 */     ByteBuffer localByteBuffer = ByteBuffer.wrap(localOctets.array(), 0, localOctets.size());
/* 109 */     paramIterator.doFilterNextOf(this, localByteBuffer, paramXio);
/*     */ 
/* 111 */     paramByteBuffer.position(paramByteBuffer.limit());
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.security.SecurityFilter
 * JD-Core Version:    0.6.2
 */