/*    */ package xio.security;
/*    */ 
/*    */ import com.goldhuman.Common.Octets;
/*    */ 
/*    */ public final class Random extends Security
/*    */ {
/*  8 */   private static java.util.Random nonce = new java.util.Random();
/*    */ 
/*    */   public Octets doUpdate(Octets paramOctets)
/*    */   {
/* 22 */     nonce.nextBytes(paramOctets.array());
/* 23 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 12 */     nonce.setSeed(System.currentTimeMillis());
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.security.Random
 * JD-Core Version:    0.6.2
 */