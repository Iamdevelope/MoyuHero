/*    */ package xio.security;
/*    */ 
/*    */ import com.goldhuman.Common.Octets;
/*    */ 
/*    */ public final class ARCFourSecurity extends Security
/*    */ {
/*  7 */   private byte[] perm = new byte[256];
/*    */   private byte index1;
/*    */   private byte index2;
/*    */ 
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 20 */       ARCFourSecurity localARCFourSecurity = (ARCFourSecurity)super.clone();
/* 21 */       localARCFourSecurity.perm = new byte[256];
/* 22 */       System.arraycopy(this.perm, 0, localARCFourSecurity.perm, 0, 256);
/* 23 */       return localARCFourSecurity;
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/* 27 */       localException.printStackTrace();
/*    */     }
/* 29 */     return null;
/*    */   }
/*    */ 
/*    */   public void setParameter(Octets paramOctets)
/*    */   {
/* 34 */     int i = paramOctets.size();
/* 35 */     int j = 0;
/* 36 */     for (int k = 0; k < 256; k++)
/*    */     {
/* 38 */       this.perm[k] = ((byte)k);
/*    */     }
/* 40 */     for (k = 0; k < 256; k++)
/*    */     {
/* 42 */       j = (byte)(j + (this.perm[k] + paramOctets.getByte(k % i)));
/* 43 */       int m = this.perm[k]; this.perm[k] = this.perm[(j & 0xFF)]; this.perm[(j & 0xFF)] = m;
/*    */     }
/* 45 */     this.index1 = 0;
/* 46 */     this.index2 = 0;
/*    */   }
/*    */ 
/*    */   public Octets doUpdate(Octets paramOctets)
/*    */   {
/* 51 */     int i = paramOctets.size();
/* 52 */     for (int j = 0; j < i; j++)
/*    */     {
/*    */       ARCFourSecurity tmp22_21 = this; this.index2 = ((byte)(this.index2 + this.perm[((tmp22_21.index1 = (byte)(tmp22_21.index1 + 1)) & 0xFF)]));
/* 55 */       int k = this.perm[(this.index1 & 0xFF)]; this.perm[(this.index1 & 0xFF)] = this.perm[(this.index2 & 0xFF)]; this.perm[(this.index2 & 0xFF)] = k;
/* 56 */       int m = (byte)(this.perm[(this.index1 & 0xFF)] + this.perm[(this.index2 & 0xFF)]);
/* 57 */       paramOctets.setByte(j, (byte)(paramOctets.getByte(j) ^ this.perm[(m & 0xFF)]));
/*    */     }
/* 59 */     return paramOctets;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.security.ARCFourSecurity
 * JD-Core Version:    0.6.2
 */