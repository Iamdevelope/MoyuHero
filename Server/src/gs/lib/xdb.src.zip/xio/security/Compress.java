/*    */ package xio.security;
/*    */ 
/*    */ import com.goldhuman.Common.Octets;
/*    */ 
/*    */ public class Compress extends Security
/*    */ {
/*    */   private long handle;
/*    */ 
/*    */   public Compress()
/*    */   {
/* 11 */     this.handle = open_compress();
/*    */   }
/*    */ 
/*    */   public Octets doUpdate(Octets paramOctets)
/*    */   {
/* 16 */     byte[] arrayOfByte = compress_update(this.handle, paramOctets.getBytes(), paramOctets.size());
/* 17 */     paramOctets.replace(arrayOfByte);
/*    */ 
/* 19 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   public Octets doFinal(Octets paramOctets)
/*    */   {
/* 24 */     byte[] arrayOfByte = compress_final(this.handle, paramOctets.getBytes(), paramOctets.size());
/* 25 */     paramOctets.replace(arrayOfByte);
/* 26 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   protected void finalize()
/*    */     throws Throwable
/*    */   {
/* 32 */     super.finalize();
/* 33 */     close_compress(this.handle);
/*    */   }
/*    */ 
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 40 */       return new Compress();
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/* 44 */       localException.printStackTrace();
/*    */     }
/* 46 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.security.Compress
 * JD-Core Version:    0.6.2
 */