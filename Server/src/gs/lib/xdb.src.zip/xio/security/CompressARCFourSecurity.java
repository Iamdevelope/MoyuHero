/*    */ package xio.security;
/*    */ 
/*    */ import com.goldhuman.Common.Octets;
/*    */ 
/*    */ public class CompressARCFourSecurity extends Security
/*    */ {
/*    */   private ARCFourSecurity arc4;
/*    */   private Compress compress;
/*    */ 
/*    */   public CompressARCFourSecurity()
/*    */   {
/* 13 */     this.arc4 = new ARCFourSecurity();
/*    */ 
/* 15 */     this.compress = new Compress();
/*    */   }
/*    */ 
/*    */   public void setParameter(Octets paramOctets)
/*    */   {
/* 21 */     this.arc4.setParameter(paramOctets);
/*    */   }
/*    */ 
/*    */   public Octets doUpdate(Octets paramOctets)
/*    */   {
/* 26 */     this.arc4.doUpdate(this.compress.doFinal(paramOctets));
/* 27 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   public Octets doFinal(Octets paramOctets)
/*    */   {
/* 32 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 39 */       CompressARCFourSecurity localCompressARCFourSecurity = (CompressARCFourSecurity)super.clone();
/* 40 */       localCompressARCFourSecurity.arc4 = ((ARCFourSecurity)this.arc4.clone());
/* 41 */       localCompressARCFourSecurity.compress = ((Compress)this.compress.clone());
/* 42 */       return localCompressARCFourSecurity;
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/* 46 */       localException.printStackTrace();
/*    */     }
/* 48 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.security.CompressARCFourSecurity
 * JD-Core Version:    0.6.2
 */