/*    */ package xio.security;
/*    */ 
/*    */ import com.goldhuman.Common.Octets;
/*    */ 
/*    */ public class DecompressARCFourSecurity extends Security
/*    */ {
/*    */   private ARCFourSecurity arc4;
/*    */   private Decompress decompress;
/*    */ 
/*    */   public DecompressARCFourSecurity()
/*    */   {
/* 13 */     this.arc4 = new ARCFourSecurity();
/* 14 */     this.decompress = new Decompress();
/*    */   }
/*    */ 
/*    */   public void setParameter(Octets paramOctets)
/*    */   {
/* 19 */     this.arc4.setParameter(paramOctets);
/*    */   }
/*    */ 
/*    */   public Octets doUpdate(Octets paramOctets)
/*    */   {
/* 24 */     this.decompress.doUpdate(this.arc4.doUpdate(paramOctets));
/* 25 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   public Octets doFinal(Octets paramOctets)
/*    */   {
/* 30 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 37 */       DecompressARCFourSecurity localDecompressARCFourSecurity = (DecompressARCFourSecurity)super.clone();
/* 38 */       localDecompressARCFourSecurity.arc4 = ((ARCFourSecurity)this.arc4.clone());
/* 39 */       localDecompressARCFourSecurity.decompress = ((Decompress)this.decompress.clone());
/* 40 */       return localDecompressARCFourSecurity;
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/* 44 */       localException.printStackTrace();
/*    */     }
/* 46 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.security.DecompressARCFourSecurity
 * JD-Core Version:    0.6.2
 */