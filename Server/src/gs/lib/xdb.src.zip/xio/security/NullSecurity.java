package xio.security;

public final class NullSecurity extends Security
{
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.security.NullSecurity
 * JD-Core Version:    0.6.2
 */