/*    */ package xio.security;
/*    */ 
/*    */ import com.goldhuman.Common.Octets;
/*    */ 
/*    */ public final class HmacMd5Hash extends Security
/*    */ {
/*  7 */   private Octets k_opad = new Octets(64);
/*  8 */   private MD5Hash md5hash = new MD5Hash();
/*    */ 
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 19 */       HmacMd5Hash localHmacMd5Hash = (HmacMd5Hash)super.clone();
/* 20 */       localHmacMd5Hash.k_opad = ((Octets)this.k_opad.clone());
/* 21 */       localHmacMd5Hash.k_opad.reserve(64);
/* 22 */       localHmacMd5Hash.md5hash = ((MD5Hash)this.md5hash.clone());
/* 23 */       return localHmacMd5Hash;
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/* 27 */       localException.printStackTrace();
/*    */     }
/* 29 */     return null;
/*    */   }
/*    */ 
/*    */   public void setParameter(Octets paramOctets)
/*    */   {
/* 34 */     Octets localOctets1 = new Octets(64);
/*    */ 
/* 36 */     int i = paramOctets.size();
/* 37 */     if (i > 64)
/*    */     {
/* 39 */       Octets localOctets2 = MD5Hash.doDigest(paramOctets);
/* 40 */       localOctets1.replace(localOctets2);
/* 41 */       this.k_opad.replace(localOctets2);
/* 42 */       i = localOctets2.size();
/*    */     }
/*    */     else
/*    */     {
/* 46 */       localOctets1.replace(paramOctets);
/* 47 */       this.k_opad.replace(paramOctets);
/*    */     }
/* 49 */     for (int j = 0; 
/* 50 */       j < i; j++)
/*    */     {
/* 52 */       localOctets1.setByte(j, (byte)(localOctets1.getByte(j) ^ 0x36));
/* 53 */       this.k_opad.setByte(j, (byte)(this.k_opad.getByte(j) ^ 0x5C));
/*    */     }
/* 55 */     for (; j < 64; j++)
/*    */     {
/* 57 */       localOctets1.setByte(j, (byte)54);
/* 58 */       this.k_opad.setByte(j, (byte)92);
/*    */     }
/* 60 */     localOctets1.resize(64);
/* 61 */     this.k_opad.resize(64);
/* 62 */     this.md5hash.doUpdate(localOctets1);
/*    */   }
/*    */ 
/*    */   public Octets doUpdate(Octets paramOctets)
/*    */   {
/* 67 */     this.md5hash.doUpdate(paramOctets);
/* 68 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   public Octets doFinal(Octets paramOctets)
/*    */   {
/* 73 */     this.md5hash.doFinal(paramOctets);
/* 74 */     MD5Hash localMD5Hash = new MD5Hash();
/* 75 */     localMD5Hash.doUpdate(this.k_opad);
/* 76 */     localMD5Hash.doUpdate(paramOctets);
/* 77 */     return localMD5Hash.doFinal(paramOctets);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.security.HmacMd5Hash
 * JD-Core Version:    0.6.2
 */