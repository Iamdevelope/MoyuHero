/*    */ package xio.security;
/*    */ 
/*    */ import com.goldhuman.Common.Octets;
/*    */ import java.security.MessageDigest;
/*    */ 
/*    */ public final class MD5Hash extends Security
/*    */ {
/*  9 */   private MessageDigest md5 = null;
/*    */ 
/*    */   public MD5Hash()
/*    */   {
/*    */     try
/*    */     {
/* 15 */       this.md5 = MessageDigest.getInstance("MD5");
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/* 19 */       localException.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 27 */       MD5Hash localMD5Hash = (MD5Hash)super.clone();
/* 28 */       localMD5Hash.md5 = ((MessageDigest)this.md5.clone());
/* 29 */       return localMD5Hash;
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/* 33 */       localException.printStackTrace();
/*    */     }
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */   public Octets doUpdate(Octets paramOctets)
/*    */   {
/* 40 */     if (this.md5 != null)
/*    */     {
/* 42 */       this.md5.update(paramOctets.array(), 0, paramOctets.size());
/*    */     }
/* 44 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   public Octets doFinal(Octets paramOctets)
/*    */   {
/* 49 */     if (this.md5 != null)
/*    */     {
/* 51 */       paramOctets.replace(this.md5.digest());
/*    */     }
/* 53 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   public static Octets doDigest(Octets paramOctets)
/*    */   {
/*    */     try
/*    */     {
/* 60 */       return new Octets(MessageDigest.getInstance("MD5").digest(paramOctets.getBytes()));
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/* 64 */       localException.printStackTrace();
/*    */     }
/* 66 */     return new Octets();
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.security.MD5Hash
 * JD-Core Version:    0.6.2
 */