/*    */ package xio.security;
/*    */ 
/*    */ import com.goldhuman.Common.Octets;
/*    */ 
/*    */ public abstract class Security
/*    */   implements Cloneable
/*    */ {
/*    */   public static final int RAMDOM = 0;
/*    */   public static final int NULLSECURITY = 1;
/*    */   public static final int ARCFOURSECURITY = 2;
/*    */   public static final int MD5HASH = 3;
/*    */   public static final int HMAC_MD5HASH = 4;
/*    */   public static final int COMPRESSARCFOURSECURITY = 5;
/*    */   public static final int DECOMPRESSFOURSECURITY = 6;
/*    */   public static final int SHA1HASH = 7;
/*    */ 
/*    */   public void setParameter(Octets paramOctets)
/*    */   {
/*    */   }
/*    */ 
/*    */   public Octets doUpdate(Octets paramOctets)
/*    */   {
/* 14 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   public Octets doFinal(Octets paramOctets) {
/* 18 */     return paramOctets;
/*    */   }
/*    */ 
/*    */   public Object clone()
/*    */   {
/*    */     try
/*    */     {
/* 25 */       return super.clone();
/*    */     }
/*    */     catch (Exception localException)
/*    */     {
/* 29 */       localException.printStackTrace();
/*    */     }
/* 31 */     return null;
/*    */   }
/*    */ 
/*    */   protected native long open_compress();
/*    */ 
/*    */   protected native byte[] compress_update(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*    */ 
/*    */   protected native byte[] compress_final(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*    */ 
/*    */   protected native void close_compress(long paramLong);
/*    */ 
/*    */   protected native long open_decompress();
/*    */ 
/*    */   protected native byte[] decompress_update(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*    */ 
/*    */   protected native void close_decompress(long paramLong);
/*    */ 
/*    */   public static native long open_security(int paramInt);
/*    */ 
/*    */   public static native void security_set_parameter(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*    */ 
/*    */   public static native byte[] security_update(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*    */ 
/*    */   public static native byte[] security_final(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*    */ 
/*    */   public static native void close_security(long paramLong);
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.security.Security
 * JD-Core Version:    0.6.2
 */