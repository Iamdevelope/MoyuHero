/*    */ package xio;
/*    */ 
/*    */ public class IOError extends Error
/*    */ {
/*    */   static final long serialVersionUID = -4675579273322106473L;
/*    */ 
/*    */   public IOError(Throwable paramThrowable)
/*    */   {
/*  7 */     super(paramThrowable);
/*    */   }
/*    */ 
/*    */   public IOError(String paramString) {
/* 11 */     super(paramString);
/*    */   }
/*    */ 
/*    */   public IOError(String paramString, Throwable paramThrowable) {
/* 15 */     super(paramString, paramThrowable);
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.IOError
 * JD-Core Version:    0.6.2
 */