/*    */ package xio;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import xdb.Trace;
/*    */ 
/*    */ public class ManagerSimple extends Manager
/*    */ {
/* 14 */   private Set<Xio> xios = new HashSet();
/* 15 */   private Object mutex = new Object();
/*    */ 
/*    */   protected void onXioRemoved(Xio paramXio, Throwable paramThrowable) {
/* 18 */     Trace.warn("onXioRemoved=" + paramXio, paramThrowable);
/*    */   }
/*    */ 
/*    */   protected void onXioAdded(Xio paramXio) {
/* 22 */     if (Trace.isWarnEnabled())
/* 23 */       Trace.warn("onXioAdded=" + paramXio);
/*    */   }
/*    */ 
/*    */   protected void removeXio(Xio paramXio, Throwable paramThrowable)
/*    */   {
/* 28 */     boolean bool = false;
/* 29 */     synchronized (this.mutex) {
/* 30 */       bool = this.xios.remove(paramXio);
/*    */     }
/* 32 */     if (bool) try {
/* 33 */         onXioRemoved(paramXio, paramThrowable);
/*    */       } catch (Throwable localThrowable) {
/*    */       } 
/*    */   }
/*    */ 
/* 38 */   protected void addXio(Xio paramXio) { int i = 0;
/* 39 */     if (Engine.isOpen()) {
/* 40 */       synchronized (this.mutex) {
/* 41 */         i = ((super.getMaxSize() <= 0) || (this.xios.size() < super.getMaxSize())) && (this.xios.add(paramXio)) ? 1 : 0;
/*    */       }
/*    */     }
/* 44 */     if (i != 0) {
/*    */       try { onXioAdded(paramXio); } catch (Throwable localThrowable) {
/*    */       }
/*    */     } else { Trace.warn("Close in addXio " + paramXio + " size=" + size() + "/" + getMaxSize());
/* 48 */       paramXio.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   protected void close()
/*    */   {
/* 54 */     super.close();
/*    */     Set localSet;
/* 58 */     synchronized (this.mutex) {
/* 59 */       localSet = this.xios;
/* 60 */       this.xios = new HashSet();
/*    */     }
/* 62 */     for (??? = localSet.iterator(); ((Iterator)???).hasNext(); ) { Xio localXio = (Xio)((Iterator)???).next();
/* 63 */       localXio.close(); }
/*    */   }
/*    */ 
/*    */   public int size()
/*    */   {
/* 68 */     synchronized (this.mutex) {
/* 69 */       return this.xios.size();
/*    */     }
/*    */   }
/*    */ 
/*    */   public Xio get()
/*    */   {
/* 75 */     synchronized (this.mutex) {
/* 76 */       if (this.xios.isEmpty())
/* 77 */         return null;
/* 78 */       return (Xio)this.xios.iterator().next();
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.ManagerSimple
 * JD-Core Version:    0.6.2
 */