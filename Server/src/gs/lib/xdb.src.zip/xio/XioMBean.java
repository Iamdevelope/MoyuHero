package xio;

public abstract interface XioMBean
{
  public abstract String getInterestOps();

  public abstract String getCreatorInfo();

  public abstract String getPeerInfo();

  public abstract int getInputBufferSize();

  public abstract int getInputBufferCapacity();

  public abstract int getOutputBufferSize();

  public abstract int getOutputBufferCapacity();

  public abstract int getOutputBufferAllocation();
}

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.XioMBean
 * JD-Core Version:    0.6.2
 */