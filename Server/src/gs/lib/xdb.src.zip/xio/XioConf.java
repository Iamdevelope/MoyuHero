/*     */ package xio;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import xdb.util.MBeans.Manager;
/*     */ 
/*     */ public class XioConf
/*     */ {
/*     */   private String name;
/*  18 */   private Map<String, Manager> managers = new HashMap();
/*     */ 
/*     */   public String getName() {
/*  21 */     return this.name;
/*     */   }
/*     */ 
/*     */   public Manager getManager(String paramString) {
/*  25 */     return (Manager)this.managers.get(paramString);
/*     */   }
/*     */ 
/*     */   void open() {
/*  29 */     for (Manager localManager : this.managers.values()) {
/*  30 */       localManager.open();
/*     */ 
/*  32 */       Engine.mbeans().register(localManager, "xio:type=" + localManager.getMBeanName());
/*     */     }
/*     */   }
/*     */ 
/*     */   void close() {
/*  37 */     for (Manager localManager : this.managers.values())
/*  38 */       localManager.close();
/*     */   }
/*     */ 
/*     */   private void add(Manager paramManager)
/*     */   {
/*  43 */     if (null != this.managers.put(paramManager.getName(), paramManager))
/*  44 */       throw new RuntimeException("Manager duplicate : " + paramManager);
/*     */   }
/*     */ 
/*     */   public XioConf(Element paramElement) throws Exception {
/*  48 */     if (false == paramElement.getNodeName().equals("XioConf")) {
/*  49 */       throw new IllegalArgumentException(paramElement.getNodeName() + " is not a XioConf.");
/*     */     }
/*  51 */     this.name = paramElement.getAttribute("name");
/*     */ 
/*  53 */     NodeList localNodeList = paramElement.getChildNodes();
/*  54 */     for (int i = 0; i < localNodeList.getLength(); i++) {
/*  55 */       Node localNode = localNodeList.item(i);
/*  56 */       if (1 == localNode.getNodeType())
/*     */       {
/*  59 */         Element localElement = (Element)localNode;
/*  60 */         String str = localElement.getNodeName();
/*  61 */         if (str.equals("Manager")) add(Manager.create(this, localElement));
/*     */         else
/*  63 */           throw new RuntimeException("Unkown! node=" + str + " parent=" + paramElement.getNodeName());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static XioConf loadInChildNodes(Element paramElement)
/*     */     throws Exception
/*     */   {
/*  75 */     NodeList localNodeList = paramElement.getChildNodes();
/*  76 */     for (int i = 0; i < localNodeList.getLength(); i++) {
/*  77 */       Node localNode = localNodeList.item(i);
/*  78 */       if (1 == localNode.getNodeType())
/*     */       {
/*  81 */         Element localElement = (Element)localNode;
/*  82 */         String str = localElement.getNodeName();
/*  83 */         if (str.equals("XioConf"))
/*  84 */           return new XioConf(localElement);
/*     */       }
/*     */     }
/*  87 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   public static void loadAndRegister(String paramString)
/*     */     throws Exception
/*     */   {
/*  96 */     Document localDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(paramString);
/*  97 */     Engine.getInstance().register(new XioConf(localDocument.getDocumentElement()));
/*     */   }
/*     */ 
/*     */   public static void loadAndRegister(Element paramElement)
/*     */     throws Exception
/*     */   {
/* 106 */     Engine.getInstance().register(new XioConf(paramElement));
/*     */   }
/*     */ 
/*     */   public static void loadAndRegisterInChildNodes(Element paramElement)
/*     */     throws Exception
/*     */   {
/* 120 */     Engine.getInstance().register(loadInChildNodes(paramElement));
/*     */   }
/*     */ }

/* Location:           E:\gameserver\Server\src\gs\lib\xdb.jar
 * Qualified Name:     xio.XioConf
 * JD-Core Version:    0.6.2
 */